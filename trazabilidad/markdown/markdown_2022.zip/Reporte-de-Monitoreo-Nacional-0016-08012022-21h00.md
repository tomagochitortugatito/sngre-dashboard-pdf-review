Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016
Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 1 de 13 

Periodo de Monitoreo: 

Desde: 09h00 08/01/2022 

Hasta: 21h00 08/01/2022 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/b10a6312e3fcc8a37719b373d75593e931d54304667d6930313fe8698ec8fb68.jpg)


- Amenaza dentro de los parámetros normales. 

## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>05H48 Emisión continua de vapor y gases a una altura igual a 1000 metros sobre el nivel del cráter en dirección Norte-Oeste</td><td>AMARILLO</td></tr><tr><td></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>07h00 Sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td></td><td>Volcán Cotopaxl</td><td>SIN ALERTA</td><td>07h00 Sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td rowspan="2"><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/c14457f8960b0c1b1d00cb0a1113b8dafcecee3ee355ae45b5f4a128660202e3.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>07h00 Sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>07h00 Sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/3d617873298929646a1345c8ba2efd9140728ae13910c18c389ec11e61d0969a.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>06h00 Emisión de ceniza observada en satélites y reportada por la VAAC con una altura de la nube igual a 870 metros sobre el nivel del cráter en dirección Oeste</td><td>AMARILLO</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/1bfd0cb2fcc3b0118049966e9b32be44acffda764f1dd21bb1bb700cbe32e8dd.jpg"/></td><td>Volcán Wolf, Galápagos</td><td></td><td>11h00 IGEPN informa erupción con una altura de la nube igual a 1300 metros sobre el nivel del cráter en dirección Oeste. Se mantiene monitoreo constante</td><td>AMARILLO</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/8706bbaa587242d1d18daba0f1041937d22ab4932ec81650a758105f344d980c.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">00 río desbordado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="5">00 ríos con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/55609f4cbce16e1ed0e4692eb1f33c719f9ac17677037cc5f726745510f5904e.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">02 incendio activo</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>Tungurahua</td><td>Ambato</td><td>Quisapincha</td><td>Casahuala</td><td>5 Ha</td></tr></table>

<table><tr><td colspan="5">OO Incendlos--- controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/af95ae2412afe365dec864680e5b05773ceecf2e59eb2381d657ae58f5f5dad6.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td>---</td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td>---</td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>70.72</td><td>85.00</td><td>03:03</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>115.72</td><td>117.00</td><td>01:00</td><td>VERDE</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td>---</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>---</td><td>106.50</td><td>---</td><td>---</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td>---</td></tr></table>

Historico del Ambiente, Agos y Transiación Estelligas Instituto Nacional de Meteorología e Hidrología 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 2 de 13

<table><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td>---</td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td>---</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/26388c2e6113e8a1bd31a9bec9155a0114b2c2e96e56b13b6ec38547d4b4ad90.jpg)


## SITUACIÓN HIDROMETEOROLÓGICA


Sábado, 08 de enero de 2022


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/5583a2ddbfd30f1a4c3d7c8d6fde071c8b56095918c8f4d8b072cf8dbdea192f.jpg)


## Pronostico Regional Para Ecuador (Válido para el 08/Ene/2022)

Región Insular: Parcial nublado con disminución ocasional de la nubosidad. 

Región Litoral: Nublado con claros, lluvias y lloviznas dispersas principalmente al norte y centro de la región. 

Región Sierra: Parcial nublado variando a nublado, lluvias dispersas. 

Reglón Amazonía: Nublado con disminución paulatina de la nubosidad, lluvias y lloviznas dispersas en estribación de cordillera y sur de la región. 

## FUENTE: INAMHI

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/2af43709d3b2e11d8f5c0b033346932c460190b3cd204eaf5705564c2b2dd157.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/87ce6145098c6875b5477a1447eb343c868614b629bf5d7cb23da7128ee61e75.jpg)



Actividad volcánica


<table><tr><td>Localización:</td><td>Galápagos/Isabela / Tomas de Berlanga / Norte de la Isla.</td></tr><tr><td>Antecedentes:</td><td>Según reporte del IG. a las 23h20 del 06/01/2022 erupciona el Volcán Wolf,el mismo que se encuentra al norte de la Isla Isabela. No existen poblaciones cercanas al volcán.</td></tr><tr><td>Situación actual:</td><td>Instituto Geofísico, indica que de acuerdo a lo solicitado por el COEGalápagos, emitirá informes diarios del volcán Wolf, mientras dure su actividad</td></tr><tr><td>Afectaciones:</td><td>Hasta el momento sin afectaciones.</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE- Unidad de Monitoreo / Respuesta</td></tr><tr><td>Fuentes de información:</td><td>SNGRE - Unidad de Monitoreo Y RESPUESTA.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/c4e4a63e713f4b7405b4725a62c9c31c6a9f97b5ef50c7faee233c2f20e78f71.jpg)



Aluvión


<table><tr><td>Localización:</td><td>Zona 7/Loja/Loja/Taquil/Naranjito, vía a La Guangora</td></tr><tr><td>Antecedentes:</td><td>EL 23/12/2021, por lluvias se produjo el desbordamiento de una quebrada que provocó el arrastre de material pétreo y flujos de lodo. Como consecuencia del aumento de caudal, personas que transitaban por el sector fueron arrastradas.</td></tr><tr><td>Situación actual:</td><td>La vía de segundo orden se encuentra habilitada, adicional las labores de búsqueda de la persona desaparecida se mantienen.</td></tr><tr><td>Afectaciones:</td><td>3 personas fallecidas.1 persona desaparecida.30 metros lineales aproximadamente.</td></tr><tr><td>Acciones de respuesta:</td><td>Personal de Cuerpo de Bomberos de Loja y Chantaco en colaboración con comuneros del sector, continúan con las tareas de búsqueda de la persona desaparecida.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/ Cuerpo de Bomberos Loja</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/2e56a224235374f8b2afa6cf4bcf682bcd3573e122d3c6da1e633cf50a6f1e0a.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>Zona 1/Imbabura/Ibarra/Carolina/San Jerónimo; vía Salinas - Lita [E 10]</td></tr><tr><td>Antecedentes:</td><td>El 22/12/2021 en horas de la madrugada, producto de las fuertes precipitaciones se registró un deslizamiento que afectó la vía de primer orden y represó el río Mira.</td></tr><tr><td>Situación actual:</td><td>Las Instituciones continúan realizando los trabajos de limpieza de la vía.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 3 de 13

<table><tr><td>Afectaciones:</td><td>125 metros lineales.2 postes de hormigón de telecomunicaciones.Colapso de la mesa de la vía en un tramo de 50 metros.40 vehículos (Ya fueron evacuados del sector).1 persona fallecida.</td></tr><tr><td>Acciones de respuesta:</td><td>Comuneros del sector construyeron una tarabita para transportar, motocicletas y toda clase de productos de montaña a montaña</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/GAD Cantonal Ibarra, MTOP.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/6d557f7cb6e8e85155f1b1c236c1b0d6ac77458a9aa7daadbef27ff033e550fb.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Zona 7/El Oro/Zaruma/Zaruma/calles Colón y 10 de Agosto</td></tr><tr><td>Antecedentes:</td><td>El 15/12/2021, se produjo un hundimiento que afectó a varias viviendas</td></tr><tr><td>Situación actual:</td><td>El 15/12/2021, el Municipio de Zaruma emitió la Declaratoria de Emergencia N° 002-2021- COE-ZARUMA, específicamente para el perímetro de las calles Colón, 29 de Noviembre, 10 de Agosto, Ernesto A. Castro, 09 de Octubre e Independencia.Presidente de la República del Ecuador, Director del SNGRE y demás autoridades nacionales se reunieron donde se emitió el decreto 316 en el que se crea el bono de contingencia a personas afectadas por eventos de origen natural o antrópico.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas en sus estructuras.- 4 viviendas destruidas (3 de patrimonios culturales).- 3 viviendas en riesgo.- 115 familias de 272 personas afectadas que habitan en la zona de peligro.- 15 familias de 37 personas damnificadas (evacuadas y se encuentran en casa acogiente).- 3 calles afectadas. (Calle Colón por hundimiento y las calles 29 de noviembre y Ernesto Castro por agrietamientos).- 25% del servicio de energía eléctrica afectado.- Centro anidado de MSP evacuó por precaución a dar atención al Hospital Humberto Molina.- Los servicios públicos que brindan en el edificio del municipio y del BanEcuador debido a la cercanía al evento fueron suspendidos por precaución.- 2 bienes privados afectados (1 vehículo que se encontraba estacionado se precipitó al foramen y club colón presenta fisuras).- 1% del sistema de telecomunicaciones se encuentra afectado.- 2 bienes públicos afectados: parque con fisuras y poste de alumbrado destruido.</td></tr><tr><td>Acciones de respuesta:</td><td>- COE Nacional, Provincial y Cantonal se mantienen activos para articular acciones en atención al evento.- Plenaria del COE Nacional se reunió de manera presencial y virtual por vía Zoom. Estuvieron en sesión: Presidente de la República del Ecuador, Director del SNGRE y demás autoridades nacionales, donde analizaron la situación actual del hundimiento y sus actividades realizadas. Además se coordinan acciones emergentes a ejecutarse para los próximos días</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ7 Unidad de Monitoreo El Oro/Sala de Situación COE Provincial</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/b8ba08cccf778bf80ee0cb514d0e2d063bef24706cc57a7c509cf2bd26167e73.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>Zona 1/Imbabura/Urcuquí/Buenos Aires/San José</td></tr><tr><td>Antecedentes:</td><td>El 14/12/2021, producto de las fuertes precipitaciones registradas en la madrugada, se presentaron deslizamientos que afectaron a viviendas y red vial de tercer orden, causando pérdida de enseres a las familias y afectó a las actividades económicas a los productores de leche y frutas debido a que no pueden transportar sus productos.</td></tr><tr><td>Situación actual:</td><td>El acceso vial de La Primavera - San José se encuentra inhabilitada.</td></tr><tr><td>Afectaciones:</td><td>11 familias, 44 personas afectadas.3 familias, 14 personas damnificadas.3 viviendas destruidas.11 viviendas afectadas.70 metros lineales.</td></tr><tr><td>Acciones de respuesta:</td><td>- COE Cantonal Urcuqui se activó con les representantes de todas las MTT.- SNGRE-UMEVA coordinó con personal del GAD Cantonal Urcuqui - UGR para realizar levantamiento de la información (EVIN) y actualizaciones periódicas.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 4 de 13

<table><tr><td></td><td>- GAD Parroquial de Buenos Aires, GAD Provincial de Imbabura y MTOP realizan trabajos de limpieza y habilitación vial.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/SNGRE CZ1 UPREA/GAD Parroquial Buenos Aires/GAD Provincial Imbabura/ MTOP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/65958dee9cf69d2ed3b41f38462a89884960a967fde5ed10cb1b30af76b60542.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Zona 3/Chimborazo/Guano/Matriz/Barrios La Merced, La Dolorosa del Cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu Santo, La Dolorosa Centro, Santa Terecita (Balneario Los Elenes)</td></tr><tr><td>Antecedentes:</td><td>El 11/12/2021, por las lluvias registradas en el sector se produjo un aluvión que afectó viviendas y calles de la zonaEn atención al evento reportado se activó el COE Cantonal y el COE Provincial</td></tr><tr><td>Situación actual:</td><td>MTOP continúan con los trabajos de limpieza en la red vial.</td></tr><tr><td>Afectaciones:</td><td>- 64 familias afectadas en infraestructura agropecuaria (256 personas)- 4 ha de cultivos afectados.- 5 ha de cultivos perdidos.- 45 animales afectados.- 8 familias afectadas en infraestructura (18 personas).- 25 familias damnificadas (91 personas).- 28 viviendas afectadas.- 5 viviendas destruidas.- 1 puente afectado.- 1 puente destruido.- 2 bienes públicos afectados.- 2 animales muertos.- 40% de locales del cantón afectados (comerciales y artesanías).- Red de agua potable: 60% afectada. (reparado en un 100%).- Red de alcantarillado sanitario y pluvial: 60% afectada. (reparada en un 90%).- 9000 metros de vía afectada (varios tramos de diferentes sectores, avances de habilitación de la vía en un 80%).</td></tr><tr><td>Acciones de respuesta:</td><td>Obras Públicas del GAD Cantonal Guano continúa realizando la limpieza de las vías en varios tramos de diferentes sectores, han avanzado en un 80%.Puente de Los Elenes tiene habilitado un solo carril.SNGRE CZ3 en cooperación con la Academia UCE, y su equipo, y en coordinación con la Gobernación de Chimborazo y el GAD Cantonal de Guano, se efectuó actividades en territorio para el análisis de Riesgos en el cerro Igualata, cantón Guano, con la finalidad de continuar con los estudios sobre las causas que originaron el aluvión el sector.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ3 Unidad de Monitoreo Chimborazo/UPREA SNGRE CZ3</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/fbc2d6f71cd3788344b842b7dad83b3ec7335ac5ecab8730ff56c0918ac46b2e.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 1/Imbabura/Pimampiro/Pimampiro/San José de Aloburo</td></tr><tr><td>Antecedentes:</td><td>El 09/11/2021, debido a las lluvias y a la presencia de fallas geológicas se registró afectaciones a la red vial y viviendas del sector. El 19/11/2021 se declaró la Situación de Emergencia en el cantón</td></tr><tr><td>Situación actual:</td><td>La comunidad realizó la habilitación de la vía de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SNGRE</td></tr><tr><td>Afectaciones:</td><td>6 invernaderos colapsados (de aguacates, mandarinas y duraznos); Canales secundarios colapsados.800 metros de red eléctrica, 3 postes colapsados.Red de distribución de agua colapsada.500 metros, que conecta San José con Aloburo.12,43 hectáreas de cultivos destruidos y 37,57 ha de pastos afectados.23 familias damnificadas fueron evacuadas (10 en la Escuela del Tejar, 3 en la Unidad Educativa Pimampiro y 10 en familias acogientes).12 viviendas destruidas.6 viviendas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal y GAD Provincial se mantienen en los trabajos para habilitar una nueva vía alterna, los mismos que aún no finalizan.UGR del GAD Cantonal Pimampiro da acompañamiento a las instituciones que realizan el informe que va a determinar la zona de influencia directa.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura-Carchi/GAD UGR Pimampiro</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 5 de 13

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/4011ec49a5bfc66ccd3f758dc24c99def594907125718a8aebf55b2837c5db96.jpg)


<table><tr><td>Localización:</td><td>Zona 3/Chimborazo/Riobamba/San Juan/EI Arenal, Nevado Chimborazo</td></tr><tr><td>Antecedentes:</td><td>El 24/10/2021, se produjo una avalancha que afectó a un grupo de montañistas</td></tr><tr><td>Situación actual:</td><td>La búsqueda se encuentra suspendida hasta que se realice el análisis del nuevo ascenso por parte de las instituciones competentes.</td></tr><tr><td>Afectaciones:</td><td>3 personas fallecidas7 personas rescatadas3 personas heridas3 personas desaparecidas</td></tr><tr><td>Acciones de respuesta:</td><td>El día 15/12/2021, se dio lugar a la reunión del GT3 donde se analizó y evaluó las condiciones climáticas, adicional se está a la espera del ascenso al nevado para continuar la búsqueda.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ3 Unidad de Monitoreo Tungurahua/SNGRE CZ3</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/1aea34ea857fcfb826b348f54b9bf6e023e31d4daa9136bdb6d66b73cd31831e.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 6/Azuay/Cuenca/Molleturo/Km 49, vía Cuenca-Molleturo-Naranjal [E-582]</td></tr><tr><td>Antecedentes:</td><td>Desde el 17/10/2021 hasta la fecha se han registrado varios deslizamientos que han ocasionado diferentes afectaciones en el sitio</td></tr><tr><td>Situación actual:</td><td>La vía se encuentra habilitada desde las 05h00 hasta las 18h30, las noches permanece cerrada por precaución.</td></tr><tr><td>Afectaciones:</td><td>13/11/20211 vehículo afectado2 personas heridasvía cerrada04/11/202140 metros de la vía afectada22/10/20211 vehículo afectado1 persona herida17/10/20211 vehículo afectado2 personas heridas1 persona fallecida</td></tr><tr><td>Acciones de respuesta:</td><td>Personal de Comisión de Tránsito colabora con el tránsito vehicular.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/CTE/MTOP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/2d14e1108ee3702abf52f0ec89e9dd7bdc1382a4971597640c439055435e04d5.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Zona 6/Azuay/Sevilla de Oro/Amaluza/Km 76, vía Paute- Guarumales-Méndez [E-40]</td></tr><tr><td>Antecedentes:</td><td>El 02/06/2021 por lluvias se produjo el desbordamiento de la quebrada Jurupis ocasionando un aluvión que afectó la vía de primer orden</td></tr><tr><td>Situación actual:</td><td>El 10/12/2021, MTOP realizó la suspensión de la circulación vehicular que se extenderá hasta recuperar la zona afectada, por el lapso de 6 a 8 semanas</td></tr><tr><td>Afectaciones:</td><td>2 viviendas presentaron socavamientos en sus bases y cuarteaduras en sus paredes (inhabitables)3 familias damnificadas (2 familias habitan en una sola vivienda y 1 en la otra vivienda con un total de 8 personas: 6 adultos y 2 menores de edad) permanecen en el albergue ubicado en los terrenos de la Junta Parroquial de Amaluza.100 metros lineales de vía de primer orden</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP continua con los trabajos de mantenimiento de la vía</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/MTOP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/f3b777b77c083650ab7a10e260ebe494f1afdfc1e1a1907ac2a12c029bcb1cb0.jpg)



Socavamiento


<table><tr><td>Localización:</td><td>Zona 2/Orellana/Francisco de Orellana/El Coca/Barrios Río Coca, Perla Amazónica, Cambahuasi y Unión y Progreso.</td></tr><tr><td>Antecedentes:</td><td>Desde el 17/05/2021 el proceso erosivo y sedimentación en el río Coca pone en riesgo a varias viviendas e infraestructura ubicada en la ribera</td></tr><tr><td>Situación actual:</td><td>Se continúa realizando los trabajos de mitigación en la ribera del río Coca junto a moradores del barrio Perla Amazónica.</td></tr><tr><td>Afectaciones:</td><td>1 familia evacuada - 7 personas en alojamiento temporal1 familia evacuada - 4 personas con familia acogiente.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal de Francisco de Orellana continúa realizando los trabajos de mitigación en la ribera del río Coca junto a moradores del barrio Perla Amazónica. El Municipio informó que las mesas técnicas de trabajo</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 6 de 13

<table><tr><td></td><td>cantonales están activadas y coordinando acciones de mitigación y seguimiento de la familia en el alojamiento temporal.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ2 Unidad de Monitoreo Napo-Orellana/Cruz Roja Ecuatoriana/GAD Cantonal Francisco de Orellana/GAD Provincial de Orellana</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/f5eac906385daf31425c52d60324760c48262c3bf77a497f41ad39b8efe00463.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 6/Azuay/Nabón/Nabón/Barrios Rosas, Bellavista, Tamboloma, Chunazana, Rosario</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2021 se reportó un movimiento de masa provocado por la filtración de agua de riego y la temporada lluviosa. El 23/11/2021 el Servicio Nacional de Gestión de Riesgos y Emergencias declaró la Alerta Naranja por movimientos en masa en el área de 130,94 hectáreas que comprende los barrios Rosas, Bellavista, Chunazana, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 03/01/2022 técnico de UGR Nabón informa que se ha procedido a evacuar 2 viviendas más adicionales a las 35 viviendas ya reportadas, adicional informa que continúan los trabajos en la vía Nabón - La Ramada en el sector la Quebrada del Canal, la misma se encuentra parcialmente habilitada.</td></tr><tr><td>Afectaciones:</td><td>60 metros de vía afectados (Vía Parcialmente Habilitada)37 familias integradas por 112 personas afectadas aproximadamente1 Casa comunal afectada con cuarteaduras35 viviendas afectadas (las familias evacuadas se alojan en diferentes medios de alojamiento como arriendos o familias de acogida)Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)Iglesia demolida por los daños estructurales presentadosCentro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>Técnico de UGR Nabón se mantiene en continúo monitoreo de la zona afectada, maquinaria de Obras Públicas realiza trabajos en la vía</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/10f6d0326b980099998dc8be17f6df8369999a5f98b6397cc4c4defc0686fcd7.jpg)


## Deslizamiento

<table><tr><td colspan="2">Deslizamiento</td></tr><tr><td>Localización:</td><td>Zona 3/Chimborazo/Chunchi/Chunchi/La Armenia, río Guataxi afluente del río Chanchán, vía Chunchi - La Armenia - Huigra.</td></tr><tr><td>Antecedentes:</td><td>El 12/02/2021 debido a las lluvias registradas en el sector se produjo el taponamiento del río Guataxi, que es afluente del río Chanchán, se reportó pérdida de animales vacunos y de especies menores.</td></tr><tr><td>Situación actual:</td><td>Autoridades del SNGRE y del GAD Cantonal Chunchi mantuvieron una reunión con el fin de seguir trabajando en la socialización a la población sobre el riesgo del deslizamiento en el sector de La Armenia.</td></tr><tr><td>Afectaciones:</td><td>255 personas afectadas directamente.68 familias afectadas directamente.30 viviendas destruidas.30 familias (89 Personas damnificadas), el día 25/10/2021 desalojaron el albergue en su totalidad.38 viviendas afectadas; 86 Familias (329 Personas evacuadas).2 personas aisladas con atención pre-hospitalaria.2 bienes públicos afectados: (red de alcantarillado y planta de tratamiento de aguas residuales (solventado), 50 % del sistema de agua potable afectado (solventado), sistema de riego, línea férrea.2 puentes de la vía de tercer orden.1 bien público destruido (estación hidrológica del INAMHI h0375 Chanchán DJ Guataxi).115 hectáreas de cultivos destruidos.718 animales de granja afectados.689 animales de granja muertos.</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE y el GAD Cantonal Chunchi coordinaron acciones de socialización sobre el riesgo del deslizamiento en el sector.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ3 Unidad de Monitoreo Chimborazo/MPCEIP.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/b709bc83c04c48fa61098fcce71bcbe1ee26507a2648f1168565444ad11085e7.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Zona 2/Orellana/La Joya de Los Sachas/San Sebastián Del Coca/San Sebastián Del Coca Zona Urbana, Toyuca, Sardinas, vía La Joya de Los Sachas - El Coca [E45A]</td></tr><tr><td>Antecedentes:</td><td>El 08/02/2021, a causa de las lluvias suscitadas se produjo un socavamiento el cual afectó la orilla del río Coca en la comunidad Toyuca, situación que</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 7 de 13

<table><tr><td></td><td>aumentó de forma significativa, adicional se reportó afectación en las bases del puente sobre el río Coca</td></tr><tr><td>Situación actual:</td><td>El proceso erosivo avanza de forma lenta. No se han registrado lluvias que causen un aumento considerable del río Coca como en los meses anteriores</td></tr><tr><td>Afectaciones:</td><td>1 familia damnificada1 persona evacuada1 puente afectado</td></tr><tr><td>Acciones de respuesta:</td><td>El 15/12/2021, SNGRE en coordinación con varias Instituciones como MSP, MINEDUC, Cuerpo de Bomberos, PPNN del Cantón de La Joya de Los Sachas, participaron en una reunión de trabajo para revisar los planes de respuesta de las MTT y GT ante la sedimentación y erosión del río Coca de acuerdo a los compromisos acordados en el COE Cantonal de La Joya de Los Sachas.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ2 Umeva-Napo-Orellana</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/bfc1a562e5065ef2dd9c9f6e48ed33bc171e305cd0ba54757355e473aa11d3cc.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Zona 5/Bolívar/Chimbo/Cabecera Cantonal/barrio Tamban</td></tr><tr><td>Antecedentes:</td><td>Desde marzo del 2020 se muestra una serie de grietas y fallas que van desde el pavimento de la cancha de uso múltiple hasta la iglesia, además mantiene una concordancia longitudinal con otras grietas observadas en la vía Chimbo-El Cristal, producto de aguas de infiltración, saturación de los elementos expuestos y además incide la falta de mantenimiento a la infraestructura hidrosanitaria.La noche del 21/12/2021 debido al proceso activo del hundimiento, se produjo el colapso del muro que se encontraba en la parte superior de la calle adoquinada, causando la pérdida total de la plataforma de la vía de primer. El 23/12/2021 sesionó el COE Cantonal y resolvió declarar en Emergencia Grave al Barrio Tambán, Parroquia Central San José, cantón Chimbo, Provincia Bolívar por el lapso de 60 días</td></tr><tr><td>Situación actual:</td><td>Hoy 07/01/2022 autoridades del MTOP y MINEDUC realizan coordinaciones interinstitucionales para la construcción del paso alterno provisional. Además el SNGRE realiza coordinación interinstitucional de logística para el traslado de la familia que se encuentra en el albergue de la U.E. Tres de Marzo quien saldrá a arrendar</td></tr><tr><td>Afectaclones:</td><td>- 2 viviendas destruidas (2 familias damnificadas 7 personas; de las cuales 1 familia 4 personas se encuentran en el albergue de la U.E Tres de Marzo, 1 familia 3 personas se encuentran arrendando).- 3 viviendas afectadas (3 familias afectadas 16 personas; de las cuales 1 familia 10 personas se encuentran en el albergue de la U.E La Asunción, 2 familias 6 personas se encuentran arrendando).- 1 bien privado destruido (iglesia)- 8 bienes públicos destruidos (1 concha acústica -salón de reuniones, 1 cancha deportiva, 4 postes, tubería de agua que abastece a las comunidades de Panchigua, Tingo y Miraflores, alcantarillado de la zona cero)- 150 metros de vía de primer orden Chimbo-El Cristal destruida.- 60 metros de la calle S/N adoquinada destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>- MTOP y MINEDUC realizan coordinaciones interinstitucionales con la finalidad de buscar la mejor alternativa para la construcción del paso alterno provisional.- El SNGRE realiza coordinación interinstitucional de logística para el traslado de la familia que se encuentra en el albergue de la U.E. Tres de Marzo quien ira arrendar en cooperación con la Empresa Privada (Cooperativa de Ahorro y Crédito San José Ltda.), el cual se prevé para el lunes 10/01/2022.- Policía Nacional permanece guiando al tránsito vehicular por las rutas alternas.- Fuerzas Armadas continúa dando seguridad en los albergues temporales y en la zona cero.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad Monitoreo Bolívar/GAD Provincial/MIES/FFAA</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/d5788c23337ba364ea3b2c5f4261dc68ab213f66506130c7c2b9dc52ee2fb38b.jpg)


<table><tr><td>Localización:</td><td>Zona 2/Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina, San Luis, vía Y de Baeza-Lago Agrio [E45]</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos como la Red Estatal Vial E45, Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.</td></tr><tr><td>Situación actual:</td><td>Dos familias ubicada en San Luis fueron evacuadas hacia la ciudad de Lago Agrio y tercera familia desde el límite provincia hasta la el cantón El Chaco. San Rafael continúa sin servicio eléctrico. El paso vehicular por la vía Baeza Agrio</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 8 de 13

<table><tr><td></td><td>Lago Agrio está cerrada, la ruta alterna Y de Baeza-Y de Narupa-Loreto-El Coca-Lago Agrio está habilitada</td></tr><tr><td>Afectaciones:</td><td>20/12/20211 familia (10 personas) evacuadas13/12/2021Rotura de la tubería de Poliducto y suspensión del bombeo.10/12/2021Población de San Rafael sin energía eléctrica.03/12/2021Puente sobre el río Piedra Fina 2 en riesgo.21/11/20211 tubería de agua afectada.19/05/20211 puente destruido (puente denominado Ventana 2)18/05/20212 viviendas destruidas (las familias fueron las evacuadas en febrero del 2021)10/03/20211 bien afectado (tanque de agua)27/02/20212 familias damnificadas y evacuadas a alojamiento temporal. Actualmente están en arriendo2 viviendas presentaron fisuras22/10/20201 puente destruido (puente sobre el río Montana)06/05/20202 familias afectadas, 2 viviendas afectadas07/04/20203 bienes afectados (tuberías del SOTE, Poliducto Shushufindi- Quito y al OCP)Afectación vial: las pérdidas y afectaciones relevantes en vías ocurrieron el 03/12/2021, 18/05/2021, 20/04/2021, 22/10/2020, 22/08/2020 y 04/06/2020 con un total de 875 metros de la vía E45.Afectación agropecuaria: durante algunos meses se ha identificado 63.95 ha de superficie agrícola perdida y 21 bovinos, 63 porcinos y 3000 tilapias perdidas.</td></tr><tr><td>Acciones de respuesta:</td><td>El 30/06/2021 el Alcalde del cantón El Chaco resolvió ratificar la declaratoria de emergencia en la comunicad de San Luis ubicado en la parroquía Gonzalo Díaz de Pineda, cantón El Chaco y demás zonas de influencia, a fin de establecer acciones inmediatas para atender la emergencia.Se mantiene el nivel de alerta roja en el tramo comprendido entre las obras de captación de la Central Hidroeléctrica Coca Codo Sinclair, ex cascada de San Rafael y el túnel de descarga de la Central , que se extiende entre las provincias de Napo y Sucumbíos.SNGRE CZ2, CZ1, CZ9 en coordinación con el GAD Cantonal El Chaco y el apoyo del Cuerpo de Bomberos de Santo Domingo se encuentran evacuando a dos familias ubicadas en San Luís hasta la ciudad de Lago Agrio y otra familia de limite Sucumbíos hacia el cantón El Chaco. SNGRE CZ2 mantendrá reunión virtual con MDG, MTOP para analizar donde va ser construido la vía para unir las dos provincia de Napo y Sucumbíos.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ2 Umeva Napo/Orellana/OCP Ecuador/MTOP/Empresa Eléctrica Quito SA - Orellana</td></tr><tr><td colspan="2">Deslizamiento</td></tr><tr><td>Localización:</td><td>Zona 9/ Pichincha/ Mejía /Manuel Cornejo Astorga (Tandapi)/ Km 29 y 44, vía Alóag</td></tr><tr><td>Antecedentes:</td><td>Por inestabilidad se reporta un deslizamiento que afecta parcialmente una vía de primer orden.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se encuentra totalmente habilitada</td></tr><tr><td>Afectaciones:</td><td>8 metros lineales</td></tr><tr><td>Acciones de respuesta:</td><td>CTE verificó el eventoGAD provincial de Pichincha realizó la limpieza del tramo de vía afectado</td></tr><tr><td>Fuentes de información:</td><td>CTE/ GAD provincial de Pichincha/ SNGRE Unidad de Monitoreo Pichincha</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/dd79b3ec50095ffc277e2e6015c3e3c4f650f9289e0d233bf70a1b1716253be2.jpg)


Dirección de Monitoreo de Eventos Adversos 

Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016
Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 9 de 13 

3 Monitoreo de estado de vías afectadas por eventos peligrosos 

VÍAS DE PRIMER ORDEN: 

<table><tr><td colspan="9">04 vías de primer orden cerradas</td></tr><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pelligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>125</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>Sevilla de Oro</td><td>Amaluza</td><td>Km 76, vía Paute-Guarumales-Méndez [E-40]</td><td>ALUVIÓN</td><td>875</td><td>02/06/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr><tr><td>3</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo, Cabecera Cantonal</td><td>barrio Tamban</td><td>HUNDIMIENTO</td><td>210</td><td>18/03/2020</td><td>Chimbo, San Miguel, San Pablo y Balsapamba</td></tr><tr><td>4</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, San Luis, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>855</td><td>02/02/2020</td><td>Sucumbíos - Coca-Narupa-Baeza-Papallacta - Quito</td></tr></table>

## 23 vías de primer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 115+500 Vivar [E-59]</td><td>DESLIZAMIENTO</td><td>30</td><td>03/01/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Morona Santiago</td><td>Limón Indanza</td><td>Yunganza (cabecera en el Rosario)</td><td>San Antonio, vía Bella Unión-Limón [E45]</td><td>DESLIZAMIENTO</td><td>160</td><td>29/12/2021</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>10 de Agosto, vía Loreto - Tena [E45A-E20]</td><td>DESLIZAMIENTO</td><td>80</td><td>17/12/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Napo</td><td>El Chaco</td><td>El Chaco</td><td>Quebrada Macanas, vía Y de Baeza-El Chaco [E45]</td><td>SOCAVAMIENTO</td><td>50</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>80</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Napo</td><td>Tena</td><td>Chontapunta</td><td>Rayayacu, vía Chontapunta - Los Zorros - La Belleza [E436]</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>17/11/2021</td><td>Humuyacu-Yuralpa Derecho-Wachayacu</td></tr><tr><td>7</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 49, vía Cuenca-Molleturo-Naranjal [E582]</td><td>DESLIZAMIENTO</td><td>40</td><td>17/10/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Manabí</td><td>Jipijapa</td><td>Jipijapa</td><td>Quimís- vía Colón-Quimís [E4-82]</td><td>COLAPSO ESTRUCTURAL</td><td>25</td><td>14/10/2021</td><td>Manabí hacía Guayas E482 sector Pila-Los Bajos de Montecristi-E15 -Puerto Cayo-Jipijapa -Jipijapa hacia Portoviejo E-482 - Rcto. Colón Quimís- vía de Tercer Orden-E462B Santa Ana-Portoviejo</td></tr><tr><td>9</td><td>Esmeraldas</td><td>San Lorenzo</td><td>San Lorenzo, Cabecera Cantonal</td><td>La Florida km9, vía San Lorenzo - Ibarra [E10]</td><td>SOCAVAMIENTO</td><td>10</td><td>28/08/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Nuevos Horizontes, vía Méndez-Guarumales [E40].</td><td>DESLIZAMIENTO</td><td>100</td><td>01/07/2021</td><td>Limón-Gualaceo</td></tr><tr><td>11</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza</td><td>Sector Tucumbatza, vía Gualaquiza-San Juan Bosco [E45] (Primer Orden).</td><td>HUNDIMIENTO</td><td>50</td><td>30/06/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], Tramo Puente Sobre El Río Copueno-Puente Sobre El Río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Y de Santa Ana-Sevilla-Seipa-Sucúa-Macas</td></tr><tr><td>14</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Copueno, vía Macas-Puyo [E45]</td><td>SOCAVAMIENTO</td><td>120</td><td>30/04/2021</td><td>Ninguna</td></tr><tr><td>15</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km. 101, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>12</td><td>14/03/2021</td><td>Ninguna</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016
Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 10 de 13


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Pelligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>16</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>17</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>18</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>19</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>SOCAVAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>20</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>21</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr><tr><td>22</td><td>Orellana</td><td>La Joya De Los Sachas</td><td>San Sebastián del Coca</td><td>Toyuca, Sardinas, Sebastián del Coca, vía La Joya de los Sachas - El Coca [E45A]</td><td>SOCAVAMIENTO</td><td>--</td><td>08/02/2021</td><td>Ninguna</td></tr><tr><td>23</td><td>Morona Santiago</td><td>Santiago</td><td>Patuca</td><td>Loma Seca vía Patuca - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>15</td><td>15/01/2020</td><td>Ninguna</td></tr></table>

## VÍAS DE SEGUNDO ORDEN:


04 vías de segundo orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Loja</td><td>Saraguro</td><td>Urdaneta (Paquishapa)</td><td>El Rodeo, vía Urdaneta-Yacuambi</td><td>SOCAVAMIENTO</td><td></td><td>23/12/2021</td><td>Urdaneta-Bahim-Yacuambi</td></tr><tr><td>2</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo.</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>3</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Alluriquín</td><td>Cristal del Lelia-Vía a los libres</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>11/02/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>


13 vías de segundo orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Chimborazo</td><td>Guano</td><td>La Matriz</td><td>Barrios La Merced, La Dolorosa del cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu santo, La Dolorosa Centro, Balneario Los Elenes</td><td>ALUVIÓN</td><td>--</td><td>11/12/2021</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>Cuenca</td><td>San Sebastián</td><td>Calle del Molino</td><td>DESLIZAMIENTO</td><td></td><td>29/11/2021</td><td>Ninguna</td></tr><tr><td>3</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>Chaquisca, vía Guanujo-Las Cochas</td><td>DESLIZAMIENTO</td><td>30</td><td>09/11/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Zamora Chinchipe</td><td>Zamora</td><td>Cumbaratza</td><td>Tunantza Alto, vía Timbara Bajo-Timbara Alto.</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/10/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Puente Salado Grande, vía Macas-Riobamba-tramo 9 de Octubre-Cebadas [E46].</td><td>DESLIZAMIENTO</td><td>60</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Km 78, vía Macas-Riobamba E46]</td><td>DESLIZAMIENTO</td><td>60</td><td>12/06/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Morona Santiago</td><td>Limón Indanza</td><td>General Leonidas Plaza Gutiérrez (Limón), cabecera cantonal</td><td>Cerro Bosco, vía Gualaceo-Limón (Segundo Orden).</td><td>DESLIZAMIENTO</td><td>50</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Chigüinda</td><td>Granadillas, vía Sig-Sig-Chiguïnda-Gualaquiza [594]</td><td>DESLIZAMIENTO</td><td>20</td><td>15/05/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Km 35, vía Cahuají - Pillate - Cotaló [E-304].</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2021</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 11 de 13

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>11</td><td>Pichincha</td><td>Quito</td><td>Checa (Chilpa)</td><td>Km 38+377, entrada a Checa, vía Cusubamba- Pifo</td><td>SOCAVAMIENTO</td><td>15</td><td>01/04/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Nabon</td><td>Nabón, cabecera cantonal</td><td>Rosas, Bellavista, Tamboloma, Chunazana.</td><td>DESLIZAMIENTO</td><td>60</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>Gualaquiza</td><td>El Rosario</td><td>El Aguacate, vía Sig-Sig-Chiguinda-Gualaquiza [E594]</td><td>DESLIZAMIENTO</td><td>50</td><td>23/09/2020</td><td>Piñas-Portovelo-Zaruma</td></tr></table>


VÍAS DE TERCER ORDEN:


## 12 vías de tercer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Yaruqui</td><td>comuna Oyambarillo vía Coturco</td><td>DESLIZAMIENTO</td><td>--</td><td>03/01/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Vía Sucúa-Asunción</td><td>DESLIZAMIENTO</td><td>30</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>3</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Santa Rita - Getsemaní; Verde Bajo - San Francisco y Río Verde Medio.</td><td>DESLIZAMIENTO</td><td>75</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Imbabura</td><td>San Miguel de Urcuquí</td><td>Buenos Aires</td><td>Pimaqui; vía Buenos Aires - Cahuasqui</td><td>DESLIZAMIENTO</td><td>75</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Río verde Alto, vía Lita - Rioverde Alto</td><td>DESLIZAMIENTO</td><td>50</td><td>18/12/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Imbabura</td><td>Cotacachi</td><td>6 De Julio De Cuellaje (Cab. En Cuellaje)</td><td>Y de Nápoles, vía de Cuellaje – El Rosario</td><td>SOCAVAMIENTO</td><td>30</td><td>13/12/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Nueva alianza</td><td>INUNDACIÓN</td><td>7000</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia, Río Guataxi afluente del río Chanchán</td><td>DESLIZAMIENTO</td><td>--</td><td>12/02/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>--</td><td>20/01/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Morona Santiago</td><td>Palora</td><td>Cumandá (Cab. en Colonia Agrícola Sevilla del Oro)</td><td>Puente sobre el río Charuyaku</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>23/10/2020</td><td>Palora-Puyo-Cumandá</td></tr></table>

## 12 vías de tercer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pelligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Tumbaco</td><td>Sector - Vía a Minas a 1 Km al sur de las Piscinas de Cunuyacu.</td><td>DESLIZAMIENTO</td><td>--</td><td>29/12/2021</td><td>Ninguna</td></tr><tr><td>2</td><td>Imbabura</td><td>San Miguel De Urcuquí</td><td>La Merced De Buenos Aires</td><td>vía Buenos Aires - La Primavera (alcantarilla sobre el Río Salado)</td><td>SOCAVAMIENTO</td><td>30</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Yaucana</td><td>ALUVIÓN</td><td>--</td><td>23/07/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Napo</td><td>El Chaco</td><td>Oyacachi</td><td>Oyacachi, vía a Jariyacu-Huashahuaicu</td><td>DESLIZAMIENTO</td><td>--</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Nueva Tarquí</td><td>El Candi</td><td>HUNDIMIENTO</td><td>800</td><td>26/05/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Centro Parroquial de Pananza</td><td>HUNDIMIENTO</td><td>10</td><td>20/05/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Riobamba</td><td>Quimiag</td><td>Sector Balcashí, vía Quimiag - Chambo</td><td>SOCAVAMIENTO</td><td>--</td><td>06/03/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Puente sobre el río Malo</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>29/01/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Valle Hermoso</td><td>Sector Sarayacu.</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>15/01/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Méndez-Bella Unión-La Dolorosa-Copal</td></tr><tr><td>11</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>


Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016
Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 12 de 13


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Pelligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>12</td><td>Pichincha</td><td>Quito</td><td>Turubamba</td><td>Guamaní Alto - quebrada Caupicho, desde el puente de la av. Susana Letor hasta el puente de Guajaló</td><td>SOCAVAMIENTO</td><td>15</td><td>01/02/2020</td><td>Ninguna</td></tr></table>

## 4. Declaratorias emitidas por el SNGRE (vigentes en orden cronológico)

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/ff95c3755438c1c3816efdecc7a712798336376124b3ae03c2dd4f30fd10f7bd.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/175969f8317eb61a7e7d3a815231a1394ca1436033754ca00994f783307bc6f8.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/a43825f267ab7ec349afb36bdddce69cd0ea80e4be91cc55e8a8489dbe51d439.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/c09255f4ef47d2c7610101889f1b140a60a9090e844b10df1014a4ad3e3df674.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/67932dfaffd2dde3ab0b95683e35814ae763c23583f83a3892b484c66ee4b1a9.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/dcc8fffbc7a7471fd02271b716eb5f0216b9a5ce0ac977d7dd3e9340160fceb4.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/fec4cc7b5f747304b44fb1c892cc64961c7f382deced856d1e4cca6765a141f2.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/592483d57fc2bf327f7b37859b0f264cf56bb229f47cc6444f43ecae65444e8a.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/d4f2ccae41dc784e2b6d752200cd174ee3eae597e6cfe32068e7a1275ece0bfa.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/1ef2ebcdabedc881946b3671ca533e41a6506d58d31fed22ccadf6653a9d152f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/dca044e49e44bfd3a2b6bdfc396649d896272f7a07d0f0f1b87b14e593206348.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/ba8435e8c54f04568d721fbee165535e0fd6fa37cac5f238e6ad56e8d55c57ff.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/bc98aea350e99ae140a42b1bc4f76b3f43cb14520eae538492fb789febf9d47d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/48aa08b0644e07492356d491806ed7680b98ffe9975dff6ebd0c36a0393ddbf2.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Movimiento en masa Barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SNGRE-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SNGRE-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SNGRE-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SNGRE-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SNGRE-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SNGRE-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SNGRE-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00016 Fecha y Hora de actualización: sábado, 08 de enero de 2022 - 21:03:47 / Página 13 de 13

<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td colspan="3">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/1d9fecc7c6f00268db69ee8b1004dfae5634954c1f401420184cdc17af4fa973.jpg"/></td><td>Inundaciones Babahoyo, Los Ríos</td><td></td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/e96806dc-a4f4-4e09-96d8-9db53e6c713b/aad14e41a9df293d53d6d18390a981f0fa7e93e6ae18d8b9b85ed7aaec48c318.jpg"/></td><td>Hundimiento, Zaruma, El Oro</td><td></td><td>07/03/2017</td><td>Resolución No. SGR-029-2015</td></tr></table>

Elaborado por: - - Fernando Saltos/Jossué Villafuerte - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. Revisado por: - Alan Mite - Analista de Monitoreo de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. Emitido por: - - Jossué Villafuerte - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 