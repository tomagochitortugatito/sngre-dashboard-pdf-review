Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025
Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 1 de 14 

Periodo de Monitoreo: 

Desde: 21h00 12/01/2022 

Hasta: 09h00 13/01/2022 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/11d6cead8597f874fdea141a220cf9daf74a9fabdc55326d98307b05fe832696.jpg)


- Amenaza dentro de los parámetros normales. 

## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/3e85c80a8644a22d0d79f4e89686defa86ff8cbaeaac3e52ca5a0279edbf3257.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>La DAC informó a las 23:37 que mediante satélite se registró una emisión de ceniza, con altura aproximada de 1000 msnc con dirección Sur. Durante la noche y madrugada el sector se presentó nublado sin reporte de actividad superficial,</td><td>AMARILLO</td></tr><tr><td rowspan="2"><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/7ae7633ab6ea332959d6f5f8bbcbc02a0c0dcaf6b5b21b7f7b0425b2f1ebc37e.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>Sector nublado sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td>Volcán Cotopaxi</td><td>SIN ALERTA</td><td>Sector parcial nublado sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td rowspan="2"><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/96c89bd5382aa88551eccb29be2de40a153143ede1e60dabbcafac8dd4c30c84.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>Sector nublado sin reporte de actividad superficial</td><td>VERDE</td></tr><tr><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>Sector nublado sin reporte de actividad superficial</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/3d617873298929646a1345c8ba2efd9140728ae13910c18c389ec11e61d0969a.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>En referencia al aviso VONA N° 2022-047, mediante imágenes satelitales de la VAAC se observa emisión de ceniza, con altura igual a 870 msnc, con dirección Sur.</td><td>AMARILLO</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/de61aa3c8612130c19642a3640328117e920d7e7e676313a32caa1df374a0768.jpg"/></td><td>Volcán Wolf, Galápagos</td><td>SIN ALERTA</td><td>En referencia a informe IGPEN de estado del volcán Wolf, según imágenes satélites (Fuente: GOES16) asociadas al mismo, muestran una disminución en la cantidad de gas emitido (Fuente: Mounts), así como en la cantidad de alertas termales generadas Se estima que los flujos de lava se encuentran muy próximos (o ingresando) al mar.</td><td>AMARILLO</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/25af00389692eca6bbea691938a11374036f157a7af8c04e54557a2206a1fb42.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">00 río desbordado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr><tr><td colspan="5"></td></tr><tr><td colspan="5">02 ríos con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>Esmeraldas</td><td>Eloy Alfaro</td><td>Maldonado</td><td>Varios Sectores</td><td>Santiago</td></tr><tr><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Estación INAMHI</td><td>Quinindé</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/adc539086b3b0297842f454ffc6bdd817ab9d89ef7e5bae285797d6fdbcc2d90.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 Incendlo activo</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>Manabí</td><td>San Vicente</td><td>Canoa</td><td>Playa Punta Napo</td><td>--</td></tr><tr><td colspan="5"></td></tr><tr><td colspan="5">00 Incendlos controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

# Dirección de Monitoreo de Eventos Adversos

Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025
Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 2 de 14 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/082e01e0805f8e732358f5f6878c80390c95f37556c3baf80901474faca31550.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td>---</td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td>---</td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>70.97</td><td>85.00</td><td>06:12</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>---</td><td>117.00</td><td>---</td><td>---</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td>---</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>---</td><td>106.50</td><td>---</td><td>---</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td>---</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td>---</td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td>---</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/7f20e9d764fa3a2daefd08da37de80bf7e5124dc1bb5e99ad7ea1b3fc440a815.jpg)


## SITUACIÓN HIDROMETEOROLÓGICA

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/811f183e1edddc957e14f633ac88b91268bf9633cebef93ce79306714b218293.jpg)



Fig. 1: Mapa de nivel de amenaza meteorológica


## Lluvias y Tormentas Eléctricas

## Vigencia: desde 16H30 del 12 de enero hasta 23H00 del 16 de enero 2022

Se prevé la presencia de precipitaciones de intensidad variable en varios sectores del Ecuador continental. Es probable que los episodios de mayor consideración se registren entre el jueves 13 y sábado 15 de enero de 2022. 

En la región Litoral, los mayores acumulados de precipitación se enfocarán al norte y zona interior, acompañados de tormentas ocasionales y presencia de niebla. 

En la Amazonía, los eventos de lluvia se concentrarán en localidades de estribación de la cordillera con tormentas dispersas. 

En la región Interandina, las lluvias más relevantes se enfocarán en las provincias del norte y sur de la región. 

## ZONAS AFECTADAS:

Litoral: Mayor énfasis al norte e interior (Esmeraldas, Sto. de los Tsáchilas, Los Ríos y Guayas). Lloviznas dispersas en el perfil costero. 

Callejón Interandino: Lluvias dispersas a lo largo de la región, en general entre ligera y moderada intensidad. 

Amazonía: Los eventos más intensos se concentrarán en estribaciones de la cordillera centro y sur. 

FUENTE: INAMHÍ 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/8ad839254b0044b6fbcb180de176f0cc6afa96d9750e685e73eac6a995ac935c.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>05:22</td><td>3.5</td><td>91.6 MLv</td><td>a 4.07 km de la Maná Cotopaxi</td><td>No</td></tr></table>

## Monitoreo de eventos peligrosos (emergencias y desastres)


Incendio Forestal


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/bd8b7ea1f4eee59a16ac45a0f6dcf2b5dfc64b1abbb3208993960be590a07241.jpg)


<table><tr><td>Localización:</td><td>Zona 4 / Manabí / San Vicente / Canoa / Playa Punta Napo</td></tr><tr><td>Antecedentes:</td><td>Se encuentra en curso un incendio forestal</td></tr><tr><td>Situación actual:</td><td>Incendio forestal activo</td></tr><tr><td>Afectaciones:</td><td>---</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Manta, Portoviejo, San Vicente, Sucre y Chone realizaron trabajos de sofocación y control del flagelo.Cuerpo de Bomberos San Vicente en horas de la mañana procederá con la respectiva inspección del lugar.SNGRE monitorea el evento</td></tr><tr><td>Fuentes de información:</td><td>Cuerpo de Bomberos San Vicente /SNGRE Unidad de Monitoreo Manabí</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 3 de 14

## Inundación

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/549a5bd2dc158daa6ff0e48f624fc8d8649de90730beda82fdbc64cfabec2542.jpg)


<table><tr><td>Localización:</td><td>Zona 4 / Santo Domingo de los Tsáchilas /Santo Domingo /Río Verde / Vía Quevedo km 7, entrada a la comuna Chigüilpe.</td></tr><tr><td>Antecedentes:</td><td>El 12/01/2022 producto de lluvias se suscitó el taponamiento de alcantarillas que provocó el ingreso de agua en varias viviendas del sector.</td></tr><tr><td>Situación actual:</td><td>El nivel de agua ha disminuido, las familias afectadas permanecen en las viviendas.</td></tr><tr><td>Afectaciones:</td><td>8 viviendas afectadas.8 familias afectadas.1 bien privado afectado (colapso de cerramiento)</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos, se movilizó al lugar a realizar la extracción del agua de las viviendas, SNGRE coordinó con la UGR GAD Cantonal la evaluación de daños y la limpieza del alcantarillado del sector.</td></tr><tr><td>Fuentes de información:</td><td>Cuerpo de Bomberos Santo Domingo/ SNGRE unidad de Monitoreo Santo Domingo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/18908e69c145841cd4d7fa498f91d9fbe8b850dae8bccd5a3c8088c34acd2a67.jpg)


## Actividad volcánica

<table><tr><td>Localización:</td><td>Zona 5 /Galápagos/Isabela / Tomas de Berlanga / Norte de la Isla.</td></tr><tr><td>Antecedentes:</td><td>Según reporte del IG. a las 23h20 del 06/01/2022 inició un proceso eruptivo el Volcán Wolf, el mismo que se encuentra al norte de la Isla Isabela. Cabe mencionar que no existen poblaciones cercanas al volcán y se han dado varias emisiones de material volcánico durante estos días.</td></tr><tr><td>Situación actual:</td><td>El 12/01/2022 IGPEN informó que según el mapa preliminar de la erupción, con base en las imágenes satelitales de Planet Scope y Sentinel-2, el flujo o flujos de lava han cubierto un área aproximada de 7.6 km2. El alcance máximo estimado de los flujos de lava es de 16.5 km desde el vento de mayor altura y 15 km desde la fisura activa, por consiguiente, se considera que, al momento los flujos de lava no lograron llegar al mar.</td></tr><tr><td>Afectaciones:</td><td>Hasta el momento sin afectaciones.</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE- Unidad de Monitoreo / Respuesta da seguimiento a la novedad reportada.El COE Provincial se encuentra activo</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ5 Unidad de Monitoreo / Unidad de Preparación y Respuesta Galápagos</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/9194eeed5b0459fa5dda9f229a1633c7e681dfde4f8ffd570db9357033e76497.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Zona 7/Loja/Loja/Taquil/Naranjito, vía a La Guangora</td></tr><tr><td>Antecedentes:</td><td>EL 23/12/2021, por lluvias se produjo el desbordamiento de una quebrada que provocó el arrastre de material pétreo y flujos de lodo. Como consecuencia del aumento de caudal, personas que transitaban por el sector fueron arrastradas.</td></tr><tr><td>Situación actual:</td><td>La vía de segundo orden se encuentra habilitada, organismos de socorro debido a solicitud de comuneros realizaran labores de búsqueda el día sábado 15/01/2022 siendo este el último día de búsqueda.</td></tr><tr><td>Afectaciones:</td><td>3 personas fallecidas.1 persona desaparecida.30 metros lineales aproximadamente.</td></tr><tr><td>Acciones de respuesta:</td><td>Teniente Político de Taquil y Personal de Cuerpo de Bomberos, mantuvieron una reunión el domingo 09/01/2021 en el que se resolvió la suspensión de las tareas de búsqueda y rescate</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/ Cuerpo de Bomberos Loja</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/d0d14b836b83bb6e7fa3c06cd61b8a42fffc487cb6d138c3e77b77e75c71683a.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 1/Imbabura/Ibarra/Carolina/San Jerónimo; vía Salinas - Lita [E 10]</td></tr><tr><td>Antecedentes:</td><td>El 22/12/2021 en horas de la madrugada, producto de las fuertes precipitaciones se registró un deslizamiento que afectó la vía de primer orden y represó el río Mira.</td></tr><tr><td>Situación actual:</td><td>La vía se mantiene cerrada al tránsito vehicular</td></tr><tr><td>Afectaciones:</td><td>125 metros lineales.2 postes de hormigón de telecomunicaciones.Colapso de la mesa de la vía en un tramo de 50 metros.40 vehículos (ya fueron evacuados del sector).1 persona fallecida.</td></tr><tr><td>Acciones de respuesta:</td><td>Comuneros del sector construyeron una tarabita para transportar, motocicletas y toda clase de productos de montaña a montaña, MTOP, GAD Provincial de Imbabura, GAD Cantonal Ibarra, GAD Parroquial Carolina</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 4 de 14

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/c1d543766decafedac7948950795075df514472566f09d3940a24a20473bb47b.jpg)


<table><tr><td></td><td>continúan realizando los trabajos de remoción de escombros y habilitación vial.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/GAD Cantonal Ibarra, MTOP.</td></tr></table>

## Hundimiento

<table><tr><td>Localización:</td><td>Zona 7/El Oro/Zaruma/Zaruma/calles Colón y 10 de Agosto</td></tr><tr><td>Antecedentes:</td><td>La noche del miércoles 15 de diciembre de 2021 se produjo un hundimiento en las calles Colón y Ernesto Castro, zona de la ciudad de Zaruma categorizada como Riesgo Muy Alto según el “Mapa de Riesgos por Desplazamientos del terreno en la ciudad de Zaruma”, elaborado por el SNGRE en marzo del 2020. Se produjo un hundimiento que afectó a varias viviendas</td></tr><tr><td>Situación actual:</td><td>Agencia de Regulación y Control de Energía y Recursos Naturales no Renovables (ARCERNR) realiza la demolición de dos chimeneas (ingreso a las minas), Cuerpo de Ingenieros del Ejército realizó una reunión técnica con SNGRE, Instituto de Investigación Geológico y Energético (IIGE), Comité empresarial Ecuatoriano (CEE) y Empresa privada, para definir el diseño final y cronograma de actividades para la construcción del tapónGAD Municipal Zaruma, MDG y empresa privada continúan realizando trabajos diarios; para el paso de aire, agua, electricidad y comunicación hacia el subsuelo que es donde se realizarán los trabajos de instalación de un tapón que sostiene material colapsado y para soluciones de relleno hidráulicoMTT-7 mantiene reunión virtual donde se analiza la implementación de un protocolo para alerta ciudadanaReunión de MTT 4 para seguimiento a los acuerdos y compromisos planteados.Realizar intervención de sensibilización según cronograma establecido a los moradores de la calle Rocafuerte y Gonzalo Pizarro</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas en sus estructuras.- 4 viviendas destruidas (3 de patrimonios culturales).- 3 viviendas en riesgo.- 107 familias de 272 personas afectadas que habitan en la zona de peligro.- 15 familias de 37 personas damnificadas (evacuadas y se encuentran en casa acogiente).- 3 calles afectadas. (Calle Colón por hundimiento y las calles 29 de noviembre y Ernesto Castro por agrietamientos).- 25% del servicio de energía eléctrica afectado.- Centro anidado de MSP evacuó por precaución a dar atención al Hospital Humberto Molina.- Los servicios públicos que brindan en el edificio del municipio y del BanEcuador debido a la cercanía al evento fueron suspendidos por precaución.- 2 bienes privados afectados (1 vehículo que se encontraba estacionado se precipitó al foramen y club colón presenta fisuras).- 1% del sistema de telecomunicaciones se encuentra afectado.- 2 bienes públicos afectados: parque con fisuras y poste de alumbrado destruido.</td></tr><tr><td>Acciones de respuesta:</td><td>COE Nacional, Provincial y Cantonal se mantienen activos para articular acciones en atención al eventoCB Zaruma continúa con la revisión visual de las calles y prestando apoyo a las entidades correspondientes para el ingreso del personal en las minasPersonal policial se encuentra cubriendo las vías de acceso aledañas al socavón ubicado en puntos estratégicos &quot;check point&quot; en los lugares de mayor afluencia de personas, así mismo cubre las vías de ingreso al cantón de zaruma, personal del Grupo Especial Móvil Antinarcóticos (GEMA) realiza inspecciones en el área de exclusión minera personal del Unidad de Policía del Medio Ambiente (UPMA) realiza control forestalInstituto geológico militar realiza el levantamiento topográfico, medición del área afectada, estudio Multitemporal, monitoreo de los componentes Horizontales y verticales de la red GeodésicaCuerpo de ingenieros del ejército, instalan escaleras en el rebaje, realizan la Voladura de un muro en la mina Pacchapamba Sra. Silvana, para pasar a la zona de exclusión y realizar voladuras en pasos clandestinos, adicional se Instaló energía eléctrica y cámaras para seguridad adicional a ello se realizó el ensamblaje de la estructura que servirá para la contención de taludes en la zona del hundimiento</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 5 de 14

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/38dd1fe11b7dd004314030fdd91a152cc3f14aafd46707b7561c2a6ed1638e71.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 1/Imbabura/Urcuquí/Buenos Aires/San José</td></tr><tr><td>Antecedentes:</td><td>El 14/12/2021, producto de las fuertes precipitaciones registradas en la madrugada, se presentaron deslizamientos que afectaron a viviendas y red vial de tercer orden, causando pérdida de enseres a las familias y afectó a las actividades económicas a los productores de leche y frutas debido a que no pueden transportar sus productos.</td></tr><tr><td>Situación actual:</td><td>El acceso vial de La Primavera - San José se encuentra inhabilitada.</td></tr><tr><td>Afectaciones:</td><td>11 familias, 44 personas afectadas.3 familias, 14 personas damnificadas.3 viviendas destruidas.11 viviendas afectadas.70 metros lineales.</td></tr><tr><td>Acciones de respuesta:</td><td>- COE Cantonal Urcuqui se activó el 21/12/2021 con les representantes de todas las MTT.- SNGRE-UMEVA coordinó con personal del GAD Cantonal Urcuqui - UGR para que se realice levantamiento de la información (EVIN) y actualizaciones periódicas.- GAD Parroquial de Buenos Aires, GAD Provincial de Imbabura y MTOP realizan trabajos de limpieza y habilitación vial.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/SNGRE CZ1 UPREA/GAD Parroquial Buenos Aires/GAD Provincial Imbabura/ MTOP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/8f2731dc0e27c8de2e09cefcfca6116f5981a01fd1331c430fc1c88046c181f6.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Zona 3/Chimborazo/Guano/Matriz/Barrios La Merced, La Dolorosa del Cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu Santo, La Dolorosa Centro, Santa Terecita (Balneario Los Elenes)</td></tr><tr><td>Antecedentes:</td><td>El 11/12/2021, por las lluvias registradas en el sector se produjo un aluvión que afectó viviendas y calles de la zonaEn atención al evento reportado se activó el COE Cantonal y el COE Provincial</td></tr><tr><td>Situación actual:</td><td>Se realizan trabajos de encausamiento del río Guano</td></tr><tr><td>Afectaciones:</td><td>- 64 familias afectadas en infraestructura agropecuaria (256 personas)- 4 ha de cultivos afectados.- 5 ha de cultivos perdidos.- 45 animales afectados.- 8 familias afectadas en infraestructura (18 personas).- 25 familias damnificadas (91 personas).- 28 viviendas afectadas.- 5 viviendas destruidas.- 1 puente afectado.- 1 puente destruido.- 2 bienes públicos afectados.- 2 animales muertos.- 40% de locales del cantón afectados (comerciales y artesanías).- Red de agua potable: 60% afectada. (reparado en un 100%).- Red de alcantarillado sanitario y pluvial: 60% afectada. (reparada en un 90%).- 9000 metros de vía afectada (habilitada)</td></tr><tr><td>Acciones de respuesta:</td><td>Obras Públicas del GAD Cantonal Guano realizó la limpieza de las vías y al momento se encuentran habilitadas en su totalidad.Puente de Los Elenes tiene habilitado un solo carril.SNGRE CZ3 en cooperación con la Academia UCE, y en coordinación con la Gobernación de Chimborazo y el GAD Cantonal de Guano, se efectuó actividades en territorio para el análisis de Riesgos en el cerro Igualata, cantón Guano, con la finalidad de continuar con los estudios sobre las causas que originaron el aluvión el sector.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ3 Unidad de Monitoreo Chimborazo/UPREA SNGRE CZ3</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/3084bf7ccf4830773a11da3a61054b452c55675744957578fcc240c0045f3510.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 1/Imbabura/Pimampiro/Pimampiro/San José de Aloburo</td></tr><tr><td>Antecedentes:</td><td>El 09/11/2021, debido a las lluvias y a la presencia de fallas geológicas se registró afectaciones a la red vial y viviendas del sector. El 19/11/2021 se declaró la Situación de Emergencia en el cantón</td></tr><tr><td>Situación actual:</td><td>Se trabaja en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad. La nueva vía tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su Cabecera Cantonal.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 6 de 14

<table><tr><td>Afectaciones:</td><td>6 invernaderos colapsados (de aguacates, mandarinas y duraznos); Canales secundarios colapsados.800 metros de red eléctrica, 3 postes colapsados.Red de distribución de agua colapsada.500 metros, que conecta San José con Aloburo.12,43 hectáreas de cultivos destruidos y 37,57 ha de pastos afectados.23 familias damnificadas fueron evacuadas (10 en la Escuela del Tejar, 3 en la Unidad Educativa Pimampiro y 10 en familias acogientes).12 viviendas destruidas.6 viviendas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR GAD cantonal Pimampiro informa que por decisión de la Máxima Autoridad están a la espera de los estudios que se encuentran realizando las siguientes instituciones: SNGRE, YACHAY, Universidad Central (FIGEMPA), GAD Provincial de Imbabura, encargados de determinar la zona de influencia directa que se encuentra en riesgo y posterior a ello tomar acciones para la rehabilitación y reconstrucción de la infraestructura de la población afectada y damnificada.</td></tr><tr><td>Eventos de información:</td><td>SNGRE, G71 Unidad de Monitario Imbabura, Corshi (GAD UGR Pimampiro)</td></tr></table>

Fuentes de Información: SNGRE CZ1 Unidad de Monitoreo Imbabura-Carchi/GAD UGR Pimampiro 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/27ddd3ccf735d8125afb182acd5958b32530f8e38d0e16d76bd7b6b73baf2854.jpg)


## Avalancha

<table><tr><td>Localización:</td><td>Zona 3/Chimborazo/Riobamba/San Juan/El Arenal, Nevado Chimborazo</td></tr><tr><td>Antecedentes:</td><td>El 24/10/2021, se produjo una avalancha que afectó a un grupo de montañistas</td></tr><tr><td>Situación actual:</td><td>Se está a la espera del ascenso por parte de las instituciones competentes.</td></tr><tr><td>Afectaciones:</td><td>3 personas fallecidas7 personas rescatadas3 personas heridas3 personas desaparecidas</td></tr><tr><td>Acciones de respuesta:</td><td>Se está a la espera del ascenso al nevado el día de hoy 12/01/2022 y continuar la búsqueda.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ3 Unidad de Monitoreo Tungurahua/SNGRE CZ3</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/a6a7e57416f1dad0e053bcd55cb86762c6f978d0fc6b8e50bebe5246bcda606c.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 6/Azuay/Cuenca/Molleturo/Km 49, vía Cuenca-Molleturo-Naranjal [E-582]</td></tr><tr><td>Antecedentes:</td><td>Desde el 17/10/2021 hasta la fecha se han registrado varios deslizamientos que han ocasionado diferentes afectaciones en el sitio</td></tr><tr><td>Situación actual:</td><td>La vía se encuentra habilitada desde las 05h00 hasta las 18h30, las noches permanece cerrada por precaución.</td></tr><tr><td>Afectaciones:</td><td>13/11/20211 vehículo afectado2 personas heridasvía cerrada04/11/202140 metros de la vía afectada22/10/20211 vehículo afectado1 persona herida17/10/20211 vehículo afectado2 personas heridas1 persona fallecida</td></tr><tr><td>Acciones de respuesta:</td><td>Personal de Comisión de Tránsito colabora con el tránsito vehicular.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/CTE/MTOP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/4be46f43cdd826f6c73e0b93e059fed04cf8a209dc5bec1b8a913fbb8cb7b5a9.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Zona 6/Azuay/Sevilla de Oro/Amaluza/Km 76, vía Paute- Guarumales-Méndez [E-40]</td></tr><tr><td>Antecedentes:</td><td>El 02/06/2021 por lluvias se produjo el desbordamiento de la quebrada Jurupis ocasionando un aluvión que afectó la vía de primer orden</td></tr><tr><td>Situación actual:</td><td>El 10/12/2021, MTOP realizó la suspensión de la circulación vehicular que se extenderá hasta recuperar la zona afectada, por el lapso de 6 a 8 semanas</td></tr><tr><td>Afectaciones:</td><td>2 viviendas presentaron socavamientos en sus bases y cuarteaduras en sus paredes (inhabitables)3 familias damnificadas (2 familias habitan en una sola vivienda y 1 en la otra vivienda con un total de 8 personas: 6 adultos y 2 menores de edad)</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 7 de 14

<table><tr><td></td><td>permanecen en el albergue ubicado en los terrenos de la Junta Parroquial de Amaluza.100 metros lineales de vía de primer orden</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP continua con los trabajos de mantenimiento de la vía</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/MTOP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/b8099c0db3a55b31ec32c4bd6685546f47449fe2f8f010335d8da7f7443ea1fd.jpg)



Socavamiento


<table><tr><td>Localización:</td><td>Zona 2/Orellana/Francisco de Orellana/El Coca/Barrios Río Coca, Perla Amazónica, Cambahuasi y Unión y Progreso.</td></tr><tr><td>Antecedentes:</td><td>Desde el 17/05/2021 el proceso erosivo y sedimentación en el río Coca pone en riesgo a varias viviendas e infraestructura ubicada en la ribera</td></tr><tr><td>Situación actual:</td><td>Con fecha 12/01/2022 se reunió el COE Provincial para realizar seguimiento de las actividades realizadas por las MTT y GT. El nivel del río Coca se encuentra nivel bajo</td></tr><tr><td>Afectaciones:</td><td>1 familia evacuada - 7 personas en alojamiento temporal1 familia evacuada - 4 personas con familia acogiente.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial de Pichincha por gestión del SNGRE se encuentra apoyando con maquinaria para los trabajos de mitigación que está realizando el GAD Municipal de Francisco de Orellana.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ2 Unidad de Monitoreo Napo-Orellana/Cruz Roja Ecuatoriana/GAD Cantonal Francisco de Orellana/GAD Provincial de Orellana</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/6e4c0c7f9a30b9505b684af00ca0cac1caf242f715b2238b68be5b396f8e25f6.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>Zona 6/Azuay/Nabón/Nabón/Barrios Rosas, Bellavista, Tamboloma, Chunazana, Rosario</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2021 se reportó un movimiento de masa provocado por la filtración de agua de riego y la temporada lluviosa. El 23/11/2021 el Servicio Nacional de Gestión de Riesgos y Emergencias declaró la Alerta Naranja por movimientos en masa en el área de 130,94 hectáreas que comprende los barrios Rosas, Bellavista, Chunazana, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 11/01/2022 técnico del Servicio Nacional de Gestión de Riesgos y Emergencias de forma conjunta con Unidad de Gestión de Riesgos Girón realizan la entrega de 81 botellones de agua y 700 pastillas purificadoras a la población afectada.Con fecha 03/01/2022 técnico de UGR Nabón informa que se ha procedido a evacuar 2 viviendas más adicionales a las 35 viviendas ya reportadas, adicional informa que continúan los trabajos en la vía Nabón - La Ramada en el sector la Quebrada del Canal, la misma se encuentra parcialmente habilitada.</td></tr><tr><td>Afectaciones:</td><td>60 metros de vía afectados (Vía Parcialmente Habilitada)37 familias integradas por 112 personas afectadas aproximadamente1 Casa comunal afectada con cuarteaduras37 viviendas afectadas (las familias evacuadas se alojan en diferentes medios de alojamiento como arriendos o familias de acogida)Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)Iglesia demolida por los daños estructurales presentadosCentro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>Técnico de UGR Nabón se mantiene en continúo monitoreo de la zona afectada, maquinaria de Obras Públicas realiza trabajos en la vía SNGRE CZ6 realizó entrega de asistencia humanitaria a familias afectadas.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/cdf48675815afbb4b59d12b3104ae15b5ddd71072c7fcdb1c68ec5da7fc3ecd5.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Zona 3/Chimborazo/Chunchi/Chunchi/La Armenia, río Guataxi afluente del río Chanchán, vía Chunchi - La Armenia - Huigra.</td></tr><tr><td>Antecedentes:</td><td>El 12/02/2021 debido a las lluvias registradas en el sector se produjo el taponamiento del río Guataxi, que es afluente del río Chanchán, se reportó pérdida de animales vacunos y de especies menores.</td></tr><tr><td>Situación actual:</td><td>Autoridades del SNGRE y del GAD Cantonal Chunchi mantuvieron una reunión con el fin de seguir trabajando en la socialización a la población sobre el riesgo del deslizamiento en el sector de La Armenia.</td></tr><tr><td>Afectaciones:</td><td>255 personas afectadas directamente.68 familias afectadas directamente.30 viviendas destruidas.30 familias (89 Personas damnificadas), el día 25/10/2021 desalojaron el albergue en su totalidad.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 8 de 14

<table><tr><td></td><td>38 viviendas afectadas; 86 Familias (329 Personas evacuadas).2 personas aisladas con atención pre-hospitalaria.2 bienes públicos afectados: (red de alcantarillado y planta de tratamiento de aguas residuales (solventado), 50 % del sistema de agua potable afectado (solventado), sistema de riego, línea férrea.2 puentes de la vía de tercer orden.1 bien público destruido (estación hidrológica del INAMHI h0375 Chanchán DJ Guataxi).115 hectáreas de cultivos destruidos.718 animales de granja afectados.689 animales de granja muertos.</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE y el GAD Cantonal Chunchi coordinaron acciones de socialización sobre el riesgo del deslizamiento en el sector.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ3 Unidad de Monitoreo Chimborazo/MPCEIP.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/d3877ae83091ab5309dee3a73b7652f26c104ecad5e6d72e6e4b47dc1c6cce14.jpg)


<table><tr><td>Localización:</td><td>Zona 2/Orellana/La Joya de Los Sachas/San Sebastián Del Coca/San Sebastián Del Coca Zona Urbana, Toyuca, Sardinas, vía La Joya de Los Sachas - El Coca [E45A]</td></tr><tr><td>Antecedentes:</td><td>El 08/02/2021, a causa de las lluvias suscitadas se produjo un socavamiento el cual afectó la orilla del río Coca en la comunidad Toyuca, situación que aumentó de forma significativa, adicional se reportó afectación en las bases del puente sobre el río Coca</td></tr><tr><td>Situación actual:</td><td>El proceso erosivo avanza de forma lenta. No se han registrado lluvias que causen un aumento considerable del río Coca como en los meses anteriores</td></tr><tr><td>Afectaciones:</td><td>1 familia damnificada1 persona evacuada1 puente afectado</td></tr><tr><td>Acciones de respuesta:</td><td>El 15/12/2021, SNGRE en coordinación con varias Instituciones como MSP, MINEDUC, Cuerpo de Bomberos, PPNN del Cantón de La Joya de Los Sachas, participaron en una reunión de trabajo para revisar los planes de respuesta de las MTT y GT ante la sedimentación y erosión del río Coca de acuerdo a los compromisos acordados en el COE Cantonal de La Joya de Los Sachas.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ2 Umeva-Napo-Orellana</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/44517cf005071a9323adfb39854ea488aa139c0de62bd83d2d6c8eced76281cd.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Zona 5/Bolívar/Chimbo/Cabecera Cantonal/barrio Tamban</td></tr><tr><td>Antecedentes:</td><td>Desde marzo del 2020 se muestra una serie de grietas y fallas que van desde el pavimento de la cancha de uso múltiple hasta la iglesia, además mantiene una concordancia longitudinal con otras grietas observadas en la vía Chimbo-El Cristal, producto de aguas de infiltración, saturación de los elementos expuestos y además incide la falta de mantenimiento a la infraestructura hidrosanitaria.La noche del 21/12/2021 debido al proceso activo del hundimiento, se produjo el colapso del muro que se encontraba en la parte superior de la calle adoquinada, causando la pérdida total de la plataforma de la vía de primer. El 23/12/2021 sesionó el COE Cantonal y resolvió declarar en Emergencia Grave al Barrio Tambán, Parroquia Central San José, cantón Chimbo, Provincia Bolívar por el lapso de 60 díasEl 10/01/2022 se trasladó los enseres del hogar de la familia que estaba en el albergue a un lugar de arriendo, por tal razón procedieron a cerrarlo. Además, autoridades socializarán a los moradores del sector la construcción del paso alterno provisional</td></tr><tr><td>Situación actual:</td><td>Con fecha 12/01/2022 se continúa realizando el estudio geofísico para evidenciar características y condiciones del subsuelo; en el que se contó con el apoyo logístico del C.B. Chimbo.CZ5 del SNGRE realizó visita de seguimiento a las familias que están en el sito de alojamiento temporal y recorrido por la zona afectada. Adicional se realiza revisión de luminarias y se realizan trabajos de alcantarillado de aguas servidas.Con fecha 11/01/2022 técnicos del SNGRE, de la Universidad Estatal de Bolívar (UEB) y del GAD Cantonal Chimbo dieron inicio con los trabajos en la zona cero para determinar la presencia de nuevas fisuras en el sector, adicional indican que la construcción del paso alterno provisional quedó sin efecto.</td></tr><tr><td>Afectaciones:</td><td>- 2 viviendas destruidas (2 familias damnificadas 7 personas; de las cuales se encuentran arrendando).</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 9 de 14

<table><tr><td></td><td>- 3 viviendas afectadas (3 familias afectadas 16 personas; de las cuales 1 familia 10 personas se encuentran en el albergue de la U.E La Asunción, 2 familias 6 personas se encuentran arrendando).- 1 bien privado destruido (iglesia)- 8 bienes públicos destruidos (1 concha acústica -salón de reuniones, 1 cancha deportiva, 4 postes, tubería de agua que abastece a las comunidades de Panchigua, Tingo y Miraflores, alcantarillado de la zona cero)- 150 metros de vía de primer orden Chimbo-El Cristal destruida.- 60 metros de la calle S/N adoquinada destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>- Técnicos del SNGRE, Unidad de Gestión de Riesgos de la Universidad Estatal de Bolívar (UEB) y Unidad de Gestión de Riesgos del GAD Cantonal Chimbo continúan realizando el estudio geofísico, aplicando tomografía eléctrica para evidenciar características y condiciones del subsuelo.- C.B. Chimbo brindó apoyo logístico al equipo técnico- EMAPA Chimbo, continua con los trabajos de alcantarillado de aguas servidas desde otro frente.- CZ5 del SNGRE realiza visita de seguimiento a las familias del albergue de la U.E. La Asunción y recorrido por la zona afectada.- CNEL-Bolívar realizar revisión de luminarias en la zona afectada.- Policía Nacional permanece guiando al tránsito vehicular por las rutas alternas.- Fuerzas Armadas continúa dando seguridad en la zona cero.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad Monitoreo Bolívar/GAD Provincial/MIES/FFAA</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/c6012f0908ef9bb30b00ba7055502dfebb836d44295df429f1a4a9779a1b67b1.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Zona 2/Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina, San Luis, vía Y de Baeza-Lago Agrio [E45]</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos como la Red Estatal Vial E45, Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.</td></tr><tr><td>Situación actual:</td><td>Dos familias ubicadas en San Luis fueron evacuadas hacia la ciudad de Lago Agrio y tercera familia desde el limite provincia hasta la el cantón El Chaco. San Rafael continúa sin servicio eléctrico. El paso vehicular por la vía Baeza Lago Agrio está cerrada, la ruta alterna Y de Baeza-Y de Narupa-Loreto-El Coca-Lago Agrio está habilitada</td></tr><tr><td>Afectaciones:</td><td>20/12/20211 familia (10 personas) evacuadas13/12/2021Rotura de la tubería de Poliducto y suspensión del bombeo.10/12/2021Población de San Rafael sin energía eléctrica.03/12/2021Puente sobre el río Piedra Fina 2 en riesgo.21/11/20211 tubería de agua afectada.19/05/20211 puente destruido (puente denominado Ventana 2)18/05/20212 viviendas destruidas (las familias fueron las evacuadas en febrero del 2021)10/03/20211 bien afectado (tanque de agua)27/02/20212 familias damnificadas y evacuadas a alojamiento temporal. Actualmente están en arriendo2 viviendas presentaron fisuras22/10/20201 puente destruido (puente sobre el río Montana)06/05/20202 familias afectadas, 2 viviendas afectadas07/04/20203 bienes afectados (tuberías del SOTE, Poliducto Shushufindi- Quito y al OCP)</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 10 de 14

<table><tr><td></td><td>Afectación vial: las pérdidas y afectaciones relevantes en vías ocurrieron el 03/12/2021, 18/05/2021, 20/04/2021, 22/10/2020, 22/08/2020 y 04/06/2020 con un total de 875 metros de la vía E45.Afectación agropecuaria: durante algunos meses se ha identificado 63.95 ha de superficie agrícola perdida y 21 bovinos, 63 porcinos y 3000 tilapias perdidas.</td></tr><tr><td>Acciones de respuesta:</td><td>El 30/06/2021 el Alcalde del cantón El Chaco resolvió ratificar la declaratoria de emergencia en la comunidad de San Luis ubicado en la parroquia Gonzalo Díaz de Pineda, cantón El Chaco y demás zonas de influencia, a fin de establecer acciones inmediatas para atender la emergencia.Se mantiene el nivel de alerta roja en el tramo comprendido entre las obras de captación de la Central Hidroeléctrica Coca Codo Sinclair, ex cascada de San Rafael y el túnel de descarga de la Central, que se extiende entre las provincias de Napo y Sucumbíos.SNGRE CZ2, CZ1, CZ9 en coordinación con el GAD Cantonal El Chaco y el apoyo del Cuerpo de Bomberos de Santo Domingo se encuentran evacuando a dos familias ubicadas en San Luis hasta la ciudad de Lago Agrio y otra familia de limite Sucumbíos hacia el cantón El Chaco. SNGRE CZ2 mantendrá reunión virtual con MDG, MTOP para analizar donde va ser construido la vía para unir las dos provincias de Napo y Sucumbíos.</td></tr><tr><td>Fuentes de Información:</td><td>SNGRE CZ2 Umeva Napo/Orellana/OCP Ecuador/MTOP/Empresa Eléctrica Quito SA - Orellana</td></tr></table>

## 3 Monitoreo de estado de vías afectadas por eventos peligrosos

VÍAS DE PRIMER ORDEN: 

## 04 vías de primer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>125</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>Sevilla de Oro</td><td>Amaluza</td><td>Km 76, vía Paute-Guarumales-Méndez [E-40]</td><td>ALUVIÓN DESLIZAMIENTO</td><td>875</td><td>02/06/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr><tr><td>3</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo, Cabecera Cantonal</td><td>barrio Tamban</td><td>HUNDIMIENTO</td><td>210</td><td>18/03/2020</td><td>Chimbo, San Miguel, San Pablo y Balsapamba</td></tr><tr><td>4</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, San Luis, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>855</td><td>02/02/2020</td><td>Sucumbíos - Coca-Narupa-Baeza-Papallacta - Quito</td></tr></table>


24 vías de primer orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Morona Santiago</td><td>Limón Indanza</td><td>Yunganza (cabecera en el Rosario)</td><td>Yananas, vía Bella Unión-Limón [E45].</td><td>DESLIZAMIENTO</td><td>50</td><td>12/01/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 115+500 Vivar [E-59]</td><td>DESLIZAMIENTO</td><td>30</td><td>03/01/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Morona Santiago</td><td>Limón Indanza</td><td>Yunganza (cabecera en el Rosario)</td><td>San Antonio, vía Bella Unión-Limón [E45]</td><td>DESLIZAMIENTO</td><td>160</td><td>29/12/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>10 de Agosto, vía Loreto - Tena [E45A-E20]</td><td>DESLIZAMIENTO</td><td>80</td><td>17/12/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>El Chaco</td><td>El Chaco</td><td>Quebrada Macanas, vía Y de Baeza-El Chaco [E45]</td><td>SOCAVAMIENTO</td><td>50</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>80</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Napo</td><td>Tena</td><td>Chontapunta</td><td>Rayayacu, vía Chontapunta - Los Zorros - La Belleza [E436]</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>17/11/2021</td><td>Humuyacu-Yuralpa Derecho-Wachayacu</td></tr><tr><td>8</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 49, vía Cuenca-Molleturo-Naranjal [E582]</td><td>DESLIZAMIENTO</td><td>40</td><td>17/10/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Manabí</td><td>Jipijapa</td><td>Jipijapa</td><td>Quimís- vía Colón-Quimís [E4-82]</td><td>COLAPSO ESTRUCTURAL</td><td>25</td><td>14/10/2021</td><td>Manabí hacía Guayas E482 sector Pila-Los</td></tr></table>

# Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025
Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 11 de 14


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Bajos de Montecristi-E15 -Puerto Cayo-Jipijapa -Jipijapa hacia Portoviejo E-482 - Rcto. Colón Quimís- vía de Tercer Orden-E462B Santa Ana-Portoviejo</td></tr><tr><td>10</td><td>Esmeraldas</td><td>San Lorenzo</td><td>San Lorenzo, Cabecera Cantonal</td><td>La Florida km9, vía San Lorenzo - Ibarra [E10]</td><td>SOCAVAMIENTO</td><td>10</td><td>28/08/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Nuevos Horizontes, vía Méndez-Guarumales [E40].</td><td>DESLIZAMIENTO</td><td>100</td><td>01/07/2021</td><td>Limón-Gualaceo</td></tr><tr><td>12</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza</td><td>Sector Tucumbatza, vía Gualaquiza-San Juan Bosco [E45] (Primer Orden).</td><td>HUNDIMIENTO</td><td>50</td><td>30/06/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>14</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Via Macas-Puyo [E45], Tramo Puente Sobre El Río Copueno-Puente Sobre El Río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Y de Santa Ana-Sevilla-Seipa-Sucúa-Macas</td></tr><tr><td>15</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Copueno, vía Macas-Puyo [E45]</td><td>SOCAVAMIENTO</td><td>120</td><td>30/04/2021</td><td>Ninguna</td></tr><tr><td>16</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km. 101, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>12</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>17</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>18</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>19</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>20</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>SOCAVAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>21</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>22</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr><tr><td>23</td><td>Orellana</td><td>La Joya De Los Sachas</td><td>San Sebastián del Coca</td><td>Toyuca, Sardinas, Sebastián del Coca, vía La Joya de los Sachas - El Coca [E45A]</td><td>SOCAVAMIENTO</td><td>--</td><td>08/02/2021</td><td>Ninguna</td></tr><tr><td>24</td><td>Morona Santiago</td><td>Santiago</td><td>Patuca</td><td>Loma Seca vía Patuca - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>15</td><td>15/01/2020</td><td>Ninguna</td></tr></table>


VÍAS DE SEGUNDO ORDEN:



04 vías de segundo orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Pelligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Loja</td><td>Saraguro</td><td>Urdaneta (Paquishapa)</td><td>El Rodeo, vía Urdaneta-Yacuambi</td><td>SOCAVAMIENTO</td><td></td><td>23/12/2021</td><td>Urdaneta-Bahim-Yacuambi</td></tr><tr><td>2</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo.</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>3</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Alluriquín</td><td>Cristal del Lelia-Vía a los libres</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>11/02/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025 Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 12 de 14

## 13 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Pelligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Chimborazo</td><td>Guano</td><td>La Matriz</td><td>Barrios La Merced, La Dolorosa del cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu santo, La Dolorosa Centro, Balneario Los Elenes</td><td>ALUVIÓN</td><td>--</td><td>11/12/2021</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>Cuenca</td><td>San Sebastián</td><td>Calle del Molino</td><td>DESLIZAMIENTO</td><td></td><td>29/11/2021</td><td>Ninguna</td></tr><tr><td>3</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>Chaquisca, vía Guanujo-Las Cochas</td><td>DESLIZAMIENTO</td><td>30</td><td>09/11/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Zamora Chinchipe</td><td>Zamora</td><td>Cumbaratza</td><td>Tunantza Alto, vía Timbara Bajo-Timbara Alto.</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/10/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Puente Salado Grande, vía Macas-Riobamba-tramo 9 de Octubre-Cebadas [E46].</td><td>DESLIZAMIENTO</td><td>60</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Km 78, vía Macas-Riobamba E46]</td><td>DESLIZAMIENTO</td><td>60</td><td>12/06/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Morona Santiago</td><td>Limón Indanza</td><td>General Leonidas Plaza Gutiérrez (Limón), cabecera cantonal</td><td>Cerro Bosco, vía Gualaceo-Limón (Segundo Orden).</td><td>DESLIZAMIENTO</td><td>50</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Chiguïnda</td><td>Granadillas, vía Sig-Sig-Chiguïnda-Gualaquiza [594]</td><td>DESLIZAMIENTO</td><td>20</td><td>15/05/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Km 35, vía Cahuají - Pillate - Cotaló [E-304].</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Pichincha</td><td>Quito</td><td>Checa (Chilpa)</td><td>Km 38+377, entrada a Checa, vía Cusubamba- Pifo</td><td>SOCAVAMIENTO</td><td>15</td><td>01/04/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Nabon</td><td>Nabón, cabecera cantonal</td><td>Rosas, Bellavista, Tamboloma, Chunazana.</td><td>DESLIZAMIENTO</td><td>60</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>Gualaquiza</td><td>El Rosario</td><td>El Aguacate, vía Sig-Sig-Chiguïnda-Gualaquiza [E594]</td><td>DESLIZAMIENTO</td><td>50</td><td>23/09/2020</td><td>Piñas-Portovelo-Zaruma</td></tr></table>


VÍAS DE TERCER ORDEN:



12 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Pellgroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Yaruqui</td><td>comuna Oyambarillo vía Coturco</td><td>DESLIZAMIENTO</td><td>--</td><td>03/01/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Vía Sucúa-Asunción</td><td>DESLIZAMIENTO</td><td>30</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>3</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Santa Rita - Getsemaní; Verde Bajo - San Francisco y Río Verde Medio.</td><td>DESLIZAMIENTO</td><td>75</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Imbabura</td><td>San Miguel de Urcuquí</td><td>Buenos Aires</td><td>Pimaqui; vía Buenos Aires - Cahuasqui</td><td>DESLIZAMIENTO</td><td>75</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Río verde Alto, vía Lita - Rioverde Alto</td><td>DESLIZAMIENTO</td><td>50</td><td>18/12/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Imbabura</td><td>Cotacachi</td><td>6 De Julio De Cuellaje (Cab. En Cuellaje)</td><td>Y de Nápoles, vía de Cuellaje – El Rosario</td><td>SOCAVAMIENTO</td><td>30</td><td>13/12/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Nueva alianza</td><td>INUNDACIÓN</td><td>7000</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia, Río Guataxi afluente del río Chanchán</td><td>DESLIZAMIENTO</td><td>--</td><td>12/02/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>--</td><td>20/01/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Morona Santiago</td><td>Palora</td><td>Cumandá (Cab. en Colonia Agrícola Sevilla del Oro)</td><td>Puente sobre el río Charuyaku</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>23/10/2020</td><td>Palora-Puyo-Cumandá</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025
Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 13 de 14 


12 vías de tercer orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquía</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Tumbaco</td><td>Sector - Vía a Minas a 1 Km al sur de las Piscinas de Cunuyacu.</td><td>DESLIZAMIENTO</td><td>--</td><td>29/12/2021</td><td>Ninguna</td></tr><tr><td>2</td><td>Imbabura</td><td>San Miguel De Urcuquí</td><td>La Merced De Buenos Aires</td><td>vía Buenos Aires - La Primavera (alcantarilla sobre el Río Salado)</td><td>SOCAVAMIENTO</td><td>30</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Yaucana</td><td>ALUVIÓN</td><td>--</td><td>23/07/2021</td><td>Ninguna</td></tr><tr><td>4</td><td>Napo</td><td>El Chaco</td><td>Oyacachi</td><td>Oyacachi, vía a Jariyacu-Huashahuaicu</td><td>DESLIZAMIENTO</td><td>--</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Nueva Tarquí</td><td>El Candi</td><td>HUNDIMIENTO</td><td>800</td><td>26/05/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Centro Parroquial de Pananza</td><td>HUNDIMIENTO</td><td>10</td><td>20/05/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Riobamba</td><td>Quimiag</td><td>Sector Balcashí, vía Quimiag - Chambo</td><td>SOCAVAMIENTO</td><td>--</td><td>06/03/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Puente sobre el río Malo</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>29/01/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Valle Hermoso</td><td>Sector Sarayacu.</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>15/01/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Méndez-Bella Unión-La Dolorosa-Copal</td></tr><tr><td>11</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr><tr><td>12</td><td>Pichincha</td><td>Quito</td><td>Turubamba</td><td>Guamaní Alto - quebrada Caupicho, desde el puente de la av. Susana Letor hasta el puente de Guajaló</td><td>SOCAVAMIENTO</td><td>15</td><td>01/02/2020</td><td>Ninguna</td></tr></table>


4. Declaratorias emitidas por el SNGRE (vigentes en orden cronológico)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/fe7cff2b6bc337b02bdff01145ad0b73d2ca1c6d87f1614629cdf8febde0fb7e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/6bbed98ad3640b632fc577b7b6d888262c30cf9ea647774ab2127a992d0ed01f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/0f5188411e5fb6bdd61c356efb4182740382cf4f24a46d0065a3dff514cf6a70.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/71e6a3f31b6979d5c676a762286467947da42e9e12c403d58230324d60fc4268.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/f7bb2b4d7cc19a84bc92dd0705790c9106c63487df9562710de68bee485869fb.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/d585f5cbd8f119671708272ec620802484ac42f97331062c89b1b6db6499a1b4.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/65ea3961d3595f9a36fe4c899a100e2dccd6ebdc89bbe3dbbcb679a7561bc0dc.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/52077ccf7bf96cd24ba067f5cfe438e0f3b0a02c1a86588b0aef1d331c057979.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Movimiento en masa Barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SNGRE-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SNGRE-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SNGRE-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SNGRE-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SNGRE-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SNGRE-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SNGRE-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 00025
Fecha y Hora de actualización: jueves, 13 de enero de 2022 - 09:31:12 / Página 14 de 14


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/30c927f417a6718836e9d0d1191ffc9af5c50fb4fd27df110da716ad52bc0190.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/c7842c25c0ece7d9ccd2ed36d391ec04978bf14a9b9f58c80636d4f871a87da0.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/4e2b2e05ca8252b6b9e2b085b6ed21c4e23727e881d35809504b074b55e58eff.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/df7bf6978c8e0002d2eb79724151c574785631418dce3467f3b6d5a6803aa015.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/639605ee563ff0d24f1b0ccaa282c047ded340b4060f2c07d5c6241f8887f963.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/2fff51eb427d959a23fd151e2b6b6cacf6f9a6879b86fb11954748fb6714f4f7.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/c1c118d918d7a34dcf6ce4e2648f73cd264962c486be2aa5616ba4a1cc979ef5.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="2">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td colspan="2">Inundaciones Babahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td colspan="2">Hundimiento, Zaruma, El Oro</td><td>07/03/2017</td><td>Resolución No. SGR-029-2015</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/c7a21fe1-bbd9-4735-8212-97347f0ee59b/a5277d9c8d86b21882471aac01016074a92ce3561159a61ad19ac462f25eeea3.jpg)


Elaborado por:. Verónica Analuisa - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Pichincha Revisado por: Angelica Larrea- Analista de Monitoreo de Turno 24/7 - Sala de Situación y Monitoreo Quito Emitido por:. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 