Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 1 de 24 

Periodo de Monitoreo: 

Desde: 21h00 24/03/2022 

Hasta: 09h00 25/03/2022 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/a2c5b372072b515218713ba47e81b2b26ae2fee6385fa65f42a55c8da439a96f.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/9d4c7c05127f88eabe9ebb6b16e2d25fc23615d72f4063a74fad157007513db8.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>06H00 Mediante cámaras ECU 911 se visualiza el sector del volcán nublado</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/e42658240478bcf79f6085fd88c9402db094ecc65d5d42d4de2d6298003d68ef.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>06H00 Mediante cámaras ECU 911 se visualiza el sector del volcán nublado</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/d70beac5966e2d65c69f6279915ffbf046d5200f59567c325899aade38377143.jpg"/></td><td>Volcán Cotopaxi</td><td>SIN ALERTA</td><td>06H00 Mediante reporte de los vigías, se visualiza el sector del volcán nublado</td><td>VERDE</td></tr><tr><td rowspan="2"><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/a20fb81c02f831fab39e9aa616057b65d9ecf0868daa9e1308168e848b9258ba.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>06H00 Mediante cámaras ECU 911 se visualiza el sector del volcán nublado</td><td>VERDE</td></tr><tr><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>06H00 Mediante cámaras ECU 911 se visualiza el sector del volcán nublado</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/d2cd6cfec4f3c004374415cc5713798bb14bf0d29820def6537886a30a745e31.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>06H00 Mediante cámaras ECU 911 se visualiza el sector del volcán nublado</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/64ce99f3a1b75d201d35a9a27f98414e2c110853e1b24da05547f6b955dda0e4.jpg"/></td><td>Volcán Wolf, Galápagos</td><td>SIN ALERTA</td><td>06H00 Se mantienen las anomalías térmicas observadas mediante satélites GOES-16.</td><td>VERDE</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/69a88f8a507b5f179748a11af3b03522e01502cda10bd7c92b571211eee503f6.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">14 ríos desbordados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>Guayas</td><td>Balzar</td><td>Balzar, Cabecera Cantonal</td><td>Recinto Chicompe</td><td>Chicompe</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>Avenida 6 de Febrero</td><td>Jujan</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>sector de San zoilo, barrio apolo</td><td>Los Amarillos</td></tr><tr><td>Guayas</td><td>Balzar</td><td>Balzar, Cabecera Cantonal</td><td>Varios sectores</td><td>Puca</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>La Providencia - LA Moraima</td><td rowspan="2">Chilintomo</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Dr. Camilo Ponce</td><td>Rio Perdido</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>Varios Sectores</td><td>Ñauza</td></tr><tr><td>Guayas</td><td>Balzar</td><td>Balzar, Cabecera Cantonal</td><td>Varios sectores</td><td>San Pauleño</td></tr><tr><td>Guayas</td><td>Balzar</td><td>Balzar, Cabecera Cantonal</td><td>San Pableño</td><td>Pucón</td></tr><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto Cabuyal</td><td>Pula</td></tr><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto Bufay</td><td>Bufay</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 2 de 24


<table><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto El Salto</td><td>El Salto</td></tr><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto Estero Lagarto</td><td>Lagarto</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Dr. Camilo Ponce</td><td>Sol Brisa</td><td>Sabana</td></tr><tr><td>Los Ríos</td><td>Baba</td><td>Isla de Bejucal</td><td>Rcto. Sierra Maestra</td><td>Isla de Bejucal</td></tr></table>

<table><tr><td colspan="5">15 ríos con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>Cotopaxi</td><td>Pangua</td><td>Moraspungo</td><td>Moraspungo</td><td>Río Calope</td></tr><tr><td>Esmeraldas</td><td>Quinindé</td><td>Chura (Chancama) (Cab. En El Yerbero)</td><td>Salinas</td><td>Esmeraldas</td></tr><tr><td>Guayas</td><td>General Antonio Elizalde (Bucay)</td><td>General Antonio Elizalde (Bucay), Cabecera Cantonal</td><td>Enrique Valdez</td><td rowspan="2">Chimbo</td></tr><tr><td>Guayas</td><td>Coronel Marcelino Maridueña</td><td>Coronel Marcelino Maridueña (San Carlos), Cabecera Cantonal</td><td>Sector Maravillas, Recinto Resistencia, La Isla, Producción Agrícola, Los Guayacanes</td></tr><tr><td>Guayas</td><td>Coronel Marcelino Maridueña</td><td>Coronel Marcelino Maridueña (San Carlos), Cabecera Cantonal</td><td>Recinto Barranco Alto</td><td>Barranco Alto</td></tr><tr><td>Guayas</td><td>San Jacinto De Yaguachi</td><td>San Jacinto De Yaguachi, Cabecera Cantonal</td><td>Recinto Marialuisa</td><td>Yaguachi</td></tr><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto La Capilla / San Pedro /Recinto El Mate /El tormento</td><td>Daule</td></tr><tr><td>Guayas</td><td>Simón Bolívar</td><td>Crnel. Lorenzo De Garaicoa (Pedregal)</td><td>Recinto Chague</td><td>Los Amarillos</td></tr><tr><td>Guayas</td><td>Coronel Marcelino Maridueña</td><td>Coronel Marcelino Maridueña (San Carlos), Cabecera Cantonal</td><td>La Modelo, Producción Agrícola Sur</td><td>Chanchan</td></tr><tr><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>El Salitre (Las Ramas), Cabecera Cantonal</td><td>Cabecera Cantonal (zona urbana)</td><td>Salitre</td></tr><tr><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>El Salitre (Las Ramas), Cabecera Cantonal</td><td>Cabecera Cantonal (zona urbana)</td><td>Vinces</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Babahoyo, Cabecera Cantonal Y Capital Provincial</td><td>Camilo Ponce</td><td>Babahoyo</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Clemente Baquerizo</td><td>El Palmar</td><td>San Pablo</td></tr><tr><td>Los Ríos</td><td>Urdaneta</td><td>Catarama, Cabecera Cantonal</td><td>Catarama</td><td>Catarama</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>Rcto. Las Malvinas</td><td>La Clementina</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Febres Cordero (Las Juntas) (Cab. en Mata de Cacao)</td><td>Febres Cordero</td><td>La Marcelina</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/03102b0522d0e151857c1468f5c7f28c2d47b93efd5947ed1e15f6fe1cb013cb.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

<table><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/674b82ece350803ff383af07f91b2040e6bc66c8c99b06fb85f62a46b10c0754.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td>--</td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td>--</td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>80.42</td><td>85.00</td><td>01:43</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>115.93</td><td>117.00</td><td>00:12</td><td>VERDE</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

<table><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td>---</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>---</td><td>106.50</td><td>---</td><td>---</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td>---</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td>---</td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td>---</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/0091d2743b858ce6f8067f0f1526dd6b1df7b4198ff1c5eab5b9734ce7841337.jpg)


## SITUACIÓN HIDROMETEOROLÓGICA

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/dee71b6fabe11df1ac7355ba04d1a49db64a8caac8bb826f1a1ce225f84ab202.jpg)


## Lluvias y Tormentas Eléctricas

Vigencia: desde 15H00 del 23 de marzo hasta 22H00 del 27 de marzo 2022 

SITUACIÓN: Los próximos días, continuarán las lluvias y tormentas eléctricas en diferentes sectores del país. Se pronostica que los episodios más relevantes se desarrollen en la región litoral, los cuales podrían en varios casos estar acompañados de tormentas eléctricas y ráfagas ocasionales de viento. 

ZONAS AFECTADAS 

- Litoral: las lluvias serán frecuentes y se extenderán en gran parte de la región, alcanzando su mayor intensidad en la zona norte e interior (áreas con nivel de amenaza alto y muy alto en el mapa). 

- Interandino y Amazonia: las precipitaciones empezarán a ser más frecuentes a partir del viernes 25 de marzo. En la Sierra, podrían presentar su mayor intensidad en las zonas norte, sur y estribación occidental. Mientras que, en la región Amazónica serían generalizadas. 

- Insular: precipitaciones dispersas de intensidad variable con posibles episodios puntuales de moderada intensidad.
FUENTE: INAMHI 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/5b8241ff9ba06d2af972d16a97e14f6d8ea556e043737a64456ba94f1b63d1c3.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

## Monitoreo de eventos peligrosos (emergencias y desastres)

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/1a1014fd8dea906791e92d6c385c285c9c58310dea63b63ee4a14d5c66f1c47b.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Ibarra/Carolina/ San Jerónimo; vía Salinas - Lita [E 10]</td></tr><tr><td>Antecedentes:</td><td>El 22/12/2021, producto de las fuertes precipitaciones, se registró un deslizamiento que afectó la vía de primer orden E10, colapsando totalmente la mesa de la vía y los postes de hormigón de telecomunicaciones; producto de esto se represó el río Mira, el mismo que ha retornado a su cauce normal.El COE-Provincial, se reunió el 16/02/2022 y resolvió: Recomendar al Ministro de Transporte y Obras Públicas la declaratoria de situación de emergencia de la vía estatal E-10 Km 114- 400, sector el Guadual en base a los informes técnicos presentados a la Plenaria del COE Provincial Imbabura por las instituciones competentes.</td></tr><tr><td>Situación actual:</td><td>En la actualidad se observa roca meteorizada prácticamente suelta, areniscas y masas coluviales que, al presentarse una lluvia de fuerte o mediana intensidad, podrían provocar nuevamente un deslizamiento de material de grandes proporciones.La vía se mantendrá Parcialmente Habilitada para vehículos livianos con horario de 06H00 a 18h00 y en la noche se cierra por precautelar la integridad de la población.</td></tr><tr><td>Afectaciones:</td><td>- El 05/02/2022, se afectó la vía en un tramo de 80 metros de la vía.- El 30/01/2022, 100 metros lineales de vía afectada por material pétreo- El 22/12/2021, se afectó 125 metros lineales de vía con material pétreo- 2 postes de hormigón de telecomunicaciones.- Colapso de la mesa de la vía en un tramo de 50 metros.- 40 vehículos y sus propietarios que se encontraban atrapados en el tramo Guadual - San Jerónimo, fueron evacuados del sector.- 1 persona fallecida de sexo masculino de 46 años.</td></tr><tr><td>Acciones de respuesta:</td><td>• La Policía Nacional realiza el control permanente en el sector y brinda seguridad al tránsito vehicular.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 4 de 24 

<table><tr><td colspan="2">Fecha y hora de actualización. Viernes, 23 de marzo de 2022 - 09.13.43/ Pagina 4 de 24</td></tr><tr><td></td><td>• La ANT regula la circulación vehicular y las frecuencias autorizadas en el sector.
• MAATE realizó el informe del estado de fuente de agua y, en su conclusión, indica la necesidad de la construcción de terrazas paralelas en la parte alta con drenajes adecuados de aguas lluvias, pero que, como esto demanda grandes inversiones y estudios preliminares para que su construcción permita la estabilidad de los taludes, debe ser adecuadamente valorado por el MTOP.
• El MTOP contrató los estudios de Refracción Sísmica en el talud 114+400, con el objeto de caracterizar los estratos, previa instrumentación de la propuesta de rehabilitación definitiva en la vía E-10.</td></tr></table>

Fuentes de información: SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/MTOP/PPNN 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/ef622852fefb826672745425faadc6b571d938463de2924f8d52dc9fc0f36ad6.jpg)


## Desplazados Forzosos

<table><tr><td>Localización:</td><td>Esmeraldas/San Lorenzo/Mataje/Mataje - San Lorenzo</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2022, debido a enfrentamientos de grupos armados en la zona de Mataje, se suscitó el desplazamiento de varias personas de la parroquia Mataje.</td></tr><tr><td>Situación actual:</td><td>UGR GAD Cantonal San Lorenzo informa que 22 familias de102 personas han retornado a sus hogares.</td></tr><tr><td>Afectaciones:</td><td>- 60 Familias, 129 Personas desplazadas.</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE UPREA Esmeraldas en conjunto con UGR San Lorenzo, realizaron el seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Esmeraldas/SNGRE UPREA Esmeraldas/UGR GAD Cantonal San Lorenzo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/209bab3190f89d90f5760d0268ca7ea4e8eecb43f3158c1052d40ee9483b22b6.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El deslizamiento acelerado ocurrido en los primeros días de noviembre del año 2021, de acuerdo al informe del SNGRE del 26/11/2021, indica que se suscitó en la vertiente heterogénea, se presume que el factor desencadenante de los movimientos en masa es el agua, además, de la presencia de fuertes lluvias, por lo que es frecuente que se presenten estos fenómenos debido a su relieve, litología y presencia de fallas geológicas, lo que condiciona la estabilidad, siendo la infiltración, los sismos y la actividad antrópica, los factores detonantes de los deslizamientos.El día 24/11/2021, aproximadamente a la 01:00, se produjo un nuevo desplazamiento acelerado, generando un movimiento en masa considerable que destruyó infraestructuras habitacionales, vías de acceso a San José de Aloburo, servicios básicos (agua, alcantarillado, energía eléctrica, telecomunicaciones), sistemas de riego particulares, colapso de invernaderos y afectaciones de plantaciones agrícolas, que se distribuyen en la zona de influencia directa del evento suscitado.Las 19 familias, que habitaban en el sector, fueron evacuadas a familias acogientes y alojamientos temporales que continúan activos.Adicional el SNGRE CZ1, con geólogos de la Prefectura, Universidad Central, Universidad Yachay y autoridades locales, realizó recorridos e inspecciones.El 19/11/2021, mediante Resolución Administrativa No. GADMSPP-A-2021 - 077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el Cantón Pimampiro, en virtud de la resolución y recomendaciones emitidos por el Comité de Operaciones de Emergencia del cantón, en atención al evento peligroso suscitado en el sector denominado la Loma de Aloburo y su impacto cantonal.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias y 113 personas afectadas directamente- 12 Familias y 35 personas damnificadas;- 38 Familias y 116 personas evacuadas (10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 familias en familias acogientes)- 12 viviendas destruidas- 6 Viviendas afectadas;- 6 invernaderos destruidos de tomate riñón y pepinillo;- 5 Reservorios colapsados;- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados;-800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado;</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

<table><tr><td rowspan="2"></td><td>Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Pagina 5 de 24</td></tr><tr><td>- 150 metros destruidos de la red de distribución de agua de consumo humano;- 150 metros de la red de alcantarillado destruidos;- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El COE Cantonal se mantiene activo desde el 24/11/2021.GAD Cantonal de Pimampiro, en apoyo del GAD Imbabura, trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad. La nueva vía tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades, con su cabecera cantonal.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/Yachay/MAG/MIDUVI/GAD Provincial /GAD Cantonal /UGR/ SNGRE - UPREA -UAR</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/49cd6481db444ac63157c50938a674c9712d2a1184bffa11e2d0c5ffbca977fa.jpg)


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina, San Luis, vía Y de Baeza-Lago Agrío [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial E45, Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.</td></tr><tr><td>Situación actual:</td><td>San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio. El frente de erosión se mantiene en la abscisa 7+900(puente de San Carlos) por 249 días. El paso vehicular por la vía Baeza Lago Agrio está cerrada, la ruta alterna Y de Baeza-Y de Narupa-Loreto-El Coca-Lago Agrio está habilitada.</td></tr><tr><td>Afectaciones:</td><td>- 05/03/2022. 1 familia evacuada- 04/03/2022, dos familias evacuadas.- 19/01/2022, una familia evacuada (1 persona).- 05/01/2022, evacuación de enseres de 3 familias (ya se encontraban 2 familias evacuadas días anteriores y la tercera familia continúa en su vivienda).- 20/12/2021, 1 familia (10 personas) evacuadas.- 13/12/2021, rotura de la tubería de poliducto.- 10/12/2021, población de San Rafael sin energía eléctrica.- 03/12/2021, puente sobre el río Piedra Fina 2 en riesgo.- 21/11/2021, 1 tubería de agua afectada.- 19/05/2021, 1 puente destruido (puente denominado Ventana 2).- 18/05/2021, 2 viviendas destruidas (las familias fueron evacuadas en febrero del 2021).- 10/03/2021, 1 bien afectado (tanque de agua).- 27/02/2021, 2 familias damnificadas y evacuadas a alojamiento temporal (al momento están en arriendo por sus propios medios); 2 viviendas presentaron fisuras.- 22/10/2020, 1 puente destruido (puente sobre el río Montana).- 06/05/2020, 2 familias afectadas, 2 viviendas afectadas.- 07/04/2020, 3 bienes afectados (tuberías del SOTE, Poliducto Shushufindi- Quito y la OCP).- Afectación vial: las pérdidas y afectaciones relevantes en vías ocurrieron en un total de 875 metros de la vía E45.- Afectación agropecuaria: durante algunos meses se ha identificado 100 ha de superficie agrícola perdida, 63 porcinos y 3000 tilapias perdidas y afectación a 385 bovinos.</td></tr><tr><td>Acciones de respuesta:</td><td>El 16/03/2022, SNGRE CZ2 realizó levantamiento de fichas de las familias damnificadas en base al informe del GAD Municipal El Chaco, además, participó en la socialización de los estudios de tomografía sísmica, realizados por IKIAM, al personal técnico del GAD El Chaco ante el continuo avance del proceso de erosión hídrica. CELEC EP y Petroecuador realizan el monitoreo de la erosión.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ2 Umeva Napo-Orellana/MSP/OCP Ecuador.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167 Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 6 de 24

ZONA 3 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/e0c554a1336d50e51d65fe55c48f165a21acf6160be34568e82ee5443674181d.jpg)



Aluvión


<table><tr><td>Localización:</td><td>Cotopaxi / Latacunga / Tanicuchi / Llactayo San Isidro, vía Tanicuchi - Toacaso.</td></tr><tr><td>Antecedentes:</td><td>El 24/03/2022 a causas de las lluvias se produjo un aluvión que afectó un vehículo, y se encuentra parcialmente habilitada una vía de tercer orden</td></tr><tr><td>Situación actual:</td><td>Vía parcialmente habilitada.</td></tr><tr><td>Afectaciones:</td><td>1 bien privado afectado</td></tr><tr><td>Acciones de respuesta:</td><td>PPNN confirmó el evento y brinda seguridad en el sitio SNGRE monitorea el evento y coordina con el GAD Provincial los trabajos de limpieza en la vía.</td></tr><tr><td>Fuentes de información:</td><td>GAD Provincial / PPNN / SNGRE Unidad de Monitoreo Chimborazo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/0229abb72ea2dfb52f6f7c554d0e576e849327ae1e03b1d7450f29a38db368a2.jpg)



Inundación


<table><tr><td>Localización:</td><td>Chimborazo /Guamote / Guamote / Comunidad Santa Lucía Bravo.</td></tr><tr><td>Antecedentes:</td><td>El 21/03/2022, debido a las lluvias, se produjo una inundación que afectó a varias viviendas del sector.</td></tr><tr><td>Situación actual:</td><td>Se realizó el levantamiento de información de necesidades, reportando afectación a los enseres del hogar de varias viviendas; al momento las familias afectadas permanecen en las mismas, al momento no se reporta lluvias por el sector.</td></tr><tr><td>Afectaciones:</td><td>- 7 viviendas afectadas.- 7 familias, 35 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR GAD Guamote realizó el levantamiento de informe EVIN, y recomienda la intervención de las instituciones del SNDGR en atención a las familias afectadas.</td></tr><tr><td>Fuentes de información:</td><td>GAD Guamote / SNGRE Unidad de Monitoreo Tungurahua</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/3aeef900bef5187e52756804d5198e0831753da08aea5a26137a36cec7145747.jpg)


<table><tr><td>Localización:</td><td>Manabí/Portoviejo/Chirijos/Varios Sectores</td></tr><tr><td>Antecedentes:</td><td>Producto de las lluvias suscitadas en hora de la mañana del 23/03/2022, se suscitó el desbordamiento del río Chamotete</td></tr><tr><td>Situación actual:</td><td>El río Chamotete se encuentra dentro de su cauce con tendencia a disminuir de nivel, la vía de segundo orden se encuentra habilitada y las familias afectadas permanecen en casa de familia acogiente de manera indefinida hasta poder realizar las limpiezas de las mismas</td></tr><tr><td>Afectaciones:</td><td>-5 viviendas afectadas-5 familias afectadas (19 personas afectadas)-30 metros de vía afectada</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE CZ4 con apoyo de personal de UGR GAD Portoviejo realizó la entrega de asistencia humanitaria.UGR del GAD Portoviejo realizó la evaluación de daños y análisis de necesidades.GAD Provincial realizó labores de limpieza de la vía afectada.CB Portoviejo con colaboración de personal de UGR GAD Portoviejo realizaron la evacuación del agua y de las familias afectadas.</td></tr><tr><td>Fuentes de información:</td><td>ECU 911 Portoviejo/SNGRE UMEVA Manabí/UGR Portoviejo/CB Portoviejo/GAD Provincial</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/04508e9ca81825636396cd6a4e10018752da7a53fbc597646808a983ae5545fb.jpg)


<table><tr><td>Localización:</td><td>Los Ríos/Baba/Baba/Jobo</td></tr><tr><td>Antecedentes:</td><td>El 24/03/2022 debido a las fuertes lluvias suscitadas, se reporta acumulación de aguas que afectaron a varias viviendas</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas se mantienen en sus viviendas y el nivel de agua se mantiene alto.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas.- 3 familias afectadas.- 9 personas afectadas.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 7 de 24 

<table><tr><td>Acciones de respuesta:</td><td>Teniente Política realizó barrido en el sitio para verificación de afectaciones y facilitó dato preliminar del evento.UGR Baba asistirá en el transcurso de la semana para levantamiento EVIN.</td></tr><tr><td>Fuentes de información:</td><td>Ministerio de Gobierno/UGR Baba/SNGRE Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/e94e7129c7d129a30d834c0888181b1cb46f2351c6a8e1f79ac2112f80b5c168.jpg)



Inundación


<table><tr><td>Localización:</td><td>Los Ríos/Baba/Isla de Bejucal/Rcto. Sierra Maestra - Rcto. La Cancagua</td></tr><tr><td>Antecedentes:</td><td>Debido a las lluvias suscitadas en el sitio el día 23/03/2022, se produjo el desbordamiento del río Isla de Bejucal, afectando a varias viviendas.</td></tr><tr><td>Situación actual:</td><td>El río continúa desbordado y las familias afectadas se mantienen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 10 viviendas afectadas.- 10 familias afectadas.- 40 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Teniente Político realizó barrido en el sitio para verificación de afectaciones y facilitó dato preliminar del evento.UGR Baba asistirá en el transcurso de la semana para levantamiento EVIN.</td></tr><tr><td>Fuentes de información:</td><td>Ministerio de Gobierno/UGR Baba/SNGRE Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/daaf73fa6b00abcf02f328536d6a7e9ec2f63032b2b02876114ba0e37332c7cc.jpg)



Hundimiento


<table><tr><td>Localización:</td><td>Bolívar / San Miguel / Bilován / Por atrás de la iglesia a 500 metros en la vía alterna a Bilován.</td></tr><tr><td>Antecedentes:</td><td>GAD Provincial de Bolívar, mediante informe técnico recibido el 21/03/2022, indica que, a causa de la temporada invernal, visualizó el hundimiento en la vía alterna a Bilován que presenta agrietamientos, fisuras, talud fracturado y asentamientos en varios tramos de la zona afectada.</td></tr><tr><td>Situación actual:</td><td>Dos familias evacuaron por precaución a una vivienda de propiedad de la junta parroquial de Bilován.</td></tr><tr><td>Afectaciones:</td><td>- 50 metros lineales- 2 familias evacuadas por precaución.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR del GAD Provincial realizó el levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>GAD Provincial, Teniente Político de Bilován, SNGRE Unidad de Monitoreo Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/a05bc18a5262fd1b146b1e27040e83965761140aa4e997240693bcc9c7d4959d.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas / Santa Lucia / Santa Lucia, Cabecera Cantonal / Varios Sectores</td></tr><tr><td>Antecedentes:</td><td>Por lluvias registradas el día 21/03/2022, se produjo el desbordamiento de los ríos Pula y Daule, así como de los esteros Bufay, El Salto y Lagarto, provocando inundaciones en varios sectores.</td></tr><tr><td>Situación actual:</td><td>Al momento 3 familias y 15 personas se encuentran en el Alojamiento Temporal Santa Rosa.El río Pula y los esteros Bufay y El Salto se mantienen desbordados, mientras que, el río Daule y estero Lagarto se encuentra desbordado</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas (ingreso de agua al interior de las viviendas)-3 familias, 15 personas afectadas (las familias se encuentran en el alojamiento temporal Santa Rosa)- 1251 hectáreas afectadas de cultivos de arroz (datos preliminares)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR del GAD Cantonal acudió al sitio para realizar el levantamiento de información y el traslado de las familias al alojamiento temporal.</td></tr><tr><td>Fuentes de información:</td><td>GAD Cantonal Santa Lucia / SNGRE Unidad de Monitoreo Guayas</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/fe19405b873f870a8e2c260c38fcf90bc250c11f7c323fba3ad7828a8006e2ce.jpg)



Socavamiento


<table><tr><td>Localización:</td><td>Bolívar/Echeandía/Cabecera Cantonal/Damas, vía Sabanetillas - San Gerardo</td></tr><tr><td>Antecedentes:</td><td>El 20/03/2022, a causa de las lluvias registradas en el sector, aumentó el nivel del río Damas y se produjo el socavamiento de las bases del puente y de la calzada que conduce de la vía Sabanetillas - San Gerardo.</td></tr><tr><td>Situación actual:</td><td>La maquinaria del GAD Provincial y GAD Cantonal de Echeandía, realizan los trabajos de reparación y relleno en las bases del puente, con el fin de rehabilitar la plataforma asfáltica.</td></tr><tr><td>Afectaciones:</td><td>-1 bien público afectado (puente) -10 metros lineales de vía destruida</td></tr><tr><td>Acciones de respuesta:</td><td>Personal del GAD Provincial realizó la inspección técnica de la zona afectada. Maquinaria del GAP Provincial y GAD Cantonal realizan trabajos de rehabilitación de la vía.</td></tr><tr><td>Fuentes de información:</td><td>GAD Cantonal/Jefe Político/SNGRE Unidad de Monitoreo Bolívar.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 8 de 24 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/7326766bc4fe2a42a4cfda1ba02fe06ef631533818b5f3141ea30737e521e32a.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Puebloviejo/San Juan/ Cristo del Consuelo - Rcto. Las casitas</td></tr><tr><td>Antecedentes:</td><td>Por lluvias acontecidas en el lugar, el 19/03/2022, se vieron afectadas varias viviendas por acumulación de aguas lluvia.</td></tr><tr><td>Situación actual:</td><td>El nivel de agua se mantiene y 2 familias se encuentran en casa acogiente, mientras que las demás permanecen en sus hogares.</td></tr><tr><td>Afectaciones:</td><td>- 30 viviendas afectadas.- 30 familias afectadas (2 familias de 9 personas en casa acogiente)- 119 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Ministerio de Gobierno realizó entrega de ayuda humanitaria.SNGRE asistió al sitio para verificación y colaboración en la entrega de ayuda humanitaria.UGR Puebloviejo asistió al sitio para verificación y colaboración en la entrega de ayuda humanitaria.</td></tr><tr><td>Fuentes de información:</td><td>GAD Puebloviejo/MSP/Ministerio de Gobierno/SNGRE Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/66f1067b31c9ca4c6427e07cb9116efeecda5c1faf89d6fea2d369fceaae723f.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Balzar/Balzar, cabecera cantonal/varios sectores</td></tr><tr><td>Antecedentes:</td><td>Por lluvias registradas en la madrugada del 19/03/2022, se produjo el desbordamiento de los ríos Chicompe y Puca, causando la inundación de cultivos de arroz y maíz en dichos sectores.</td></tr><tr><td>Situación actual:</td><td>Los ríos Chicompe, Puca, San Pauleño y San Pableño siguen desbordados</td></tr><tr><td>Afectaciones:</td><td>- 99 viviendas afectadas (ingreso del agua al interior de los inmuebles)- 99 familias afectadas (286 personas) permanecen en sus viviendas.</td></tr><tr><td>Acciones de respuesta:</td><td>MTT 3 y 4 solicitan botes para poder realizar inspección en las zonas de difícil accesoMTT 2 realizará brigadas médicas en sectores afectados por la etapa invernal GAD Cantonal realizó recorridos en las zonas afectadas el 21, 22 y 23 de marzo del presente año.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Balzar</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/e7bb1eab19d9ffb1a4cad27f54666993072b8d896121678e531ee9912ab33ccd.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Santa Elena / Santa Elena / Santa Elena / Barrios de la cabecera cantonal.</td></tr><tr><td>Antecedentes:</td><td>El 17/03/2022, por las lluvias, se reportó la inundación a varias viviendas en el sector.</td></tr><tr><td>Situación actual:</td><td>El Alcalde del cantón Santa Elena declaró el estado de emergencia cantonal por los efectos negativos, que hasta ahora, han causado las fuertes lluvias, decisión que se tomó en la reunión de la Plenaria COE del 17/03/2022, por lo que se destinarán fondos para la mitigación del impacto que genere la presente etapa invernal.Las familias afectadas por ingreso de agua en sus domicilios lograron evacuarla, no se evidenciaron daños a bienes y se mantienen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 57 viviendas afectadas- 57 familias afectadas (228 Personas)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Cantonal y CB Santa Elena, colaboraron con la evacuación de aguas lluvias y limpieza de canales.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE Unidad de Monitoreo Santa Elena / UGR Cantonal.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/c8ae1b0bb02e27eb24fbadb40013db359c282ba0155479b89af274ddeb8e88b7.jpg)


## Inundación

Localización: Los Ríos/Babahoyo/Pimocha/Las Conchas 1 y 2 - Los Juncos - San Vicente - Santa Rita - La Maruja - El Porvenir - Playas del Porvenir - La Fortuna - Poza Honda - La Puntilla - Los Robles - San Francisco - Limonal - La Pinela
Antecedentes: El 12/03/2022, por lluvias, se produjo el desbordamiento de los ríos Catarama de Urdaneta y Babahoyo, afectando varias viviendas de la zona.
Situación actual: Debido al crecimiento de los caudales de los ríos Babahoyo, Clementina y Catarama de Urdaneta, se vieron afectados varios sectores, actualmente los caudales se mantienen en aumento y con presencia de agua en las viviendas, las familias afectadas se mantienen en sus hogares a excepción de 1 familia que permanece en casa acogiente. 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 9 de 24 

<table><tr><td colspan="2">Fecha y Hora de actualización: Viernes, 25 de marzo de 2022 - 09:13:45/ Pagina 9 de 24</td></tr><tr><td rowspan="3">Afectaciones:</td><td>-1394 viviendas afectadas.</td></tr><tr><td>-1394 familias afectadas (1 familia de 4 integrantes en casa acogiente).</td></tr><tr><td>-5429 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>- GAD Babahoyo asistió al punto para entrega de ayuda humanitaria, facilitó matriz de afectaciones y realizó verificación de novedades.</td></tr><tr><td>Fuentes de información:</td><td>GAD Babahoyo/SNGRE Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/9b0807c720f53b8dd748641f84af54ba2b568a33e938024cb41df1c986fe1b34.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Dr. Camilo Ponce/Terminal Terrestre Babahoyo, vía Jujan - cruce de La Carmela - río Perdido - Sol Brisa - Ecuavegetal</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2022, por lluvias suscitadas en la zona, se produjo la acumulación de aguas lluvias, desbordamiento del río Chilintomo y estero Sabana que afectó el tránsito normal de vehículos en la vía.</td></tr><tr><td>Situación actual:</td><td>MTOP reporta incremento de agua con presencia de lechuguines en la vía, el tránsito vehicular está habilitado con precaución, ya que los caudales continúan desbordados, cabe mencionar que las familias afectadas se mantienen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>-98 viviendas afectadas.- 98 familias afectadas.- 416 personas afectadas.-1 bien público afectado (Terminal Terrestre Babahoyo)-2000 metros lineales afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP asistió al sitio para colaborar con maquinaria en la limpieza de la vía y la verificación de novedades.Personal de CTE y ATM se mantienen en la vía colaborando con el tránsito vehicular.UGR Babahoyo realizó inspección técnica el 22/03/22 y con la matriz de afectaciones, se verifica cambios en los valores de afectaciones.</td></tr><tr><td>Fuentes de información:</td><td>CTE/MTOP/ATM/SNGRE Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/12fa49c4c2e78e628f7e125b1cc1656da0e2f7630d270bb68b3a54a15e4c2ec7.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/El Salto/La Chorrera - cancha La Pava - Coop. Rosa de Agosto - Justino Cornejo - río Catarama</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2022, por causa de las fuertes lluvias suscitadas y a la confirmación con los puntos focales se indica que el desbordamiento del caudal es el río Catarama de Urdaneta y Sabana, afectaron varias viviendas de la zona baja en el cantón Babahoyo.</td></tr><tr><td>Situación actual:</td><td>SNGRE se movilizó vía aérea, en compañía de Ministerio de Gobierno, MAG y FFAA, para realizar inspección de la zonas afectadas, adicional el río Catarama aún se mantiene alto; las familias afectadas permanecen en sus viviendas y 1 familia continúa en casa acogiente.</td></tr><tr><td>Afectaciones:</td><td>-78 viviendas afectadas.-78 familia afectadas (1 familia de 7 personas en casa acogiente).-312 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>FFAA, SNGRE y MAG realizaron inspección en las zonas afectadas el 22/03/2022.Cuerpo de Bomberos de Babahoyo asistió al sitio para inspección</td></tr><tr><td>Fuentes de información:</td><td>FFAA/MAG/Cuerpo de Bomberos Babahoyo/ Ministerio de Gobierno/SNGRE UPREA/ SNGRE Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/d69546aa5f17cd4a886139cf0a20e924cb172b5243e7c2b944712086d34b3fba.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Clemente Baquerizo/Universidad Agraria, vía Montalvo - Los Laureles, atrás de la Unidad Educativa Réplica Eugenio Espejo - 1ro de Mayo - La Ventura - Justino Cornejo - Mujeres Solas - Paraíso Norte.</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2022, debido a lluvias, se reportó acumulación de aguas lluvias con los consecuentes desbordamientos del río San Pablo y del estero Sabana que afectó el tránsito normal de vehículos en la vía.</td></tr><tr><td>Situación actual:</td><td>La vía se encuentra habilitada sin presencia de agua y el tránsito circula con normalidad, el río San Pablo se encuentra con tendencia aumentar y el estero Sabana desbordado, adicional a ello las familias afectadas se mantienen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 519 viviendas afectadas.- 519 familias afectadas.- 1876 personas afectadas.- 1000 metros lineales afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>CTE realizó verificación de novedades en la vía.UGR Babahoyo realizó levantamiento de información en el sitio.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 10 de 24 

Fuentes de información: SNGRE CZ5 Unidad de Monitoreo Los Ríos/CTE 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/34ced3f605acd82e17986fc4277a1ea536697dc75bce4274c406d9d2504bb876.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Alfredo Baquerizo Moreno (Jujan)/Alfredo Baquerizo Moreno, cabecera cantonal/varios sectores</td></tr><tr><td>Antecedentes:</td><td>Por lluvias registradas el día 11/03/2022 se desbordó el río Jujan ocasionado el ingreso de agua en las calles y avenidas de los sectores Calle Malecón, Calle 13 de Noviembre, Calle Simón Bolívar y Barrio Sur. Con fecha 12/03/2022 se desbordó el río Los Amarillos afectando el Barrio San Zoilo, Barrio Apolo, Primero de Mayo, Miguel Yúnez. Con fecha 19/3/2022 se desbordó el río Chilintomo afectando a los sectores de La Providencia – La Moraima.Por lluvias ocasionadas la noche del 18/03/2022 y madrugada del 19/03/2022 los ríos Juajn, Chilintomo y Los Amarillos se desbordaron.</td></tr><tr><td>Situación actual:</td><td>Subsecretario y personal del SNGRE conjuntamente con GAD Cantonal, realizaron recorridos por las zonas afectadas y entregaron asistencia humanitaria, además, los ríos Jujan, Chilintomo, Los Amarillos y Estero Ñauza siguen desbordados</td></tr><tr><td>Afectaciones:</td><td>- 740 viviendas afectadas.- 740 familias afectadas- 2615 personas afectadas en sus viviendas.</td></tr><tr><td>Acciones de respuesta:</td><td>Personal de SNGRE realizó recorridos por las zonas afectadas y entregó asistencia humanitaria.Jefe Político acompañó en el recorrido y en la entrega de asistencia humanitaria.Jefe Político acompañó en el recorrido y entrega de asistencia humanitaria Obras Públicas del GAD Municipal continúa realizando limpieza de las zonas afectadasGAD Cantonal realizó recorridos en las zonas afectadas</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Guayas/Coordinador Zonal SNGRE/GAD Cantonal Jujan</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/faabfb5abc31c511bcc7647bb68009635992252dcb0ddf9784b774744b44005c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Caluma/Caluma/Varios Sectores (El Triunfo, La Esperanza - San Vicente de Pacana, Paraíso, Charquiyacu, barrio San José, San Vicente, barrio Central, Guayabal, Guamaspungo - Hemisferio, Plomovado)</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en la madrugada del 10/03/2022, se produjo el desbordamiento del río Caluma en la parte alta de la zona, afectando a bienes públicos (captación del agua, muros de gaviones, alcantarillas) y bienes privados (Centro Turístico el Acorazado, chanchera). Adicional en varios sectores hubo el ingreso de agua lluvia y lodo en algunas viviendas, sin causar afectación a sus enseres y los propietarios realizaron la limpieza respectiva.Con fecha 20/03/2022 por las lluvias se produjo nuevamente el desbordamiento del río Caluma en el sector de Charquiyacu donde se reporta la pérdida de la mesa de la vía de tercer orden que conduce al centro de Salud Charquiyacu - Hoyobravo, arrastre del muro de contención, pérdida del complejo turístico Acorazado, pérdida de chancheras y animales de varias familias. Cabe mencionar que tres familias fueron evacuadas por prevención a hogar acogientes.</td></tr><tr><td>Situación actual:</td><td>Subsecretario y personal del SNGRE conjuntamente con Gobernador de Bolívar, Alcalde del cantón Caluma, realizaron un recorrido por la zona afectada, donde se estableció el compromiso interinstitucional para ejecutar acciones de mitigación y respuesta antes los estragos de la época lluviosa y precautelar la seguridad de las familias que están en zona de riesgo en el sector de Charquiyacu.</td></tr><tr><td>Afectaciones:</td><td>-10 bienes privados afectados (chancheras)-16 bienes privados destruido (Complejo Turístico Acorazado, Chancheras, Galpones)- 5 bienes públicos afectados (1 captación de agua, 3 alcantarillas afectadas, 191 metros lineales de muro de contención de gaviones)- 41 metros lineales de calle adoquinada afectada- 25 metros lineales de vía de tercer orden afectada- 180 ha de cultivos afectados- 25 ha de cultivos perdidos- 180 animales afectados- 220 animales muertos- 43 productores afectados- 25 productores con pérdida total</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

<table><tr><td>Acciones de respuesta:</td><td>Personal de SNGRE, Gobernación y GAD Caluma realizaron un recorrido por el sector de Charquiyacu.Maquinaria del GAD Cantonal realiza el dragado del rio Caluma y protección del muro de contención en el sector de Charquiyacu.Personal del MAG Bolívar continúan brindando asistencia técnica a varias familias en el sector de Charquiyacu</td></tr><tr><td>Fuentes de información:</td><td>GAD Cantonal/SNGRE CZ5/SNGRE Unidad de Respuesta y Unidad de Monitoreo Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/4a88f57fc12d46d5fe9eb052cd49c23afb1e486743af3769e5f013e84c167212.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas / Cnel. Marcelino Maridueña / Cnel. Marcelino Maridueña, Cabecera Cantonal / Sector Maravilla - recinto Resistencia, recintos Producción Agrícola Sur y La Modelo</td></tr><tr><td>Antecedentes:</td><td>Por lluvias registradas en la madrugada del 08/03/2022 se produjo el desbordamiento del río Chimbo en el recinto Resistencia, afectando plantaciones de cultivos de cacao. Adicional se vio afectado un brazo del Río Chanchán, causando la inundación de cultivos de cacao en dicho sector. Por lluvias en la madrugada del 19/03/2022 GAD Cantonal informa que el río Chimbo y río Barranco Alto se encuentran con tendencia a aumentar el nivel y el río Chanchán se encuentra desbordado.</td></tr><tr><td>Situación actual:</td><td>Al momento el río Chimbo, río Chanchán y río Barranco Alto se encuentra con tendencia a aumentar el nivel del cauce</td></tr><tr><td>Afectaciones:</td><td>240 hectáreas afectadas de cultivos de cacao, maíz y verde (datos preliminares de los dos sectores)</td></tr><tr><td>Acciones de respuesta:</td><td>Obras Públicas de la Prefectura de Guayas se encuentran trabajando en las laderas del río ChanchánObras Públicas del GAD Municipal continúa trabajando en laderas del río Chimbo.</td></tr><tr><td>Fuentes de información:</td><td>GAD Cantonal Marcelino Maridueña / SNGRE Unidad de Monitoreo Guayas</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/524630c8e8547cd9cab6ed898686cf8bcb2e3f09746f6ea301af22258cf2cf1c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Febres Cordero/El Palmar - rcto. La Rosita-vía Las Juntas - Las Jaguas - Rcto. Mata de Cacao - San Román - Isla María - río Febres cordero - río Marcelina - rcto. La Alambra - rcto. Los Angeles - río Chilintomo - río San Pablo - La Avelina - Macarena</td></tr><tr><td>Antecedentes:</td><td>Por causa de las fuertes lluvias suscitadas en la zona el 08/03/2022, se produjo acumulación de aguas y el desbordamiento de los ríos Febres Cordero, Marcelina, Chilintomo y San Pablo, afectando a varias viviendas del lugar.</td></tr><tr><td>Situación actual:</td><td>El río Chilintomo continúa desbordado afectando a viviendas y las familias afectadas se mantienen en sus viviendas, a excepción de 4 familias que continúan en casa acogiente.</td></tr><tr><td>Afectaciones:</td><td>- 485 viviendas afectadas.- 485 familias afectadas (4 familias de 16 personas en casa acogiente)- 1882 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Babahoyo realizó barrido y actualización de afectaciones en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Los Ríos/GAD Babahoyo/SNGRE UPREA</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/f09032fbee27fed29250a966f4da5bea74b38721761e1e845c70771047531f14.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Guayas/ Balao/ Balao, Cabecera Cantonal / E25 Panamericana Puente Gala como referencia a 1km del Recinto Shumiral</td></tr><tr><td>Antecedentes:</td><td>Por el asentamiento de un estribo del puente que está encima del río Gala y el afluente paso de vehículos pesados que transitan, el 07/03/2022 se produjo el desplazamiento de sus bases.Personal de CTE ha cerrado la vía en los dos sentidos y los vehículos livianos están transitando por la ruta: San Carlos - Balao - Tenguel y para vehículos pesados San Antonio - Tenguel</td></tr><tr><td>Situación actual:</td><td>MTOP en conjunto con la concesionaria Intervías realizan los trabajos de construcción de un puente Bailey. La vía permanece aún cerrada.</td></tr><tr><td>Afectaciones:</td><td>1 puente afectado</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP se encuentran en al sitio realizando trabajo con maquinariasConcesionaria Intervías se encuentran en al sitio realizando trabajo con maquinariasCTE continúan en el sitio coordinando el tránsito vehicular</td></tr><tr><td>Fuentes de información:</td><td>MTOP /SNGRE Unidad de Monitoreo Guayas</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167 Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 12 de 24

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/625f397c027854b508f4e3304b51c52141501a69a98f2794850af3031e655236.jpg)



Inundación


<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/La Unión/La Puntilla, Brisas del Río, Los Robles y San Francisco - La Iglesia - Juan Sanalata - La Limonal - Vicente Rocafuerte - La Pinela</td></tr><tr><td>Antecedentes:</td><td>Por causa de las lluvias, se suscitó el desbordamiento del río “Clementina” el 03/03/2022</td></tr><tr><td>Situación actual:</td><td>SNGRE en compañía de Jefe Político de La Unión, visitaron el sector San Clemente en horas de la noche del 23/03/2022, donde se procedió a realizar entrega de asistencia humanitaria, actualmente el nivel del caudal está con tendencia aumentar y las familias afectadas se mantienen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 209 viviendas afectadas.- 209 familias afectadas.- 718 personas afectadas.- 1 bien público afectado (puente).- 200 metros lineales afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE entregó asistencia humanitaria el 23/03/2022.Ministerio de Gobierno asistió con Jefe Político para colaborar con la entrega de asistencia humanitaria el 23/03/2022.</td></tr><tr><td>Fuentes de información:</td><td>GAD Babahoyo/SNGRE Unidad de Monitoreo Los Ríos</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/b6f6b4f7268ffd1df370fb732bbdbdf354cbb59a2ab83f26bab87955039fc640.jpg)



Hundimiento


<table><tr><td>Localización:</td><td>Bolívar/Chimbo/Cabecera Cantonal/barrio Tamban</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2020, se presentaron una serie de grietas y fallas en el pavimento de la cancha de uso múltiple a la iglesia, además mantienen una concordancia longitudinal con otras grietas observadas en la vía Chimbo - El Cristal.La noche del 21/12/2021 debido al proceso activo del hundimiento y de la infiltración del agua de escorrentía superficial por las grietas principalmente en la vía adoquinada, se produjo el colapso del muro que se encontraba en la parte superior de la calle adoquinada, causando la pérdida total de la plataforma de la vía de primer orden Chimbo - El Cristal.</td></tr><tr><td>Situación actual:</td><td>MTOP Bolívar continúa realizando trabajos de construcción de un relleno del Km 1.8 con el material pétreo, con la finalidad de recuperar la plataforma de la vía estatal.</td></tr><tr><td>Afectaciones:</td><td>- 2 viviendas destruidas (2 familias damnificadas 7 personas que se encuentran arrendando).- 3 viviendas afectadas (3 familias afectadas 16 personas; de las cuales 1 familia 10 personas se encuentran en el alojamiento temporal de la U.E La Asunción, 2 familias 6 personas se encuentran arrendando).- 1 bien privado destruido (iglesia)- 8 bienes públicos destruidos (1 concha acústica - salón de reuniones, 1 cancha deportiva, 4 postes, tubería de agua que abastece a las comunidades de Panchigua, Tingo y Miraflores, alcantarillado de la zona cero)- 150 metros de vía de primer orden Chimbo-El Cristal destruida.- 60 metros de la calle S/N adoquinada destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria del MTOP Bolívar conjuntamente con maquinaria del GAD Cantonal Chimbo, GAD Parroquial La Asunción, GAD Parroquial La Magdalena y Empresa Privada, realizan la extracción del material pétreo de la Mina de Pacatón y trabajos de relleno en la zona afectada.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Bolívar/MTOP-B</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/fd0b3bff90f901634cc5fb6118398419c8167d4f2b00de03dac70c2a4e5b1b97.jpg)


<table><tr><td>Localización:</td><td>Azuay/Camilo Ponce Enríquez/ Camilo Ponce Enríquez /Shumiral</td></tr><tr><td>Antecedentes:</td><td>Por causas de las lluvias se suscitó el incremento del caudal estero Bohórquez ocasionando un socavón en el puente que conduce a la comunidad de Shumiral.</td></tr><tr><td>Situación actual:</td><td>Con fecha 18/03/2022 se reunió el COE Cantonal para realizar un análisis de la situación que atraviesa el cantón por las lluvias suscitadas tomando las siguientes resoluciones:</td></tr><tr><td>Afectaciones:</td><td>Puente afectado</td></tr><tr><td>Acciones de respuesta:</td><td>-El Presidente del COE Cantonal acogiendo las recomendaciones de la plenaria Declara en Emergencia, vial, sanitaria, puentes, viviendas, riveras de los ríos y asistencia humanitaria a todo el cantón Camilo Ponce Enríquez.</td></tr></table>


Inundación


Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

<table><tr><td rowspan="2"></td><td>Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 13 de 24</td></tr><tr><td>- Recomendar al presidente del COE Cantonal solicitar la concurrencia al Gobierno Provincial del Azuay para intervenir en la vialidad a la Prefectura.- Declarar en sesión permanente al COE Cantonal y dejar activas las mesas 1,2,3, y 4.Con fecha 21/03/2022 se resuelve: Declarar en Estado de Emergencia, Vial, Sanitaria, Puentes, Viviendas, Riveras de los Ríos y Asistencia Humanitaria a todo El Cantón Camilo Ponce Enríquez.</td></tr><tr><td>Fuentes de información:</td><td>UGR Ponce Enríquez/SNGRE Unidad de Monitoreo Azuay-Cañar</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/a895896bd9778ff4e159a588af365bde438e28835cda6e00f3520a57181ee571.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/barrios Rosas, Bellavista, Tamboloma, Chunazana, Rosario.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2021, se reportó un movimiento de masa provocado por la filtración de agua de riego y la temporada lluviosa. El 23/11/2021, el Servicio Nacional de Gestión de Riesgos y Emergencias declaró la Alerta Naranja por movimientos en masa en un área de 130,94 hectáreas que comprende los barrios Rosas, Bellavista, Tamboloma, Chunazana y Rosario.</td></tr><tr><td>Situación actual:</td><td>Con fecha 22/03/2022 técnico de la UGR Nabón reporta que se ha evacuado 1 vivienda más adicional a las 43 viviendas ya reportadas.</td></tr><tr><td>Afectaciones:</td><td>- 44 familias integradas por 130 personas afectadas aproximadamente.- 44 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 40 metros de vía afectados (Vía parcialmente habilitada, sector Trancapata)- 60 metros de vía afectados (Vía parcialmente Habilitada, sector quebrada del Canal)- 1 casa comunal afectada con cuarteaduras.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones).- Iglesia demolida por los daños estructurales presentados.- Centro de salud con fisuras, en evaluación permanente por parte del MSP.</td></tr><tr><td>Acciones de respuesta:</td><td>Técnico de UGR Nabón se mantiene en continuo monitoreo de la zona afectada.MIDUVI realiza levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar / UGR Nabón.</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/fd63b65f53599d0c3b1ca96db01341bfac4f096487598c5093d6ce9f455cd574.jpg)


<table><tr><td>Localización:</td><td>El Oro/Santa Rosa/Santa Rosa, cabecera cantonal/29 de Noviembre</td></tr><tr><td>Antecedentes:</td><td>El 24/03/2022, por lluvias se registró el colapso de una vivienda de ladrillo y madera, dejando 1 familia de 4 personas damnificadas</td></tr><tr><td>Situación actual:</td><td>Al momento la familia se encuentra en casa de familia acogiente.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda destruida.- 1 familia de 4 personas damnificadas</td></tr><tr><td>Acciones de respuesta:</td><td>UGR del cantón Santa Rosa realizó levantamiento de información y confirmó la novedad.SNGRE coordina con UGR para la entrega de asistencia humanitaria.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE Unidad de Monitoreo El Oro / UGR Cantonal</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/bdc652ca74b6d84fae4f0bd530c085cbcbae5587570cc37d140800820bfdb617.jpg)


<table><tr><td>Localización:</td><td>Loja/Chaguarpamba/Chaguarpamba/Varios sectores</td></tr><tr><td>Antecedentes:</td><td>Debido a las precipitaciones registradas en la tarde del jueves 03/03/2022, se suscitaron inundaciones en varios sectores de la parroquia con anegación de las calles por colapso de alcantarillas. Adicional el día 15/03/2022 un deslizamiento de tierra afectó una vivienda con colapso parcial</td></tr><tr><td>Situación actual:</td><td>La vía de segundo orden continúa parcialmente habilitada al tránsito vehicular</td></tr><tr><td>Afectaciones:</td><td>- 11 viviendas afectadas.- 9 familias conformadas por 36 personas continúan habitando sus viviendas- 3 familia conformada por 08 personas fueron evacuadas por seguridad a casa de familias acogientes.- 1 institución educativa afectada (Colegio Técnico de Chaguarpamba)-20 metros de longitud de vía</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos Chaguarpamba, Personal de GAD Cantonal de Chaguarpamba y habitantes del sector realizaron los trabajos de limpieza.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 14 de 24 

<table><tr><td rowspan="2"></td><td>Pecia y hora de actualización. Viernes, 25 de marzo de 2022 - 09.13.43/ Pagina 14 de 24</td></tr><tr><td>Personal técnico de UGR Chaguarpamba continúa realizando levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>UMEVA Loja-Zamora Chinchipe- SNGRE /UGR Chaguarpamba</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/4e401c37f436fbeb2456ce9b196aca73875cd8d7d38504c8a30a30b1945ff258.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>El Oro/Pasaje /Uzhcurrumi/varios sectores: Jesús del Gran Poder, Tres de Mayo y Barrio Central; Calle Girón y Pasaje</td></tr><tr><td>Antecedentes:</td><td>El 13/03/2022, por lluvias suscitadas en horas de la noche, se registró un aluvión con desprendimiento de agua, material y lodo que afectó a tres sectores de la cabecera parroquial.</td></tr><tr><td>Situación actual:</td><td>SNGRE en presencia de GAD cantonal y jefatura política realizó entrega de asistencia humanitaria a 2 familias conformadas por 4 damnificadas y 3 conformadas por 7 personas afectadas por el evento.</td></tr><tr><td>Afectaciones:</td><td>- 25 viviendas afectadas por ingreso de agua y lodo (2 viviendas temporalmente no habitables).- 25 familias de 100 personas afectadas.- 2 familias de 4 personas damnificadas en casa acogiente.- 5 bienes públicos afectados por el arrastre de material, agua y lodo (Oficina CNEL, Seguro Campesino del IESS, Tramo de tubería de Agua Potable, Bodega de GAD Parroquial, 1 poste de energía eléctrica)</td></tr><tr><td>Acciones de respuesta:</td><td>MAG realiza levantamiento de información de los sectores agrícolas afectados.SNGRE coordinó con GAD Cantonal para la entrega de asistencia humanitaria.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ7 Unidad de Monitoreo El Oro/SNGRE UPREA.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/f1e3e7f4344c9a1dc72040b2f7462111b93a9cb08d6b2c27138ca959e148c284.jpg)


<table><tr><td colspan="2">Aluvión</td></tr><tr><td>Localización:</td><td>El Oro/Chilla/Chilla, cabecera cantonal/varios vectores (Carabota, El Cruce, El Cucho, Pacayunga)</td></tr><tr><td>Antecedentes:</td><td>El 13/03/2022, por lluvias se produjo el desbordamiento de una quebrada sin nombre, la cual provocó un aluvión ocasionando el socavamiento y pérdida de mesa vial de la vía de tercer orden. Adicional, producto del evento varias viviendas resultaron afectadas.</td></tr><tr><td>Situación actual:</td><td>El servicio energía eléctrica se encuentra restablecido en su totalidad y al momento la vía en el sector Carabota se encuentra parcialmente habilitada y los trabajos de limpieza continúan.Adicional 9 familias de 23 personas afectadas por el evento recibieron asistencia humanitaria; adicional las familias que se encontraban en los diferentes alojamientos temporales retornaron a sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 22 viviendas afectadas. (3 viviendas afectadas por ingreso de lodo ubicadas en zona de riesgo de deslizamiento, 1 vivienda con daños estructurales; la cual se encuentra inhabitable y 18 viviendas con daños estructurales leves que están habitables).- 15 familias de 50 personas afectadas en sus domicilios.- 7 familias de 24 damnificadas en diferentes alojamientos temporales: 4 familias de 15 personas que pernoctaron en familias acogientes del sitio Carabota retornaron a sus viviendas, 2 familias de 7 personas alojadas en refugio temporal Casa Comunal del sitio Pacayunga, retornaron a sus viviendas, 1 familia de 2 personas alojadas en refugio temporal UPC de Pacayunga, retornaron a sus viviendas.- 48 familias de 201 personas afectadas indirectamente por aislamiento, debido a daños en la vía.- 100 metros de vía afectada.- 50% del servicio de energía electica (restablecido en su totalidad)- 15 % servicio de agua Potable afectado (se realiza trabajos de remediación de tuberías)</td></tr><tr><td>Acciones de respuesta:</td><td>COE Cantonal de Chilla se encuentra activo desde el 08/02/2022.SNGRE en presencia de jefe político y UGR GAD realizó entrega de asistencia humanitaria a famitas afectadas por el evento.Obras Públicas del GAD Chilla realiza trabajos de remediación de tuberías MTOP y GAD Cantonal de Chilla realizan limpieza de la vía.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE Unidad de Monitoreo El Oro / SNGRE CZ7 Loja.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167 Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 15 de 24

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/726b91ef298b560cf701684120b2711d60b4adbc7a7f8aab8c24002e349eb771.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Loja/Loja/Gualel/Gualel</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2022, por lluvias registradas en la tarde se registró un aluvión en el sector.</td></tr><tr><td>Situación actual:</td><td>Al momento las familias damnificadas continúan en casas de acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 7 familias damnificadas (conformadas por 30 personas que permanecen en casa de familias acogientes.- 12 familias afectadas (3 en casa de familias acogientes.)- 5 viviendas destruidas- 12 viviendas afectadas.- 100 metros de longitud de vía aproximadamente.- 2 postes de alumbrado público destruidos.- 3 postes de alumbrado público afectados (en peligro de colapsar)- Red de servicio de agua potable afectado (60%)- 2 hectáreas de sembríos de maíz afectados.- 2 vehículos afectados (retirados del sector)</td></tr><tr><td>Acciones de respuesta:</td><td>Teniente Político de Gualel continúa con el levantamiento de información.VIALSUR continúa con los trabajos de limpieza en la vía.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/f54cbf01ea2bcd7e082f5407c575e259d05f7c83a1e46804a37ac428b7595518.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Loja/Espíndola/Jimbura/Machay, vía a Amaluza hacia Jimbura</td></tr><tr><td>Antecedentes:</td><td>Por lluvias presentadas en la madrugada del sábado 05/03/2022, se produjo un hundimiento.</td></tr><tr><td>Situación actual:</td><td>La vía de segundo orden que conduce desde Amaluza hacia Jimbura, continúa cerrada al tránsito vehicular.</td></tr><tr><td>Afectaciones:</td><td>- 20 metros de longitud de vía aproximadamente.- 9 viviendas afectadas.- 7 familias afectadas conformadas por 53 personas permanecen en sus viviendas- 01 familia conformada por 02 personas fue evacuadas por seguridad a la iglesia del barrio Machay.- 01 familia conformadas por 03 personas fueron evacuadas por seguridad a las instalaciones de la Unidad Educativa de Machay</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Espíndola confirmó la novedad y realizó el levantamiento de información</td></tr><tr><td>Fuentes de información:</td><td>SNGRE Unidad de Monitoreo de Eventos Adversos Loja/Zamora Chinchipe-SNGRE/UGR Espíndola</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/97e8fa2214e3c9eb99076ad06f6b309523963faa30adff8f4cde0c16bfc41de3.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Loja/Espíndola/Bellavista/Amaluza, vía Amaluza-Bellavista</td></tr><tr><td>Antecedentes:</td><td>El 05/03/2022, a causas de las lluvias se produjo un deslizamiento en el sector.</td></tr><tr><td>Situación actual:</td><td>La vía de segundo orden se encuentra parcialmente habilitada</td></tr><tr><td>Afectaciones:</td><td>- 25 metros de longitud de vía aproximadamente”- 4 viviendas afectadas.- 2 familias conformadas por 05 personas continúan habitando sus viviendas.- 2 familias conformadas por 04 personas fueron evacuadas por precaución a la Casa de acogida de la Iglesia de Bellavista- 1 unidad educativa afectada (Escuela de Educación Básica Melva Vicenta Ontaneda García)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Espíndola confirmó la novedad y realizó el levantamiento de información.VIALSUR continúa realizando los trabajos de limpieza en la vía</td></tr><tr><td>Fuentes de información:</td><td>SNGRE Unidad de Monitoreo Loja-Zamora Chinchipe / UGR Espíndola</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/93a598f850030fab2f02908b79199c72ed00c24a84522bb0707226323f1f5632.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Loja/Catamayo/El Tambo/La Merced</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas en la tarde el viernes 04/03/2022 se produjo el aumento del caudal de la quebrada Casharuro; causando una inundación en el sector.</td></tr><tr><td>Situación actual:</td><td>Se brindó asistencia humanitaria a las familias afectadas.El cantón Catamayo se encuentra declarado en emergencia desde el jueves 10/03/2022.</td></tr><tr><td>Afectaciones:</td><td>- 1 vehículo afectado.- 2 personas heridas- 1 persona fallecida</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167

<table><tr><td colspan="2">Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 16 de 24</td></tr><tr><td rowspan="7"></td><td>- 14 viviendas afectadas</td></tr><tr><td>- 14 familias conformadas por 66 personas afectadas</td></tr><tr><td>- 3 viviendas destruidas.</td></tr><tr><td>- 3 familias damnificadas conformadas por 6 personas</td></tr><tr><td>- 15.341 animales afectados (aves de corral, bovinos, vacunos, porcinos y alevines)</td></tr><tr><td>- 13,75 hectáreas afectadas de sembríos de legumbres.</td></tr><tr><td>- Red de servicio de agua potable afectado (70%)</td></tr><tr><td rowspan="2">Acciones de respuesta:</td><td>Técnico de SNGRE realizó la entrega de asistencia humanitaria</td></tr><tr><td>Personal y maquinaria de DEMAPAL continúa con trabajos de reparación en el sistema de distribución de agua</td></tr><tr><td>Fuentes de información</td><td>SNGRE Unidad de Monitoreo Loja-Zamora Chinchipe/UGR Catamayo</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/aa401cf3e81c32f5d38183e1df9d0b2c6079408c2db50122b7b2ceba9ea9ddcc.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Pichincha / Quito / Amaguaña/ Santa Isabel de Amaguaña por la vía antigua a Conocoto</td></tr><tr><td>Antecedentes:</td><td>El 23/03/2022, por lluvias, se reporta el desbordamiento de la quebrada San Pedrodel sector que ocasionó una inundación que afecta una vía de segundo orden.</td></tr><tr><td>Situación actual:</td><td>Se continúa con los trabajos de limpieza en el sitio; al momento se mantiene la vía de segundo orden cerrada</td></tr><tr><td>Afectaciones:</td><td>- 1 bien privado afectado(vehículo)- 1 vivienda afectada- 1 familia afectada (5 personas)</td></tr><tr><td>Acciones de respuesta:</td><td>EPMMOP, EPMAPS, Administración Zonal Los Chillos, EP EMSEGUIRDAD COE-M realizaron las tareas de limpieza, remoción de escombros y succión de agua en el lugar donde se registró el desbordamiento de la quebrada San Pedro.Se coordinan acciones de entrega de asistencia humanitaria a la familia afectada. AMT en el sitio realiza el direccionamiento del tránsito vehicular hasta culminar los trabajos de encausamiento</td></tr><tr><td>Fuentes de información</td><td>AMT/EPMAPS/CBDMQ/SNGRE Unidad de Monitoreo Pichincha</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 17 de 24 

3. Monitoreo de estado de vías afectadas por eventos peligrosos 

VÍAS DE PRIMER ORDEN: 


11 vías de primer orden cerradas


<table><tr><td></td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Chimborazo</td><td>Alausí</td><td>Alausí, Cabecera Cantonal</td><td>Km 537 Cementerio de Alausí, vía Alausí - Chunchi [E35]</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Guayas</td><td>Balao</td><td>Balao</td><td>E25 Panamericana Puente Gala como referencia a 1km del Recinto Shumiral</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Río Pindo, vía a la Costa [E50]</td><td>DELIZAMIENTO</td><td>---</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Loja</td><td>Calvas</td><td>Colaisaca</td><td>Asanuma, vía Cariamanga-Sozoranga[E69]</td><td>DESLIZAMIENTO</td><td>0</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 90, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Rumiñahui</td><td>Sangolquí</td><td>Selva Alegre, Av. Gral. Rumiñahui [E35] a la altura del club Naval</td><td>SOCAVAMIENTO</td><td>60</td><td>17/02/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Pichincha</td><td>Rumiñahui</td><td>Sangolqui</td><td>E-35 y Calle Viejo Roble</td><td>INUNDACIÓN</td><td>50</td><td>11/02/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 49, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>17/10/2021</td><td>Cuenca-Azogues-Biblian-Zhud-Cochancay-EI Triunfo y Cuenca-Girón-Pasaje-Machala-Guayaquil</td></tr><tr><td>10</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo, Cabecera Cantonal</td><td>barrio Tamban</td><td>HUNDIMIENTO</td><td>210</td><td>18/03/2020</td><td>Chimbo, San Miguel, San Pablo y Balsapamba/Chimbo-Susanga</td></tr><tr><td>11</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>875</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>


46 vías de primer orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Nanegalito</td><td>km 62, vía Mitad del Mundo - Río Blanco [E28]</td><td>DESLIZAMIENTO</td><td>---</td><td>25/03/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Pichincha</td><td>Quito</td><td>Nono</td><td>km 40, Río Blanco - Mitad del Mundo [E28]</td><td>DESLIZAMIENTO</td><td>---</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Loja</td><td>Catamayo</td><td>San Pedro</td><td>San Vicente, vía Catamayo- hacia la Costa [E69]</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Azuay</td><td>Gualaceo</td><td>Gualaceo</td><td>km 20 vía Cuenca-Gualaceo-Limón [E-45]</td><td>DESLIZMIENTO</td><td>50</td><td>22/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Bolívar</td><td>San Miguel</td><td>Balsapamba</td><td>a 1 Km de Santa Lucía, vía El Torneado</td><td>HUNDIMIENTO</td><td>50</td><td>22/03/2022</td><td>Chimbo-San Miguel-Balsapamba.</td></tr><tr><td>6</td><td>Loja</td><td>Saraguro</td><td>Saraguro</td><td>Salida de Saraguro, vía Saraguro - Loja [E35]</td><td>DESLIZAMIENTO</td><td>40</td><td>19/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Pichincha</td><td>Quito</td><td>Calacalí</td><td>km 32, vía Mitad del Mundo - Río Blanco [E28]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Loja</td><td>Calvas</td><td>Utuana</td><td>Utuana, vía Cariamanga-Macará[E69]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Bolívar</td><td>San Miguel</td><td>Balsapamba</td><td>km 50+000 al Km 63+300, vía Las Guardias-Balsapamba [E491]</td><td>HUNDIMIENTO</td><td>--</td><td>08/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>Varios sectores, Agua Blanca - La Piedra - Atandahua - Capilluco, vía Guanujo-Echeandía [E494]</td><td>DESLIZAMIENTO</td><td>220</td><td>07/03/2022</td><td>Guaranda-Balsapamba-La Esmeralda-Caluma.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 18 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>12</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Km 94, Siete Ríos, vía Pujilí - La Maná [E-30].</td><td>DESLIZAMIENTO</td><td>60</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Río Pindo, vía a la Costa [E50]</td><td>DESLIZAMIENTO</td><td>0</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Loja</td><td>Chaguarpamba</td><td>El Rosario</td><td>El Rosario vía a Portovelo</td><td>DESLIZAMIENTO</td><td>40</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>20</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 66, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>60</td><td>26/02/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Loja</td><td>Loja</td><td>Santiago</td><td>Santiago, vía Loja a Saraguro [E35]</td><td>DESLIZAMIENTO</td><td>20</td><td>26/02/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>0</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Pedro km 101-Rocafuerte, vía Salinas Lita E10</td><td>DESLIZAMIENTO</td><td>30</td><td>20/02/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>Puente sobre el río Pucuno, vía Hatun Sumaco, Y de Narupa</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>18/02/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Pedro, vía Salinas Lita E10</td><td>DESLIZAMIENTO</td><td>40</td><td>03/02/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>El Palmar, Tilipulo, Saraguasi, San José de Tilipulo, California, La Esperanza.</td><td>INUNDACIÓN</td><td>0</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilalo</td><td>Caserio Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tulcán - Ibarra 2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>27</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>10 de Agosto, vía Loreto - Tena [E45A-E20]</td><td>DESLIZAMIENTO</td><td>80</td><td>17/12/2021</td><td>Vía Chontapunta-La Belleza</td></tr><tr><td>28</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Macanas, vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>50</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>29</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>30</td><td>Napo</td><td>Tena</td><td>Chontapunta</td><td>Rayayacu, vía Chontapunta - La Belleza [E436]</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>17/11/2021</td><td>Vía de tercer orden Humuyacu-Yuralpa Derecho-Wachayacu.</td></tr><tr><td>31</td><td>Tungurahua</td><td>San Pedro De Pelileo</td><td>Pelileo</td><td>La Hamaca, vía Pelileo - Baños [E30]</td><td>SOCAVAMIENTO</td><td></td><td>16/10/2021</td><td>Ninguna</td></tr><tr><td>32</td><td>Manabí</td><td>Jipijapa</td><td>Jipijapa, Cabecera Cantonal</td><td>Quimís, Vía Colón-Quimís [E4-82]</td><td>COLAPSO ESTRUCTURAL</td><td>25</td><td>14/10/2021</td><td>Manabí hacía Guayas: E482 Sector Pila-Los Bajos de Montecristi-E15 Puerto Cayo-Jipijapa Jipijapa hacía Portoviejo: E-482 Rcto. Colón Quimi-Vía Tercer Orden-E462B Santa Ana-Portoviejo</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 19 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>33</td><td>Napo</td><td>Quijos</td><td>Cuyuja</td><td>Flor del Bosque, Quebrada Rio Negro, Jatuntinahua, Molana, El Laurel, vía Y de Baeza -Papallacta [E20]</td><td>DESLIZAMIENTO</td><td>200</td><td>19/07/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Nuevos Horizontes, vía Méndez-Guarumales [E40].</td><td>DESLIZAMIENTO</td><td>100</td><td>01/07/2021</td><td>Ninguna</td></tr><tr><td>35</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza</td><td>Sector Tucumbatza, vía Gualaquiza-San Juan Bosco [E45] (Primer Orden).</td><td>HUNDIMIENTO</td><td>50</td><td>30/06/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>38</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km. 101, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>12</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>39</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>40</td><td>Orellana</td><td>La Joya De Los Sachas</td><td>San Sebastián del Coca</td><td>Toyuca, Sardinas, Sebastian del Coca, vía La Joya de los Sachas - El Coca [E45A]</td><td>SOCAVAMIENTO</td><td>0</td><td>08/02/2021</td><td>Ninguna</td></tr><tr><td>41</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>42</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>43</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>44</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>45</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr><tr><td>46</td><td>Morona Santiago</td><td>Santiago</td><td>Patuca</td><td>Loma Seca vía Patuca - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>15</td><td>15/01/2020</td><td>Ninguna</td></tr></table>


VÍAS DE SEGUNDO ORDEN:



14 vías de segundo orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Cotopaxi</td><td>Sigchos</td><td>Sigchos, Cabecera Cantonal</td><td>Caserío Las Manzanas Km 3 y 7, vía Sigchos - Latacunga</td><td>DESLIZAMIENTO</td><td>--</td><td>23/03/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Pichincha</td><td>Quito</td><td>Amaguaña</td><td>Santa Isabel de Amaguaña por la vía antigua a Conocoto</td><td>INUNDACIÓN</td><td>--</td><td>23/03/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Guayas</td><td>San Jacinto de Yaguachi</td><td>Gral. Pedro J. Montero (Boliche)</td><td>Recinto La Melida</td><td>SOCAVAMIENTO</td><td>60</td><td>22/03/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Napo</td><td>Tena</td><td>Chonta Punta</td><td>Vía Comunidad Cano Yacu</td><td>DESLIZAMIENTO</td><td>--</td><td>15/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Puente de Jondachi, vía Y de Narupa - Tena[E45]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>El Oro</td><td>Piñas</td><td>Saracay</td><td>Chorro Viringo, Chorro, Vía Piñas - Saracay [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Piñas</td><td>Moromoro</td><td>Buenaventura, Vía Piñas - Zaracay [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Pepinales, vía Alausí - Huigra [E-47]</td><td>SOCAVAMIENTO</td><td>0</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Loja</td><td>Espíndola</td><td>Jimbura</td><td>Machay, vía a Amaluza hacia Jimbura</td><td>HUNDIMIENTO</td><td>20</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>Gral. Vernaza (Dos Esteros)</td><td>Recinto Hacienda Nueva</td><td>SOCAVAMIENTO</td><td>15</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Los Ríos</td><td>Valencia</td><td>La Unión</td><td>La Burbuja - Río San Pablo -Rcto. 6 de Agosto</td><td>INUNDACIÓN</td><td>125</td><td>30/01/2022</td><td>Puente Nuevo de la calle Arcos Pérez vía al río San Pablo.</td></tr><tr><td>12</td><td>Loja</td><td>Loja</td><td>Sucre</td><td>Parque Eólico, vía antigua a Catamayo [E35]</td><td>DESLIZAMIENTO</td><td>0</td><td>29/01/2022</td><td>Ninguna</td></tr></table>

Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 20 de 24 

Dirección de Monitoreo de Eventos Adversos 

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>13</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>14</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 32 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Loja</td><td>Catamayo</td><td>San Pedro</td><td>San Vicente, vía Catamayo- hacia la Costa [E69]</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Chimborazo</td><td>Alausí</td><td>Huigra</td><td>Chulpicay , vía Huigra - El Triunfo [E-47].</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>Quito</td><td>Lloa</td><td>Entrada a la parroquia Lloa</td><td>DESLIZAMIENTO</td><td>12</td><td>23/03/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>El Oro</td><td>Zaruma</td><td>Muluncay Grande</td><td>Muluncay Chico, vía Zaruma - Atahualpa [E-585]</td><td>SOCAVAMIENTO</td><td>3</td><td>22/03/2022</td><td>La misma</td></tr><tr><td>5</td><td>Tungurahua</td><td>Patate</td><td>Patate</td><td>Tunga, Vía Patate - Pillaro.</td><td>DESLIZAMIENTO</td><td>--</td><td>20/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Cahuají km 34 1/2, vía Penipe- Baños [E490]</td><td>DESLIZAMIENTO</td><td>--</td><td>17/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Piñas</td><td>Piñas, la matriz</td><td>Urna San José, Piñas - Saracay [E-585]</td><td>DESLIZAMIENTO</td><td>15</td><td>15/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Orellana</td><td>Francisco de Orellana</td><td>La Belleza</td><td>vía Jaguar 2 - Cacique Jumandy</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Loja</td><td>Saraguro</td><td>Tenta</td><td>Tenta, vía Tenta-Celén</td><td>DESLIZAMIENTO</td><td>20</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Pichincha</td><td>Mejía</td><td>Alóag</td><td>km 2.5 Tras el UPC de Alóag</td><td>INUNDACIÓN</td><td>10</td><td>08/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista vía Girón Santa Teresita</td><td>COLPASO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>El Oro</td><td>Piñas</td><td>Piñas / la matriz</td><td>LA GARGANTA, VIA PIÑAS - ZARACAY [E-585]</td><td>DESLIZAMIENTO</td><td>30</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Espíndola</td><td>Bellavista</td><td>Amaluza, vía Amaluza-Bellavista</td><td>DESLIZAMIENTO</td><td>25</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>MALVAS, VÍA MALVAS - ARCAPAMBA [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Bolívar</td><td>Guaranda</td><td>Salinas</td><td>Apahua, vía Guaranda - Salinas</td><td>DESLIZAMIENTO</td><td>---</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>KM 75, VIA MALVAS - ZARUMA [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Chimborazo</td><td>Alausí</td><td>Huigra</td><td>Pagma, vía Huigra - El Triunfo [E-47]</td><td>DESLIZAMIENTO</td><td>500</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Cotopaxi</td><td>Latacunga</td><td>Toacaso</td><td>San Francisco vía Sigchos - Latacunga</td><td>DESLIZAMIENTO</td><td>300</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Bolívar</td><td>San Miguel</td><td>San Vicente de Pusir</td><td>vía San Vicente - Ungubi</td><td>DESLIZAMIENTO</td><td>---</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Chimborazo</td><td>Alausí</td><td>HUIGRA</td><td>Por el puente dos bocas, vía Alausí - Huigra - El Triunfo [E47].</td><td>DESLIZAMIENTO</td><td>80</td><td>14/02/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>Chquisca, vía Guanujo-Las Cochas</td><td>DESLIZAMIENTO</td><td>30</td><td>09/11/2021</td><td>sector de Negroyacu o barrio Mantilla</td></tr><tr><td>22</td><td>Chimborazo</td><td>Guano</td><td>La Matriz</td><td>Barrios La Merced, La Dolorosa del cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu santo, La Dolorosa Centro, Balneario Los Elenes</td><td>ALUVIÓN</td><td>9000</td><td>11/12/2021</td><td>Ninguna</td></tr><tr><td>23</td><td>Zamora Chinchipe</td><td>Zamora</td><td>Cumbaratza</td><td>Tunantza Alto, vía Timbara Bajo - Timbara Alto</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/10/2021</td><td>Ninguna</td></tr><tr><td>24</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Puente Salado Grande, vía Macas-Riobamba-tramo 9 de Octubre-Cebadas [E46].</td><td>DESLIZAMIENTO</td><td>60</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>25</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>26</td><td>Tungurahua</td><td>Patate</td><td>Patate, cabecera cantonal</td><td>Puñapí, vía Puñapí - Baños.</td><td>DESLIZAMIENTO</td><td>---</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>27</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Km 78, vía Macas-Riobamba E46]</td><td>DESLIZAMIENTO</td><td>60</td><td>12/06/2021</td><td>Ninguna</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 21 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>28</td><td>Morona Santiago</td><td>Limón Indanza</td><td>General Leonidas Plaza Gutiérrez (Limón), cabecera cantonal</td><td>Cerro Bosco, vía Gualaceo-Limón (Segundo Orden).</td><td>DESLIZAMIENTO</td><td>50</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>29</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Km 35, vía Cahuají - Pillate - Cotaló [E-304].</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2021</td><td>Riobamba - Mocha - Baños</td></tr><tr><td>30</td><td>Pichincha</td><td>Quito</td><td>Checa (Chilpa)</td><td>Km 38+377, entrada a Checa, vía Cusubamba- Pifo</td><td>SOCAVAMIENTO</td><td>15</td><td>01/04/2021</td><td>Ninguna</td></tr><tr><td>31</td><td>Azuay</td><td>Nabon</td><td>Nabón, cabecera cantonal</td><td>Rosas, Bellavista, Tamboloma, Chunazana.</td><td>DESLIZAMIENTO</td><td>100</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>32</td><td>Morona Santiago</td><td>Gualaquiza</td><td>El Rosario</td><td>El Aguacate, vía Sig-Sig-Chiguinda-Gualaquiza [E594]</td><td>DESLIZAMIENTO</td><td>50</td><td>23/09/2020</td><td>Ninguna</td></tr></table>


VÍAS DE TERCER ORDEN:



44 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Zamora Chinchipe</td><td>Nangaritza</td><td>Zurmi</td><td>Comunidad Shaimi</td><td>DESLIZAMIENTO</td><td>---</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>San Miguel de Jipangoto.</td><td>DESLIZAMIENTO</td><td>---</td><td>21/03/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>recinto Miraflores, vía Luz María - Miraflores</td><td>SOCAVAMIENTO</td><td>--</td><td>20/03/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Quito</td><td>Amaguaña</td><td>Calle Abdón Calderón, sector El Pedregal, Amaguaña.</td><td>DESLIZAMIENTO</td><td>---</td><td>18/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Imbabura</td><td>Cotacachi</td><td>Cuellaje</td><td>San Antonio</td><td>DESLIZAMIENTO</td><td>50</td><td>17/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Loja</td><td>Loja</td><td>El Valle</td><td>Varios sectores</td><td>DESLIZAMIENTO</td><td>--</td><td>15/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Piñas</td><td>Piñas, La Matriz</td><td>San José, vía San José - Capiro</td><td>DESLIZAMIENTO</td><td>--</td><td>15/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Porotillo, vía Pasaje - Chilla</td><td>SOCAVAMIENTO</td><td>20</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>Los Beldacos</td><td>INUNDACIÓN</td><td>100</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>El Oro</td><td>Zaruma</td><td>Abañin</td><td>Algodonal, vía Algodonal - Sumo Bajo</td><td>SOCAVAMIENTO</td><td>10</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Cotopaxi</td><td>Sigchos</td><td>Isinliví</td><td>Guangomalag.</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Cotopaxi</td><td>Sigchos</td><td>Isinliví</td><td>Guantualo, vía Insiliví - Sigchos.</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Uzhcurrumi, vía Uzhcurrumi - Chillayacu</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>El Oro</td><td>Piñas</td><td>San Roque</td><td>Lozumbe, vía Lozumbe - Capiro</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>El Oro</td><td>Chilla</td><td>Chilla, cabecera cantonal</td><td>Nariz del Diablo, vía Nariz del Diablo - Chilla</td><td>DESLIZAMIENTO</td><td>60</td><td>11/03/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Bolívar</td><td>Guaranda</td><td>Simiatug</td><td>Cascarilla, Límite Provincial Entre Bolívar Y Cotopaxi.</td><td>DESLIZAMIENTO</td><td>100</td><td>08/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>El Oro</td><td>Pasaje</td><td>Progreso</td><td>Palo Marcado, Vía Palo Marcado - Progreso</td><td>DESLIZAMIENTO</td><td>15</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>El Oro</td><td>Portovelo</td><td>Salati</td><td>La Tira, Via Salati-Ambocas</td><td>DESLIZAMIENTO</td><td>30</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>El Oro</td><td>Piñas</td><td>Piñas Grande</td><td>Piñas Grandes, Vía Piñas Grande - Cabecera Cantonal</td><td>DESLIZAMIENTO</td><td>40</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>El Oro</td><td>Zaruma</td><td>Salvias</td><td>Ortega Alto, Vía Ortega Alto - Ortega Bajo</td><td>INUNDACIÓN</td><td>---</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Chimborazo</td><td>Pallatanga</td><td>PALLATANGA</td><td>San Juan de Trigoloma, vía San Juan de Trigoloma - Tablarrumi.</td><td>DESLIZAMIENTO</td><td>---</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Cotopaxi</td><td>Latacunga</td><td>TOACASO</td><td>San Francisco, vía Sigchos - Latacunga</td><td>DESLIZAMIENTO</td><td>20</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Pichincha</td><td>Quito</td><td>LLOA</td><td>vía Lloa - La Tablera</td><td>DESLIZAMIENTO</td><td>30</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Tungurahua</td><td>Ambato</td><td>ATOCHA FICOA</td><td>Atocha Ficoa/ 100 metros de la salida del parque, vía Atocha - Laquigo.</td><td>DESLIZAMIENTO</td><td>---</td><td>27/02/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>El Oro</td><td>Balsas</td><td>BALSAS</td><td>Aguacatillo</td><td>DESLIZAMIENTO</td><td>50</td><td>24/02/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 22 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>28</td><td>Pichincha</td><td>Mejía</td><td>MANUEL CORNEJO ASTORGA (TANDAPI)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>29</td><td>Cotopaxi</td><td>Sigchos</td><td>CHUGCHILLAN</td><td>Km 17, vía Sigchos - Chugchillán</td><td>DESLIZAMIENTO</td><td>0</td><td>04/02/2022</td><td>Ninguna</td></tr><tr><td>30</td><td>Cotopaxi</td><td>Sigchos</td><td>ISINLIVI</td><td>Isinliví /Isinliví, vía Isinliví - Guantualó.</td><td>HUNDIMIENTO</td><td>0</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>31</td><td>Los Ríos</td><td>Valencia</td><td>LA UNIÓN</td><td>La Burbuja -Rcto. 6 de Agosto - Tercera Banquera - Valle Negro - río San Pablo</td><td>INUNDACIÓN</td><td>125</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>32</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Ríoverde Alto, vía Lita - Rioverde Alto</td><td>DESLIZAMIENTO</td><td>50</td><td>18/12/2021</td><td>Ninguna</td></tr><tr><td>33</td><td>El Oro</td><td>Zaruma</td><td>Zaruma, cabecera cantonal</td><td>Calles Colon y 10 de Agosto</td><td>HUNDIMIENTO</td><td>---</td><td>15/12/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>Imbabura</td><td>San Miguel De Urcuquí</td><td>La Merced De Buenos Aires</td><td>San José</td><td>DESLIZAMIENTO</td><td>70</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>35</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Nueva alianza</td><td>INUNDACIÓN</td><td>7000</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>0</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>38</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia, Río Guataxi afluente del río Chanchán</td><td>DESLIZAMIENTO</td><td>0</td><td>12/02/2021</td><td>Ninguna</td></tr><tr><td>39</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>0</td><td>20/01/2021</td><td>Ninguna</td></tr><tr><td>40</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Guilliloma - Kullpa - Armenia</td><td>HUNDIMIENTO</td><td>0</td><td>26/12/2020</td><td>Ninguna</td></tr><tr><td>41</td><td>Morona Santiago</td><td>Palora</td><td>Cumandá (cab. en Colonia Agrícola Sevilla del Oro)</td><td>Puente sobre el río Charuyaku</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>23/10/2020</td><td>Palora-Puyo-Cumandá</td></tr><tr><td>42</td><td>El Oro</td><td>Zaruma</td><td>Abañin</td><td>Sumo Bajo, vía Abañin - Uzhcurrumi</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>43</td><td>Tungurahua</td><td>Quero</td><td>Quero, cabecera cantonal</td><td>San Vicente, vía Quero - Pelileo</td><td>SOCAVAMIENTO</td><td>0</td><td>13/07/2020</td><td>Ninguna</td></tr><tr><td>44</td><td>Tungurahua</td><td>Quero</td><td>Quero, cabecera cantonal</td><td>Quiambe, vía Quero - Rumipamba</td><td>SOCAVAMIENTO</td><td>0</td><td>13/07/2020</td><td>Ninguna</td></tr></table>

## 39 vías de tercer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Piñas</td><td>Piñas, La Matriz</td><td>Florida Alto, vía Kennedy - Piñas Grande</td><td>DESLIZAMIENTO</td><td>10</td><td>22/03/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>Chimbo</td><td>Telimbela</td><td>Varios sectores, San Francisco Chico, Choropamba, El Atio, Guarumal, vía Telimbela - Cochabamba y vía Telimbela - Al Valle.</td><td>DESLIZAMIENTO</td><td>50</td><td>21/03/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Morona Santiago</td><td>Logroño</td><td>Logroño</td><td>El Panecillo vía a voluntad de Dios</td><td>DESLIZAMIENTO</td><td>25</td><td>19/03/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza, cabecera cantonal</td><td>La Dolorosa, vía Guayuzal-La Dolorosa</td><td>ALUVIÓN</td><td>8</td><td>19/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Chilla</td><td>Chilla</td><td>Sada, vía Chilla - Pasaje</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>El Oro</td><td>Chilla</td><td>Chilla</td><td>Tucumba, vía Chilla - Pasaje</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>La Unión, vía Pasaje - Chilla</td><td>SOCAVAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>El Oro</td><td>Piñas</td><td>Piñas</td><td>Calera Chica, vía Piñas - Paccha</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>El Oro</td><td>Zaruma</td><td>Guanazán</td><td>Guanazán, vía Uzhcurrumi - Chillayacu</td><td>DESLIZAMIENTO</td><td>10</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>El Oro</td><td>Piñas</td><td>Capiro</td><td>Mochata, vía Piñas - Capiro</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>La Unión, vía Pasaje - Chilla</td><td>DESLIZAMIENTO</td><td>80</td><td>13/03/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>12</td><td>Chimborazo</td><td>Guamote</td><td>Palmira</td><td>Sector de Vishut Km 512, Vía Riobamba - Alausí [E-35].</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Pilchipamba el Descanso, vía Jipangoto - Azacoto.</td><td>INUNDACIÓN</td><td>14</td><td>08/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>El Oro</td><td>Piñas</td><td>Piñas, la matriz</td><td>Nueva Esperanza, vía Nueva Esperanza - Moromoro</td><td>DESLIZAMIENTO</td><td>25</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>El Oro</td><td>Zaruma</td><td>Huertas</td><td>Quizpe, Vía Quizpe - Muluncay</td><td>DESLIZAMIENTO</td><td>10</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>El Oro</td><td>Zaruma</td><td>Sinsao</td><td>Sinsao, Vía Sinsao - El Roble</td><td>DESLIZAMIENTO</td><td>30</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Cotopaxi</td><td>Pujilí</td><td>ANGAMARCA</td><td>Teodasín, vía Angamarca - Zumbahua</td><td>DESLIZAMIENTO</td><td>100</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Cotopaxi</td><td>Sigchos</td><td>Sigchos, Cabecera Cantonal</td><td>Toachi, vía Yaló - Sigchos.</td><td>DESLIZAMIENTO</td><td>20</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>El Oro</td><td>Portovelo</td><td>Portovelo</td><td>Buenos Aires</td><td>DESLIZAMIENTO</td><td>22</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>El Oro</td><td>Piñas</td><td>Capiro (Cab. En La Capilla De Capiro)</td><td>Conchicola, Vía Conchicola - Los Amarillos</td><td>DESLIZAMIENTO</td><td>20</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Limón, vía Pasaje - Uzhcurrumi</td><td>DESLIZAMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>El Arenal; Vía Lita E10</td><td>DESLIZAMIENTO</td><td>50</td><td>06/02/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>El Oro</td><td>Portovelo</td><td>Portovelo</td><td>Pindo, Vía Portovelo - Loja</td><td>DESLIZAMIENTO</td><td>10</td><td>04/02/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>El Oro</td><td>Pasaje</td><td>Progreso</td><td>La Playa</td><td>ALUVIÓN</td><td>7</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>Junquillal</td><td>Recinto El Morocho</td><td>SOCAVAMIENTO</td><td>6</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Balazul, Vía Jalubí - Las Rosas</td><td>DESLIZAMIENTO</td><td>40</td><td>25/01/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Barrio la Laguna, vía Sucúa- Asunción</td><td>ALUVIÓN</td><td>30</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>28</td><td>Tungurahua</td><td>Baños De Agua Santa</td><td>Lligua</td><td>Capa Rosa, vía Lligua - Baños.</td><td>ALUVIÓN</td><td>150</td><td>22/08/2021</td><td>Ninguna</td></tr><tr><td>29</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Yaucana</td><td>ALUVIÓN</td><td>---</td><td>23/07/2021</td><td>Ninguna</td></tr><tr><td>30</td><td>Napo</td><td>El Chaco</td><td>Oyacachi</td><td>Oyacachi, vía a Jariyacu- Huashahuaicu</td><td>DESLIZAMIENTO</td><td>---</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>31</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Nueva Tarqui</td><td>El Candi</td><td>HUNDIMIENTO</td><td>800</td><td>26/05/2021</td><td>Ninguna</td></tr><tr><td>32</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Centro Parroquial de Pananza</td><td>HUNDIMIENTO</td><td>10</td><td>20/05/2021</td><td>Ninguna</td></tr><tr><td>33</td><td>Tungurahua</td><td>Patate</td><td>Patate, cabecera cantonal</td><td>Puñapí, vía alterna Baños - Patate</td><td>DESLIZAMIENTO</td><td>80</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>Chimborazo</td><td>Riobamba</td><td>Quimiag</td><td>Sector Balcashí, vía Quimiag - Chambo</td><td>SOCAVAMIENTO</td><td>---</td><td>06/03/2021</td><td>Ninguna</td></tr><tr><td>35</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Puente sobre el río Malo</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>29/01/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Valle Hermoso</td><td>Sector Sarayacu.</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/01/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>38</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr><tr><td>39</td><td>Pichincha</td><td>Quito</td><td>Turubamba</td><td>Guamaní Alto - quebrada Caupicho, desde el puente de la av. Susana Letor hasta el puente de Guajaló</td><td>SOCAVAMIENTO</td><td>15</td><td>01/02/2020</td><td>Ninguna</td></tr></table>

## 4. Declaratorias emitidas por el SNGRE (vigentes en orden cronológico)

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/a2eaa595f51f7e23e1b9453eb26225003dd50788fd90be5aed1055d964f6f046.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Movimiento en masaBarrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SNGRE-171-2021</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0167
Fecha y Hora de actualización: viernes, 25 de marzo de 2022 - 09:13:45 / Página 24 de 24


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/811b529cf19bf573aca102c3fc14e17a8d01b8a494adf6b6de1a3e1a2d6b186b.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/9095918540e20ba863eafe825d715983b4ce17466fd2cee2f77e2dad86d723c9.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/7d3e9e600a86c69c94b0e611d0f0f0e702ed2ecd9f196c7b5ed538c186c81518.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/b375b6dcb17b4c32ce345fe874d09fd01d2df4baed82dd167638557aa6426c09.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/3fd5a96f272b7340aa0df4a3a1e28c4d6a41b38748baab12cb6a2b56c22d6a5a.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/ad9f6088a5d3f63a22eac55bb5d2084913cc60cd17b74f0091434d8f11318f7e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/6909862ee14da6332351d0259155120bfabf9d40b226d1eb2f1e9446b94a766a.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/e32ca87c7482476ae678fd183888cdd5831db5b4136c707969c3a7b9da48c7f9.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/cd05682452e7f21921c958f10756b3280df293e7a62106af473f13dea354eb28.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/0e7d7eaa0b49f4cb1528abcc99d6e9f27339d07c224570ea68ea67a55069828e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/86160d8a2cf6507004ac11f5324c0621f93f9d70c814203ac421b089eb75f7f7.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/acd04042f7dd4f82a2a91043948cdc52db3dae29ec5834a7468c3c255ae4b03f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/ecbcc94b2f34f1c7959512406059fed2ccce7e9ab8f86bb740f34abbe5da89b1.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/a30865bb04a634dec486c2227b140a3da9e728997efa510b071a40a62a35b9f1.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4d61c50f-fa16-49a0-8e87-fe654f7906b0/36af92c647fe0b43c211dfafffb24b3a16e3cd039f74871d0b9d2f50322d6c3b.jpg)


<table><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SNGRE-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SNGRE-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SNGRE-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SNGRE-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SNGRE-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SNGRE-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr></table>

<table><tr><td>Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Inundaciones Babahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td>Hundimiento, Zaruma, El Oro</td><td>07/03/2017</td><td>Resolución No. SGR-029-2015</td></tr></table>


Elaborado por: Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón
Revisado por: - Ing. Mariana Quispillo - Analista de Monitoreo de Turno 24/7 - Sala de Situación y Monitoreo Quito.
Emitido por Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 
