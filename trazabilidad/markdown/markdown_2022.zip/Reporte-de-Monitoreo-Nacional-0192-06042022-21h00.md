Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 1 de 24 

Periodo de Monitoreo: 

Desde: 09h00 06/04/2022 

Hasta: 21h00 06/04/2022 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/26bbd586ba78b2e6b2daf99d502257ee8277b3535f66528b263543ca668f0838.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/e8903e6311e37fe81d6b3b03184a8968379a558e861eab3c70da8006928e89c3.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>16h46 IGEPN informa que emisiones de vapor y ceniza con una altura de la nube volcánica mayor a los 800 metros sobre el nivel del cráter, en dirección Nor Oeste.</td><td>Amarillo</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/a8c129edb5ae1d3b56a5cf63cce66925dcd36be6a81086748bbdb8701f25a05c.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18h34 Mediante cámaras ECU 911 se visualiza el sector del volcán nublado.</td><td>Verde</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/439d32e8b90ada7a4a6d922e25659c9d0cfbd274af0fc88aac7daa90e20a0b74.jpg"/></td><td>Volcán Cotopaxi</td><td>SIN ALERTA</td><td>18h00 Mediante cámaras ECU 911 se visualiza el sector del volcán nublado y sin novedades.</td><td>Verde</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/dfc96b76f18fe79a18c94c22befbcb10416f5ab3708472c969602faf7d01e2ea.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>18h15 Mediante cámaras ECU 911 se visualiza el sector del volcán parcialmente nublado, sin novedad.</td><td>Verde</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/14a4a4d36ead4db6d0540f66adb46cc7b5dd68e8f069f25c1b4c9f552e49b73c.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18h00 Se visualiza el sector del volcán nublado.</td><td>Verde</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/fb5e97ee2f37f7bb34231b8a6909901c3bbcb5737dcca432a8b4159f96883fc1.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>16h02 IGEPN informa columna de emisión de gases y ceniza, observada en satélite y reportada por la VAAC de Washington, con una altura de la nube volcánica igual a los 1170 metros sobre el nivel del cráter, en dirección Oeste.</td><td>Amarillo</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/373a28f3ff09cdcba8d3ec7418d711e3fda904bf8947a566c8d658a2516a55bd.jpg"/></td><td>Volcán Wolf, Galápagos</td><td>SIN ALERTA</td><td>12h01 No se tiene reportes de la Washington VAAC.</td><td>Verde</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/c6ac2f23f01586f65382fc05a1c10530624c15495e44006fb99d378fcbe994d4.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">07 ríos desbordados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>Avenida 6 de Febrero</td><td>Jujan</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>sector de San zoilo, barrio apolo</td><td>Los Amarillos</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>La Providencia - LA Moraima</td><td rowspan="2">Chilintomo</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Dr. Camilo Ponce</td><td>Río Perdido</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>Varios Sectores</td><td>Ñauza</td></tr><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto Cabuyal</td><td>Pula</td></tr><tr><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>Gral. Vernaza (Dos Esteros)</td><td>Recinto Las Ramas /Hacienda Nueva</td><td>Mastrantal</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Dr. Camilo Ponce</td><td>Sol Brisa</td><td>Sabana</td></tr></table>


11 ríos con tendencia a aumentar de nivel 


## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 2 de 24


<table><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>Cotopaxi</td><td>Pangua</td><td>Moraspungo</td><td>Moraspungo</td><td>Río Calope</td></tr><tr><td>Esmeraldas</td><td>Quinindé</td><td>Chura (Chancama) (Cab. En El Yerbero)</td><td>Salinas</td><td>Esmeraldas</td></tr><tr><td>Guayas</td><td>General Antonio Elizalde (Bucay)</td><td>General Antonio Elizalde (Bucay), Cabecera Cantonal</td><td>Enrique Valdez</td><td rowspan="3">Chimbo</td></tr><tr><td>Guayas</td><td>Coronel Marcelino Maridueña</td><td>Coronel Marcelino Maridueña (San Carlos), Cabecera Cantonal</td><td>Sector Maravillas, Recinto Resistencia, La Isla, Producción Agrícola, Los Guayacanes</td></tr><tr><td>Guayas</td><td>San Jacinto De Yaguachi</td><td>Yaguachi Viejo (Cone)</td><td>Recinto Vuelta Larga</td></tr><tr><td>Guayas</td><td>Coronel Marcelino Maridueña</td><td>Coronel Marcelino Maridueña (San Carlos), Cabecera Cantonal</td><td>Recinto Barranco Alto</td><td>Barranco Alto</td></tr><tr><td>Guayas</td><td>Naranjal</td><td>Taura</td><td>Cabecera Cantonal - Malecón</td><td>Taura</td></tr><tr><td>Guayas</td><td>Coronel Marcelino Maridueña</td><td>Coronel Marcelino Maridueña (San Carlos), Cabecera Cantonal</td><td>La Modelo, Producción Agrícola Sur</td><td>Chanchan</td></tr><tr><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>El Salitre (Las Ramas), Cabecera Cantonal</td><td>Cabecera Cantonal (zona urbana)</td><td>Salitre</td></tr><tr><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>El Salitre (Las Ramas), Cabecera Cantonal</td><td>Cabecera Cantonal (zona urbana)</td><td>Vinces</td></tr><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto Bufay</td><td>Bufay</td></tr><tr><td>Guayas</td><td>Santa Lucía</td><td>Santa Lucía, Cabecera Cantonal</td><td>Recinto El Salto</td><td>El Salto</td></tr><tr><td>Guayas</td><td>Milagro</td><td>Milagro, Cabecera Cantonal</td><td>Recintos Los Monos</td><td>Los Monos</td></tr></table>

<table><tr><td colspan="5">00 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

<table><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/05067f916848782023024e46fb350f79b36cd43850c8443341b4ac1a3d279e48.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td>--</td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td>--</td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>83.10</td><td>85.00</td><td>03:28</td><td>Verde</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>116.33</td><td>117.00</td><td>00:11</td><td>Verde</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>63.60</td><td>66.00</td><td>11:05</td><td>Verde</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>104.35</td><td>106.50</td><td>11:05</td><td>Verde</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>62.05</td><td>68.50</td><td>11:05</td><td>Verde</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td>---</td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td>---</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192 Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 3 de 24

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/fa42539dab05fbb6b4e5b5288cab63378a8f3927aaa7b0a9ee44a4e7c6f639d4.jpg)


## SITUACIÓN HIDROMETEOROLÓGICA

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/98ec8473bd42b0885e949901fd8ba81515b2415dd354cf8e990a1b5ad885c2cf.jpg)


## ADVERTENCIA No. 13

AMENAZA: Lluvias y Tormentas Eléctricas 

Vigencia: desde 15H00 del 07 de Abril hasta 22H00 del 11 de abril 2022. 

SITUACIÓN: A partir de la tarde del 07/04/2022, se presentarán precipitaciones de intensidad variable en distintos sectores del territorio nacional. Es posible que los episodios más relevantes se presenten en la zona interior del Litoral, zona occidental del Callejón Interandino y norte - sur de la región Amazónica. 

## ZONAS AFECTADAS:

- Litoral: Las precipitaciones se enfocarán en la zona norte e interior, donde se podrán presentar tormentas eléctricas. 

- Callejón Interandino: precipitaciones de intensidad variable, mayor intensidad en localidades próximas a estribaciones de la cordillera occidental. 

- Amazonia: las precipitaciones serán dispersas y se presentarán de ligera a moderada intensidad con algunas descargas eléctricas. 

## Fuente: INAMHI

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/d0eea056868493c03ac9e40e2e00e42a5897b4b7caa19ab521e4120e8bff96b5.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/d5df1c4fb0b5caa972c85174473d86bc64c0eb0734f1b72d91e83e2069077d43.jpg)


## Sismo

<table><tr><td>Localización:</td><td>Esmeraldas</td></tr><tr><td>Antecedentes:</td><td>El 26/03/2022, a las 23:28 se registró un sismo de magnitud de 6,2 a 11,79 km de la ciudad de Esmeraldas</td></tr><tr><td>Situación actual:</td><td>El 03/04/2022 a las 02:46:31 se presentó un sismo de 3.5 con una profundidad de 8 Km.Anteriormente se habían presentado 2 sismos en la noche del 02/04/2022, uno de 3.3 y otro de 3.5 a las 18</td></tr><tr><td>Afectaciones:</td><td>- 493 viviendas con daños severos- 749 familias damnificadas- 2962 personas damnificadas- 2589 viviendas con afectación leve- 1222 viviendas con afectación parcial- 876 familias afectadas- 3583 personas afectadas- 16 unidades Educativas afectadas- 15 centros de salud afectados- 12 bienes públicos afectados- 6 bienes privados afectados- 1 puente afectado</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE conjuntamente con otras instituciones continúan con el levantamiento de información.Se mantiene activo el COE Provincial. El PMU y el COE Cantonal de Esmeraldas.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

<table><tr><td colspan="2">Fecha y Hora de actualización: miercoles, 06 de abril de 2022 - 21:15.20 / Pagina 4 de 24</td></tr><tr><td></td><td>Se mantiene activo el Puesto de Comando en el Batallón de infantería Motorizados (BIMOT) de las Fuerzas Armadas, liderado por la Sra. Gobernadora.Mediante la coordinación de la mesa MTT 4 se realizó la entregó asistencia humanitaria por medio de ACNUR.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Esmeraldas/GAD Cantonal Esmeraldas/Cruz Roja/MSP/MINEDUC/UGR Esmeraldas/Cuerpo de Bomberos Quito/MIDUVI/ACNUR/MINTUR</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/e6789881269614de4b143af86c5efc4657f59110ae51eae48c657683957e7085.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Ibarra/Carolina/San Jerónimo; vía Salinas - Lita [E 10]</td></tr><tr><td>Antecedentes:</td><td>El 22/12/2021, producto de las fuertes precipitaciones, se registró un deslizamiento que afectó la vía de primer orden E10, colapsando totalmente la mesa de la vía.</td></tr><tr><td>Situación actual:</td><td>Debido a las fuertes precipitaciones registradas el 31/03/2022, se presentaron deslizamientos en el sector que dejan la vía parcialmente habilitada al tránsito vehicular.</td></tr><tr><td>Afectaciones:</td><td>- El 05/02/2022, se afectó un tramo de 80 metros de la vía.- El 30/01/2022, 100 metros lineales de vía afectada por material pétreo- El 22/12/2021, se afectaron 125 metros lineales de vía con material pétreo- 2 postes de hormigón de telecomunicaciones.- Colapso de la mesa de la vía en un tramo de 50 metros.- 40 vehículos y sus propietarios que se encontraban atrapados en el tramo Guadual - San Jerónimo, fueron evacuados del sector.- 1 persona fallecida</td></tr><tr><td>Acciones de respuesta:</td><td>PPNN realiza el control permanente en el sector y brinda seguridad al tránsito vehicular.ANT regula la circulación vehicular y las frecuencias autorizadas en el sector.MAATE realizó el informe del estado de fuente de agua y, en su conclusión, indica la necesidad de la construcción de terrazas paralelas en la parte alta con drenajes adecuados de aguas lluvias.MTOP contrató los estudios de Refracción Sísmica en el talud 114+400.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/MTOP/PPNN</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/f70329b1cbd3483ac31c1cae62f22c1f3d943d8cc21aeadd2c1a412e71bf101f.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>De acuerdo al informe del SNGRE del 26/11/2021, indica que el evento se suscitó en la vertiente heterogénea, se presume que el factor desencadenante de los movimientos en masa es el agua, además, de la presencia de fuertes lluvias.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas)- 12 familias damnificadas (35 personas)- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 familias en familias acogientes)- 12 viviendas destruidas- 6 viviendas afectadas- 6 invernaderos destruidos de tomate riñón y pepinillo;- 5 Reservorios colapsados- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados-800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado- 150 metros destruidos de la red de distribución de agua de consumo humano- 150 metros de la red de alcantarillado destruidos- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El COE Cantonal se mantiene activo desde el 24/11/2021.GAD Cantonal de Pimampiro, en apoyo del GAD Imbabura, trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad. La nueva vía tendrá la conexión directa de las</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 5 de 24 

<table><tr><td></td><td>comunidades de Aloburo, San Juan, entre otras comunidades, con su cabecera cantonal.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/Yachay/MAG/MIDUVI/GAD Provincial /GAD Cantonal /UGR/ SNGRE - UPREA -UAR</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/6fac4a6a2d5cbd16a8d74b569c6f75e05ee72dbed13f1c7e6b775294395e864a.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Napo/ El Chaco/ Gonzalo Díaz De Pineda (El Bombón)/ San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45]</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial E45, Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio. El frente de erosión se mantiene en la abscisa 7+900(puente de San Carlos) por 249 días. El paso vehicular por la vía Baeza Lago Agrio está cerrada, la ruta alterna Y de Baeza-Y de Narupa-Loreto-El Coca-Lago Agrio está habilitada.</td></tr><tr><td>Situación actual:</td><td>San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio. El paso vehicular por la vía Baeza Lago Agrio está cerrada, la ruta alterna Y de Baeza-Y de Narupa-Loreto-El Coca-Lago Agrio está habilitada.</td></tr><tr><td>Afectaciones:</td><td>- 05/03/2022. 1 familia evacuada- 04/03/2022, 2 familias evacuadas.- 19/01/2022, 1 familia evacuada (1 persona).- 05/01/2022, evacuación de enseres de 3 familias (ya se encontraban 2 familias evacuadas días anteriores y la tercera familia continúa en su vivienda).- 20/12/2021, 1 familia (10 personas) evacuadas.- 13/12/2021, rotura de la tubería de poliducto.- 10/12/2021, población de San Rafael sin energía eléctrica.- 03/12/2021, puente sobre el río Piedra Fina 2 en riesgo.- 21/11/2021, 1 tubería de agua afectada.- 19/05/2021, 1 puente destruido (puente denominado Ventana 2).- 18/05/2021, 2 viviendas destruidas (las familias fueron evacuadas en febrero del 2021).- 10/03/2021, 1 bien afectado (tanque de agua).- 27/02/2021, 2 familias damnificadas y evacuadas a alojamiento temporal (al momento están en arriendo por sus propios medios); 2 viviendas presentaron fisuras.- 22/10/2020, 1 puente destruido (puente sobre el río Montana).- 06/05/2020, 2 familias afectadas, 2 viviendas afectadas.- 07/04/2020, 3 bienes afectados (tuberías del SOTE, Poliducto Shushufindi- Quito y la OCP).- Afectación vial: las pérdidas y afectaciones relevantes en vías ocurrieron en un total de 875 metros de la vía E45.Afectación agropecuaria: durante algunos meses se ha identificado 100 ha de superficie agrícola perdida, 63 porcinos y 3000 tilapias perdidas y afectación a 385 bovinos.</td></tr><tr><td>Acciones de respuesta:</td><td>El 16/03/2022, SNGRE CZ2 realizó levantamiento de fichas de las familias damnificadas en base al informe del GAD Municipal El Chaco, además, participó en la socialización de los estudios de tomografía sísmica, realizados por IKIAM, al personal técnico del GAD El Chaco ante el continuo avance del proceso de erosión hídrica. CELEC EP y Petroecuador realizan el monitoreo de la erosión.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ2 Unidad de Monitoreo Napo-Orellana/MSP/OCP Ecuador.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192 Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 6 de 24

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/2e1a514597bac40d38a2024d0ab79360cb7f2596fdb4d202fa81dfc8e3f8dc19.jpg)



Inundación


<table><tr><td>Localización:</td><td>Cotopaxi/Pujilí/Tingo/Siete Ríos y Macuchi.</td></tr><tr><td>Antecedentes:</td><td>El 30/01/2022 a causas de las lluvias se produjo el desbordamiento de un estero provocando afectación a varias viviendas del sector.</td></tr><tr><td>Situación actual:</td><td>Las personas que permanecían en el alojamiento temporal de Macuchi salieron del mismo, al momento no se reporta presencia de lluvias.</td></tr><tr><td>Afectaciones:</td><td>- 3 familias (6 personas albergadas en Macuchi casa comunal).- 6 familias (29 personas se encuentran con familias acogientes).- 1 bien público afectado.- 19 familias afectadas (44 personas).- 15 familias damnificadas (42 personas).- 20 viviendas afectadas- 6 viviendas destruidas- 35 metros de vía afectada (perdida de cuneta y señalización vertical, socavación por crecida de río).- La vertiente de donde se abastecía la población de agua se encuentra afectada al 100%.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Cantonal indica que en Macuchi ya se cerró el alojamiento temporal por cuanto las personas ya salieron del mismo.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ3 Unidad de Monitoreo Chimborazo/UGR GAD Pujilí</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/bd86e7fcc1fffb93112a378816de9d1591788ef02d3a010c18e2b1b7b9e59ba5.jpg)


<table><tr><td colspan="2">Inundación</td></tr><tr><td>Localización:</td><td>Santo Domingo de los Tsáchilas/Santo Domingo/Santa María del Toachi/Recinto el Bimbe</td></tr><tr><td>Antecedentes:</td><td>El 02/04/2022 producto de las lluvias, se produjo el desbordamiento del Río Toachi, lo que provocó el ingreso de agua a viviendas cercanas al río, de igual manera las familias continúan en sus viviendas.</td></tr><tr><td>Situación actual:</td><td>El nivel del Río Toachi se encuentra en su estado es normal.</td></tr><tr><td>Afectaciones:</td><td>- 5 viviendas afectadas.- 5 familias, 20 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos realizó trabajos de evacuación de enseres de hogar y ponerlos a buen recaudo.SNGRE coordinó con Patronato del GAD Municipal para la evaluación de daños y análisis de necesidades.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ4 Unidad de Monitoreo Santo Domingo/SIS. ECU 911/Cuerpo de Bomberos de Santo Domingo/GAD Parroquial.</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/523747ef6f711ad74abd99aaaf5d619ee064a7700f30e0775e8e5540781ada32.jpg)


## Vendaval

<table><tr><td>Localización:</td><td>Guayas/Santa Lucia/Santa Lucia, Cabecera Cantonal/varios sectores</td></tr><tr><td>Antecedentes:</td><td>El 01/04/2022, por lluvias y vientos fuertes se produjo varios vendavales, causando el desprendimiento del techo de varias viviendas.</td></tr><tr><td>Situación actual:</td><td>Una familia afectada se encuentra en casa de acogida hasta poder realizar reparaciones de su vivienda.</td></tr><tr><td>Afectaciones:</td><td>- 4 viviendas afectadas (3 viviendas de construcción de cemento y una de construcción mixta caña y madera) - 4 familias, 23 personas afectadas (una familia integrada por 6 personas se encuentra en familia acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal realizó verificación y levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Santa Lucia</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/8728b0496da70f9d36682b7300c1f618fb2597c4c9c9f44e5e247fc479f6826a.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Guayas/Guayaquil/Pedro Carbo/Cerro del Carmen, tercer callejón Modesto Carbo Noboa y 26 de julio.</td></tr><tr><td>Antecedentes:</td><td>El 01/04/2022, a causa de las lluvias se produjo un deslizamiento de tierra en el cerro del Carmen.</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

<table><tr><td>Situación actual:</td><td>Hasta el momento existen tres viviendas en riesgo de colapsar ubicadas en dicha pendiente, de las cuales 2 son habitadas por 3 familias y una deshabitada.</td></tr><tr><td>Afectaciones:</td><td>---</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Guayaquil verificó novedad.GAD Cantonal realizó levantamiento de información y entrega de asistencia humanitaria a las familias afectadas</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Guayas/Cuerpo de Bomberos de Guayaquil/GAD Cantonal Guayaquil.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/5fca79a4e43eec7473d352f2c7cfe24bb92a5829a5bb88fc4fd760e7684831b6.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Quinsaloma/Quinsaloma/recintos: Chipe Minuape - Rcto. San Gabriel</td></tr><tr><td>Antecedentes:</td><td>El 01/04/2022, debido a las fuertes lluvias que provocaron el rompimiento del muro y el desbordamiento del río Pijullo, se vieron afectadas varias viviendas en el sitio.</td></tr><tr><td>Situación actual:</td><td>Se rectifica el sector del recinto Pijullo a recinto Roblecito, con actualización en los valores de afectaciones; el nivel del caudal se encuentra normal y las familias afectadas permanecen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 32 viviendas afectadas.- 32 familias afectadas.- 102 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Urdaneta asistió al sitio para verificación de afectaciones el 06/04/2022.MIES realizó levantamiento ODK en la zona el 03/04/2022.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Los Ríos/GAD Urdaneta/MIES</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/668f5c2e0df938633127b1eb7fe3ac42a56271017eefc26710649e7690e5e00c.jpg)



Inundación


<table><tr><td>Localización:</td><td>Los Ríos/Quinsaloma/Quinsaloma/recintos: Chipe Minuape - Rcto. San Gabriel</td></tr><tr><td>Antecedentes:</td><td>El 26/03/2022, a las fuertes lluvias suscitadas en la zona, se reporta el desbordamiento del río Chipe el 26/03/22, afectando metros lineales de la vía y a viviendas del lugar.</td></tr><tr><td>Situación actual:</td><td>Mediante barrido en la zona se verificó que el nivel del caudal se mantiene en su cauce normal, las familias afectadas fueron otorgadas de ayuda humanitaria y permanecerán en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 59 viviendas afectadas.- 59 familias afectadas.- 245 personas afectadas.- 70 metros lineales</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Quinsaloma realizó entrega de ayuda humanitaria y verificó situación actual en la zona el 05/05/2022 y nos facilita documento EVIN.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Los Ríos/GAD Quinsaloma</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/1322724c82edca6f9f05e551a0a6d16b1256052d637d402b0c4a43393f585e4f.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Baba/Guare/Guayabo - Cancagua - Riveras del Arenal</td></tr><tr><td>Antecedentes:</td><td>El 26/03/2022, las fuertes lluvias suscitadas provocaron el desbordamiento del río El Arenal y el 28/03/2022 del río Matecito.</td></tr><tr><td>Situación actual:</td><td>Al momento los caudales se encuentran con tendencia a disminuir de nivel y las familias afectadas permanecen en sus hogares</td></tr><tr><td>Afectaciones:</td><td>- 20 viviendas afectadas.- 20 familias afectadas.- 80 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>MAG asistió el 04/04/2022 para verificación de afectaciones a cultivos.Teniente Política realizó verificación de afectaciones.SNGRE coordinó con Cruz Roja y GAD Baba inspección técnica el 29/03/2022 en las zonas afectadas.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Los Ríos/Ministerio de Gobierno/UGR Baba/SNGRE UPREA</td></tr></table>

Inundación 

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192 Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 8 de 24

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/064bb74e6e24e89c628e5a49aa504f10e17c4357972df12e06dd6a67829f5a4d.jpg)


<table><tr><td>Localización:</td><td>Los Ríos/Baba/Baba/Jobo - recintos: Tinoco - Coop. 27 de noviembre - Higuerilla - Rosa de Oro - El Arenal</td></tr><tr><td>Antecedentes:</td><td>El 26/03/2022, las lluvias provocaron el desbordamiento del río La Flora y río El Arenal, afectando a las viviendas del - recintos: Tinoco - Coop. 27 de noviembre - Higuerilla - Rosa de Oro</td></tr><tr><td>Situación actual:</td><td>Al momento los caudales de los ríos se encuentran con tendencia a disminuir de nivel y las personas permanecen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 73 viviendas afectadas.- 73 familias afectadas.- 292 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Teniente Política realizó barrido en el sitio para verificación de afectaciones. UGR realiza el respectivo EVIN.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Los Ríos/Ministerio de Gobierno/UGR Baba</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/a22f2e5419203e6d58a9641262f98bc9dc5f7c4d2ef6a537dc597e4a14bf6221.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Santa Lucia/Santa Lucia, Cabecera Cantonal/varios sectores</td></tr><tr><td>Antecedentes:</td><td>El 21/03/2022, por lluvias registradas se produjo el desbordamiento de los ríos Pula y Daule, así como de los esteros Bufay, El Salto y Lagarto, provocando inundaciones en varios sectores.</td></tr><tr><td>Situación actual:</td><td>Se realizó entrega de asistencia humanitaria</td></tr><tr><td>Afectaciones:</td><td>- 8 viviendas afectas- 11 familias, 33 personas afectadas.- 1251 hectáreas afectadas de Cultivos de arroz (datos preliminares)- calles inundadas</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Cantonal en acompañamiento a MSP entregaron toldos</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Santa Lucia</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/419b2efd919b02507462a76b7c04774b23dd2d88ce7d8cae79078dfe89afcae8.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Balzar/Balzar, Cabecera Cantonal/varios sectores</td></tr><tr><td>Antecedentes:</td><td>El 19/03/2022, por lluvias se produjo el desbordamiento de los ríos Chicompe y Puca, causando inundación en el Recinto Chicompe y varios sectores. Con fecha 21/03/2022 se desbordó el Río San Pauleño que ocasionó inundación en el Recinto Salamina. Con fecha 23/03/2022 se desbordó el Río Pucón ocasionando inundación en el Recinto San Pableño.</td></tr><tr><td>Situación actual:</td><td>Se realizó entrega de asistencia humanitaria a las familias afectadas del sector La Oz y La Pampa, las cuales fueron donadas por parte de la Gobernación del Guayas.</td></tr><tr><td>Afectaciones:</td><td>- 111 viviendas afectadas- 111 familias, 338 personas afectadas (4 familias, 18 personas se encuentra en familia acogiente y las demás familias permanecen en sus inmuebles)- cultivos de arroz, maíz y cacao</td></tr><tr><td>Acciones de respuesta:</td><td>05/04/2022SNGRE, GAD Cantonal, Cruz Roja. CB Balzar acompañaron en la entrega de asistencia humanitaria donada por Gobernación</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Guayas/UPREA/GAD Cantonal Balzar</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/858112ee6e44da0b27017ab20176562fd91a93158f7b6c9aa7760fb555417297.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/El Salto/La Chorrera - cancha La Pava - Coop. Rosa de Agosto - Justino Cornejo - río Catarama</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2022, por causa de las lluvias se produjo el desbordamiento del caudal del río Catarama de Urdaneta y Sabana, que afectaron varias viviendas de la zona baja en el cantón Babahoyo.</td></tr><tr><td>Situación actual:</td><td>El río Catarama se encuentra con tendencia a disminuir de nivel; las familias afectadas permanecen en sus viviendas y 1 familia continúa en casa acogiente.</td></tr><tr><td>Afectaciones:</td><td>- 78 viviendas afectadas.- 78 familia afectadas (1 familia de 7 personas en casa acogiente).- 312 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>El 22/03/2022, FFAA, SNGRE y MAG realizaron inspección en las zonas afectadas</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

Fecha y Hora de actualización: miércoles, 06 de abril de 2022 – 21:15:20 / Página 9 de 24 

Cuerpo de Bomberos de Babahoyo asistió al sitio para inspección 

Fuentes de información: SNGRE CZ5 Unidad de Monitoreo Los Ríos/FFAA/MAG/Cuerpo de Bomberos Babahoyo/Ministerio de Gobierno/SNGRE UPREA 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/f084887a599b65aa671e872a2757eea5420d82084de54e58e92734839131edad.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Clemente Baquerizo/Universidad Agraria, vía Montalvo - Los Laureles, atrás de la Unidad Educativa Réplica Eugenio Espejo - 1ro de Mayo - La Ventura - Justino Cornejo - Mujeres Solas - Paraíso Norte.</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2022, debido a lluvias, se reportó acumulación de aguas lluvias con los consecuentes desbordamientos del río San Pablo y del estero Sabana que afectó el tránsito normal de vehículos en la vía.</td></tr><tr><td>Situación actual:</td><td>La vía se encuentra habilitada sin presencia de agua y el tránsito circula con normalidad, el río San Pablo se encuentra con tendencia disminuir de nivel y el estero Sabana desbordado, adicional a ello las familias afectadas se mantienen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 519 viviendas afectadas.- 519 familias afectadas.- 1876 personas afectadas.- 1000 metros lineales afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>CTE realizó verificación de novedades en la vía.UGR Babahoyo realizará levantamiento de información en el sitio.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Los Ríos/CTE</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/2dd105e0fb3f0bc658b66a029b136c151dac1ba7517e9be2553de1aec1788fa8.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Alfredo Baquerizo Moreno (Jujan)/Alfredo Baquerizo Moreno, cabecera cantonal/varios sectores</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2022, por lluvias registradas se desbordó el río Jujan ocasionado el ingreso de agua en las calles y avenidas de los sectores Calle Malecón, Calle 13 de Noviembre, Calle Simón Bolívar y Barrio Sur. Con fecha 12/03/2022 se desbordó el río Los Amarillos afectando el Barrio San Zoilo, Barrio Apolo, Primero de Mayo, Miguel Yúnez. Con fecha 19/3/2022 se desbordó el río Chilintomo afectando a los sectores de La Providencia - La Moraima. Por lluvias ocasionadas la noche del 18/03/2022 y madrugada del 19/03/2022 los ríos Juan, Chilintomo y Los Amarillos se desbordaron.</td></tr><tr><td>Situación actual:</td><td>Los ríos Juján, Los Amarillos, Chilintomo y estero Ñauza siguen desbordados</td></tr><tr><td>Afectaciones:</td><td>- 740 viviendas afectadas.- 740 familias afectadas- 2615 personas afectadas en sus viviendas.</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE realizó la entrega de asistencia humanitaria, donada por la Gobernación de GuayasPPNN realizó resguardo policial a la ciudadaníaAlcaldesa y Personal Técnico del GAD Cantonal, Cruz Roja, Jefe Político, acompañaron a la entrega de asistencia humanitaria</td></tr><tr><td>Fuentes de información:</td><td>GAD Cantonal Jujan / SNGRE Unidad de Monitoreo Guayas</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/a82f7cb211d602d9b93511399e3befbb125e8efa5a76b409a4405710d012334e.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Caluma/Caluma/varios sectores (El Triunfo, La Esperanza - San Vicente de Pacana, Paraíso, Charquiyacu, barrio San José, San Vicente, barrio Central, Guayabal, Guamaspungo - Hemisferio, Plomovado)</td></tr><tr><td>Antecedentes:</td><td>El 20/03/2022, por las lluvias se produjo nuevamente el desbordamiento del río Caluma en el sector de Charquiyacu donde se reporta la pérdida de la mesa de la vía de tercer orden que conduce al centro de Salud Charquiyacu - Hoyobravo.</td></tr><tr><td>Situación actual:</td><td>Se realizó la entrega de asistencia humanitaria en el sector de Charquiyacu, 1 kit agrícola, 1 kit botiquín veterinario y 24.000 Kg de banano, siendo beneficiados 40 productores.Se continúa realizando los trabajos de encauzamiento y dragado del río Caluma en los sectores de Retiro de Charquiyacu y en Charquiyacu; además GAD Provincial concluyó con los trabajos de reforzamiento de las bases del puente vehicular.</td></tr><tr><td>Afectaciones:</td><td>-10 bienes privados afectados (chancheras)</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

<table><tr><td rowspan="13"></td><td>Fecha y Hora de actualización: miercoles, 06 de abril de 2022 - 21:15:20 / Pagina 10 de 24</td></tr><tr><td>-16 bienes privados destruido (Complejo Turístico Acorazado, Chancheras, Galpones)</td></tr><tr><td>- 5 bienes públicos afectados (1 captación de agua, 3 alcantarillas afectadas, 191 metros lineales de muro de contención de gaviones)</td></tr><tr><td>- 41 metros lineales de calle adoquinada afectada</td></tr><tr><td>- 205 metros lineales de vía de tercer orden afectada</td></tr><tr><td>- 180 ha de cultivos afectados</td></tr><tr><td>- 25 ha de cultivos perdidos</td></tr><tr><td>- 180 animales afectados</td></tr><tr><td>- 220 animales muertos</td></tr><tr><td>- 43 productores afectados</td></tr><tr><td>- 25 productores con pérdida total</td></tr><tr><td>- 2 puentes vehiculares afectados (hormigón armado y metálico)</td></tr><tr><td>- 1 puente peatonal destruido de caña de guadua.</td></tr><tr><td rowspan="2">Acciones de respuesta:</td><td>GAD Cantonal Caluma y la Empresa Privada continúan realizando trabajos de encauzamiento, dragado del rio Caluma.</td></tr><tr><td>GAD Provincial realizó reforzamiento de las bases del puente de hormigón. MAG Bolívar realizó la entrega de asistencia humanitaria a productores.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Respuesta y Unidad de Monitoreo Bolívar/GAD Cantonal/SNGRE CZ5</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/3f9bda2a97cdd7cd149558a9af5ba41138399355fb06e31ec04e9345e52814db.jpg)



Hundimiento


<table><tr><td>Localización:</td><td>Bolívar/Chimbo/Cabecera Cantonal/barrio Tamban</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2020, se presentaron una serie de grietas y fallas en el pavimento de la cancha de uso múltiple a la iglesia, además mantienen una concordancia longitudinal con otras grietas observadas en la vía Chimbo - El Cristal.La noche del 21/12/2021 debido al proceso activo del hundimiento y de la infiltración del agua de escorrentía superficial por las grietas principalmente en la vía adoquinada, se produjo el colapso del muro que se encontraba en la parte superior de la calle adoquinada, causando la pérdida total de la plataforma de la vía de primer orden Chimbo - El Cristal.</td></tr><tr><td>Situación actual:</td><td>MTOP Bolívar continúa realizando los trabajos de remoción y limpieza del material en la zona afectada.</td></tr><tr><td>Afectaciones:</td><td>- 2 viviendas destruidas (2 familias damnificadas 7 personas que se encuentran arrendando).- 3 viviendas afectadas (3 familias afectadas 16 personas; de las cuales 1 familia 10 personas se encuentran en el- alojamiento temporal de la U.E La Asunción, 2 familias 6 personas se encuentran arrendando).- 1 bien privado destruido (iglesia)- 8 bienes públicos destruidos (1 concha acústica - salón de reuniones, 1 cancha deportiva, 4 postes, tubería de agua que abastece a las comunidades de Panchigua, Tingo y Miraflores, alcantarillado de la zona cero)- 150 metros de vía de primer orden Chimbo-El Cristal destruida.- 60 metros de la calle S/N adoquinada destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP Bolívar, realiza trabajos de remoción y limpieza del material en la parte donde era la cancha.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Bolívar/MTOP-B</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/88090f70e4e2aecd318cc9af87952d16a90ca6f64bd1841ac86f6a284c0c5f41.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Girón/Girón/Cementerio de Lentag</td></tr><tr><td>Antecedentes:</td><td>El 02/04/2021, a causa de las lluvias se suscitó un deslizamiento que afecta la estructura de una vivienda de 1 piso construcción mixta (Bloque y zinc)</td></tr><tr><td>Situación actual:</td><td>1 familia integrada por 4 personas mismas que fue evacuada a casa de un familiar.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda afectada- 1 familia, 4 personas afectadas</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 11 de 24 

<table><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos Girón colaboran con la evacuación de la vivienda, SNGRE coordina con UGR Girón para que realice levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar / UGR Nabón.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/c9392f0bad774e265e2b4e935c0a19747aca3d776829276eade2b86ff5d7d1ce.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Azuay/Santa Isabel/Chaguarurco/Minas de Shurupe</td></tr><tr><td>Antecedentes:</td><td>Por causa de las lluvias suscitadas el 30/03/2022 se produjo el incremento del caudal del río Minas y el colapso del puente que conduce a Minas de Shurupe.01/04/2022 se declara en estado de emergencia, El Sector Mina de Shurupe, de la parroquia Santa Isabel(Chaguarurco) para restablecer la conexión vial de las comunidades Chamana, Tablón, San Pedro Bajo, Chalcalo con el centro cantonal de Santa Isabel, a causa de las fuertes precipitaciones en dichas zonas.</td></tr><tr><td>Situación actual:</td><td>Las comunidades tienen como vía alterna la antigua vía Girón-Pasaje; él caudal del río Minas se encuentra normal y no se reportan lluvia en el sector.</td></tr><tr><td>Afectaciones:</td><td>- 1 Puente destruido</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal realiza trabajos para habilitar una variante</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Santa Isabel</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/a1d417d381d10eac7608ff18be97b0c1d1f7740964d93031930c2493d39b42d9.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Cuenca/Sayausí/Gulag - Marianza, Km 12 vía Cuenca-Molleturo-Naranjal [E-582]</td></tr><tr><td>Antecedentes:</td><td>El 27/03/2021, a causa de las lluvias se suscitó deslizamientos de material pétreo en la vía de primer orden, la misma que se encuentra cerrada.El 28/03/20222, COE Cantonal sugiere declarar en emergencia la parroquia Sayausí sector Gulag-Marianza, Km 12 vía Cuenca-Molleturo.</td></tr><tr><td>Situación actual:</td><td>SNGRE informa que, luego del levantamiento de información realizado se identificó a las familias damnificadas las cuales se encuentran en familias de acogida y se determinó que las familias que se encuentran en el alojamiento temporal de la Escuela “Fray Gaspar de Carvajal” son familias evacuadas por precaución ya que pertenecen a las viviendas afectadas.MTOP informa que en horas de la noche del 31/03/2022 por las lluvias se suscitó un nuevo deslizamiento de material lodoso en la zona del evento, adicional.</td></tr><tr><td>Afectaciones:</td><td>- 15 postes destruidos- 4000 metros de vía aproximadamente- 4 personas fallecidas- 6 personas afectadas (personas con hipotermia, tratados en el punto)- 5 personas heridas- 1 Vehículo destruido- 40% del cantón sin servicio de agua potable- 9 Viviendas destruidas (7 viviendas habitadas y 2 deshabitadas)- 12 Familias damnificadas integradas por 30 personas (familias acogientes)- 5 Familias afectadas integradas por 14 personas evacuadas por precaución (alojamiento temporal)- 1 Familia afectada integrada por 9 personas evacuadas por precaución (familia acogiente)- 27 Viviendas afectadas con ingreso de agua y lodo- 1 Unidad Educativa &quot;Escuela de Marianza Laureles&quot; estado INACTIVO, daño total a la edificación.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial, GAD Cantonal, MTOP continúan con labores de limpieza en el lugar del evento, y Cuerpo de Bomberos Cuenca colabora con tanquero para abastecimiento de líquido vital en el sector</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/GAD Provincial/Cruz Roja/MTOP/CTE</td></tr></table>

Socavamiento 

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192 Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 12 de 24

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/1d7dbeaeb0804dcb01a0a060f072b94a0d0ce9e931a79292a803ca052c83885b.jpg)


<table><tr><td>Localización:</td><td>Azuay/Santa Isabel/Abdón Calderón/Yunguilla</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2022, por causa de las lluvias suscitadas se reportó la creciente del río Chantaco ocasionando un socavamiento en los márgenes del río, las escolleras del puente Chantaco y afectando la vía antigua Girón-Pasaje de segundo orden, la cual se encuentra cerrada. Adicional con la misma fecha se declaró en emergencia los sectores de San Javier, Centro Parroquial y Quillosisa Bajo pertenecientes a la parroquia Abdón Calderón por la creciente de los ríos Chantaco, Llaushari y Naranjos.</td></tr><tr><td>Situación actual:</td><td>La vía continúa cerrada; él caudal del río Chantaco se encuentra normal y no se reportan lluvias en el sector.</td></tr><tr><td>Afectaciones:</td><td>- 1 Puente afectado.- 20 metros lineales</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal realiza trabajos en el lugar del evento</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Santa Isabel</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/e77615d7c75cda7bae6615f9d65ad9b9de57a49f4603e091b5036bbf1c33dd07.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/barrios Rosas, Bellavista, Tamboloma, Chunazana, Rosario.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2021, se reportó un movimiento de masa provocado por la filtración de agua de riego y la temporada lluviosa. El 23/11/2021, el Servicio Nacional de Gestión de Riesgos y Emergencias declaró la Alerta Naranja por movimientos en masa en un área de 130,94 hectáreas que comprende los barrios Rosas, Bellavista, Tamboloma, Chunazana y Rosario.</td></tr><tr><td>Situación actual:</td><td>Prefectura realiza trabajos de limpieza en la vía Nabón-El Progreso, la misma se mantiene cerrada.</td></tr><tr><td>Afectaciones:</td><td>- 44 familias integradas por 130 personas afectadas aproximadamente.- 44 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 40 metros de vía afectados (Vía parcialmente habilitada, sector Trancapata)- 60 metros de vía afectados (Vía parcialmente Habilitada, sector quebrada del Canal)- 1 casa comunal afectada con cuarteaduras.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones).- Iglesia demolida por los daños estructurales presentados.- Centro de salud con fisuras, en evaluación permanente por parte del MSP.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Nabón se mantiene en continúo monitoreo de la zona afectada, maquinaria de la Prefectura realiza trabajos en la vía</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar / UGR Nabón.</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/714fd8d0a669219f50f49f94da50123daa5b1eba5a6dfbaf050419c66c809932.jpg)


<table><tr><td>Localización:</td><td>El Oro/Huaquillas/Huaquillas, cabecera cantonal/Barrio 9 de Octubre</td></tr><tr><td>Antecedentes:</td><td>El 04/04/2022, se produjo un incendio estructural que comprometió a varia viviendas y una bodega.</td></tr><tr><td>Situación actual:</td><td>Hasta el momento el incendio consumió 4 viviendas y 1 registra afectación parcial, las familias damnificadas se movilizaron por sus propios medios a casas de familias acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 4 viviendas destruidas- 5 familias de (23 personas) damnificadas en casas de familias acogientes.- 1 vivienda afectada- 1 familia (3 personas) afectadas en su vivienda.- 1 bien privado destruido (bodega)</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Huaquillas, con apoyo del Cuerpo de Bomberos de Arenillas, realizaron tareas de liquidación del flagelo, y realizan levantamiento de escombros.GAD Cantonal y Provincial colaboraron con abastecimiento de agua en tanqueros.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

<table><tr><td colspan="2">Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 13 de 24</td></tr><tr><td rowspan="2"></td><td>UGR GAD realizó levantamiento de información de daños mismo quecontinuará el día de mañana.</td></tr><tr><td>SNGRE realiza monitoreo y coordina acciones en atención al evento.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ7 Unidad de Monitoreo El Oro/CB Huaquillas/UGR GAD Huaquillas</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/c205f6bdafda03651bbbe1a3e6b1aaa3fd2808400690ac36aa187bc3db6395bd.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>El Oro/Portovelo /Portovelo /El Tablón</td></tr><tr><td>Antecedentes:</td><td>El 02/04/2022, por lluvias suscitadas se produjo un deslizamiento de talud tunelizado por donde atraviesa el ducto de agua potable del cantón Portovelo, provocando el colapso de un tramo del mismo, además el hundimiento en otro tramo de canal.</td></tr><tr><td>Situación actual:</td><td>El 04/04/2022 Se reunió el COE Cantonal donde se tomaron resoluciones en atención al evento.La cabecera cantonal de Portovelo al momento no cuenta con agua potable.</td></tr><tr><td>Afectaciones:</td><td>- 25 m de afectación- 10.000 personas afectadas indirectamente</td></tr><tr><td>Acciones de respuesta:</td><td>Resoluciones de COE Cantonal:1. Aceptar los informes técnicos de las Mesas 1,2, 3 sobre las afectaciones de la Época lluviosa en el sistema de captación y conducción a la Planta de Tratamiento de Agua Potable.2. Recomendar a la Señora Alcaldesa y al Concejo Cantonal de Portovelo la Declaratoria deSituación Emergente a la Ciudad Portovelo por la Época Lluviosa y afectaciones en el canal de conducción de agua.3. Pedir el soporte técnico al COE Provincial para la atención inmediata a las acciones tomadas.4. La plenaria del COE Cantonal de Portovelo se activa en sesión permanente para atención de las emergencias por la época lluviosa hasta el 15 de mayo del 2022.5. El puesto de mando unificado estará habilitado en la base del Cuerpo de Bomberos de Portovelo.6. Exhortar al presidente de la República del Ecuador, que realice la asignación de recursos por concepto de regalías mineras que por derecho nos corresponden.Bomberos de Portovelo, Piñas, Zaruma y Santa Rosa colaboran con abastecimiento de líquido vital al cantón.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/a8494b50d2caa07054ff6a365651d5177ce1229bcda70620bab8d100a7329141.jpg)


<table><tr><td colspan="2">Deslizamiento</td></tr><tr><td>Localización:</td><td>Loja/Loja/Malacatos/El Porvenir-Nangora, vía Loja-Malacatos [E682]</td></tr><tr><td>Antecedentes:</td><td>El 31/03/2022, por lluvias presentadas en la tarde, se produjo un deslizamiento de tierra en la vía de primer orden.</td></tr><tr><td>Situación actual:</td><td>Debido a la desestabilización del talud se registró desprendimiento de rocas que afectaron 2 viviendas; 3 viviendas en riesgo donde habitan un total de 5 familias conformadas por 21 personas, mismas que fueron evacuadas por seguridad a casa de familias acogientes- vía parcialmente habilitada</td></tr><tr><td>Afectaciones:</td><td>- 50 metros de longitud de vía- 02 viviendas afectadas- 05 familias,21 personas evacuadas por precaución</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP Loja realiza labores de limpieza vialSNGRE realizó levantamiento de información y evaluación de afectaciones</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/UPREA/MTOP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/b2c320de95f555e305143e382b03715c7ffc8b746195aff0d2209221e92144b5.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>El Oro/Zaruma/Malvas/Malvas, Barrio La Colorada</td></tr><tr><td>Antecedentes:</td><td>El 02/03/2022, por lluvias se registró un deslizamiento que pone en riesgo a varias viviendas del sector.Debido a las emergencias presentadas en fechas pasadas en el cantón de Zaruma, la plenaria del COE Cantonal se reunió el 28/03/2022, donde analizaron la situación por los distintos eventos peligrosos registrados en las parroquias y en la cabecera cantonal.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

<table><tr><td></td><td>Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 14 de 24Alcalde de Zaruma resolvió declarar en situación de emergencia, por el plazo de 60 días, bajo los términos de los informes de la MTT3 y MTT2.</td></tr><tr><td>Situación actual:</td><td>1 familia 2 personas que se mantiene en su vivienda, recibió ayuda humanitaria.</td></tr><tr><td>Afectaciones:</td><td>- 2 viviendas afectadas- 2 familia 5 personas afectadas:(1 familia 2 personas se mantiene en su vivienda y 1 familia 3 personas fue evacuada a casa de familia acogiente.)- 5 viviendas en riesgo- 6 familias 18 personas, evacuadas por precaución a casa de familia acogiente.</td></tr><tr><td>Acciones de respuesta:</td><td>PPNN brindó seguridad en el sitio.SNGRE en conjunto con GAD Cantonal de Zaruma realizó la entrega de asistencia humanitaria.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ7 Unidad de Monitoreo El Oro/UPREA El Oro</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/5541b148f1043a6677aec6183b8795aadb8c0f8810344d7315481ed3da2ceb22.jpg)


<table><tr><td>Localización:</td><td>El Oro/Chilla/Chilla, cabecera cantonal/varios vectores (Carabota, El Cruce, El Cucho, Pacayunga)</td></tr><tr><td>Antecedentes:</td><td>El 13/03/2022, por lluvias se produjo el desbordamiento de una quebrada sin nombre, la cual provocó un aluvión ocasionando el socavamiento y pérdida de mesa vial de la vía de tercer orden. Adicional, producto del evento varias viviendas resultaron afectadas.</td></tr><tr><td>Situación actual:</td><td>El servicio energía eléctrica se encuentra restablecido en su totalidad y al momento la vía en el sector Carabota se encuentra parcialmente habilitada y los trabajos de limpieza continúan.Adicional 9 familias de 23 personas afectadas por el evento recibieron asistencia humanitaria; adicional las familias que se encontraban en los diferentes alojamientos temporales retornaron a sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 22 viviendas afectadas. (3 viviendas afectadas por ingreso de lodo ubicadas en zona de riesgo de deslizamiento, 1 vivienda con daños estructurales; la cual se encuentra inhabitable y 18 viviendas con daños estructurales leves que están habitables).- 15 familias de 50 personas afectadas en sus domicilios.- 7 familias de 24 damnificadas en diferentes alojamientos temporales: 4 familias de 15 personas que pernoctaron en familias acogientes del sitio Carabota retornaron a sus viviendas, 2 familias de 7 personas alojadas en refugio temporal Casa Comunal del sitio Pacayunga, retornaron a sus viviendas, 1 familia de 2 personas alojadas en refugio temporal UPC de Pacayunga, retornaron a sus viviendas.- 48 familias de 201 personas afectadas indirectamente por aislamiento, debido a daños en la vía.- 100 metros de vía afectada.- 50% del servicio de energía electica (restablecido en su totalidad)- 15 % servicio de agua Potable afectado (se realiza trabajos de remediación de tuberías)</td></tr><tr><td>Acciones de respuesta:</td><td>COE Cantonal de Chilla se encuentra activo desde el 08/02/2022.SNGRE en presencia de jefe político y UGR GAD realizó entrega de asistencia humanitaria a famitas afectadas por el evento.Obras Públicas del GAD Chilla realiza trabajos de remediación de tuberíasMTOP y GAD Cantonal de Chilla realizan limpieza de la vía.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ7 Unidad de Monitoreo El Oro/SNGRE CZ7 Loja.</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/e90894afe9eee6a9c2d33a6c4a6345f7b43887cd7006f0c01a93328747384698.jpg)


<table><tr><td>Localización:</td><td>Pichincha/Quito/Puembo/sector Arrayanes - en la Hacienda Nápoles.</td></tr><tr><td>Antecedentes:</td><td>El 06/04/2022, se suscitó el colapso de un muro, en el cual quedaron atrapadas dos personas.</td></tr><tr><td>Situación actual:</td><td>Se informa que 3 personas se encontraban trabajando al interior de un pozo con una profundidad de 2.8m de las cuales una de ellas fue trasladada a casa de salud y las otras dos personas fueron atendidas en el lugar.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192

Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 15 de 24 

<table><tr><td colspan="2">Fecha y hora de actualización: Intercoles, 08 de abril de 2022 - 21.13.20 / Pagina 13 de 24</td></tr><tr><td>Afectaciones:</td><td>- 3 heridos</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Quito realizo el traslado de 1 persona herida a casa de salud.Operativo Zonal realizo una inspección en el lugar y reporta que el Propietario correrá con todos los gastos ocasionados por la emergencia</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ9 Unidad de Monitoreo/COE-M/CB-DMQ</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/5094715679f34e78eef5d698c18d15cc037f70e3302e8a908d47675a18b56eaa.jpg)


Colapso estructural 

<table><tr><td>Localización:</td><td>Pichincha/San Miguel de los Bancos/Mindo/Mindo, Planta de captación de agua.</td></tr><tr><td>Antecedentes:</td><td>El 02/04/2022, por lluvias y el incremento de nivel del río Mindo, se reportó la afectación a la planta de captación de agua y al sistema de distribución lo que dejó sin servicio de agua potable al centro parroquial.</td></tr><tr><td>Situación actual:</td><td>El día de hoy se continuara con la entrega de líquido vital en los recintos; Primero de Mayo, Santa Tadeo y Pueblo Nuevo.</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público afectado (planta de captación)- 600 familias afectadas indirectamente (sin servicio de agua potable)</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de San Miguel de los Bancos, realiza la distribución del agua en los 3 barrios afectados, UGR informa que se continúan con los trabajos de reparación de las tuberías afectadas, adicional se informa que en la parte alta del sector de Mindo ya cuentan con el servicio de agua potable.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ9 Unidad de Monitoreo/GAD Cantonal SMB - UGR</td></tr></table>

## 3. Monitoreo de estado de vías afectadas por eventos peligrosos

VÍAS DE PRIMER ORDEN: 

10 vías de primer orden cerradas 

<table><tr><td></td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Cañar</td><td>Cañar</td><td>Ventura</td><td>Cutuguay, Recinto Primero de Mayo, vía Alausí-Huigra [E-40]</td><td>SOCAVAMIENTO</td><td>80</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Guayas</td><td>Triunfo</td><td>Triunfo</td><td>Recinto Primero de Mayo, vía Alausí-Huigra (E-40)</td><td>SOCAVAMIENTO</td><td>20</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Azuay</td><td>Cuenca</td><td>Sayausí</td><td>Gulag - Marianza, km 12 vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>4000</td><td>27/03/2022</td><td>Biblián-Zhud-Cochancay-El Triunfo</td></tr><tr><td>4</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 90, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Pichincha</td><td>Rumiñahui</td><td>Sangolquí</td><td>Selva Alegre, Av. Gral. Rumiñahui [E35] a la altura del club Naval</td><td>SOCAVAMIENTO</td><td>60</td><td>17/02/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Rumiñahui</td><td>Sangolqui</td><td>E-35 y Calle Viejo Roble</td><td>INUNDACIÓN</td><td>50</td><td>11/02/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 49, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>17/10/2021</td><td>Cuenca-Azogues-Biblian-Zhud-Cochancay-El Triunfo y Cuenca-Girón-Pasaje-Machala-Guayaquil</td></tr><tr><td>9</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo, Cabecera Cantonal</td><td>barrio Tamban</td><td>HUNDIMIENTO</td><td>210</td><td>18/03/2020</td><td>Chimbo, San Miguel, San Pablo y Balsapamba/Chimbo-Susanga</td></tr><tr><td>10</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>875</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


49 vías de primer orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>Guapuloma, vía Bilován - Las Guardias.</td><td>DESLIZAMIENTO</td><td>8</td><td>03/04/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Antes le llegar al puente Hollin, vía Loreto - Y de Narupa [E20-E45A]</td><td>DESLIZAMIENTO</td><td>---</td><td>02/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>El Oro</td><td>Machala</td><td>El Cambio</td><td>El Cambio, vía Machala - El Guabo [E-25]</td><td>SOCAVAMIENTO</td><td>--</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Río Pindo, vía a la Costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Loja</td><td>Loja</td><td>Malacatos</td><td>El Porvenir-Nangora, vía Loja-Malacatos [E682]</td><td>DESLIZAMIENTO</td><td>50</td><td>31/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Loja</td><td>Paltas</td><td>Catacocha</td><td>Catacocha, vía Catacocha a San Antonio (entrada a El Sauce) [E35]</td><td>SOCAVAMIENTO</td><td>--</td><td>31/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Loja</td><td>Célica</td><td>Célica</td><td>Mullunumá, vía Célica El Empalme [E68]</td><td>DESLIZAMIENTO</td><td>20</td><td>30/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Loja</td><td>Loja</td><td>Yangana</td><td>Suro, vía Yangana-Vilcabamba[E35]</td><td>DESLIZAMIENTO</td><td>40</td><td>30/03/2022</td><td>hasta el cantón Zumba por (La Elvira, Comunidades y Mazanamaca)</td></tr><tr><td>9</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Río Pindo, vía a la Costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Manabí</td><td>Olmedo</td><td>Olmedo</td><td>Olmedo, vía Olmedo - Santa Ana Sector Travesía</td><td>SOCAVAMIENTO</td><td>--</td><td>29/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Manabí</td><td>Santa Ana</td><td>Santa Ana</td><td>Santa Ana, vía Olmedo - Santa Ana Cerro Visquije</td><td>HUNDIMIENTO</td><td>--</td><td>29/03/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Km 70 +860, vía Alóag - Unión del Toachi, [E20]</td><td>SOCAVAMIENTO</td><td>---</td><td>26/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Bolívar</td><td>Chillanes</td><td>Cabecera Cantonal</td><td>Varios Sectores, (frente a la Gasolinera, a 100 metros de la Gasolinera, Sicoto), vía Chillanes - San Pablo [E495]</td><td>DELIZAMIENTO</td><td>---</td><td>26/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Loja</td><td>Calvas</td><td>Utuana</td><td>Utuana, vía Cariamanga-Macará[E69]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Bolívar</td><td>San Miguel</td><td>Balsapamba</td><td>km 50+000 al Km 63+300, vía Las Guardias-Balsapamba [E491]</td><td>HUNDIMIENTO</td><td>100</td><td>08/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>varios sectores, Agua Blanca - La Piedra - Atandahua - Capilluco, Tambo Real, Km 19, vía Guanujo-Echeandia [E494]</td><td>DESLIZAMIENTO</td><td>300</td><td>07/03/2022</td><td>Guaranda-Balsapamba-La Esmeralda-Caluma.</td></tr><tr><td>18</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Km 94, Siete Ríos, vía Pujilí - La Maná [E-30].</td><td>DESLIZAMIENTO</td><td>60</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Loja</td><td>Calvas</td><td>Colaisaca</td><td>Asanuma, vía Cariamanga-Sozoranga[E69]</td><td>DESLIZAMIENTO</td><td>0</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>20</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 66, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>60</td><td>26/02/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>0</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Pedro km 101-Rocafuerte, vía Salinas Lita E10</td><td>DESLIZAMIENTO</td><td>30</td><td>20/02/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>Puente sobre el río Pucuno, vía Hatun Sumaco, Y de Narupa</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>18/02/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Pedro, vía Salinas Lita E10</td><td>DESLIZAMIENTO</td><td>40</td><td>03/02/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>El Palmar, Tilipulo, Saraguasi, San José de Tilipulo, California, La Esperanza.</td><td>INUNDACIÓN</td><td>0</td><td>31/01/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 17 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>28</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>29</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>30</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tulcán - Ibarra2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>31</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>10 de Agosto, vía Loreto - Tena [E45A-E20]</td><td>DESLIZAMIENTO</td><td>80</td><td>17/12/2021</td><td>Vía Chontapunta-La Belleza</td></tr><tr><td>32</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Macanas, vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>50</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>33</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>Napo</td><td>Tena</td><td>Chontapunta</td><td>Rayayacu, vía Chontapunta - La Belleza [E436]</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>17/11/2021</td><td>Vía de tercer orden Humuyacu-Yuralpa Derecho-Wachayacu.</td></tr><tr><td>35</td><td>Tungurahua</td><td>San Pedro De Pelileo</td><td>Pelileo</td><td>La Hamaca, vía Pelileo - Baños [E30]</td><td>SOCAVAMIENTO</td><td></td><td>16/10/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Manabí</td><td>Jipijapa</td><td>Jipijapa, Cabecera Cantonal</td><td>Quimís, Vía Colón-Quimís [E4-82]</td><td>COLAPSO ESTRUCTURAL</td><td>25</td><td>14/10/2021</td><td>Manabí hacía Guayas: E482 Sector Pila-Los Bajos de Montecristi-E15 Puerto Cayo-Jipijapa Jipijapa hacía Portoviejo: E-482 Rcto. Colón Quimi-Vía Tercer Orden-E462B Santa Ana-Portoviejo</td></tr><tr><td>37</td><td>Napo</td><td>Quijos</td><td>Cuyuja</td><td>Flor del Bosque, Quebrada Rio Negro, Jatuntinahua, Molana, El Laurel, vía Y de Baeza -Papallacta [E20]</td><td>DESLIZAMIENTO</td><td>200</td><td>19/07/2021</td><td>Ninguna</td></tr><tr><td>38</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Nuevos Horizontes, vía Méndez-Guarumales [E40].</td><td>DESLIZAMIENTO</td><td>100</td><td>01/07/2021</td><td>Ninguna</td></tr><tr><td>39</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza</td><td>Sector Tucumbatza, vía Gualaquiza-San Juan Bosco [E45] (Primer Orden).</td><td>HUNDIMIENTO</td><td>50</td><td>30/06/2021</td><td>Ninguna</td></tr><tr><td>40</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>41</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>42</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km. 101, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>12</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>43</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>44</td><td>Orellana</td><td>La Joya De Los Sachas</td><td>San Sebastián del Coca</td><td>Toyuca, Sardinas, Sebastian del Coca, vía La Joya de los Sachas - El Coca [E45A]</td><td>SOCAVAMIENTO</td><td>0</td><td>08/02/2021</td><td>Ninguna</td></tr><tr><td>45</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>46</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>47</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>48</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>49</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>


VÍAS DE SEGUNDO ORDEN:



14 vías de segundo orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Malvas, Vía Malvas - Arcapamba [E-585]</td><td>DESLIZAMIENTO</td><td>50</td><td>02/04/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Zamora Chinchipe</td><td>Zamora</td><td>Timbara</td><td>Barrio Numbani, vía a Romerillos.</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Tena</td><td>Chonta Punta</td><td>Vía Comunidad Cano Yacu</td><td>DESLIZAMIENTO</td><td>--</td><td>15/03/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>El Oro</td><td>Piñas</td><td>Moromoro</td><td>Buenaventura, Vía Piñas - Zaracay [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Pepinales, vía Alausí - Huigra [E-47]</td><td>SOCAVAMIENTO</td><td>0</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Loja</td><td>Espíndola</td><td>Jimbura</td><td>Machay, vía a Amaluza hacia Jimbura</td><td>HUNDIMIENTO</td><td>20</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>Gral. Vernaza (Dos Esteros)</td><td>Recinto Hacienda Nueva</td><td>SOCAVAMIENTO</td><td>15</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Los Ríos</td><td>Valencia</td><td>La Unión</td><td>La Burbuja - Río San Pablo -Rcto. 6 de Agosto</td><td>INUNDACIÓN</td><td>125</td><td>30/01/2022</td><td>Puente Nuevo de la calle Arcos Pérez vía al río San Pablo.</td></tr><tr><td>9</td><td>Loja</td><td>Loja</td><td>Sucre</td><td>Parque Eólico, vía antigua a Catamayo [E35]</td><td>DESLIZAMIENTO</td><td>0</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>11</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr><tr><td>12</td><td>Azuay</td><td>Nabón</td><td>Nabón, cabecera cantonal</td><td>Rosas, Bellavista, Tamboloma, Chunazana.</td><td>DESLIZAMIENTO</td><td>100</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>El Oro</td><td>Piñas</td><td>Saracay</td><td>Chorro Viringo, Chorro, Vía Piñas - Saracay [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>El Oro</td><td>Piñas</td><td>Moromoro</td><td>Buenaventura, Vía Piñas - Zaracay [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr></table>


39 vías de segundo orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Princesa Toa</td><td>DESLIZAMIENTO</td><td>--</td><td>04/04/20222</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>Echeandía</td><td>Echeandía</td><td>San José de Camarón, vía Camarón - Echeandía.</td><td>SOCAVAMIENTO</td><td>15</td><td>02/04/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 19 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>3</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Malvas, Via Malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>50</td><td>02/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>El Oro</td><td>Atahualpa</td><td>San Juan de Cerro Azul</td><td>Cerro Azul, vía Cerro Azul - Paccha [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Chimborazo</td><td>Colta</td><td>Juan de Velasco (Pangor)</td><td>Tablón km 73, vía Colta - Pallatanga [E487]</td><td>DESLIZAMIENTO</td><td>--</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Cuenca</td><td>Monay</td><td>Av. 24 de mayo</td><td>DESLIZAMIENTO</td><td>--</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Pichincha</td><td>Quito</td><td>Chillogallo</td><td>km 12 vía antigua a santo domingo</td><td>DESLIZAMIENTO</td><td></td><td>31/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Bolívar</td><td>Guaranda</td><td>Salinas</td><td>Chazojuan, vía Chazo Juan - Camarón</td><td>SOCAVAMIENTO</td><td>--</td><td>30/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>La Soberana, vía Cumanda - El Triunfo [E487]</td><td>ALUVIÓN</td><td>1000</td><td>30/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Cinacumbe a 4 km desde Alausí, vía Alausí-Huigra [E47].</td><td>ALUVIÓN</td><td>30</td><td>29/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Bolívar</td><td>Guaranda</td><td>San Luis de Pambil</td><td>Varios sectores (recinto Río Blanco, Recinto Chongona), vía San Luis de Pambil-Moraspungo (límite provincia de Cotopaxi).</td><td>SOCAVAMIENTO</td><td>--</td><td>29/03/2022</td><td>Las Minas</td></tr><tr><td>12</td><td>Loja</td><td>Catamayo</td><td>San Pedro</td><td>San Vicente, vía Catamayo- hacia la Costa [E69]</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>El Oro</td><td>Zaruma</td><td>Muluncay Grande</td><td>Muluncay Chico, vía Zaruma - Atahualpa [E-585]</td><td>SOCAVAMIENTO</td><td>3</td><td>22/03/2022</td><td>La misma</td></tr><tr><td>14</td><td>Tungurahua</td><td>Patate</td><td>Patate</td><td>Tunga, Vía Patate - Píllaro.</td><td>DESLIZAMIENTO</td><td>--</td><td>20/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Cahuají km 34 1/2, vía Penipe- Baños [E490]</td><td>DESLIZAMIENTO</td><td>--</td><td>17/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Puente de Jondachi, vía Y de Narupa - Tena[E45]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Orellana</td><td>Francisco de Orellana</td><td>La Belleza</td><td>vía Jaguar 2 - Cacique Jumandy</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Pichincha</td><td>Mejía</td><td>Alóag</td><td>km 2.5 Tras el UPC de Alóag</td><td>INUNDACIÓN</td><td>10</td><td>08/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista vía Girón Santa Teresita</td><td>COLPASO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>El Oro</td><td>Piñas</td><td>Piñas / La matriz</td><td>La Garganta, vía Piñas - Zaracay [É-585]</td><td>DESLIZAMIENTO</td><td>30</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Loja</td><td>Espíndola</td><td>Bellavista</td><td>Amaluza, vía Amaluza-Bellavista</td><td>DESLIZAMIENTO</td><td>25</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Malvas, vía Malvas - Arcapamba [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Bolívar</td><td>Guaranda</td><td>Salinas</td><td>Apahua, vía Guaranda - Salinas</td><td>DESLIZAMIENTO</td><td>---</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>KM 75, VIA MALVAS - ZARUMA [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Chimborazo</td><td>Alausí</td><td>Huigra</td><td>Pagma, vía Huigra - El Triunfo [E-47]</td><td>DESLIZAMIENTO</td><td>500</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Cotopaxi</td><td>Latacunga</td><td>Toacaso</td><td>San Francisco vía Sigchos - Latacunga</td><td>DESLIZAMIENTO</td><td>300</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>Bolívar</td><td>San Miguel</td><td>San Vicente de Pusir</td><td>vía San Vicente - Ungubi</td><td>DESLIZAMIENTO</td><td>15</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>28</td><td>Chimborazo</td><td>Alausí</td><td>Huigra</td><td>Por el puente dos bocas, vía Alausí - Huigra - El Triunfo [E47].</td><td>DESLIZAMIENTO</td><td>80</td><td>14/02/2022</td><td>Ninguna</td></tr><tr><td>29</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>Chaquisca, vía Guanujo-Las Cochas</td><td>DESLIZAMIENTO</td><td>30</td><td>09/11/2021</td><td>sector de Negroyacu o barrio Mantilla</td></tr><tr><td>30</td><td>Chimborazo</td><td>Guano</td><td>La Matriz</td><td>Barrios La Merced, La Dolorosa del cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu santo, La Dolorosa Centro, Balneario Los Elenes</td><td>ALUVIÓN</td><td>9000</td><td>11/12/2021</td><td>Ninguna</td></tr><tr><td>31</td><td>Zamora Chinchipe</td><td>Zamora</td><td>Cumbaratza</td><td>Tunantza Alto, vía Timbara Bajo - Timbara Alto</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/10/2021</td><td>Ninguna</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 20 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>32</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Puente Salado Grande, vía Macas-Riobamba-tramo 9 de Octubre-Cebadas [E46].</td><td>DESLIZAMIENTO</td><td>60</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>33</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>Tungurahua</td><td>Patate</td><td>Patate, cabecera cantonal</td><td>Puñapí, vía Puñapí - Baños.</td><td>DESLIZAMIENTO</td><td>---</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>35</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Km 78, vía Macas-Riobamba E46]</td><td>DESLIZAMIENTO</td><td>60</td><td>12/06/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Morona Santiago</td><td>Limón Indanza</td><td>General Leonidas Plaza Gutiérrez (Limón), cabecera cantonal</td><td>Cerro Bosco, vía Gualaceo-Limón (Segundo Orden).</td><td>DESLIZAMIENTO</td><td>50</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Km 35, vía Cahuají - Pillate - Cotaló [E-304].</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2021</td><td>Riobamba - Mocha - Baños</td></tr><tr><td>38</td><td>Pichincha</td><td>Quito</td><td>Checa (Chilpa)</td><td>Km 38+377, entrada a Checa, vía Cusubamba- Pifo</td><td>SOCAVAMIENTO</td><td>15</td><td>01/04/2021</td><td>Ninguna</td></tr><tr><td>39</td><td>Morona Santiago</td><td>Gualaquiza</td><td>El Rosario</td><td>El Aguacate, vía Sig-Sig-Chiguinda-Gualaquiza [E594]</td><td>DESLIZAMIENTO</td><td>50</td><td>23/09/2020</td><td>Ninguna</td></tr></table>


VÍAS DE TERCER ORDEN: 



46 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El</td><td>Piñas</td><td>Piñas</td><td>El Trigal - vía Piñas - Paccha</td><td>DESLIZAMIENTO</td><td>20</td><td>02/04/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Santo Domingo de los Tsáchilas</td><td>Santo Domingo</td><td>Alluriquín</td><td>Recinto El Meme, km 4</td><td>DESLIZAMIENTO</td><td>--</td><td>31/03/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>El Oro</td><td>Las Lajas</td><td>El Paraíso</td><td>Villa Seca, vía Las Lajas - Marcabelí</td><td>SOCAVAMIENTO</td><td>-</td><td>31/03/2022|</td><td>Ninguna</td></tr><tr><td>4</td><td>Bolívar</td><td>Las Naves</td><td>Las Naves-Cabecera cantonal</td><td>Cerro Azul, vía Selva Alegre, La Unión y La Esperanza.</td><td>SOCAVAMIENTO</td><td>8</td><td>30/03/2022|</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Piñas</td><td>San Roque</td><td>San Roque, Vía San Roque - Lozumbe</td><td>DESLIZAMIENTO</td><td>10</td><td>29/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>El Oro</td><td>Zaruma</td><td>Zaruma</td><td>Miraflores - vía Miraflores - Sinsao</td><td>DESLIZAMIENTO</td><td>10</td><td>28/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Zamora Chinchipe</td><td>Nangaritza</td><td>Zurmi</td><td>Comunidad Shaime</td><td>DESLIZAMIENTO</td><td>70</td><td>24/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Bolívar</td><td>Chimbo</td><td>Telimbela</td><td>Varios sectores, San Francisco Chico, Choropamba, El Atio, Guarumal, vía Telimbela - Cochabamba y vía Telimbela - Al Valle.</td><td>DESLIZAMIENTO</td><td>250</td><td>21/03/202</td><td>Ninguna</td></tr><tr><td>9</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>San Miguel de Jipangoto.</td><td>DESLIZAMIENTO</td><td>---</td><td>21/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>recinto Miraflores, vía Luz María - Miraflores</td><td>SOCAVAMIENTO</td><td>--</td><td>20/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Pichincha</td><td>Quito</td><td>Amaguaña</td><td>Calle Abdón Calderón, sector El Pedregal, Amaguaña.</td><td>DESLIZAMIENTO</td><td>---</td><td>18/03/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Imbabura</td><td>Cotacachi</td><td>Cuellaje</td><td>San Antonio</td><td>DESLIZAMIENTO</td><td>50</td><td>17/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Loja</td><td>El Valle</td><td>Varios sectores</td><td>DESLIZAMIENTO</td><td>--</td><td>15/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>El Oro</td><td>Piñas</td><td>Piñas, La Matriz</td><td>San José, vía San José - Capiro</td><td>DESLIZAMIENTO</td><td>--</td><td>15/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Porotillo, vía Pasaje - Chilla</td><td>SOCAVAMIENTO</td><td>20</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>Los Beldacos</td><td>INUNDACIÓN</td><td>100</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Cotopaxi</td><td>Sigchos</td><td>Isinliví</td><td>Guangomalag.</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Cotopaxi</td><td>Sigchos</td><td>Isinliví</td><td>Guantualo, vía Insiliví - Sigchos.</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 21 de 24


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>19</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Uzhcurrumi, vía Uzhcurrumi - Chillayacu</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>El Oro</td><td>Piñas</td><td>San Roque</td><td>Lozumbe, vía Lozumbe - Capiro</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>El Oro</td><td>Chilla</td><td>Chilla, cabecera cantonal</td><td>Nariz del Diablo, vía Nariz del Diablo - Chilla</td><td>DESLIZAMIENTO</td><td>60</td><td>11/03/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>El Oro</td><td>Portovelo</td><td>Salati</td><td>La Tira, Via Salati-Ambocas</td><td>DESLIZAMIENTO</td><td>30</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>El Oro</td><td>Piñas</td><td>Piñas Grande</td><td>Piñas Grandes, Vía Piñas Grande - Cabecera Cantonal</td><td>DESLIZAMIENTO</td><td>40</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Chimborazo</td><td>Pallatanga</td><td>PALLATANGA</td><td>San Juan de Trigoloma, vía San Juan de Trigoloma - Tablarrumi.</td><td>DESLIZAMIENTO</td><td>---</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Cotopaxi</td><td>Latacunga</td><td>TOACASO</td><td>San Francisco, vía Sigchos - Latacunga</td><td>DESLIZAMIENTO</td><td>20</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Pichincha</td><td>Quito</td><td>LLOA</td><td>vía Lloa - La Tablera</td><td>DESLIZAMIENTO</td><td>30</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>Tungurahua</td><td>Ambato</td><td>ATOCHA FICOA</td><td>Atocha Ficoa/ 100 metros de la salida del parque, vía Atocha - Laquigo.</td><td>DESLIZAMIENTO</td><td>---</td><td>27/02/2022</td><td>Ninguna</td></tr><tr><td>28</td><td>El Oro</td><td>Balsas</td><td>BALSAS</td><td>Aguacatillo</td><td>DESLIZAMIENTO</td><td>50</td><td>24/02/2022</td><td>Ninguna</td></tr><tr><td>29</td><td>Pichincha</td><td>Mejía</td><td>MANUEL CORNEJO ASTORGA (TANDAPI)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>30</td><td>Cotopaxi</td><td>Sigchos</td><td>CHUGCHILLAN</td><td>Km 17, vía Sigchos - Chugchillán</td><td>DESLIZAMIENTO</td><td>0</td><td>04/02/2022</td><td>Ninguna</td></tr><tr><td>31</td><td>Cotopaxi</td><td>Sigchos</td><td>ISINLIVI</td><td>Isinliví /Isinliví, vía Isinliví - Guantualó.</td><td>HUNDIMIENTO</td><td>0</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>32</td><td>Los Ríos</td><td>Valencia</td><td>LA UNIÓN</td><td>La Burbuja -Rcto. 6 de Agosto - Tercera Banquera - Valle Negro - río San Pablo</td><td>INUNDACIÓN</td><td>125</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>33</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Ríoverde Alto, vía Lita - Rioverde Alto</td><td>DESLIZAMIENTO</td><td>50</td><td>18/12/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>El Oro</td><td>Zaruma</td><td>Zaruma, cabecera cantonal</td><td>Calles Colon y 10 de Agosto</td><td>HUNDIMIENTO</td><td>---</td><td>15/12/2021</td><td>Ninguna</td></tr><tr><td>35</td><td>Imbabura</td><td>San Miguel De Urcuquí</td><td>La Merced De Buenos Aires</td><td>San José</td><td>DESLIZAMIENTO</td><td>70</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Nueva alianza</td><td>INUNDACIÓN</td><td>7000</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>38</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>0</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>39</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia, Río Guataxi afluente del río Chanchán</td><td>DESLIZAMIENTO</td><td>0</td><td>12/02/2021</td><td>Ninguna</td></tr><tr><td>40</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>0</td><td>20/01/2021</td><td>Ninguna</td></tr><tr><td>41</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Guilliloma - Kullpa - Armenia</td><td>HUNDIMIENTO</td><td>0</td><td>26/12/2020</td><td>Ninguna</td></tr><tr><td>42</td><td>Morona Santiago</td><td>Palora</td><td>Cumandá (cab. en Colonia Agrícola Sevilla del Oro)</td><td>Puente sobre el río Charuyaku</td><td>COLAPSO ESTRUCTURAL</td><td>0</td><td>23/10/2020</td><td>Palora-Puyo-Cumandá</td></tr><tr><td>43</td><td>El Oro</td><td>Zaruma</td><td>Abañin</td><td>Sumo Bajo, vía Abañin - Uzhcurrumi</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>44</td><td>Tungurahua</td><td>Quero</td><td>Quero, cabecera cantonal</td><td>San Vicente, vía Quero - Pelileo</td><td>SOCAVAMIENTO</td><td>0</td><td>13/07/2020</td><td>Ninguna</td></tr><tr><td>45</td><td>Tungurahua</td><td>Quero</td><td>Quero, cabecera cantonal</td><td>Quiambe, vía Quero - Rumipamba</td><td>SOCAVAMIENTO</td><td>0</td><td>13/07/2020</td><td>Ninguna</td></tr><tr><td>46</td><td>Santo Domingo de los Tsáchilas</td><td>Santo Domingo</td><td>Alluriquín</td><td>Recinto El Meme, km 4</td><td>DESLIZAMIENTO</td><td>--</td><td>31/03/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 22 de 24
49 vías de tercer orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Zaruma</td><td>Guizhaguiña</td><td>Canelal</td><td>DESLIZAMIENTO</td><td>--</td><td>02/04/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>El Oro</td><td>Zaruma</td><td>Guizhaguiña</td><td>Canelal, Vía Guizhaguiña - Canelal</td><td>DESLIZAMIENTO</td><td>--</td><td>02/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Malvas, Vía Malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>--</td><td>02/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>Recinto Buenos Aires, vía Buenos Aires - La Isla</td><td>SOCAVAMIENTO</td><td>--</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Pasaje</td><td>Casacay</td><td>Casacay, Vía, - Quera - Uzhcurrumi</td><td>DESLIZAMIENTO</td><td>--</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo</td><td>Estadio el Batán, vía el Batán - al cementerio</td><td>DESLIZAMIENTO</td><td>25</td><td>01/04/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Guano</td><td>San Isidro de Patulú</td><td>Chocavi Central, vía a la comunidad Pulug</td><td>ALUVIÓN</td><td>---</td><td>30/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>El Oro</td><td>Zaruma</td><td>Sinsao</td><td>Ortega Bajo, Sinsao - Zaruma</td><td>DESLIZAMIENTO</td><td>10</td><td>26/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>El Oro</td><td>Piñas</td><td>Piñas, La Matriz</td><td>Florida Alto, vía Kennedy - Piñas Grande</td><td>DESLIZAMIENTO</td><td>10</td><td>22/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Bolívar</td><td>Caluma</td><td>Caluma</td><td>puente de Charquiyacu</td><td>DESLIZAMIENTO</td><td>180</td><td>20/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza, cabecera cantonal</td><td>La Dolorosa, vía Guayuzal-La Dolorosa</td><td>ALUVIÓN</td><td>8</td><td>19/03/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>El Oro</td><td>Zaruma</td><td>Abañin</td><td>Algodonal, vía Algodonal - Sumo Bajo</td><td>SOCAVAMIENTO</td><td>10</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>El Oro</td><td>Chilla</td><td>Chilla</td><td>Sada, vía Chilla - Pasaje</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>El Oro</td><td>Chilla</td><td>Chilla</td><td>Tucumba, vía Chilla - Pasaje</td><td>DESLIZAMIENTO</td><td>20</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>La Unión, vía Pasaje - Chilla</td><td>SOCAVAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>El Oro</td><td>Piñas</td><td>Piñas</td><td>Calera Chica, vía Piñas - Paccha</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>El Oro</td><td>Zaruma</td><td>Guanazán</td><td>Guanazán, vía Uzhcurrumi - Chillayacu</td><td>DESLIZAMIENTO</td><td>10</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>El Oro</td><td>Piñas</td><td>Capiro</td><td>Mochata, vía Piñas - Capiro</td><td>DESLIZAMIENTO</td><td>15</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>La Unión, vía Pasaje - Chilla</td><td>DESLIZAMIENTO</td><td>80</td><td>13/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Chimborazo</td><td>Guamote</td><td>Palmira</td><td>Sector de Vishut Km 512, Vía Riobamba - Alausí [E-35].</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Pilchipamba el Descanso, vía Jipangoto - Azacoto.</td><td>INUNDACIÓN</td><td>14</td><td>08/03/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>El Oro</td><td>Piñas</td><td>Piñas, la matriz</td><td>Nueva Esperanza, vía Nueva Esperanza - Moromoro</td><td>DESLIZAMIENTO</td><td>25</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>El Oro</td><td>Zaruma</td><td>Huertas</td><td>Quizpe, Vía Quizpe - Muluncay</td><td>DESLIZAMIENTO</td><td>10</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>El Oro</td><td>Zaruma</td><td>Sinsao</td><td>Sinsao, Vía Sinsao - El Roble</td><td>DESLIZAMIENTO</td><td>30</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Cotopaxi</td><td>Pujilí</td><td>ANGAMARCA</td><td>Teodasín, vía Angamarca - Zumbahua</td><td>DESLIZAMIENTO</td><td>100</td><td>05/03/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Cotopaxi</td><td>Sigchos</td><td>Sigchos, Cabecera Cantonal</td><td>Toachi, vía Yaló - Sigchos.</td><td>DESLIZAMIENTO</td><td>20</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>El Oro</td><td>Portovelo</td><td>Portovelo</td><td>Buenos Aires</td><td>DESLIZAMIENTO</td><td>22</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>28</td><td>Bolívar</td><td>San Miguel</td><td>Balsapamba</td><td>Balsapamba</td><td>HUNDIMIENTO</td><td>50</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>29</td><td>El Oro</td><td>Piñas</td><td>Capiro (Cab. En La Capilla De Capiro)</td><td>Conchicola, Vía Conchicola - Los Amarillos</td><td>DESLIZAMIENTO</td><td>20</td><td>01/03/2022</td><td>Ninguna</td></tr><tr><td>30</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Limón, vía Pasaje - Uzhcurrumi</td><td>DESLIZAMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>31</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>El Arenal; Vía Lita E10</td><td>DESLIZAMIENTO</td><td>50</td><td>06/02/2022</td><td>Ninguna</td></tr><tr><td>32</td><td>El Oro</td><td>Portovelo</td><td>Portovelo</td><td>Pindo, Vía Portovelo - Loja</td><td>DESLIZAMIENTO</td><td>10</td><td>04/02/2022</td><td>Ninguna</td></tr><tr><td>33</td><td>El Oro</td><td>Pasaje</td><td>Progreso</td><td>La Playa</td><td>ALUVIÓN</td><td>7</td><td>31/01/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>34</td><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>Junquillal</td><td>Recinto El Morocho</td><td>SOCAVAMIENTO</td><td>6</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>35</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Balazul, Vía Jalubí - Las Rosas</td><td>DESLIZAMIENTO</td><td>40</td><td>25/01/2022</td><td>Ninguna</td></tr><tr><td>36</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Barrio la Laguna, vía Sucúa- Asunción</td><td>ALUVIÓN</td><td>30</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Tungurahua</td><td>Baños De Agua Santa</td><td>Lligua</td><td>Capa Rosa, vía Lligua - Baños.</td><td>ALUVIÓN</td><td>150</td><td>22/08/2021</td><td>Ninguna</td></tr><tr><td>38</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Yaucana</td><td>ALUVIÓN</td><td>---</td><td>23/07/2021</td><td>Ninguna</td></tr><tr><td>39</td><td>Napo</td><td>El Chaco</td><td>Oyacachi</td><td>Oyacachi, vía a Jariyacu- Huashahuaicu</td><td>DESLIZAMIENTO</td><td>---</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>40</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Nueva Tarqui</td><td>El Candi</td><td>HUNDIMIENTO</td><td>800</td><td>26/05/2021</td><td>Ninguna</td></tr><tr><td>41</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Centro Parroquial de Pananza</td><td>HUNDIMIENTO</td><td>10</td><td>20/05/2021</td><td>Ninguna</td></tr><tr><td>42</td><td>Tungurahua</td><td>Patate</td><td>Patate, cabecera cantonal</td><td>Puñapí, vía alterna Baños - Patate</td><td>DESLIZAMIENTO</td><td>80</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>43</td><td>Chimborazo</td><td>Riobamba</td><td>Quimiag</td><td>Sector Balcashí, vía Quimiag - Chambo</td><td>SOCAVAMIENTO</td><td>---</td><td>06/03/2021</td><td>Ninguna</td></tr><tr><td>44</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Puente sobre el río Malo</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>29/01/2021</td><td>Ninguna</td></tr><tr><td>45</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Valle Hermoso</td><td>Sector Sarayacu.</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/01/2021</td><td>Ninguna</td></tr><tr><td>46</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>47</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr><tr><td>48</td><td>Pichincha</td><td>Quito</td><td>Turubamba</td><td>Guamaní Alto - quebrada Caupicho, desde el puente de la av. Susana Letor hasta el puente de Guajaló</td><td>SOCAVAMIENTO</td><td>15</td><td>01/02/2020</td><td>Ninguna</td></tr><tr><td>49</td><td>Pichincha</td><td>Quito</td><td>Turubamba</td><td>Guamaní Alto - quebrada Caupicho, desde el puente de la av. Susana Letor hasta el puente de Guajaló</td><td>SOCAVAMIENTO</td><td>15</td><td>01/02/2020</td><td>Ninguna</td></tr></table>


4. Declaratorias emitidas por el SNGRE (vigentes en orden cronológico)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/c5417890befd09d94a5a9e1f099e7426d01a3c18f87a41454407d83175190e4f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/0b785f2f37c55aeb88f21ea73da5510f45ca419fe67d647a01e22fde56a2aaf6.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/bddf6d08f013f68599d1cdb8c38f167bac005de1e408cb75fce82e88d40e1f07.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/2dd75d34d9e8b06d078919e00b00628c572d2c20c7804475c3e378eb415403c7.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/ea81e640002f60aad8519f67b03d42d3b0d433b7991cc3b8638ee6cf6d365a28.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Movimiento en masa Barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SNGRE-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SNGRE-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SNGRE-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SNGRE-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SNGRE-111-2019</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0192
Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 24 de 24


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/b41c7c88cc643d4512515d344b9317fad442875f8ba193eaf6cda0d640e48165.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/d75550518a1701ac0775109eec23b8bafa33664452eca91f07718a2e7832aaa2.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/fd15683bfca6a8ea43bfdde6eca0d3b0491cbe0130730c2b2b626190e3e21614.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/0a8f1de84f73d736aac67c217741c846a18a31c92283b039b95dda6933eed457.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/94542e03587b69a0e75036be93fedcc9879ce4c6fe0e2591940e23f80b48cfd8.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/83e2ee076a0bdff3ab99d74fba01efca030f8467c81b7a6c431943972053c77d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/f51303fa596ed2f0f97e3363389e20144731fcbd01f1dd6e36471aa0c7df39bd.jpg)


<table><tr><td colspan="4">Fecha y Hora de actualización: miércoles, 06 de abril de 2022 - 21:15:20 / Página 24 de 24</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SNGRE-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SNGRE-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles – Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/0c9c46d2ec4532fb4ade4fe5afaf33e69e630eb508075c8641cb9be06354039f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/5e4431857ed5d4a7f583b833c18120597c76add9048ad13420f09f71221686dc.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/432a49a0be6d6230958283292bba858e5058f7c2d594a03ec0d04dfcca409dcb.jpg)


<table><tr><td>Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Inundaciones Babahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td>Hundimiento, Zaruma, El Oro</td><td>07/03/2017</td><td>Resolución No. SGR-029-2015</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/4a3e8480-c39e-44c2-9d25-bf380d68b900/0eba7ab7013d446678fddcf9584e529f6cd6bb04b351ee6c967a54bc2243df1c.jpg)



Elaborado por: Jorge Dután. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón
Revisado por: Alan Mite. - Analista de Monitoreo de Turno 24/7 - Sala de Situación y Monitoreo Samborondón
Emitido por: Jorge Dután. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón.
