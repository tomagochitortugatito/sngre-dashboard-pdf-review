Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 1 de 14 

Periodo de Monitoreo: 

Desde: 09h00 13/12/2022 

Hasta: 21h00 13/12/2022 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/e159cfa6e8ece9a34e6c0689d443629b83d72987b5bf599bd2e204b54770ae88.jpg)


- Amenaza dentro de los parámetros normales. 

## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/da7768f6f8c4288ef536e16d3e6bad53975d9ddb5b0d71a9cdf34a6e7dfd8fc8.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:21 Reventador para la COMUNIDAD, IGEPN informa emisión de gas con ceniza, con una altura de la nube igual a 1000 metros sobre el nivel del cráter con dirección Oeste.</td><td>Amarillo</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/e5c61ee8b3338c8c196b071bc0a003fcc9c7776058d4e2eb0a5974b13330b77b.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el sector del volcán nublado, sin novedad.</td><td>Verde</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/9877b7c83f7b7bb764b17bb6b319049e7cbd9e4b1e20449819fb7056ed1d9761.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>A las 10:28 tiempo local, a través de las cámaras de vigilancia del Cotopaxi ubicadas alrededor del volcán, se observa una columna de ceniza que alcanza 500 metros sobre el cráter y se dirige hacia el oeste. El IG-EPN vigila el evento e informará oportunamente en caso de detectar cambios en las señales sísmicas.</td><td>Amarillo</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/14adcfa478c25b72cb6cf28f4ba030b4ba744ebbbd3467520da1ce9b30f193d9.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>18:00 Mediante cámaras se visualiza el sector del volcán nublado, sin novedad.</td><td>Verde</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/799fb52c3450974160769bd66ef587a6c5b25b576c23d06f3e41017855171b69.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el sector del volcán nublado, sin novedad.</td><td>Verde</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/a517e39f2add8340718cfa1d2fe5cc0cd986c299db9a3b7d5aea7d093ca426a4.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>08:40 Sangay para la COMUNIDAD, IGEPN informa emisión de vapor y ceniza, con una altura de la nube igual a 1000 metros sobre el nivel del cráter con dirección Suroeste.</td><td>Amarillo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/994b34c212006fb35380955dea61944b7593ee23f1d7dd29c843276e12358719.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">00 Ríos desbordados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 Ríos con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">03 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>Esmeraldas</td><td>Esmeraldas</td><td>Tachina</td><td>Atrás del aeropuerto General Rivadeneira</td><td>0.03</td></tr><tr><td>Pichincha</td><td>Quito</td><td>El Condado</td><td>Hcda. Yanacocha, vía a Nono</td><td>--</td></tr><tr><td>Azuay</td><td>Cuenca</td><td>Sayausí</td><td>Control Integrado Cajas (Quinuas)</td><td>--</td></tr><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr></table>

Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización martes, 13 de diciembre de 2022 - 20:26:36 / Página 2 de 14 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/d92fa6c4a2df5437c68bca30998d2deab13197cc1db3fc1f5e9cb24d13a85adb.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td>---</td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td>---</td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>74.58</td><td>85.00</td><td>07:20</td><td>Verde</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>114.81</td><td>117.00</td><td>08:37</td><td>Verde</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td>---</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>---</td><td>106.50</td><td>---</td><td>---</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td>---</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td>---</td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td>---</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/994601a28b42153a7fe2606af7e1210d0d95cc283764cf79404194720def5845.jpg)



SITUACIÓN HIDROMETEREOLOGICA



AVISO A CORTO PLAZO



PRONÓSTICO PARA LAS PRÓXIMAS HORAS
EMISIÓN: 13 de diciembre de 2022 / 13:30 horas
VIGENCIA: Desde las 13:00 del 13 hasta las 13:00 del 14 de diciembre de 2022



FENÓMENO: LLUVIAS Y TORMENTAS


![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/ca1bc049e6acf03256ed2767b9d1ebdcee8c83ce2257bba90f60448fdec07c14.jpg)



ESTIMACIÓN DE
LLUVIA EN 24 HORAS


<table><tr><td colspan="4">Cantidad máxima de precipitación en 24 horas (mm)</td></tr><tr><td>REGIÓN</td><td>NIVEL MEDIO</td><td>NIVEL ALTO</td><td>NIVEL MUY ALTO</td></tr><tr><td>Litoral/insular</td><td>10 - 18</td><td>18 - 41</td><td>-</td></tr><tr><td>Interandina</td><td>8 - 11</td><td>-</td><td>-</td></tr><tr><td>Amazonía</td><td>22 - 31</td><td>32 - 54</td><td>55 - 80</td></tr></table>

Gobierno del Encuentro 

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695 Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 3 de 14

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/8cfd4a93484677d2cab8fbfb337d6abafd3230556925f5a087c431f49d7a5dd5.jpg)


PELIGRO SÍSMICO 

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

## Monitoreo de eventos peligrosos (emergencias y desastres)

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/c27ff2fb0b67b0ff571f4dc5f5739bbc6897171fa8a9831d25a66728c2827774.jpg)


<table><tr><td>Localización:</td><td>Carchi/Tulcán, San Pedro de Huaca, Montúfar, Espejo, Bolívar, Mira, Potrerillos - Chalpatán.</td></tr><tr><td>Antecedentes:</td><td>El 25/07/2022 producto de la actividad volcánica se registró un sismo de magnitud 5.2, con epicentro a 17.8 km de Tulcán, con una profundidad de 2 km.Se declararon en emergencia los cantones de Montúfar, Espejo y San Pedro de Huaca. El COE Provincial se mantiene activo coordinando acciones en atención a la emergencia.</td></tr><tr><td>Situación actual:</td><td>MIDUVI y GAD Cantonal atienden requerimientos esporádicos.</td></tr><tr><td>Afectaciones:</td><td>- 9 Heridos- 2354 personas afectadas- 743 personas damnificadas- 677 familias afectadas- 229 familias damnificadas- 26 bienes públicos afectados- 34 unidades Educativas afectadas- 4 bienes privados afectados- 7 unidades de Salud afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>- El MIDUVI y GAD Cantonales según requerimiento realizan evaluaciones de viviendas afectadas.- Al momento se mantienen activos 2 albergues temporales, Casa Comunal parroquia La Libertad - San Isidro con un total de 3 familias (11 personas) y Biblioteca Municipal Mesías Arcos parroquia Pioter con un total de 1 familia (4 personas).</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/MSP/MINEDUC/MIES/MIDUVI/SIS ECU 911/GAD Provincial/GAD Cantonal UGR/Cuerpo de Bomberos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/2de9fd9ec809fa8813446cfd41d78e33a3b2c165432e3c651f45ee2a7795aba3.jpg)


## Deslizamiento

Localización: Imbabura/Pimampiro/Pimampiro/San José de Aloburo.
Antecedentes: De acuerdo al informe del SNGRE del 26/11/2021, se indica que, el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias. Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.
Situación actual: MIDUVI concluye que el predio denominado “Monserrat 3 - Pimampiro” con código Nro. 1130 ha sido aprobado y se procede a solicitar al GAD Cantonal: (estudios de suelos, factibilidad de servicios, subdivisión y entrega a los beneficiarios, con escritura individual y obras de mejoramiento del suelo).
Afectaciones: - 41 familias afectadas (113 personas), - 12 familias damnificadas (35 personas), 

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695 Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 4 de 14

<table><tr><td></td><td>- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservorios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>MIES validó la información y se entregó el Bono de Contingencia a 4 familias.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/Yachay/MAG/MIDUVI/GAD Provincial /GAD Cantonal /UGR/ SNGRE - UPREA -UAR</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/41e1784f163a268c0aa15fe16a6aec6e3ba6759e8ae93c32df8bebc5484b0474.jpg)


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP. El frente de erosión se mantiene en la abscisa 7+900(puente de San Carlos).Se mantiene la declaratoria emitida mediante resolución SNGRE-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>03/12/2022 CELEC en sus reportes diarios de monitoreo informó que se mantienen las condiciones de inestabilidad en la zona de Ventana 2, que amenazan los terrenos de la zona del antiguo campamento de SINOHYDRO, la zona del poblado de San Luis y las zonas ubicadas en la margen izquierda del cauce. El frente de erosión se mantiene en la abscisa 7+700 por 2 días. San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio. La vía San Luis-Lago Agrio permanece cerrada. La vía construida por los moradores está habilitada para vehículos 4x4.</td></tr><tr><td>Afectaciones:</td><td>- 05/08/2022 Evacuación de 1 familia (5 personas)- 12/07/2022 1 bien público afectado (Tubería de agua potable, solventado)- 09/07/2022 Evacuación de 1 familia (4 personas)- 04/07/2022 Pérdida de la vía construida por moradores- 27/05/2022 1 familia evacuada (2 personas).- 05/03/2022. 1 familia evacuada.- 04/03/2022, 2 familias evacuadas.- 19/01/2022, 1 familia evacuada (1 persona).- 05/01/2022, evacuación de enseres de 3 familias (ya se encontraban 2 familias evacuadas días anteriores y la tercera familia continúa en su vivienda).- 20/12/2021, 1 familia (10 personas) evacuadas.- 13/12/2021, rotura de la tubería de poliducto.- 10/12/2021, población de San Rafael sin energía eléctrica.- 03/12/2021, puente sobre el río Piedra Fina 2 en riesgo.</td></tr></table>

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695 Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 5 de 14

<table><tr><td></td><td>- 21/11/2021, 1 tubería de agua afectada.- 19/05/2021, 1 puente destruido (puente denominado Ventana 2).- 18/05/2021, 2 viviendas destruidas (las familias fueron evacuadas en febrero del 2021).- 10/03/2021, 1 bien afectado (tanque de agua).- 27/02/2021, 2 familias damnificadas y evacuadas a alojamiento temporal (al momento están en arriendo por sus propios medios); 2 viviendas presentaron fisuras.- 22/10/2020, 1 puente destruido (puente sobre el río Montana).- 06/05/2020, 2 familias afectadas, 2 viviendas afectadas.- 07/04/2020, 3 bienes afectados (tuberías del SOTE, Poliducto Shushufindi- Quito y la OCP).- Afectación vial: las pérdidas y afectaciones relevantes en vías ocurrieron en un total de 875 metros de la vía [E45].- Afectación agropecuaria: durante estos meses se ha identificado la pérdida de 100 ha de superficie agrícola, 63 porcinos, 3000 tilapias y 385 bovinos.</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP continúa realizando trabajos en la apertura de la vía provisional en el sector de El Reventador y San Luis.SNGRE CZ2 mantiene monitoreo constante con puntos focales en San Luis. La CTC Río Coca realizan el monitoreo del proceso erosivo.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ2 Unidad de Monitoreo Napo-Orellana/GAD Municipal El Chaco/CELEC EP/ Teniente Político Gonzalo Díaz de Pineda.</td></tr></table>

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/39fbd05a7a3f91083483abfded8a99c9e4eeb8d8d8c36e9319af4367f9c2bfeb.jpg)


<table><tr><td>Localización:</td><td>Cotopaxi/Latacunga/Latacunga/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>Mediante el acuerdo ministerial No.134 del MAG se declara el estado de Emergencia Zoosanitaria en el territorio ecuatoriano por un periodo de 90 días</td></tr><tr><td>Situación actual:</td><td>MAG mantiene monitoreo constante a las granjas del alrededor por posibles infecciones nuevas, se mantiene el estado de Emergencia zoosanitaria desde el 01/12/2022, lo cual han transcurrido 13 días.</td></tr><tr><td>Afectaciones:</td><td>30 Granjas afectadas (180.000 aves).</td></tr><tr><td>Acciones de respuesta:</td><td>MAG realizó inspección y levantamiento de información y no se registran más granjas infectadas por el momento.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ3 Umeva de Monitoreo Tungurahua/MAG</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/8fd7b4b7168f03338cceb458ab7e3d1f24d7c859dce19fddef990c4959ac64bc.jpg)


<table><tr><td>Localización:</td><td>Santo Domingo de los Tsáchilas/Santo Domingo/Rio Verde/Coop. Santa Martha.</td></tr><tr><td>Antecedentes:</td><td>El 24/06/2022, se suscitó la intoxicación de personas por la ingesta de alcohol metílico en un velorio.</td></tr><tr><td>Situación actual:</td><td>Al momento una persona permanece en observación en el hospital Gustavo Domínguez, los demás pacientes fueron dados de alta médica, de igual manera indicó que no existe ingreso de más personas con síntomas de intoxicación.</td></tr><tr><td>Afectaciones:</td><td>42 personas con atención Pre-hospitalaria.14 personas fallecidas.</td></tr><tr><td>Acciones de respuesta:</td><td>MSP realiza monitoreo a la persona que se encuentra en el Hospital Gustavo Domínguez.</td></tr><tr><td>Fuentes de información:</td><td>MSP/SNGRE UMEVA Santo Domingo.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695 Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 6 de 14

ZONA 5 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/b8e02d9f10eb76a2e98fee6b5e0ef7e0fa615b3e8330ce3109c5a1aa7acb8491.jpg)



Incendio estructural


<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Dr. Camilo Ponce/ calles Eloy Alfaro y 5 de junio</td></tr><tr><td>Antecedentes:</td><td>El 12/12/2022, debido a causas desconocidas se suscitó un incendio estructural que consumió 4 pequeños locales de madera y zinc en su totalidad.</td></tr><tr><td>Situación actual:</td><td>Al momento se realizó limpieza de escombros en el lugar con personal bomberil y GAD se encuentra levantando información de los dueños de los locales destruidos, por lo que se espera el consolidado de afectación total del documento EVIN.”</td></tr><tr><td>Afectaciones:</td><td>- 4 locales comerciales destruidos (bien privado de madera).</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Babahoyo se encuentra realizando levantamiento EVIN para determinar la causa del flagelo.Cuerpo de Bomberos de Babahoyo colaboró con la limpieza de escombros en el sitio.Jefa Política de Babahoyo asistió al sitio para verificación de afectaciones.</td></tr><tr><td>Fuentes de información:</td><td>UGR Babahoyo / Cuerpo de Bomberos Babahoyo/ SNGRE Unidad de Monitoreo Los Ríos.</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/db8c14ab3bd9c9d35a0c0e2d98c47b3d4b3ebbbfa7d23f10770c5f604ff6cc03.jpg)


<table><tr><td>Localización:</td><td>Azuay/Cuenca/Sayausí/Control Integrado Cajas (Quinuas)</td></tr><tr><td>Antecedentes:</td><td>Desde el 12/12/2022, se encuentra en curso un incendio forestal</td></tr><tr><td>Situación actual:</td><td>Bomberos informa que los trabajos de liquidación se dificultan por las condiciones del clima, el forestal al momento se encuentra activo.</td></tr><tr><td>Afectaciones:</td><td>--</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos Cuenca, Guarda parques del GAD de Cuenca continúan con labores de sofocación y liquidaciónPersonal del Consejo de Seguridad Ciudadana colabora con drones para sobrevuelo de la zona, se realiza protocolo de activación del personal de FF.AA. para que colabore con tareas de sofocación, adicional se encuentra activado el PMU.</td></tr><tr><td>Fuentes de información:</td><td>C. B. de Cuenca/SNGRE Unidad de Monitoreo Azuay-Cañar</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/dbef8c662029af799186a8d9ea1fd880e93ac9a9cc828fd9c2e272174ef0be32.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/Rosas, Bellavista, Tamboloma, Chunazana.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Servicio Nacional de Gestión de Riesgos y Emergencias declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 31/10/2022 se realizó simulacro de evacuación de la población, para medir los tiempos de respuesta de las instituciones y de la población</td></tr><tr><td>Afectaciones:</td><td>-50 metros de vía afectada (vía habilitada, sector El Progreso)-80 familias afectadas integradas por 238 personas afectadas-60 familias damnificadas, integradas por 162 personas damnificadas-40 metros de vía afectados (vía parcialmente habilitada, sector Trancapata)-60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)-1 Casa comunal afectada con cuarteaduras-47 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695 Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 7 de 14

<table><tr><td></td><td>-Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)-Iglesia demolida por los daños estructurales presentados-Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE CZ6, PPNN, Bomberos Nabón, MSP participaron en el simulacro y apoyo a la población.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/8d64155c744be075a6498c9e98dc463ca8b51b9345caf456e0766d3a1ee34e27.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Pichincha/Quito/Cumbayá/Urbanización Rancho San Francisco.</td></tr><tr><td>Antecedentes:</td><td>Con fecha al 05/11/2022 por inestabilidad del talud se generaron varios deslizamientos con caída de tierra hacia el interior de la quebrada del río Machángara que atraviesa el sector, con aproximadamente 200 metros lineales de material deslizado.Una vez realizada la inspección, refieren que en los taludes que se encuentra en el río Machángara, entre la quebrada Jatunhuaycu y Uroloma, se observa que la dinámica del río está provocando procesos hídricos que están erosionando la base de los taludes, con lo que se genera una pérdida de terreno e inestabilidad, además ocasiona un socavamiento de las paredes donde impacta el agua. El material deslizado se depositó en la base del talud, formando una escollera que ha empujado parte del talud hacia el costado derecho, protegiendo temporalmente del golpe directo del afluente</td></tr><tr><td>Situación actual:</td><td>Se realizó inspección al lugar y a estructuras de alcantarillado y colectores sin reportar afectaciones a viviendas ni bienes, se coordinan monitoreos semanales sobre el estado del talud deslizado y del río.</td></tr><tr><td>Afectaciones:</td><td>200 metros lineales de material deslizado hacia la quebrada.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal EPMAPS realizó inspecciones a colectores sin identificar afectaciones a sus estructuras, Operativo Zonal realiza cada semana monitoreo continuo del evento.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ9 Unidad de Monitoreo Pichincha/COE-M.</td></tr></table>

## 2. Monitoreo de estado de vías afectadas por eventos peligrosos

VÍAS DE PRIMER ORDEN: 

## 01 vía de primer orden cerrada

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>875</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>

## 40 vías de primer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Guacamayos, sector cocodrilos, vía Y de Narupa-Y de Baeza[E45]-[E20]</td><td>DESLIZAMIENTO</td><td>--</td><td>02/12/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización: martes. 13 de diciembre de 2022 - 20:26:36 / Página 8 de 14


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>2</td><td>Pastaza</td><td>Mera</td><td>Shell</td><td>Bellavista Caserío Lindosulay, Vía Baños - Puyo [E30]</td><td>SOCAVAMIENTO</td><td>--</td><td>14/11/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Y de Narupa, km 22 vía Loreto - Coca. [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>02/11/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Carchi</td><td>Tulcán</td><td>Julio Andrade</td><td>Yalquer, vía Chauchin-Yalquer</td><td>DESLIZAMIENTO</td><td>30</td><td>21/10/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Huamboya</td><td>Huamboya</td><td>Valle del Pastaza, vía Macas-Puyo [E45]</td><td>DESLIZAMIENTO</td><td>8</td><td>14/10/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Napo</td><td>Quijos</td><td>Cosanga</td><td>Varios sectores, vía Y de Narupa - Y de Baeza [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/10/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>vía Paute Guarumales Mendez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Azuay</td><td>Cuenca</td><td>Sayausí</td><td>Km 7, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>25</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Manabí</td><td>Puerto López</td><td>Salango</td><td>La Rinconada 5 Cerros, vía Puerto López - Santa Elena [E15].</td><td>HUNDIMIENTO</td><td>4</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua E-383</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Napo</td><td>Quijos</td><td>Baeza</td><td>Sector de Guagrayacu, vía Baeza-Papallacta [E20]</td><td>DESLIZAMIENTO</td><td>10</td><td>12/08/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Calvas</td><td>Utuana</td><td>Utuana, vía Cariamanga-Macará [E69]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Loja</td><td>Calvas</td><td>Colaisaca</td><td>Asanuma, vía Cariamanga-Sozoranga [E69]</td><td>DESLIZAMIENTO</td><td>30</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 66, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>60</td><td>26/02/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>--</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>El Palmar, Tilipulo, Saraguasi, San José de Tilipulo, California, La Esperanza.</td><td>INUNDACIÓN</td><td>--</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Rios, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tullcán - Ibarra</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 9 de 14


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>25</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Macanas, vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>50</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>26</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>27</td><td>Napo</td><td>Tena</td><td>Chontapunta</td><td>Rayayacu, vía Chontapunta - La Belleza [E436]</td><td>COLAPSO ESTRUC TURAL</td><td>--</td><td>17/11/2021</td><td>Vía de tercer orden Humuyacu- Yuralpa Derecho- Wachayacu.</td></tr><tr><td>28</td><td>Tungurahua</td><td>San Pedro De Pelileo</td><td>Pelileo</td><td>La Hamaca, vía Pelileo - Baños [E30]</td><td>SOCAVAMIENTO</td><td>--</td><td>16/10/2021</td><td>Ninguna</td></tr><tr><td>29</td><td>Napo</td><td>Quijos</td><td>Cuyuja</td><td>Flor del Bosque, Quebrada Rio Negro, Jatuntinahua, Molana, El Laurel, vía Y de Baeza -Papallacta [E20]</td><td>DESLIZAMIENTO</td><td>200</td><td>19/07/2021</td><td>Ninguna</td></tr><tr><td>30</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza</td><td>Sector Tucumbatza, vía Gualaquiza-San Juan Bosco [E45] (Primer Orden).</td><td>HUNDIMIENTO</td><td>50</td><td>30/06/2021</td><td>Ninguna</td></tr><tr><td>31</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>32</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>33</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km. 101, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>12</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvio Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>35</td><td>Orellana</td><td>La Joya De Los Sachas</td><td>San Sebastián del Coca</td><td>Toyuca, Sardinas, Sebastian del Coca, vía La Joya de los Sachas - El Coca [E45A]</td><td>SOCAVAMIENTO</td><td>--</td><td>08/02/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>37</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>38</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>39</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>40</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUC TURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>

Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 10 de 14 

VIAS DE SEGUNDO ORDEN 

## 09 vías de segundo orden cerradas

<table><tr><td>o.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Imbabura</td><td>San Miguel de Urcuqui</td><td>San Blas</td><td>Santa Cecilia</td><td>SOCAVAMIENTO</td><td>20</td><td>26/10/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Pichincha</td><td>Pedro Moncayo</td><td>Tocachi</td><td>Ingreso a las pirámides de Cochasqui</td><td>DESLIZAMIENTO</td><td>--</td><td>13/12/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Imbabura</td><td>Antonio Ante</td><td>San Roque</td><td>La Merced; vía Atuntaqui - Cotacachi</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>08/10/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Atahualpa</td><td>San Juan De Cerro Azul</td><td>Cerro Azul, Vía Cerro Azul - Paccha [E-585]</td><td>DESLIZAMIENTO</td><td>30</td><td>09/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Pepinales, vía Alausí - Huigra [E-47]</td><td>SOCAVAMIENTO</td><td>--</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>9</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 12 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (Cab. En 9 de Octubre)</td><td>km 15, vía Riobamba-Macas</td><td>DESLIZAMIENTO</td><td>300</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Orellana</td><td>Francisco de Orellana</td><td>La Belleza</td><td>Vía Jaguar 2 - Cacique Jumandy</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Alausí</td><td>Huigra</td><td>Pagma, vía Alausí - Huigra - El Triunfo [E-47]</td><td>DESLIZAMIENTO</td><td>500</td><td>02/03/2022</td><td>Ninguna</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>9</td><td>Chimborazo</td><td>Guano</td><td>La Matriz</td><td>Barrios La Merced, La Dolorosa del cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu santo, La Dolorosa Centro, Balneario Los Elenes</td><td>ALUVIÓN</td><td>9000</td><td>11/12/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>Chaquisca, vía Guanujo-Las Cochas</td><td>DESLIZAMIENTO</td><td>30</td><td>09/11/2021</td><td>sector de Negroyacu o barrio Mantilla</td></tr><tr><td>11</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Km 35, vía Cahuají - Pillate - Cotaló [E-304].</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2021</td><td>Riobamba - Mocha - Baños</td></tr></table>

## VÍAS DE TERCER ORDEN:


14 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Morona Santiago</td><td>Gualaquiza</td><td>San Miguel de Cuyes</td><td>Vía a San Miguel de Cuyes</td><td>SOCAVAMIENTO</td><td>20</td><td>05/07/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio.</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Tungurahua</td><td>Santiago de Píllaro</td><td>Baquerizo Moreno</td><td>Plazuela, vía Plazuela - Baquerizo Moreno</td><td>ALUVION</td><td>500</td><td>24/06/2022.</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur.</td><td>INUNDACION</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Río verde Alto, vía Lita - Rioverde Alto</td><td>DESLIZAMIENTO</td><td>50</td><td>18/12/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Imbabura</td><td>San Miguel De Urcuqui</td><td>La Merced De Buenos Aires</td><td>San José</td><td>DESLIZAMIENTO</td><td>70</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Nueva alianza</td><td>INUNDACIÓN</td><td>7000</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>--</td><td>20/01/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Guilliloma - Kullpa - Armenia</td><td>HUNDIMIENTO</td><td>--</td><td>26/12/2020</td><td>Ninguna</td></tr><tr><td>14</td><td>Morona Santiago</td><td>Palora</td><td>Cumandá (Cab. en Colonia Agrícola Sevilla del Oro)</td><td>Puente sobre el río Charuyaku</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>23/10/2020</td><td>Palora-Puyo-Cumandá</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20.26.36 / Página 12 de 14 


17 vías de tercer orden parcialmente habilitadas.


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Chimborazo</td><td>Guano</td><td>Santa Fe de Galán</td><td>La Palestina</td><td>DESLIZAMIENTO</td><td>--</td><td>02/12/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Cañar</td><td>Azogues</td><td>Rivera</td><td>Libertad, Zhoray, Colepato, Huigra, Matrama, Mazar.</td><td>ALUVION</td><td>100</td><td>04/07/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Carchi</td><td>Bolívar</td><td>Monte Olivo</td><td>Monte Olivo, vía Bolívar - Monte Olivo</td><td>ALUVION</td><td>50</td><td>04/07/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Chimborazo</td><td>Guamote</td><td>Palmira</td><td>Sector de Vishut Km 512, Vía Riobamba - Alausí [E-35].</td><td>DESLIZAMIENTO</td><td>10</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Barrio la Laguna, vía Sucúa-Asunción</td><td>ALUVIÓN</td><td>30</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Tungurahua</td><td>Baños De Agua Santa</td><td>Lligua</td><td>Capa Rosa, vía Lligua - Baños.</td><td>ALUVIÓN</td><td>150</td><td>22/08/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Yaucana</td><td>ALUVIÓN</td><td>---</td><td>23/07/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Napo</td><td>El Chaco</td><td>Oyacachi</td><td>Oyacachi, vía a Jariyacu-Huashahuaicu</td><td>DESLIZAMIENTO</td><td>---</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Nueva Tarqui</td><td>El Candi</td><td>HUNDIMIENTO</td><td>800</td><td>26/05/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Centro Parroquial de Pananza</td><td>HUNDIMIENTO</td><td>10</td><td>20/05/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Tungurahua</td><td>Patate</td><td>Patate, cabecera cantonal</td><td>Puñapí, vía alterna Baños - Patate</td><td>DESLIZAMIENTO</td><td>80</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Chimborazo</td><td>Riobamba</td><td>Quimiag</td><td>Sector Balcashí, vía Quimiag - Chambo</td><td>SOCAVAMIENTO</td><td>---</td><td>06/03/2021</td><td>Ninguna</td></tr><tr><td>14</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Puente sobre el río Malo</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>29/01/2021</td><td>Ninguna</td></tr><tr><td>15</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Valle Hermoso</td><td>Sector Sarayacu.</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/01/2021</td><td>Ninguna</td></tr><tr><td>16</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>17</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>


4. Declaratorias emitidas por el SNGRE (vigentes en orden cronológico)


<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/64aefb10a88e5f0baa1bdb81cae0120acc00f9c7c3e54795056e258122040def.jpg"/></td><td>Incremento Actividad Volcánica Cotopaxi</td><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SNGRE-0311-2022</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/190f459405e54cdd5c28455ef31d2b3dce64559f99d88fcc494670726c42ec77.jpg"/></td><td>Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo.</td><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SNGRE-182-2022</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 13 de 14


![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/e848632a847ffba3012d3e141400c5ecb2bdfe459994efbabe84e8dd7dd0653a.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/50142b197a42cb6cda3aa71572a56b2e126e7215bd3b8b11e2d35f3533f9f6b8.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa en los sectores: Pasán y Namza Chico, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo.</td><td>Amarilla</td><td>20/05/2022</td><td>Resolución No. SNGRE-118-2022</td></tr><tr><td>Movimiento en masa barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SNGRE-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SNGRE-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SNGRE-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SNGRE-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SNGRE-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SNGRE-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SNGRE-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/afd537a5bc4f88b1a2d15604ea177a111ea4d8324cc94e4e42d5b5b61cabe1a6.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/3e2b22d7403cb3d4598fb270ebd5d36033c29a7a1cd3cc979e5b55566ba9c1ae.jpg)


Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0695
Fecha y Hora de actualización: martes, 13 de diciembre de 2022 - 20:26:36 / Página 14 de 14


<table><tr><td></td><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/7f43a393d6ff2def39f914bbc0775f7a186c4b4e40a606e3f22ad753217592a6.jpg"/></td><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/6cf5867beb96c4855117b7bdbc8958bde49dd8aed6dad45c16af81901de4ad2a.jpg"/></td><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="3">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/7eef268975a4456222633e516eb5f6349db60ed1cc61a38a8b8ff50ddc2a865d.jpg"/></td><td>Inundaciones Babahoyo, Los Ríos</td><td colspan="2">11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-07-31/15c864e9-8da1-4f05-aafb-df5d940a6ab7/9d1056eab1542e9ef38a87079a07368468a3a2b143ed560c5b67d6f1b7f06d9e.jpg"/></td><td>Hundimiento, Zaruma, El Oro</td><td colspan="2">07/03/2017</td><td>Resolución No. SGR-029-2015</td></tr></table>

Elaborado por: Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón
Revisado por: - Analista Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón.
Enviado por: Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón 