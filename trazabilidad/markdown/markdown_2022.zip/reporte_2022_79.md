Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633
Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 1 de 13 

Periodo de Monitoreo: 

<table><tr><td>Desde:</td><td>09h00</td><td>12/11/2022</td></tr></table>

<table><tr><td>Hasta:</td><td>21h00</td><td>12/11/2022</td></tr></table>

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/12e8d60097b4fcc4e20fff83063494ac68c794b0966b34b99f24298786069581.jpg)


- Amenaza dentro de los parámetros normales. 

## PELIGRO VOLCÁNICO

<table><tr><td colspan="3">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/d13e52da475692462748a5b35a8df1eb25f1d857336cbb3b2dad1f57dd065605.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:23 IGEPN informa emisión de vapor y ceniza, con una altura mayor a 1000 metros sobre el nivel del cráter en dirección Nor-Oeste.</td><td>Amarillo</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/5136c76a37ab84f05b214c22064dbb6b52aa736dfd7e11b87e50f1ea094c26e7.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18:03 Se visualiza el volcán despejado.</td><td>Verde</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/915067268fbe82b6ea760e363a35187e0799f457421256e27749cc1a04a6588c.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el sector del volcán Nublado, sin novedad</td><td>Verde</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/0daba5483248e68d8d1022fef06c76650c4e29f3a010defcd812d7d5f2b46a41.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>18:00 Mediante cámaras se visualiza el sector del volcán nublado, sin novedad.</td><td>Verde</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/4dd44782228e0fd6d2c4631d5b0adcd5d77522f02ef27c813c2da3b43646f1bc.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18:00 Sin reporte de actividad.</td><td>Verde</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/700e898a908b5d34a7fd2cf34390fa8bb9997507d482bf5680db00d5e6a53781.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>18:00 IGEPN informa emisión de ceniza observada en imágenes satelitales y reportada por la Washington VAAC, con una altura igual a 1170 metros sobre el nivel del cráter en dirección Oeste.</td><td>Amarillo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/674887e1258a059ad4fa00446c1f7fe672435c93d67dd317bea83a36d7b1ff62.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">00 Ríos desbordados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 Ríos con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/2bef8b1eb4963cf53a1a26cf0bbec6999638f828d062281844516d756c8231bc.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">01 incendio activo</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Arquillo</td><td>--</td></tr><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633 Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 2 de 13


PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS


<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td>---</td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td>---</td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>78.38</td><td>85.00</td><td>06:23</td><td>Verde</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>114.99</td><td>117.00</td><td>08:27</td><td>Verde</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>59.61</td><td>66.00</td><td>14:13</td><td>Verde</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>104.58</td><td>106.50</td><td>14:13</td><td>Verde</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/a039e33fc0c45eea6a7e9dd599ed1b2a3981d82850b0358609b8106cfd9a77ad.jpg)


<table><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>59.87</td><td>68.50</td><td>14:13</td><td>Verde</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td>---</td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td>---</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/88f023e9def73075b949cb782d50b2e607dd39743482934f7784890db5e45f52.jpg)



SITUACIÓN HIDROMETEOROLÓGICA


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/4e92bd0243ac72bb649bea314ac42553ce97c61e5791fc67907f42fc7a4c6ccf.jpg)


## AMENAZA: ALERTA POR ALTAS TEMPERATURAS DIURNAS

ADVERTENCIA METEOROLÓGICA N° 39 

Vigencia: desde 13H00 del 11 de noviembre hasta las 00H00 del 12 de noviembre de 2022. 

SITUACIÓN: Nuevamente, esta tarde se esperan lluvias moderadas a puntualmente fuertes con tormentas ocasionales en la región interandina y parte de la amazonía. Estas condiciones se presentarían hasta horas de la noche. 

## FUENTE: INAMHI

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/bd72bfa95b0f8319036d1020b422732c616a95dca74fa419fa50b2d4925ae8f9.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>--</td><td>--</td><td>---</td><td>---</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633 Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 3 de 13

## Monitoreo de eventos peligrosos (emergencias y desastres)

ZONA 1 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/86ce810610bb1e008773258110bd4e0017953e766a1f8722b117e7d1fbf13174.jpg)



Intoxicación


<table><tr><td>Localización:</td><td>Esmeraldas/Rioverde/Montalvo/Recinto Paufí.</td></tr><tr><td>Antecedentes:</td><td>El 24/10/2022 debido a la ingesta de alcohol adulterado (alcohol metílico) se produce la intoxicación de varias personas.</td></tr><tr><td>Situación actual:</td><td>UGR-MSP informa que hasta el momento se registran 47 personas intoxicadas.</td></tr><tr><td>Afectaciones:</td><td>- 18 personas fallecidas (7 en Rioverde, 3 en Quinindé, 3 en Esmeraldas, 3 en Eloy Alfaro y 2 en Muisne)- 15 personas con síntomas graves se encuentran hospitalizados.- 14 personas que presentan síntomas leves (se incluye a los ya dados de alta)</td></tr><tr><td>Acciones de respuesta:</td><td>MSP da seguimiento a las personas que continúan siendo atendidas.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Esmeraldas/MSP Esmeraldas - Rioverde.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/87411229a1eefbdf22cf6f619afafa37f8c8bf6a0ab691bab6d4807a873700af.jpg)


## Sismo

<table><tr><td>Localización:</td><td>Carchi/Tulcán, San Pedro de Huaca, Montúfar, Espejo, Bolívar, Mira, Potrerillos - Chalpatán.</td></tr><tr><td>Antecedentes:</td><td>El 25/07/2022 producto de la actividad volcánica se registró un sismo de magnitud 5.2, con epicentro a 17.8 km de Tulcán, con una profundidad de 2 km.Se declararon en emergencia los cantones de Montúfar, Espejo y San Pedro de Huaca. El COE Provincial se mantiene activo coordinando acciones en atención a la emergencia.</td></tr><tr><td>Situación actual:</td><td>Personal de MIDUVI y GAD Cantonal atienden requerimientos esporádicos.</td></tr><tr><td>Afectaciones:</td><td>- 9 Heridos- 2270 personas afectadas- 685 personas damnificadas- 677 familias afectadas- 229 familias damnificadas- 26 bienes públicos afectados- 34 unidades Educativas afectadas- 4 bienes privados afectados- 7 unidades de Salud afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>- El MIDUVI y GAD Cantonales según requerimiento realizan evaluaciones de viviendas afectadas.- Al momento se mantienen activos 2 albergues temporales, Casa Comunal parroquia La Libertad - San Isidro con un total de 3 familias (11 personas) y Biblioteca Municipal Mesías Arcos parroquia Pioter con un total de 1 familia (4 personas).</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/MSP/MINEDUC/MIES/MIDUVI/SIS ECU 911/GAD Provincial/GAD Cantonal UGR/ Cuerpo de Bomberos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/eaefd5af8e10226f25d5dfccc071cccae428d4c2741528979cf390132ed9c2cf.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>De acuerdo al informe del SNGRE del 26/11/2021, se indica que, el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr.Alcalde resuelve declarar la situación de emergencia en el cantón</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633

<table><tr><td colspan="2">Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 4 de 13Pimampiro.</td></tr><tr><td>Situación actual:</td><td>MIDUVI concluye que el predio denominado “Monserrat 3 - Pimampiro” con código Nro. 1130 ha sido aprobado y se procede a solicitar al GAD Cantonal:(estudios de suelos, factibilidad de servicios, subdivisión y entrega a los beneficiarios, con escritura individual y obras de mejoramiento del suelo).</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservoirios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>MIES validó la información y se entregó el Bono de Contingencia a 4 familias.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ1 Unidad de Monitoreo Imbabura - Carchi/Yachay/MAG/MIDUVI/GAD Provincial /GAD Cantonal /UGR/ SNGRE - UPREA -UAR</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/7631cc19b0e51fd747c479f3cc481cf169f42662e215f8f829c21b658e2393fe.jpg)


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP. El frente de erosión se mantiene en la abscisa 7+900(puente de San Carlos).Se mantiene la declaratoria emitida mediante resolución SNGRE-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>30/10/2022 CELEC en sus reportes diarios de monitoreo informa que se mantienen las condiciones de inestabilidad en la zona de Ventana 2, que amenazan los terrenos de la zona del antiguo campamento de SINOHYDRO, la zona del poblado de San Luis y las zonas ubicadas en la margen izquierda del cauce. El frente de erosión se mantiene en la anscisa 7+900 por 469 días. Al momento no se presentan lluvias en el sector.San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio. La vía San Luis-Lago Agrio permanece cerrada. A causa de la erosión se produjo la pérdida de la vía construida por los moradores.</td></tr><tr><td>Afectaciones:</td><td>- 05/08/2022 Evacuación de 1 familia (5 personas)- 12/07/2022 1 bien público afectado (Tubería de agua potable, solventado)- 09/07/2022 Evacuación de 1 familia (4 personas)- 04/07/2022 Pérdida de la vía construida por moradores- 27/05/2022 1 familia evacuada (2 personas).- 05/03/2022. 1 familia evacuada.</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633

<table><tr><td colspan="2">Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 5 de 13</td></tr><tr><td rowspan="17"></td><td>- 04/03/2022, 2 familias evacuadas.</td></tr><tr><td>- 19/01/2022, 1 familia evacuada (1 persona).</td></tr><tr><td>- 05/01/2022, evacuación de enseres de 3 familias (ya se encontraban 2 familias evacuadas días anteriores y la tercera familia continúa en su vivienda).</td></tr><tr><td>- 20/12/2021, 1 familia (10 personas) evacuadas.</td></tr><tr><td>- 13/12/2021, rotura de la tubería de poliducto.</td></tr><tr><td>- 10/12/2021, población de San Rafael sin energía eléctrica.</td></tr><tr><td>- 03/12/2021, puente sobre el río Piedra Fina 2 en riesgo.</td></tr><tr><td>- 21/11/2021, 1 tubería de agua afectada.</td></tr><tr><td>- 19/05/2021, 1 puente destruido (puente denominado Ventana 2).</td></tr><tr><td>- 18/05/2021, 2 viviendas destruidas (las familias fueron evacuadas en febrero del 2021).</td></tr><tr><td>- 10/03/2021, 1 bien afectado (tanque de agua).</td></tr><tr><td>- 27/02/2021, 2 familias damnificadas y evacuadas a alojamiento temporal (al momento están en arriendo por sus propios medios); 2 viviendas presentaron fisuras.</td></tr><tr><td>- 22/10/2020, 1 puente destruido (puente sobre el río Montana).</td></tr><tr><td>- 06/05/2020, 2 familias afectadas, 2 viviendas afectadas.</td></tr><tr><td>- 07/04/2020, 3 bienes afectados (tuberías del SOTE, Poliducto Shushufindi- Quito y la OCP).</td></tr><tr><td>- Afectación vial: las pérdidas y afectaciones relevantes en vías ocurrieron en un total de 875 metros de la vía [E45].</td></tr><tr><td>- Afectación agropecuaria: durante estos meses se ha identificado la pérdida de 100 ha de superficie agrícola, 63 porcinos, 3000 tilapias y 385 bovinos.</td></tr><tr><td>Acciones de respuesta:</td><td>Los trabajos en la vía provisional se encuentran paralizados debido a inconvenientes con los moradores del sector.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ2 Unidad de Monitoreo Napo-Orellana/GAD Municipal El Chaco/CELEC EP/ Teniente Político Gonzalo Díaz de Pineda.</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/37fc878545431f96b72a01bb40e41d7bf64dede1138ee0b383d89a84a119a8d0.jpg)


<table><tr><td>Localización:</td><td>Santo Domingo de los Tsáchilas/Santo Domingo/Rio Verde/Coop. Santa Martha.</td></tr><tr><td>Antecedentes:</td><td>26/10/2022 Se suscitó la intoxicación de personas por la ingesta de alcohol metílico en un velorio.</td></tr><tr><td>Situación actual:</td><td>MSP informó, que continúan los ingresos en los establecimientos de salud, de personas que han ingerido licor adulterado. Adicional indicó que hay hasta el momento 35 personas dadas de alta médica.</td></tr><tr><td>Afectaciones:</td><td>- 39 personas con atención pre-hospitalaria.- 14 personas fallecidas.</td></tr><tr><td>Acciones de respuesta:</td><td>01/11/2022. Intendencia realizó la clausura 2 tiendas donde se expendía licor sin registro sanitario, adicional se retiraron un total de 1623 litros de licor sin registros sanitarios.ARCSA realiza los análisis del licor retirado por parte de la intendencia.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ4 Unidad de Monitoreo Santo Domingo/UPREA SNGRE/MSP.</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/4409b89669b44dd104ceec053fb575756a5fadf22a306fa08476deed4865600d.jpg)


## Deslizamiento

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633

<table><tr><td colspan="2">Fecha y Hora de actualización: sabado, 12 de noviembre de 2022 - 20:58:55 / Pagina 6 de 13</td></tr><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/Rosas, Bellavista, Tamboloma, Chunazana.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Servicio Nacional de Gestión de Riesgos y Emergencias declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 31/10/2022 se realizó simulacro de evacuación de la población, para medir los tiempos de respuesta de las instituciones y de la población</td></tr><tr><td>Afectaciones:</td><td>-50 metros de vía afectada (vía habilitada, sector El Progreso)-80 familias afectadas integradas por 238 personas afectadas-60 familias damnificadas, integradas por 162 personas damnificadas-40 metros de vía afectados (vía parcialmente habilitada, sector Trancapata)-60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)-1 Casa comunal afectada con cuarteaduras-47 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)-Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)-Iglesia demolida por los daños estructurales presentados-Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>SNGRE CZ6, PPNN, Bomberos Nabón, MSP participaron en el simulacro y apoyo a la población.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/89e4048472ca1162901863f9ccad9314d5a0e86fd4fb5bfb238729f9828f7cbe.jpg)


<table><tr><td>Localización:</td><td>Pichincha/Quito/Cumbayá/Urbanización Rancho San Francisco</td></tr><tr><td>Antecedentes:</td><td>Con fecha al 05/11/2022 por inestabilidad del talud se generaron varios deslizamientos con caída de tierra hacia el interior de la quebrada del río Machángara que atraviesa el sector, con aproximadamente 200 metros lineales de material deslizado.</td></tr><tr><td>Situación actual:</td><td>Al momento no se registra represamiento en el caudal del río Machángara,se realizó la evaluación del estado del evento y en días posteriores se informarán medidas a tomar de acuerdo al informe técnico correspondiente.</td></tr><tr><td>Afectaciones:</td><td>---</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal DMQ manifiesta que se realizó una nueva inspección en el lugar mediante personal técnico geólogo, indicando que el talud se encuentra erosionando por factores naturales y recomienda el desarrollo de obras de mitigación (un muro de contención) en el lugar. Posteriormente la DMGR DMQ remitirá los informes técnicos a las autoridades para el posible desarrollo de obras de mitigación.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ9 Unidad de Monitoreo Pichincha/COE-M</td></tr></table>

## 2. Monitoreo de estado de vías afectadas por eventos peligrosos

VÍAS DE PRIMER ORDEN: 

Dirección de Monitoreo de Eventos Adversos 

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633

Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 7 de 13 

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>875</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>


38 vías de primer orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Y de Narupa, km 22 vía Loreto - Coca. [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>02/11/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Carchi</td><td>Tulcán</td><td>Julio Andrade</td><td>Yalquer, vía Chauchin-Yalquer</td><td>DESLIZAMIENTO</td><td>30</td><td>21/10/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Morona Santiago</td><td>Huamboya</td><td>Huamboya</td><td>Valle del Pastaza, vía Macas-Puyo [E45]</td><td>DESLIZAMIENTO</td><td>8</td><td>14/10/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Napo</td><td>Quijos</td><td>Cosanga</td><td>Varios sectores, vía Y de Narupa - Y de Baeza [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/10/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>vía Paute Guarumales Mendez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Cuenca</td><td>Sayausí</td><td>Km 7, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>25</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Manabí</td><td>Puerto López</td><td>Salango</td><td>La Rinconada 5 Cerros, vía Puerto López - Santa Elena [E15].</td><td>HUNDIMIENTO</td><td>4</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua E-383</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Napo</td><td>Quijos</td><td>Baeza</td><td>Sector de Guagrayacu, vía Baeza-Papallacta [E20]</td><td>DESLIZAMIENTO</td><td>10</td><td>12/08/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Loja</td><td>Calvas</td><td>Utuana</td><td>Utuana, vía Cariamanga-Macará[E69]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Calvas</td><td>Colaisaca</td><td>Asanuma, vía Cariamanga-Sozoranga[E69]</td><td>DESLIZAMIENTO</td><td>30</td><td>07/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 66, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>60</td><td>26/02/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>--</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>El Palmar, Tilipulo, Saraguasi, San José de Tilipulo, California, La Esperanza.</td><td>INUNDACIÓN</td><td>--</td><td>31/01/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>21</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tulcán - Ibarra 2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>23</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Macanas, vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>50</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>24</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>25</td><td>Napo</td><td>Tena</td><td>Chontapunta</td><td>Rayayacu, vía Chontapunta - La Belleza [E436]</td><td>COLAPSO ESTRUC TURAL</td><td>--</td><td>17/11/2021</td><td>Vía de tercer orden Humuyacu-Yuralpa Derecho-Wachayacu.</td></tr><tr><td>26</td><td>Tungurahua</td><td>San Pedro De Pelileo</td><td>Pelileo</td><td>La Hamaca, vía Pelileo - Baños [E30]</td><td>SOCAVAMIENTO</td><td>--</td><td>16/10/2021</td><td>Ninguna</td></tr><tr><td>27</td><td>Napo</td><td>Quijos</td><td>Cuyuja</td><td>Flor del Bosque, Quebrada Rio Negro, Jatuntinahua, Molana, El Laurel, vía Y de Baeza -Papallacta [E20]</td><td>DESLIZAMIENTO</td><td>200</td><td>19/07/2021</td><td>Ninguna</td></tr><tr><td>28</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza</td><td>Sector Tucumbatza, vía Gualaquiza-San Juan Bosco [E45] (Primer Orden).</td><td>HUNDIMIENTO</td><td>50</td><td>30/06/2021</td><td>Ninguna</td></tr><tr><td>29</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>30</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>31</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km. 101, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>SOCAVAMIENTO</td><td>12</td><td>14/03/2021</td><td>Ninguna</td></tr><tr><td>32</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvio Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>33</td><td>Orellana</td><td>La Joya De Los Sachas</td><td>San Sebastián del Coca</td><td>Toyuca, Sardinas, Sebastian del Coca, vía La Joya de los Sachas - El Coca [E45A]</td><td>SOCAVAMIENTO</td><td>--</td><td>08/02/2021</td><td>Ninguna</td></tr><tr><td>34</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>35</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>36</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos

## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633

Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 9 de 13 

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>37</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>38</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUC TURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>

## VIAS DE SEGUNDO ORDEN

## 09 vías de segundo orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Cotopaxi</td><td>Latacunga</td><td>Ignacio Flores</td><td>San Carlos calle Euclides Salazar y Av. Roosevelt.</td><td>ALUVION</td><td>---</td><td>12/11/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Imbabura</td><td>San Miguel de Urcuqui</td><td>San Blas</td><td>Santa Cecilia</td><td>SOCAVAMIENTO</td><td>20</td><td>26/10/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Imbabura</td><td>Antonio Ante</td><td>San Roque</td><td>La Merced; vía Atuntaqui - Cotacachi</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>08/10/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Atahualpa</td><td>San Juan De Cerro Azul</td><td>Cerro Azul, Vía Cerro Azul - Paccha [E-585]</td><td>DESLIZAMIENTO</td><td>30</td><td>09/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Pepinales, vía Alausí - Huigra [E-47]</td><td>SOCAVAMIENTO</td><td>--</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>9</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 12 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (Cab. En 9 de Octubre)</td><td>km 15, vía Riobamba-Macas</td><td>DESLIZAMIENTO</td><td>300</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Orellana</td><td>Francisco de Orellana</td><td>La Belleza</td><td>Vía Jaguar 2 - Cacique Jumandy</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr></table>

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633
Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 10 de 13


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td>ESTRUCTURAL</td><td></td><td></td><td></td></tr><tr><td>7</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Alausí</td><td>Huigra</td><td>Pagma, vía Alausí - Huigra - El Triunfo [E-47]</td><td>DESLIZAMIENTO</td><td>500</td><td>02/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Chimborazo</td><td>Guano</td><td>La Matriz</td><td>Barrios La Merced, La Dolorosa del cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu santo, La Dolorosa Centro, Balneario Los Elenes</td><td>ALUVIÓN</td><td>9000</td><td>11/12/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>Chaquisca, vía Guanujo-Las Cochas</td><td>DESLIZAMIENTO</td><td>30</td><td>09/11/2021</td><td>sector de Negroyacu o barrio Mantilla</td></tr><tr><td>11</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Km 35, vía Cahuají - Pillate - Cotaló [E-304].</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2021</td><td>Riobamba - Mocha - Baños</td></tr></table>


VÍAS DE TERCER ORDEN:



14 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Morona Santiago</td><td>Gualaquiza</td><td>San Miguel de Cuyes</td><td>Vía a San Miguel de Cuyes</td><td>SOCAVAMIENTO</td><td>20</td><td>05/07/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio.</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Tungurahua</td><td>Santiago de Píllaro</td><td>Baquerizo Moreno</td><td>Plazuela, vía Plazuela - Baquerizo Moreno</td><td>ALUVION</td><td>500</td><td>24/06/2022.</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur.</td><td>INUNDACION</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Imbabura</td><td>Ibarra</td><td>Lita</td><td>Río verde Alto, vía Lita - Rioverde Alto</td><td>DESLIZAMIENTO</td><td>50</td><td>18/12/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Imbabura</td><td>San Miguel De Urcuqui</td><td>La Merced De Buenos Aires</td><td>San José</td><td>DESLIZAMIENTO</td><td>70</td><td>14/12/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Nueva alianza</td><td>INUNDACIÓN</td><td>7000</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>--</td><td>20/01/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Guilliloma - Kullpa - Armenia</td><td>HUNDIMIENTO</td><td>--</td><td>26/12/2020</td><td>Ninguna</td></tr><tr><td>14</td><td>Morona Santiago</td><td>Palora</td><td>Cumandá (Cab. en Colonia Agrícola</td><td>Puente sobre el río Charuyaku</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>23/10/2020</td><td>Palora-Puyo-Cumandá</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 


Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633
Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 11 de 13


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td></td><td></td><td></td><td>Sevilla del Oro)</td><td></td><td></td><td></td><td></td><td></td></tr></table>

## 16 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Cañar</td><td>Azogues</td><td>Rivera</td><td>Libertad, Zhoray, Colepato, Huigra, Matrama, Mazar.</td><td>ALUVION</td><td>100</td><td>04/07/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Carchi</td><td>Bolívar</td><td>Monte Olivo</td><td>Monte Olivo, vía Bolívar - Monte Olivo</td><td>ALUVION</td><td>50</td><td>04/07/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Chimborazo</td><td>Guamote</td><td>Palmira</td><td>Sector de Vishut Km 512, Vía Riobamba - Alausí [E-35].</td><td>DESLIZAMIENTO</td><td>10</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Barrio la Laguna, vía Sucúa-Asunción</td><td>ALUVIÓN</td><td>30</td><td>22/12/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Tungurahua</td><td>Baños De Agua Santa</td><td>Lligua</td><td>Capa Rosa, vía Lligua - Baños.</td><td>ALUVIÓN</td><td>150</td><td>22/08/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Napo</td><td>El Chaco</td><td>Sardinas</td><td>Quebrada Yaucana</td><td>ALUVIÓN</td><td>---</td><td>23/07/2021</td><td>Ninguna</td></tr><tr><td>8</td><td>Napo</td><td>El Chaco</td><td>Oyacachi</td><td>Oyacachi, vía a Jariyacu-Huashahuaicu</td><td>DESLIZAMIENTO</td><td>---</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>9</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Nueva Tarqui</td><td>El Candi</td><td>HUNDIMIENTO</td><td>800</td><td>26/05/2021</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Centro Parroquial de Pananza</td><td>HUNDIMIENTO</td><td>10</td><td>20/05/2021</td><td>Ninguna</td></tr><tr><td>11</td><td>Tungurahua</td><td>Patate</td><td>Patate, cabecera cantonal</td><td>Puñapí, vía alterna Baños - Patate</td><td>DESLIZAMIENTO</td><td>80</td><td>18/05/2021</td><td>Ninguna</td></tr><tr><td>12</td><td>Chimborazo</td><td>Riobamba</td><td>Quimiag</td><td>Sector Balcashí, vía Quimiag - Chambo</td><td>SOCAVAMIENTO</td><td>---</td><td>06/03/2021</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Puente sobre el río Malo</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>29/01/2021</td><td>Ninguna</td></tr><tr><td>14</td><td>Santo Domingo De Los Tsáchilas</td><td>Santo Domingo</td><td>Valle Hermoso</td><td>Sector Sarayacu.</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/01/2021</td><td>Ninguna</td></tr><tr><td>15</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>16</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>

## 4. Declaratorias emitidas por el SNGRE (vigentes en orden cronológico)

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/ec31c4cfab8f19bdfef287b42eaf5448b970092d8a5b8d842aa00c937ea2a3dd.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/4ef014a37414daf1df3e9d179bd4109831d3974ba282c293b247ee6f0c4f0ed8.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Incremento Actividad Volcánica Cotopaxi</td><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SNGRE-0311-2022</td></tr><tr><td>Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo.</td><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SNGRE-182-2022</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/f8160705f036d8f35e72794caf20fe00de8858543f5d3e78196bb7ee5cbc5a46.jpg)


## Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633 Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 12 de 13

<table><tr><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa en los sectores: Pasán y Namza Chico, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo.</td><td>Amarilla</td><td>20/05/2022</td><td>Resolución No. SNGRE-118-2022</td></tr><tr><td>Movimiento en masa barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SNGRE-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SNGRE-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SNGRE-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SNGRE-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SNGRE-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SNGRE-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SNGRE-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="2">Declaratorias de Zonas de Riesgos</td><td>Fecha de</td><td>Documento</td></tr></table>

Dirección de Monitoreo de Eventos Adversos 

# Reporte de monitoreo de amenazas y eventos peligrosos - No. 0633 Fecha y Hora de actualización: sábado, 12 de noviembre de 2022 - 20:58:55 / Página 13 de 13

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/2949bb0e5dc17c18c40bada1d3c86aa9d5d87b0729b7980353d57ca9bc41b7aa.jpg)


Inundaciones
Babahoyo, Los Ríos 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-01/5cdf8a39-22b2-4902-ba58-9ef8a6397930/da708cf5eb58a1d7113db6e6cfd3d0cdbc5fcb4ea5e0e308b4e728781ad745dc.jpg)


Hundimiento, 

Zaruma, El Oro 

Elaborado por: Jorge Dután. Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón
Revisado por: Angélica Larrea. - Analista Nacional de Turno 24/7 - Sala de Situación y Monitoreo Pichincha.
Enviado por: Jorge Dután. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón 

11/12/2019 Resolución No. SGR-149-2019 

07/03/2017 Resolución No. SGR-029-2015 