# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 1 de 20

Periodo de Monitoreo: 

Desde: 09h00 28/02/2023 

Hasta: 21h00 28/02/2023 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/87a1125284333405e45f06ca5f02fe877aae58ad7faa569bd1449e99f10f218a.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="3">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td rowspan="2"></td><td rowspan="2"><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/882c9c8ad5288e213f3e10432a505fad8be260377898a7321f503afe60d12a64.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:08 Mediante cámaras se visualiza el volcán nublado.</td><td>VERDE</td></tr><tr><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18:08 Mediante cámaras se visualiza el volcán nublado.</td><td>VERDE</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/4241790fd00d78d9704d0d9cdae690b381773607c853201e54657406e6221f46.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>15:37 Desde las14h30 TL, a través de las cámaras de vigilancia del volcán Cotopaxi, se observa una columna de ceniza que alcanza 500 metros sobre la cumbre y se dirige hacia el sur-occidente. Acompañando esta emisión de ceniza se *registra un aumento de la energía del tremor en la estación símica BREF similar a lo registrado durante los pulsos de mayor actividad del actual período eruptivo. La nube tiene contenido moderado de ceniza y podría generar caída de ceniza en el cantón Latacunga</td><td>AMARILLA</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/579d89601b5434708bdb88e59052a7c26693cdf184d8ce31aff868b92ec78b8a.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>18:15 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/8601511a55d7ab321b136a0348c649a6e792a4e0fd7c6b65955ecdf89f196ff7.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18:00 Sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/037de5ca79fe278546ff0eaec1d65f11d671daaf7c2ce5ac8ca7cbdfae2206c1.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>18:08 Mediante cámaras se visualiza el volcán nublado.</td><td>VERDE</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/720db5c2a86f4bea436fe0def4535c281b523250f712b4df0bb8429784f2e465.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">01 Río desbordado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Alfredo Baquerizo Moreno (Juján), Cabecera Cantonal</td><td>Moraima</td><td>Chilintomo</td></tr><tr><td colspan="5">10 Ríos con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del río</td></tr><tr><td rowspan="2">Guayas</td><td rowspan="2">Salitre (Urbina Jado)</td><td rowspan="2">El Salitre (Las Ramas), Cabecera Cantonal</td><td>La Bocana</td><td>Vinces</td></tr><tr><td>San Matías</td><td>Salitre</td></tr><tr><td>Guayas</td><td>Salitre (Urbina Jado)</td><td>Gral. Vernaza (Dos Esteros)</td><td>Recinto Mastrantal</td><td>Mastrantal</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Babahoyo, Cabecera Cantonal Y Capital Provincial</td><td>Camilo Ponce</td><td>Babahoyo</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>Rcto. Las Malvinas</td><td>La Clementina</td></tr><tr><td>Los Ríos</td><td>Vinces</td><td>Vinces, Cabecera Cantonal</td><td>Vinces</td><td>Vinces</td></tr><tr><td>Los Ríos</td><td>Quevedo</td><td>San Camilo</td><td>San Camilo</td><td>Quevedo</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Clemente Baquerizo</td><td>El Palmar</td><td>San Pablo</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Febres Cordero (Las Juntas) (Cab. en Mata de Cacao)</td><td>Rcto. Isla María</td><td>Las Juntas</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 2 de 20

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/700bc32b89cddc3789e62ebc5516a21179a67d2aed5b7d51b39768792e357c24.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td>Los Ríos</td><td>Palenque</td><td>Palenque, Cabecera Cantonal</td><td>Palenque</td><td>La Revesa</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/42a96bfda62b85cbe375665c45d9fad9ceeabea90b92cda77177481198cd9bf9.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 incendio controlado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/9bc7d9a7e276317288bd7e0e2d0f9d4cc0ed9d5c49da320b26bfb4dd3f3be3cc.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td></td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td></td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>75.32</td><td>85.00</td><td>08:18</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>116.05</td><td>117.00</td><td>08:49</td><td>VERDE</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>56.71</td><td>66.00</td><td>13:59</td><td>VERDE</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>100.22</td><td>106.50</td><td>13:59</td><td>VERDE</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>57.33</td><td>68.50</td><td>13:59</td><td>VERDE</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td></td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td></td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/29a755931304cfe5936edc8f6b68727aeceb2cedf94c4facb14412385ad41d43.jpg)



SITUACIÓN HIDROMETEREOLÓGICA


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/17b9082af560bb44bf0cc25d93ef2a9d7e3eadb758157222a5a04aa35f3fe66f.jpg)


## ADVERTENCIA

AMENAZA: LLUVIAS Y TORMENTAS ADVERTENCIA METEOROLÓGICA N°09 

Vigente desde 15H00 del 27 de febrero hasta las 07H00 del 04 de marzo de 2023 

SITUACIÓN: Entre el 27 de febrero y el 04 de marzo se prevé que continúen los eventos de lluvias intensas y tormentas en la región Litoral, así como ciertas zonas de la región Amazónica y zonas puntuales del Callejón Interandina; las mayores intensidades se continuarán presentando en las tardes y madrugadas en el Litoral, mayor énfasis en la zona centro – sur 

- Región Litoral: Se prevé lluvias muy fuertes al centro y norte con probables tormentas eléctricas. 

- Región Interandina: Se esperan lluvia de ligera y moderada intensidad al centro y las estribaciones occidentales. 

- Región Amazónica: Se espera precipitaciones de moderada intensidad en gran parte de la región, con énfasis en la zona centro Norte. 

FUENTE: INAMHI 

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 3 de 20

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/5db8325a11e9ae4e949e0df621d155f4bc8d0875557d7485bc9418be1bf0961a.jpg)


PELIGRO SÍSMICO 

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

ZONA 1 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/fec7ac4a2d9e83f1c1aecadc6d44c1c4aa7c3cd4a04c9e8613cf50b63005b5f1.jpg)


<table><tr><td>Localización:</td><td>Imbabura/Ibarra/Sagrario/Redondel de Ajaví, Parque Chiles; Ciudadela El Jardín y Av. Fray Vacas Galindo, Ciudadela El Jardín y Parque Chiles.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023, debido a las fuertes precipitaciones registradas en la noche y madrugada del 22/02/2023, se taponaron los sumideros y alcantarillas, producto de esto quedaron anegados varios sectores; y daños en la red vial donde se encuentra gran cantidad de flujos de lodo, sedimentos, material pétreo y escombros; lo que obstaculiza el tránsito vehicular.</td></tr><tr><td>Situación actual:</td><td>Las viviendas y locales comerciales anegadas y afectadas por el ingreso de lodo en el sector del Redondel de Ajaví, se encuentran rehabilitadas; se continúa con la intervención y limpieza de los sistemas de alcantarillado, se evacuó los sedimentos, escombros y remoción de material pétreo de las calles afectadas, donde el tránsito está habilitado. Se continúa realizando la limpieza de la calzada de los sectores afectados debido al polvo que se han quedado en las calles.Como medida de mitigación por el evento registrado se realiza trabajos en las Quebradas El Laurel y Las Flores</td></tr><tr><td>Afectaciones:</td><td>- 34 familias y 47 personas afectadas; (25 familias y 25 personas corresponde a propietarios de los negocios afectados).- 12 viviendas afectadas, por el ingreso de lodo.- 25 bienes privados afectados locales comerciales (restaurantes, servicios electrónicos, farmacias, pastelerías, panaderías, ferreterías, peluquerías, tiendas de víveres).- 850 metros lineales de la red vial urbana</td></tr><tr><td>Acciones de respuesta:</td><td>La SGR entrega asistencia humanitaria en acompañamiento de la UGR del GAD C Ibarra.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/Cuerpo de Bomberos de Ibarra/UGR GAD C Ibarra/Cruz Roja Ecuatoriana/GAD P Imbabura.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/211efb173a68b2c0c8f34c2ecaad70ec2f25dd0eedd22fb64e2370ab3dc0b832.jpg)



Inundación


<table><tr><td>Localización:</td><td>Imbabura/Ibarra/San Francisco/Jardines de Odila, El Ejido de la Florida/ Av. Mariano Acosta y Heleodoro Ayala/10 de Agosto/Av. Eugenio Espejo y Divino Niño, FECOMI; Av. Heleodoro Ayala y Mariano Acosta.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023, debido a las fuertes precipitaciones registradas en la noche y madrugada del 22/02/2023 se taponó los sumideros y alcantarillas, producto de esto quedaron anegados varios sectores; adicional, las calles se encontraban con gran cantidad de flujo de lodo, material pétreo y escombros.</td></tr><tr><td>Situación actual:</td><td>Las viviendas anegadas y afectadas por el ingreso de lodo en el sector de Odila, se encuentran rehabilitadas; se continúa con la intervención y limpieza de los sistemas de alcantarillado, se evacuó los sedimentos, escombros y remoción de material pétreo de las calles afectadas, donde el tránsito está habilitado. Adicional, se continúa realizando la limpieza de la calzada de los sectores afectados debido al polvo que se han quedado en las calles.Como medida de mitigación por el evento registrado se realiza trabajos en las Quebradas El Laurel y Las Flores</td></tr><tr><td>Afectaciones:</td><td>-113 familias y 401 personas afectadas- 113 viviendas afectadas, por el ingreso de lodo- 2100 metros lineales afectados de la red vial urbana- 5 bienes privados afectados (taller de mecánica, lubricadora de vehículos, entre otros)</td></tr><tr><td>Acciones de respuesta:</td><td>EMAPA Ibarra realiza la limpieza del sistema de alcantarillado.El GAD C Ibarra OP realiza trabajos de rehabilitación.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 4 de 20

<table><tr><td></td><td>Cuerpo de Bomberos Ibarra con el apoyo de Bomberos Antonio Ante y Urcuqui realizaron el baldeo de las vías afectadas.El 23/02/2023, se mantuvo una reunión interinstitucional para seguimiento de acciones de respuesta y se activó la MTT4 - C para coordinar la entrega de asistencia humanitaria a los afectados.El 24/02/2023, la SGR entrega asistencia humanitaria en acompañamiento de la Gobernación y demás actores del SNDGR.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/Gobernación/MSP/SGR-CZ1/GAD P Imbabura/UGR GAD Cantonal de Ibarra/Cruz Roja Ecuatoriana/Cuerpo de Bomberos de Ibarra.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/723b358689a55edb834fa9aa6df0e7b01680db9957adc4950661c058a1a96229.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Imbabura/Ibarra/Caranqui/San Cristóbal de Caranqui, San Francisco de Chorlavisito/ Guayaquil de Caranqui, Simón Bolívar.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023 debido a las fuertes precipitaciones registradas en la noche y madrugada del 22/02/2023, se taponaron los sumideros y alcantarillas, producto de esto quedaron anegados varios sectores; adicional, las calles se encuentran con gran cantidad de flujos de lodo, material pétreo y escombros.</td></tr><tr><td>Situación actual:</td><td>Las viviendas anegadas y afectadas por el ingreso de lodo se encuentran rehabilitadas; y se continúa con la intervención y limpieza de los sistemas de alcantarillado, evacuación sedimentos, escombros y remoción de material pétreo de las calles afectadas, donde el tránsito está parcialmente habilitado. Adicional, se continúa realizando la limpieza de la calzada de los sectores afectados debido al polvo que se han quedado en las calles.Existen vías donde el adoquinado se levantó (calle Huiracocha) y otras vías empedradas, las cuales se encuentran intransitables.Como medida de mitigación por el evento registrado se realiza trabajos en las Quebradas El Laurel y Las Flores*La EMAPA Ibarra realizó la reparación de la tubería de la red de distribución que resultó afectada.</td></tr><tr><td>Afectaciones:</td><td>- 8 familias y 21 personas afectadas- 8 viviendas afectadas por el ingreso de lodo- 675 metros lineales afectados de la red vial- 20 metros afectados de la red de distribución de agua</td></tr><tr><td>Acciones de respuesta:</td><td>EMAPA Ibarra realiza la limpieza del sistema de alcantarillado.El GAD C Ibarra OP realiza trabajos de rehabilitación.Cuerpo de Bomberos Ibarra con el apoyo de Bomberos Antonio Ante y Urcuqui realizaron el baldeo de las vías afectadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/UGR GAD C Ibarra/ Cruz Roja Ecuatoriana/Cuerpo de Bomberos de Ibarra.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/b1f9c6ab0144535b93cf6b6f8db9c255dc5661908542b2f3bb846454de0f0a71.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El 26/11/2021, de acuerdo al informe del SGR se indicó que el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr.Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.Se informa que el SGR CZ1, geólogos de la Prefectura, Universidad Central,Universidad Yachay y autoridades locales realizaron recorridos e inspecciones técnicas.El 16/11/2021, SGR-CZ1 entregó asistencia humanitaria. El Informe del MAG indica que la afectación de los cultivos en total es de 12,43 ha de cultivos de la zona. GAD Cantonal de Pimampiro en apoyo del GAD Provincial Imbabura trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad, tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su cabecera cantonal.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes. Desde enero de 2023 se inició con la instalación de las acometidas de los servicios básicos. El MIDUVI está a la espera de que el GAD termine de hacer las acometidas para iniciar con la construcción de las viviendas; ya que dispone de los recursos económicos para este proyecto.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),</td></tr></table>

- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes), 

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 5 de 20

<table><tr><td></td><td>- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservoirios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El GAD Cantonal de Pimampiro determinó un predio para la construcción del Proyecto de Vivienda, y realiza la instalación de servicios básicos.GAD Cantonal y Provincial de Imbabura habilitaron una vía alterna. La comunidad habilitó la vía a Mariano Acosta que pasa por la zona de riesgo de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SGR, exponiéndose a futuros riesgos vinculados a la zona propensa de deslizamiento.Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi / MIES, MIDUVI, GAD C Pimampiro - UGR.</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/6d52615e9894ea416aa7d859b5156c9b1245a2b9e771492f6b208672aceadccd.jpg)


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda/en el tramo de la vía E45, río Marker.</td></tr><tr><td>Antecedentes:</td><td>El 22/02/2023, debido a las lluvias se produjo el colapso de un puente de primer orden en el tramo Reventador - Punto de Socavamiento de San Luis.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se cerrada en su totalidad.</td></tr><tr><td>Afectaciones:</td><td>-1 puente destruido (Puente sobre el río Marker)-1 bien público destruido ( Torre de soporte de tubería Tipo H)</td></tr><tr><td>Acciones de respuesta:</td><td>ACCIONES DE RESPUESTA:-27/02/2023 Petroecuador informa que los trabajos en la zona del río Marker registran un avance del 89%.-Se mantiene la suspensión del bombeo de crudo por el SOTE y el Oleoducto de Crudos Pesados OCP (operado por OCP Ecuador) y de combustible por el Poliducto Shushufindi - Quito.-SGR CZ 2 realiza monitoreo del evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/OCP/CB El Chaco/Petroecuador</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/94f55f3ec019c1917f42b6f3e49ad42b3b4ec81c73768985dbc1e3f49165b8da.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.Se mantiene la declaratoria emitida mediante resolución SGR-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>La variante emergente El Chaco - Lago Agrio se encuentra cerrada debido a trabajos en la vía y condiciones climáticas. Vía alterna Baeza-Narupa-Loreto-Coca. La Comisión Ejecutora del Río Coca informó el 27/02/2023 que, se mantienen las condiciones de inestabilidad en la zona de Ventana 2 que amenazan los terrenos del antiguo campamento de SINOHYDRO, el sector del poblado de San Luis y las zonas ubicadas en la margen izquierda del cauce. El frente de erosión se encuentra en la abscisa 7+700 por 85 días.Al momento el sector se encuentra nublado, sin presencia de lluvias.</td></tr><tr><td>Afectaciones:</td><td>Desde el 2020 a la fecha las afectaciones son las siguientes:- Personas Afectadas indirectas: 100- Personas Damnificadas: 51- Personas Afectadas: 76</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 6 de 20

<table><tr><td></td><td>- Personas Evacuadas: 63- Viviendas destruidas: 2- Metros de vía afectadas: 1040- Puentes destruidos: 3 (Puente sobre el río Motana, Puente Ventana 2 y Puente Piedra Fina)- Puente afectados: 1 (Puente Piedra Fina)- Bienes Afectados: 4 (tuberías del SOTE, Poliducto Shushufindi- Quito y OCP; Sistema de Agua Potable de San Luis)- Ha de Cultivo perdida: 100.03- Animales de granja afectados y muertos: 3448</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria de MTOP se encuentra en el sector pero no se encuentran realizando trabajos.-SGR CZ2 mantiene monitoreo constante con puntos focales en San Luis. La CTC Río Coca realizan el monitoreo del proceso erosivo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/CELEC EP/GAD Municipal El Chaco/CB Chaco/MTOP/PPNN Chaco.</td></tr></table>

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/683fde14dc9b4974e8d6a4f8372f4feb01b20389513df29b17fac86582ec8a99.jpg)


<table><tr><td>Localización:</td><td>Cotopaxi / La Maná / El Triunfo / San Francisco de Chipe.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias suscitadas en horas de la madrugada del 28/03/2023 se reportó el desbordamiento del Río Chipe, causando el ingreso de agua a las viviendas</td></tr><tr><td>Situación actual:</td><td>El evento se encuentra en etapa de evaluación</td></tr><tr><td>Afectaciones:</td><td>--</td></tr><tr><td>Acciones de respuesta:</td><td>PPNN confirma el evento.CB realiza una inspección.SGR monitorea el evento y coordina con la UGR GADC La Maná una inspección y/o levantamiento de EVIN.</td></tr><tr><td>Fuentes de información:</td><td>UGR/ ECU/UGR GADC / SGR Unidad de Monitoreo Tungurahua.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/408613733f1fb65d52cd58c269e8e28cb5f7d08d6d150b6fc7a6573e620b2e9f.jpg)


<table><tr><td>Localización:</td><td>Chimborazo / Alausí / Alausí, Cabecera Cantonal / Casual, Vía Guamote - Alausí - Chunchi [E35]</td></tr><tr><td>Antecedentes:</td><td>Por causa desconocidas se produjo un deslizamiento que afectó totalmente la vía de primer orden.</td></tr><tr><td>Situación actual:</td><td>A momento la vía de primer orden se encuentra parcialmente habilitada. MAG realizó el levantamiento de matriz MAAPEA e informe ejecutivo de afectación y acciones de respuesta.</td></tr><tr><td>Afectaciones:</td><td>- 80 metros de vía afectada.- 1 ha de cultivo destruido.- 1 familia afectada (4 personas).</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP informa que los trabajos están próximos a terminar se estima que hasta el 02 de marzo ya concluyan ya que continúan estabilizando el talud.MAG intervino en el evento con el levantamiento por afectaciones y acciones de respuesta.SGR monitorea el evento.</td></tr><tr><td>Fuentes de información:</td><td>MAG / MTOP / SGR Unidad de Monitoreo Tungurahua.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/3f1519e0de1502360cc1cdacfdefef035c9406ecfa95c48b15c6c0e1eeea149c.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Chimborazo/Pallatanga/Pallatanga/Caserío Guapo, vía Colta -Pallatanga [E-487], Barrios: Jiménez, María de Lourdes, Municipal, Central, El Ingenio, Cornelio Dávalos, Santa Ana Norte, El Progreso, Morera.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023, a causa de las lluvias suscitadas en horas de la madrugada, se suscító un aluvión.</td></tr><tr><td>Situación actual:</td><td>Se activó el COE Provincial donde se tomaron las siguientes resoluciones:1.- Insistir desde la presidencia del COE Provincial a la Prefectura y a los Ministerios competentes para brindar atención a la comunicación del GAD de Alausí, respecto de la atención emergente y la entrega de informes de riesgo de la zona según corresponda de manera urgente.2.- Peticionar a la Dirección del MTOP Chimborazo se informe en 24 horas, sobre el tiempo de trabajos en la zona de Alausí para aperturar la vía y que se remita un informe de inspección de la actuación de la empresa Verdú encargada del mantenimiento de la vía en Alausí.</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 7 de 20

<table><tr><td></td><td>3.- Activar la MTT4 Provincial a fin de atender con asistencia humanitaria en las zonas afectadas del cantón Pallatanga.4.- Exhortar al ministro del MTOP se otorguen recursos económicos y materiales para que se pueda optimizar de manera inmediata la funcionalidad y operatividad del personal para atender la emergencia de Pallatanga.5.- Declarar al COE provincial en sesión permanente hasta que la crisis de la emergencia sea superada.</td></tr><tr><td>Afectaciones:</td><td>- 4 personas fallecidas- 2 personas heridas- 2 personas damnificadas- 2 personas evacuadas- 113 familias afectadas (9 familias por afectaciones a viviendas y 104 familias por afectaciones a cultivos y animales).- 438 personas afectadas (22 personas por afectaciones a viviendas y 416 personas por afectaciones a cultivos y animales).- 700 personas afectadas indirectamente- 40 metros de vía afectada.- 6 bienes privados afectados (bus, camión, local comercial, propiedades)- 1 bien público afectados (poste)- 1 bien público destruido (manguera de conducción de agua)- Los Barrios: Jiménez, María de Lourdes, Municipal, Central y El Ingenio se encuentran sin abastecimiento de agua.- 7 viviendas en riesgo- 2 viviendas afectadas- 1 vivienda destruida.- 214 animales muertos- 13.5 ha de cultivos afectados.- 28 ha de cultivos destruidos.- 120 animales afectados.- 120 animales muertos.- 1 puente afectado.- 10 metros de vía de tercer orden.</td></tr><tr><td>Acciones de respuesta:</td><td>COE provincial de Chimborazo emite resoluciones en torno a las afectaciones producidas por el aluvión reportado en Pallatanga y el deslizamiento de Alausí Casual.GAD realizó la reparación de la tubería de agua potable afectada al momento los barrios afectados se encuentra al 100% con el abastecimiento de agua potable.GAD Pallatanga reparó la vía de tercer orden Azafrán - San Rafael donde se produjo un hundimiento, se encuentra completamente habilitada.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/COE P.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/863e9c6c16655c5f1ce4e5ccb3dab115ffc392109c92ad40c653ab93022a1d5a.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Zona 3/Chimborazo/Alausí/Alausí, Cabecera Cantonal/Casual, vía Guamote - Alausí [E-35].</td></tr><tr><td>Antecedentes:</td><td>El 01/01/2023, se produjo un hundimiento en la vía de primer orden, que al momento está cerrada por personas que procedieron a poner obstáculos.SGR informa en cumplimiento a la Resolución Nro. SGR-039-2023 del 19/02/2023, declara el estado de ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua; el mismo que comprende un área de aproximadamente 247 hectáreas.</td></tr><tr><td>Situación actual:</td><td>MAG realizó el levantamiento del informe MAAPEA, al momento la vía de primer orden se encuentra parcialmente habilitada.</td></tr><tr><td>Afectaciones:</td><td>- 80 metros de vía afectada.- 1 ha de cultivo destruido.- 1 familia afectada (4 personas).</td></tr><tr><td>Acciones de respuesta:</td><td>MAG realizó el levantamiento de información.SGR monitoreo el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MTOP Chimborazo/MAG.</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 8 de 20

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/d8a0e26ba6a8310f1633d47b1716d11fcf24b088cb3fe804b3b9c17274e0e3ec.jpg)


## Plaga

<table><tr><td>Localización:</td><td>Tungurahua/Cevallos/Cevallos/La Florida.</td></tr><tr><td>Antecedentes:</td><td>El 14/01/2023, AGROCALIDAD realizó toma de muestras y se confirma que las aves que se encuentran en las granja “AVINATURAL Y AVIVAL, dieron positivo a influenza aviar subtipo H5.</td></tr><tr><td>Situación actual:</td><td>Al momento no se registran nuevos casos de influenza aviar.</td></tr><tr><td>Afectaciones:</td><td>- 2 granjas afectadas (8100 aves afectadas y sacrificadas)</td></tr><tr><td>Acciones de respuesta:</td><td>MAG y AGROCALIDAD: Continúan con el despoblamiento de las aves infectadas.Toma de muestras en las diferentes granjas que quedan a 1 Km del foco de infección.Se mantiene con 2 puntos de desinfección y control del foco 24/7. Se mantiene el control constante en los mercados y ferias con el cumplimiento de las medidas de bioseguridad.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/AGROCALIDAD.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/36c7e23f153d231b13412be81cfc47ba078a1df597f153444f20bfa1db864e32.jpg)


## Plaga

<table><tr><td>Localización:</td><td>Cotopaxi/Latacunga/Latacunga/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 01/12/2022, mediante el acuerdo ministerial No.134 del MAG, se declara el estado de Emergencia Zoosanitaria en el territorio ecuatoriano por un periodo de 90 días.</td></tr><tr><td>Situación actual:</td><td>Desde el 01/12/2022 se declaró el estado Emergencia Zoosanitaria en el territorio ecuatoriano, hoy se cumple el día 87 del estado de emergencia. Al momento no se reporta nuevos casos de gripe aviar.</td></tr><tr><td>Afectaciones:</td><td>- 30 Granjas afectadas (180.000 aves).</td></tr><tr><td>Acciones de respuesta:</td><td>MAG y AGROCALIDAD desde el 20/02/2021 realiza el levantamiento catastral de avícolas en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MAG/AGROCALIDAD.</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/72ca29f1e20ae68499c3426b246bde89e50731c4d3c21c2ca20947cb6794b3cd.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/San Antonio/San Pablo</td></tr><tr><td>Antecedentes:</td><td>El 24/02/2023 por lluvias suscitadas en horas de la madrugada se produjo una inundación con afectación a varias viviendas.</td></tr><tr><td>Situación actual:</td><td>Personal de la UGR indica que las familias se encuentran en sus viviendas, la información se levantó el 25/02/2023.</td></tr><tr><td>Afectaciones:</td><td>-11 viviendas afectadas-11 familias afectadas (36 personas afectadas)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR GAD Cantonal realizó el levantamiento de informaciónSGR realiza el seguimiento del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR Monitoreo Manabí/ UGR GAD Chone</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/25be9e3ac0d9fd62062f0874505f4d06a49a77e915092e64179cf10f91ac94a2.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Junín/Junín/San Juan del Toro</td></tr><tr><td>Antecedentes:</td><td>El 24/02/2023 por lluvias suscitadas en horas de la madrugada se produjo una inundación con afectación en varias viviendas.</td></tr><tr><td>Situación actual:</td><td>El 26-02-2023 EL Personal de la UGR y jefatura política indica que las familias se encuentran en sus viviendas, aún puede variar las estadísticas.</td></tr><tr><td>Afectaciones:</td><td>-15 viviendas afectadas-65 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>Jefatura Política y UGR GAD Cantonal realizó el levantamiento de informaciónSGR realiza el seguimiento del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR Monitoreo Manabí/ UGR GAD Junín/ Jefatura Política Junín</td></tr></table>

## ZONA 5

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 9 de 20

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/9e42d2ace156a5841f3a2103fbedc1102241347bf9b7a3f63a1953d0546323fd.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Bolívar/Guaranda/San Lorenzo/Huapungoto, Planta de Tratamiento de Agua del cantón Chimbo</td></tr><tr><td>Antecedentes:</td><td>UGR del GAD Chimbo informa que, por las lluvias constantes en el sector se produjo un aluvión que arrasó todo tipo de material, ingresando material pétreo que viene desde el río a la Planta de Tratamiento de Agua, lo que ocasionó el desabastecimiento del líquido vital en el todo el cantón Chimbo.</td></tr><tr><td>Situación actual:</td><td>El cantón Chimbo se encuentra si líquido vital,</td></tr><tr><td>Afectaciones:</td><td>La afectación se encuentra en etapa de evaluación.</td></tr><tr><td>Acciones de respuesta:</td><td>- Personal de la EMAPA Chimbo, realiza trabajos de limpieza para restablecer el líquido vital en el cantón.- UGR del GAD Cantonal realiza seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>GAD Chimbo, EMAPA Chimbo, SGR Unidad de Monitoreo Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/7481284826b6c98f52dee21a1251b376feff009651fd629a5b5ea1d1cea02784.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Vinces/Antonio Sotomayor/ Comunidad Rural El Mate</td></tr><tr><td>Antecedentes:</td><td>Debido a las lluvias suscitadas en la noche del 27/02/2023 y al drenado de una bananera del lugar, provocaron el ingreso de agua en 30 viviendas con 32 familias de 128 personas afectadas,</td></tr><tr><td>Situación actual:</td><td>Mediante inspección técnica, se procedió a dotar de ayuda humanitaria a las familias afectadas y se coordinó atención médica para el 01/03/2023, actualmente existe acumulación de aguas lluvias y las familias se mantienen en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 30 viviendas afectadas (caña-cemento-madera)- 32 familias afectadas- 128 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>- UGR Vinces realizó entrega de ayuda humanitaria y Tenienta Política colaboró con la entrega y verificación de la misma.- MSP realizará atención médica el 01/03/2023</td></tr><tr><td>Fuentes de información:</td><td>GAD Vinces/ Ministerio de Gobierno-Tenencia Política Antonio Sotomayor/SGR-Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/45f4629ac971bd474f202d22abfce09d48114012f6a5f4d4f2c44660a7838ab5.jpg)


## Colapso estructural

<table><tr><td>Localización:</td><td>Los Ríos/Montalvo/Montalvo/ Cdla. Arcesio Estrada - calle Santa Martha de Roldós</td></tr><tr><td>Antecedentes:</td><td>Debido a las lluvias suscitadas en el cantón en la noche del 27/02/2023, se suscitó un colapso estructural</td></tr><tr><td>Situación actual:</td><td>Mediante levantamiento de información en el sitio y recepción de documento EVIN, se verificó que son 7 personas damnificadas, mismas que se mantienen en casa acogiente (casa de vecina).</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda destruida mixta (caña-madera)- 1 familia damnificada- 7 personas damnificadas (casa acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>- UGR Montalvo realizó informe EVIN.</td></tr><tr><td>Fuentes de información:</td><td>GAD Montalvo/SGR-Unidad de Monitoreo Los Ríos</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/3bbc63e869a113b25386b5e516a2ff948e6fdd0f1dff012dcd0dd5ad09b2ef73.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Bolívar/San Miguel/San Miguel/El Calzado-Abs.27+800, vía San Miguel-Balsapamba [E 491]</td></tr><tr><td>Antecedentes:</td><td>Director del MTOP informa que, por las lluvias constantes en el sector existe inestabilidad del talud de corte, provocando deslizamientos continuos que invaden un carril de la vía de primer orden a la circulación vehicular.En inspección realizada el 23/02/2023 han podido observar deslizamiento en la corona del talud con la presencia de fisuras considerables, por lo que se podría dar un deslizamiento de gran magnitud, poniendo en riesgo a las viviendas en la parte baja del talud (lateral derecha de la carretera), por lo que se sugiere que por prevención se evacue a las familias para evitar desgracias personales.</td></tr><tr><td>Situación actual:</td><td>Personal de la SGR-Bolívar indica que la vía continúa parcialmente habilitada al tránsito vehicular y se mantendrán en los próximos días los trabajos de remoción y limpieza del material deslizado.</td></tr><tr><td>Afectaciones:</td><td>-60 metros lineales</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 10 de 20

<table><tr><td>Acciones de respuesta:</td><td>Maquinaria del MTOP Bolívar continúa realizando trabajos de remoción y limpieza del material deslizado.Cuerpo de Bomberos de San Miguel realiza labores de baldeo de la calzada.SGR-Bolívar acudió al lugar y realizó seguimiento a las acciones realizadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR Unidad de Respuesta y Unidad de Monitoreo Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/16df958003163cc75341c8d8f877a7625ea9fbce60f43f9485f8c28c83cff98e.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Alfredo Baquerizo Moreno (Jujan)/Alfredo Baquerizo Moreno (Jujan), Cabecera Cantonal / Varios Sectores.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en la madrugada del 21/02/2023 se desbordó el Río Chilintomo; la madrugada del 22/02/2023, se desbordó el río Los Amarillos.</td></tr><tr><td>Situación actual:</td><td>UGR - GAD Cantonal realiza recorridos en los diferentes sectores, e indica que el Río Chilintomo sigue desbordado y el nivel del Río Los Amarillos se encuentra con tendencia a aumentar su caudal</td></tr><tr><td>Afectaciones:</td><td>-1 establecimiento educativo afectado (Ingreso de agua al predio)-Cultivos afectados (la cantidad de cultivos está bajo verificación)-Calles inundadas- 283 viviendas afectadas- 283 familias, 889 personas afectadas (se mantienen en los mismos inmuebles)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal - Obras Públicas realiza la colocación de sacos de arena en las riberas del ríoUGR - GAD Cantonal seguirá realizando el levantamiento de informaciónPrefectura se encuentra realizando trabajos de Mitigación.SGR - Umeva Guayas dará seguimiento al evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas UGR - GAD Cantonal Alfredo Baquerizo Moreno (Jujan) /</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/917efc5ee2228f94f421fa560b8fad7b1e9c5c27764cbc464ca5d456ba051e8c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Febres Cordero/Plaza de Chilintomo - río Chilintomo</td></tr><tr><td>Antecedentes:</td><td>Debido a las lluvias suscitadas en la noche del 25/02/2023, se reportó ingreso de agua en las viviendas a causa del desbordamiento del río Chilintomo, actualmente el río continúa desbordado con presencia de agua en las viviendas y las familias se mantienen en sus hogares.</td></tr><tr><td>Situación actual:</td><td>Mediante visita técnica, se verificó que actualmente el río descendió en el sitio, pero existe agua estancada en los alrededores, adicional a ello se recepta documento EVIN y las familias se mantienen en sus hogares.</td></tr><tr><td>Afectaciones:</td><td>- 39 viviendas afectadas (caña y madera)- 39 familias afectadas.- 118 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Babahoyo realizó levantamiento EVIN y verificación de novedades 27/03/2023.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Babahoyo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/4d61be1bab8171434562aa76e4a352c3b9a17ec94a54a67589c78fd929659376.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Playas/General Villamil (Playas)/Varios Sectores.</td></tr><tr><td>Antecedentes:</td><td>Por las fuertes precipitaciones suscitadas la noche del 24/02/2023 y madrugada del 25/02/2023 se reportó varios sectores inundados por acumulación de agua y el desbordamiento del río Suyuna, Técnicos de SGR realizan recorridos en los diferentes sectores. GAD Cantonal indica que el nivel del río se encuentra con tendencia a aumentar su caudal</td></tr><tr><td>Situación actual:</td><td>Técnicos de SGR realizan recorridos en los diferentes sectores. Personal de la prefectura realizaron trabajos de mitigación y reforzamiento de las bases del puente en la vía Engabao - Puerto Engabao la misma que se encuentra habilitada</td></tr><tr><td>Afectaciones:</td><td>-1 poste eléctrico-1 Tubería madre-Calles y Avenidas inundadas-115 viviendas afectadas-115 familias, 470 personas afectadas (las familias se encuentran en los mismos predios)</td></tr><tr><td>Acciones de respuesta:</td><td>Técnico de UGR - GAD Cantonal realizó el levantamiento de información</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 11 de 20

Fuentes de información: SGR CZ5 Unidad de Monitoreo Guayas/MDG/GAD Cantonal Playas/UPREA. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/0712528f8d3031b7627f4089485f52e63677b6197f96fcf3814e9b853252edbb.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Santa Elena/Salinas/Salinas/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 20/02/2023, debido a las lluvias suscitadas en el cantón, se reportó varias viviendas afectadas.</td></tr><tr><td>Situación actual:</td><td>Por reporte de la UGR cantonal, el recinto La Frutilla de la parroquia Simón Bolívar se encuentra aislada, la única vía de acceso se vió interrumpida por un corte en un pase de rio de la zona que por la fuerte lluvia del 25/02/2023 aumento su caudal .</td></tr><tr><td>Afectaciones:</td><td>- 120 Familias afectadas (300 personas)</td></tr><tr><td>Acciones de respuesta:</td><td>OE cantonal se mantiene activo.UGR cantonal realizara entrega de asistencia humanitaria a las familias afectadas.Gobernación de la Provincia y SGR gestionan movilización aérea para traslado de kits hasta la comunidad.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Babahoyo/UPREA - SGR.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/525854d86ba5b2e4513c03929904b1262135c984ec64aa81b1b10bef44c388f2.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/La Unión/ Recintos: San Juan - San Francisco - La Esperanza - Las Malvinas- río La Clementina.</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, debido a las lluvias suscitadas en el cantón, se reportó el desbordamiento del río La Clementina en horas de la madrugada, afectando a varios recintos del lugar</td></tr><tr><td>Situación actual:</td><td>Mediante visita técnica con maquinaria, se realizaron trabajos de reparación en la vía San Juan de tercer orden, misma que continúa cerrada e inhabilitada, las 12 personas afectadas continúan en casa acogiente, hay presencia de lluvias en el sitio y el río La Clementina aumentó de nivel.</td></tr><tr><td>Afectaciones:</td><td>- 7 viviendas mixtas afectadas (cemento-madera y caña).- 8 familias afectadas.- 32 personas afectadas (12 personas en casa de familia acogiente).- 01 bien privado afectado (iglesia).- 40 metros lineales afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>Prefectura colaboró en el sitio el 24/02/2023.UGR Babahoyo realizó inspección técnica en el sitio el 24/02/2023</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Babahoyo/UPREA - SGR.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/dfc89616438865424c36c988216568dcd2bf3a907272e10b2610a8146eb6c477.jpg)


## Plaga

<table><tr><td>Localización:</td><td>Bolívar/Guaranda/Simiatug/Centro de la Parroquia.</td></tr><tr><td>Antecedentes:</td><td>El 10/01/2023, AGROCALIDAD realizó una toma de muestra para la verificación de una posible gripe aviar.El 11/01/2023, MAG en conjunto con AGROCALIDAD, realizó operativo de control para el ingreso de aves y subproductos a la parroquia Simiatug.Mediante comunicado Oficial del MSP, se indica que se confirmó en el laboratorio del Instituto Nacional de Investigación y Salud Pública (INSPI), el primer caso de influencia A-H5 (gripe aviar) en una niña de 9 años por el contacto directo con aves que portaban el virus.</td></tr><tr><td>Situación actual:</td><td>MSP informa que la niña continúa internada en condiciones estables en el área de hospitalización.Agrocalidad menciona que se ha obtenido el resultado muestreado por vigilancia activa de 4 granjas ubicadas en la zona del foco y perifoco, de las cuales se han realizado 2 muestreos a cada granja que han resultado negativo.Adicional se han enviado 6 muestras de predios de traspatio, de las cuales se reportan cómo negativo y hasta la fecha no se han detectado nuevos brotes de gripe aviar en la zona.</td></tr><tr><td>Afectaciones:</td><td>- 8 animales de granja sacrificados.- 1 persona afectada.</td></tr><tr><td>Acciones de respuesta:</td><td>Agrocalidad, con apoyo de técnicos del MAG, realizan actividades de vigilancia en el foco y perifoco, además, realizan controles en carreteras de lugares de expendio de animales vivos.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/AGROCALIDAD, UPREA.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 12 de 20

ZONA 6 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/d3ef856d85a474cd78cafbade0ecc6bfa80425a46307681fbd821447e92382ea.jpg)


## Deslizamiento

<table><tr><td>Localización:Antecedentes:</td><td>Azuay/Nabón/Nabón/Rosas, Bellavista, Tamboloma, Chunazana.El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Secretaría de Gestión de Riesgos declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 25/11/2022, UGR Nabón realizó un nuevo levantamiento de información, dando a conocer nuevas afectaciones 59 viviendas colapsadas, 37 viviendas afectadas y 4 familias afectadas adicionales a las ya reportadas. Adicional, informa que se realizan estudios de repotenciación del centro de salud antiguo.</td></tr><tr><td>Afectaciones:</td><td>- 50 metros de vía afectada (vía habilitada, sector El Progreso)- 84 familias afectadas (238 personas afectadas)- 60 familias damnificadas (162 personas damnificadas)- 40 metros de vía afectados (vía parcialmente habilitada, sector Trancapata)- 60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)- 1 Casa comunal afectada con cuarteaduras- 84 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 59 viviendas destruidas.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)- Iglesia demolida por los daños estructurales presentados- Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>El 25/11/2022, UGR Nabón realizó un nuevo levantamiento de información y se mantiene en monitoreo constante.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/07c89a2e4acba543ce1d5706d4b48a7ed47f5b7be4826fd3dc4fc2301abc9b5d.jpg)


<table><tr><td>Localización:</td><td>Loja/Pindal/Pindal/Pindal, Varios sectores</td></tr><tr><td>Antecedentes:</td><td>Por lluvias presentadas en la tarde del 24/02/2023, se produjo la inundación de varios sectores.</td></tr><tr><td>Situación actual:</td><td>GADC Pindal, acogiendo la recomendación del COE con fecha 25 de febrero del 2023; declara en situación de emergencia al cantón Pindal por las afectaciones producidas a causa de las lluvias presentadas en días anteriores Vía de primer orden habilitada en su totalidad</td></tr><tr><td>Afectaciones:</td><td>01 familia evacuada por seguridad conformada por 01 persona15 viviendas afectadasColapso del Sistema de Alcantarillado30 locales comerciales afectados10 metros de longitud de vía aproximadamente</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Pindal realizó labores de limpieza de alcantarillas en los sectores afectados por la inundación</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/Comandante de Cuerpo de Bomberos de Pindal.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/03e49911987a156844a0db11a3d59936b8d7bd1e2f2e689e1a63124b705c2445.jpg)


## Colapso estructural

<table><tr><td>Localización:</td><td>Loja/Saraguro/Manu/Manú, vía Manú-Udushi.</td></tr><tr><td>Antecedentes:</td><td>El 19/02/2023, por lluvias presentadas durante la madrugada, se produjo el colapso del puente en la vía de tercer orden.</td></tr><tr><td>Situación actual:</td><td>La vía de tercer orden se encuentra cerrada.</td></tr><tr><td>Afectaciones:</td><td>- 01 puente colapsado. (Río Panasco).- 01 puente afectado. (Quebrada Sigsipamba).- vía de tercer orden cerrado. (Vía Manú-Udushi).- vía Selva Alegre - Manú se encuentra habilitada.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 13 de 20

<table><tr><td>Acciones de respuesta:</td><td>GAD-P Loja - VIALSUR - técnicos realizaron inspección técnica a la vía y se realizarán los trabajos de habilitación del puente sobre la quebrada Sigsipamba el mismo que se encuentra parcialmente afectado con la finalidad de poder trasladas la maquinaria y material para la reconstrucción del puente sobre el río Panasco, estos trabajos lo realizarán a partir del día lunes 27/02/2023.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/Consola de Servicios Municipales.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/31b9005f0445adaa2ac75d93ac30435109307aaf745ae63c2617f80cd78cabca.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Portovelo/Salatí/varios sectores: Ambocas, Chunchi, Vado Ancho.</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias suscitadas, se registró el desbordamiento de los ríos Ambocas y Granadillo causando afectaciones en puentes, casas y calles de distintos sectores.</td></tr><tr><td>Situación actual:</td><td>SGR en monitoreo realizado, se informa que en el sitio El Chunchi se ha colocado un puente provisional para el paso de la comunidad, asimismo en el Vado Ancho se realizó la colocación de soga con polea para pasar los alimentos brindados. Las familias y productores afectados recibieron ayuda humanitaria y psicosocial de parte del MIES y MAG.</td></tr><tr><td>Afectaciones:</td><td>- 2 puentes destruidos (1 puente vehicular en el sitio Chunchi y 1 puente peatonal en el sitio Vado Ancho).- 24 familias de 96 personas afectadas indirectamente (13 familias de 52 personas en Chunchi y 11 familias de 44 personas en Vado Ancho).- 2 puentes afectados (Puente vehicular de Ambocas está habilitado y puente de Lourdes habilitado).- 4 viviendas afectadas (por ingreso de agua, lodo y presentan en la parte posterior socavamiento, sector Ambocas).- 4 familias de 17 personas afectadas directamente (3 familias de 14 que fueron evacuadas a refugio temporal retornaron a sus viviendas).- 2 bienes privados destruidos (1 chanchera y 1 moto en Chunchi).- 3 animales de granja muertos (cerdos).- 1 bien público afectado (sistema de captación de agua en el sitio Lourdes).</td></tr><tr><td>Acciones de respuesta:</td><td>El 24/02/2023, MAG realizó recorrido, evaluó los sectores afectados y brindaron ayuda a productores afectados. Asimismo, el MIES brindó apoyo psicológico y entregó asistencia humanitaria.Autoridades del Ministerio del Gobierno como Gobernador de El Oro, Jefe Político de Portovelo y Tenencia Política de Salatí, acompañaron a los recorridos y dieron seguimiento a las acciones ejecutadas en los sectores afectados.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo de El Oro/SGR Uprea El Oro.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/3e108924f27b44f7c475e9ddfe0faa2b9a286c6834f4b4a56ab5730ec210a009.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Portovelo/Portovelo, cabecera cantonal/El Pindo.</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias registradas en la noche, se produjo el desbordamiento del río Pindo, provocando afectaciones en la estructura del complejo El Pindo y en el puente que une la provincia de El Oro con la provincia de Loja.</td></tr><tr><td>Situación actual:</td><td>SGR, luego de realizar el monitoreo, informa que el río Pindo se encuentra en su cauce normal y que el puente que une la provincia de Loja con la provincia de El Oro, se encuentra habilitado.</td></tr><tr><td>Afectaciones:</td><td>- 1 bien privado afectado (complejo turístico).- 1 puente afectado (al momento cerrado).</td></tr><tr><td>Acciones de respuesta:</td><td>OOPP del GAD Provincial realiza trabajos de remediación sobre las bases de puente, con la finalidad de reforzarlo.GAD Cantonal de Portovelo, realizará evaluación al complejo turístico y posterior gestionar la ayuda pertinente.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/Cuerpo de Bomberos de Portovelo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/a2825c35c7afadfc054b27e42714b862270b5e3272077b64a6ed0c71301daf6f.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Portovelo/Salatí/Sitio Los Amarillos.</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias registradas durante la noche, se produjo el desbordamiento del rio Pindo, causando afectaciones en varias viviendas y puentes peatonales que servían como vía de acceso hacia sitios aledaños.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 

Código postal: 092302 / Samborondón-Ecuador 

Teléfono: +593-4-259 3500 

www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 14 de 20

<table><tr><td>Situación actual:</td><td>SGR mediante informe EVIN indica que las familias damnificadas salieron del refugio temporal &quot;Trapiche de Oro&quot; hacia casas de familia acogientes ubicadas el sector Trapiche de la parroquia El Rosario en la provincia de Loja.</td></tr><tr><td>Afectaciones:</td><td>- 6 puentes destruidos (3 puentes peatonales de hormigón y 3 puentes colgantes de madera)- 11 familias afectadas indirectamente (26 personas aisladas)- 3 viviendas afectadas (en sus estructuras)- 3 familias damnificadas (5 personas en familia acogiente).</td></tr><tr><td>Acciones de respuesta:</td><td>SGR en compañía de autoridades cantonales y parroquiales entregó asistencia humanitaria a las familias en situación de emergencia.COE Cantonal de Portovelo se encuentra activo y en sesión permanente para articular acciones emergentes a las distintas emergencias presentadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/Uprea El Oro.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/8d2399768276a35a1702ffded729bf6206ba8e951c0f5759a8837a7520e8f4bf.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Loja/Chaguarpamba/El Rosario/Trapiche, vía a la costa [E50].</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias presentadas en la tarde, se produjo el desbordamiento del río Pindo provocando la inundación de una vivienda y la afectación a la vía principal.</td></tr><tr><td>Situación actual:</td><td>Gobernación de Loja, conjuntamente con el SGR CZ7, realizan la coordinación de atención a las familias afectadas y damnificadas.</td></tr><tr><td>Afectaciones:</td><td>- 3 familias damnificadas conformadas por 06 personas.- 24 familias afectadas conformadas por 70 personas.- 6 puentes peatonales colapsados (puentes de conexión entre comunidades del sector).- 3 viviendas destruidas.- 24 viviendas afectadas.- 01 puente vehicular afectado (vía de segundo orden).- 20 metros de longitud aproximadamente de vía - (vía parcialmente habilitada).- 01 bien privado destruido (vehículo arrastrado por la corriente).</td></tr><tr><td>Acciones de respuesta:</td><td>SGR CZ7 realizó la entrega de Asistencia Humanitaria a las familias afectadas y damnificadas.Gobernación de Loja acompañó en la coordinación de la atención a la emergencia.Cuerpo de Bomberos de Chaguarpamba continúa realizando labores de limpieza de las viviendas afectadas.GAD Provincial Loja (VIALSUR) realiza trabajos de limpieza y habilitación vial.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/Cuerpo de Bomberos de Chaguarpamba/VIALSUR.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/40e73229cea8bc23cce5345e8b778ba8a3fd4c07354427fae187585ea8bb1112.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Zamora Chinchipe/Nangaritza/Nangaritza/Guayzimi.</td></tr><tr><td>Antecedentes:</td><td>El 15/01/2023, por presencia de lluvias suscitadas en la mañana, se produjo el desbordamiento de la quebrada Guayzimi, causando el descenso de lodo y piedras.GAD-C Nangaritza, mediante resolución Nro. GADCN-ALC-2023-003, acogiendo la recomendación del COE con fecha 16 de enero del 2023, declara en situación de emergencia a toda la ciudad de Guayzimi, perteneciente al cantón Nangaritza, por las afectaciones producidas a causa del desbordamiento de quebradas Guayzimi y Central, con una duración de 90 días, contados a partir de la fecha de declaración.De acuerdo al informé realizado por personal técnico de SGR se determinó que el evento se trata de INUNDACIÓN</td></tr><tr><td>Situación actual:</td><td>El sistema de alcantarillado y servicio de agua potable ha sido reestablecido.Las vías de tercer orden se encuentran habilitadas al tránsito vehicular.</td></tr><tr><td>Afectaciones:</td><td>- Bienes privados afectados (5 piscinas de pesca deportiva).- Daños en redes de los sistemas de alcantarillado y sistema fluvial.- Daños en la tubería de agua potable (algunos barrios no cuentan con el líquido vital).- 10 familias afectadas (continúan en sus viviendas).- 10 viviendas afectadas.- 30 metros lineales de vías de tercer orden afectadas (lodo, piedras y escombros).</td></tr></table>

## Secretaría de Gestión de Riesgos


Deslizamiento


# Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 15 de 20

<table><tr><td></td><td>- Afectación a varias calles dentro del casco urbano (lodo, piedras y escombros).</td></tr><tr><td>Acciones de respuesta:</td><td>OOPP de Gobierno Cantonal de Nangaritza realizó los trabajos de reconstrucción de los de los sistemas de alcantarillado y sistema fluvial.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/PPNN/ECU 911.</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/0de6a04f0afedc3d515e9497823549f2a77d363649581105d551bd1654fa9b88.jpg)


<table><tr><td>Localización:</td><td>Pichincha / Quito / Jipijapa/ Parqueadero de Zambiza</td></tr><tr><td>Antecedentes:</td><td>El 27/02/2023 por lluvias, se suscitó un deslizamiento de tierra en un parqueadero que afectó a varios vehículos.</td></tr><tr><td>Situación actual:</td><td>El parqueadero se encuentra cerrado, a la atención al público hasta que culminen con la evaluación y limpieza total.</td></tr><tr><td>Afectaciones:</td><td>11 bienes privados afectados (vehículos)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal - EPMMOP se encuentra realizando una evaluación técnica y coordino maquinaria para el día de mañana 01/03/2023 para realizar un terraplén y limpieza de pequeños desprendimientos.</td></tr><tr><td>Fuentes de información:</td><td>AMT/EPMMOP/SGR Unidad de Monitoreo Pichincha</td></tr></table>

## 3. Monitoreo de estado de vías afectadas por eventos peligrosos

VÍAS DE PRIMER ORDEN: 

## 07 vías de primer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Carchi</td><td>Tulcán</td><td>Tufiño</td><td>vía, Tufiño - Maldonado - El Chical [E182]</td><td>DESLIZAMIENTO</td><td>--</td><td>25/02/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Napo</td><td>Chaco</td><td>Gonzalo Díaz de Pineda</td><td>Puente sobre el río Marker, vía E45 San Luis -El Reventador</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>22/02/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Guapo, vía Colta - Pallatanga [E-487]</td><td>ALUVIÓN</td><td>40</td><td>21/02/2023</td><td>Riobamba Guaranda Babahoyo Guayaquil</td></tr><tr><td>4</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>Km 114 [E-10]</td><td>DESLIZAMIENTO</td><td>---</td><td>20/02/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 78, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>60</td><td>18/02/2023</td><td>Zhud-Cañar-Cochancay</td></tr><tr><td>6</td><td>Manabí</td><td>Manta</td><td>San Lorenzo</td><td>Ruta del Spondiylus San Lorenzo - Santa Rosa [E15]</td><td>OLEAJE</td><td>1200</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>875</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>

## 31 vías de primer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Gramalote, vía Cuenca-Girón - Pasaje</td><td>INUNDACIÓN</td><td>15</td><td>22/02/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0118
Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 16 de 20


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>2</td><td>Los Ríos</td><td>Babahoyo</td><td>Dr. Camilo Ponce</td><td>Vía E-25 Jujan - Babahoyo - Piladora Don Eduardo - Cruce de La Carmela - río Chilintomo</td><td>INUNDACIÓN</td><td>750</td><td>23/02/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Chimborazo</td><td>Alausí</td><td>Alausí, Cabecera Cantonal</td><td>Casual, Vía Guamote - Alausí - Chunchi [E35]</td><td>DESLIZAMIENTO</td><td>80</td><td>19/02/2023</td><td>Riobamba - Alausí antigua vía Pueblo Viejo - Chunchi (vehículos livianos)Riobamba - Colta - Pallatanga - Cumandá - El Triunfo - Zhud (vehículos pesados).</td></tr><tr><td>4</td><td>Loja</td><td>Chaguarpamba</td><td>El Rosario</td><td>Varios sectores (Trapiche, Pindo), vía a la costa [E50]</td><td>INUNDACIÓN</td><td>20</td><td>18/02/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Puente en el sector Jondachi, vía Archidona- Y de Narupa [E-45]</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>14/02/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Km 91-96, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>80</td><td>13/02/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Chipianga, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>01/02/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Esmeraldas</td><td>Quinindé</td><td>Viche</td><td>El Achiote, vía Esmeraldas - Quinindé [E20]</td><td>SOCAVAMIENTO</td><td>15</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>km 22 vía Loreto - Coca. [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>02/11/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>Km 61, vía Paute Guarumales Méndez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Manabí</td><td>Puerto López</td><td>Salango</td><td>La Rinconada 5 Cerros, vía Puerto López - Santa Elena [E15].</td><td>HUNDIMIENTO</td><td>4</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Loja</td><td>Calvas</td><td>Utuana</td><td>Utuana, vía Cariamanga-Macará[E69]</td><td>DESLIZAMIENTO</td><td>30</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tullcán - Ibarra.2- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0118
Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 17 de 20


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>23</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>24</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>25</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>26</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>27</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>28</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>29</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>30</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>31</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>

## VÍAS DE SEGUNDO ORDEN

## 06 vías de segundo orden cerradas

<table><tr><td></td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Sucumbíos</td><td>Sucumbíos</td><td>La Bonita</td><td>Km 10 antes de llegar a Rosa Florida</td><td>DESLIZAMIENTO</td><td></td><td>28/10/2022</td><td></td></tr><tr><td>2</td><td>Imbabura</td><td>San Miguel de Urcuqui</td><td>San Blas</td><td>Santa Cecilia</td><td>SOCAVAMIENTO</td><td>20</td><td>26/10/2022</td><td>Vía antigua de Santa Cecilia - Timbuyacu.</td></tr><tr><td>3</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>6</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 09 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Guapo, vía Colta -Pallatanga [E-487]</td><td>ALUVIÓN</td><td>40</td><td>21/02/2023</td><td>Riobamba -Guaranda -Babahoyo -Guayaquil</td></tr><tr><td>2</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>Chalguayacu, vía Pallatanga -Guayaquil [E-487]</td><td>ALUVIÓN</td><td>60</td><td>20/02/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Zamora Chinchipe</td><td>Nangaritza</td><td>Nangaritza</td><td>Guayzimi</td><td>ALUVIÓN</td><td>30</td><td>15/01/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>15</td><td>7/05/2022</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0118 Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 18 de 20

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>5</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr></table>

## VÍAS DE TERCER ORDEN:

## 07 vías de tercer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>2</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur</td><td>INUNDACIÓN</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>955.9</td><td>20/01/2021</td><td>Ninguna</td></tr></table>

## 04 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Portovelo</td><td>Morales</td><td>Vía Morales - La Chorrera</td><td>DESLIZAMIENTO</td><td>20</td><td>27/02/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>4</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>

## 4. Declaratorias emitidas por el SGR (vigentes en orden cronológico)

<table><tr><td></td><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>[x5HX]</td><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua.</td><td>Amarilla</td><td>17/02/2023</td><td>Resolución No. SGR-039-2023</td></tr></table>

## Secretaría de Gestión de Riesgos

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/d3f69532f38722353c362579543da244c1b7572cacceaae7f9ba92e46c6d6f44.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/70821d98527d4ff7e7f2a48fbd07ad63d063437078c10a7022ce74533324fc1e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/5305858c96331fe557d2caecb47aaf098b8dfe2a9c98a9699f97160296dfd81d.jpg)



Reporte de monitoreo de amenazas y eventos peligrosos - No 0118
Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 19 de 20


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/fd43bdfd393d984d720e4446f5a007dbd1510cd83d475e6376e55db398310bdd.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/bfa1dcdec92e0e0cea9e29341ab39b9ab84f21141e7b1a046e724fd28a5d2199.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/f6193b0a497a051d934c19c483a1f7e58d04ccba3dc621e04eecd85adb86a507.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/b57ddffbd81ae26d7a18024b84efd32d794805fbbf750b62b0ea15e5b7f31a2e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/9a1d0dd71bff7f610450527d43fd56b84642e37ceab8059b7867b27ec6fcbd9f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/6cc8420b4c638c71bb260d564e4ae597ccf3692141b1faa4a27b494b1f1b765d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/5406d6c188b1baad0e302265cafa5a864c5d8f087e03ec568dbfc837d2bb409f.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Incremento Actividad Volcánica Cotopaxi</td><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SGR-0311-2022</td></tr><tr><td>Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo.</td><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SGR-182-2022</td></tr><tr><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa en los sectores: Pasán y Namza Chico, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo.</td><td>Amarilla</td><td>20/05/2022</td><td>Resolución No. SGR-118-2022</td></tr><tr><td>Movimiento en masa barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SGR-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SGR-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SGR-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SGR-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SGR-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SGR-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SGR-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/eb037ce9b2f81a87b8da36a553a558897511b16d49ce1fa46dc1e83e17cca918.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/7f713498b944760b4540a82ae04617077dc44dd21c7f28496c1da24543083774.jpg)


## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Dirección de Monitoreo de Eventos Adversos



Reporte de monitoreo de amenazas y eventos peligrosos - No 0118
Fecha y Hora de actualización: martes, 28 de febrero de 2023 - 20:46:24 / Página 20 de 20


<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/d34172253355a6ef81b3a361b93127028ab55d2118b1757099accd40000cf3db.jpg"/></td><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/d759e85503f3f438277b8ce675adb6ea1f5cdd6fa41e391466f1326fd7869acc.jpg"/></td><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="3">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/412b53bc74856ad632d19c553048bb6384305533e816c29d03822ba69ac5f068.jpg"/></td><td>Inundaciones Babahoyo, Los Ríos</td><td colspan="2">11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/3c278bbc-eca4-486a-9d47-1e4f896a2a67/aa72f768cb05a3e1b0e9aa48c55bcc26cf6af775517d365debee2dcb197979ea.jpg"/></td><td>Hundimiento, Zaruma, El Oro</td><td colspan="2">07/03/2017</td><td>Resolución No. SGR-029-2015</td></tr></table>

Elaborado por. Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón
Revisado por: I - Analista Nacional de Turno 24/7 - Sala de Situación y Monitoreo Pichincha.
Enviado por. Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 