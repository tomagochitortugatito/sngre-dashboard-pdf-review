# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 1 de 23

Periodo de Monitoreo: 

Desde: 09h00 12/03/2023 

Hasta: 21h00 12/03/2023 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/42867b3e832fe8a7042ba457fd0ecd339f2734d17b9e1ec43f3386d1f1daabf2.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="3">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/b298feb390cfae9f647c9f64c01318bc18d9ce063443bf2333441764780c1d68.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:00 Se visualiza el volcán nublado, sin novedad</td><td>VERDE</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/099a59e1657b77208c7f0b6fe0085c5c84fac4e4efc8b19badbaaa9245c3d9e8.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18:00 Se visualiza el volcán nublado, sin novedad</td><td>VERDE</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/7d9e4bb1649d780151a8f06a5bdb581dac1c653caec58dead1e990ff09250d02.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>18:00 Se visualiza el volcán nublado, sin novedad</td><td>AMARILLA</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/7d5d955eef296f56a41ea1c798b04234c4857733107bf4ccf72e95136e340093.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>18:00 Se visualiza el volcán nublado, sin novedad</td><td>VERDE</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/7f2785716b6d3711e5df566c52e7cbd9f17b0c7adb1fb513c50d694ba974fc91.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18:00 Sin novedades</td><td>VERDE</td></tr><tr><td></td><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/41eec3418e0bf812524d3aba4f5d34909d191aba9e38406e26328c747d77febb.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>18:00 Se visualiza el volcán nublado, sin novedad</td><td>VERDE</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/ad3612d2c227669b78f147535f2459fbbf3ac043188b3b731772df7f8130c890.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">05 Cuerpos de agua desbordados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del cuerpo de agua</td></tr><tr><td>Guayas</td><td>Milagro</td><td>Milagro, Cabecera Cantonal</td><td>Av, Paquisha</td><td>Milagro</td></tr><tr><td>Guayas</td><td>Durán</td><td>Eloy Alfaro (Durán)</td><td>Varios Sectores</td><td>Bulubulu</td></tr><tr><td>Guayas</td><td>Naranjito</td><td>Naranjito, Cabecera Cantonal</td><td>Recinto La Primavera</td><td>EL Hediondo</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>Rcto. Las Malvinas</td><td>La Clementina</td></tr><tr><td>Los Ríos</td><td>Ventanas</td><td>Zapotal</td><td>La María</td><td>Onsebi</td></tr><tr><td colspan="5">20 Cuerpos de Agua con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del cuerpo de agua</td></tr><tr><td rowspan="6">Esmeraldas</td><td rowspan="2">Quinindé</td><td>Malimpia</td><td>Malimpia</td><td>Blanco</td></tr><tr><td>Rosa Zárate (Quinindé),Cabecera Cantonal</td><td>Malecón de Quinindé</td><td>Quinindé</td></tr><tr><td>Esmeraldas</td><td>5 De Agosto</td><td>Vías Los Puentes</td><td rowspan="2">Esmeraldas</td></tr><tr><td>Quinindé</td><td>Chura (Chancama) (Cab. En El Yerbero)</td><td>Salinas</td></tr><tr><td>Quinindé</td><td>Viche</td><td>Puente de Viche</td><td>Viche</td></tr><tr><td>Quinindé</td><td>Rosa Zárate (Quinindé),Cabecera Cantonal</td><td>Boca de Mache</td><td>Mache</td></tr><tr><td rowspan="7">Guayas</td><td>Daule</td><td>Los Lojas (Enrique Baquerizo Moreno)</td><td>Recinto La Majada</td><td>Los Tintos</td></tr><tr><td>Salitre (Urbina Jado)</td><td>Gral. Vernaza (Dos Esteros)</td><td>Recinto Mastrantal</td><td>Mastrantal</td></tr><tr><td rowspan="2">Salitre (Urbina Jado)</td><td rowspan="2">El Salitre (Las Ramas),Cabecera Cantonal</td><td>La Bocana</td><td>Vinces</td></tr><tr><td>San Matías</td><td>Salitre</td></tr><tr><td>El Empalme</td><td>Guayas (Pueblo Nuevo)</td><td>Varios Sectores</td><td>Congo</td></tr><tr><td>Nobol</td><td>Narcisa De Jesús, Cabecera Cantonal</td><td>Cabecera Cantonal</td><td>Bijahual</td></tr><tr><td>San Jacinto De Yaguachi</td><td>Gral. Pedro J. Montero (Boliche)</td><td>Cabecera parroquial</td><td>Bulubulu</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Babahoyo, Cabecera Cantonal</td><td>Camilo Ponce</td><td>Babahoyo</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 2 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/b9568daa2a5354ef25350ca8131ac983d3e2cd4bb86a8830daa3da112cd5eb3c.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td rowspan="7"></td><td>Vinces</td><td>Vinces, Cabecera Cantonal</td><td>Vinces</td><td>Vinces</td></tr><tr><td>Ventanas</td><td>Zapotal</td><td>Zapotal</td><td>El Lechugal</td></tr><tr><td>Babahoyo</td><td>Clemente Baquerizo</td><td>El Palmar</td><td>San Pablo</td></tr><tr><td>Buena Fé</td><td>San Jacinto de Buena Fé,Cabecera Cantonal</td><td>Pto. Bajaña</td><td>Pto. Bajaña</td></tr><tr><td>Ventanas</td><td>Los Ángeles</td><td>Puente de Ventanas</td><td>Sibimbe</td></tr><tr><td>Palenque</td><td>Palenque, Cabecera Cantonal</td><td>Palenque</td><td>La Revesa</td></tr><tr><td>Mocache</td><td>Mocache, Cabecera Cantonal</td><td>Mocache</td><td>Mocache</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/d475fd783dd37543f811bd0a5c300f42953778f62bdeed3ddec5bbe01db69b14.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 incendio controlado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/3a5ba1209a162edae0a6fc1ff59b5495cece3b6e60c447b7544a94a0c3f16272.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td></td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td></td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>79.93</td><td>85.00</td><td>07:11</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>115.94</td><td>117.00</td><td>08:37</td><td>VERDE</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td></td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>---</td><td>106.50</td><td>---</td><td></td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td></td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td></td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td></td></tr></table>

## SITUACIÓN HIDROMETEREOLÓGICA

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/0931e38660ff98883d4918a44259513cea927acb66607635aa64ac7e2c5f2d1d.jpg)


## Advertencia Meteorológica N° 11

ALERTA POR LLUVIAS Y TORMENTAS 

<table><tr><td>DESDE13:00 del 08 de marzo</td><td>HASTA13:00 del 13 de marzo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/aabf7f9e49b34c432ee2990c47461512a2f46c3a6213d55f28b710ee12454aed.jpg)



Instituto Nacional de Meteorología e Hidrología - INAMHI


## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## ADVERTENCIA

AMENAZA: LLUVIAS Y TORMENTAS - ADVERTENCIA METEOROLÓGICA N°11 

Vigente desde 13H00 del 08 hasta las 13H00 del 13 de marzo de 2023 

SITUACIÓN: Entre el 08 y el 13 de marzo se prevé que continúen los eventos de lluvias intensas y tormentas en la región Litoral y la región Amazónica, adicionalmente, se prevé la presencia de lluvias fuertes en el Callejón Interandino; los eventos de mayor intensidad se presentarán entre la tarde y madrugada en las zonas marcadas. 

- Región Litoral: Se prevé lluvias muy fuertes al interior de la región con probables tormentas eléctricas. 

- Región Insular: Se prevé lluvias moderadas con probables tormentas eléctricas en la zona sur y este. 

- Región Interandina: Se esperan lluvias moderadas e intensas acompañadas de tormentas eléctricas con mayor incidencia estribaciones occidentales y al sur de la región. 

- Región Amazónica: Se espera precipitaciones moderadas y fuertes en gran parte de la región con probables tormentas eléctricas, con énfasis en la zona norte y las estribaciones. 

FUENTE: INAMHI 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 3 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/cc6800e85d7928a0e77567b02363141c6e1a6080016761ee7eedda1515baa068.jpg)


PELIGRO SÍSMICO 

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/cf99a6025ba996a7f66d5a1deb83298e867d4ccef543dad4d60bafd33e8a8749.jpg)


<table><tr><td>Localización:</td><td>Esmeraldas/Atacames/Súa/Ciudadela Alonso de Illescas y Nuevo Porvenir.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 por lluvias se produjo el desbordamiento del río Súa, el cual provocó una inundación en el sector.</td></tr><tr><td>Situación actual:</td><td>El río Súa se encuentra en su cauce normal.</td></tr><tr><td>Afectaciones:</td><td>-56 familias, 214 personas afectadas (directas).-24 familias, 106 personas afectadas (indirectas).-80 viviendas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>SGR Esmeraldas realizó la entrega de asistencia humanitaria en el sector Nuevo Porvenir y El Mangal.Coordinador Zonal 1, Gobernador de la Provincia, GAD Cantonal Tenencia Política se encuentra en sitio brindando apoyo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Esmeraldas.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/3ddebc63ee0ad5992fa3aea37ec6f6d9f6ed3afa553399bdbceb6f1bf02503db.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El 26/11/2021, de acuerdo al informe del SGR se indicó que el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.Se informa que el SGR CZ1, geólogos de la Prefectura, Universidad Central, Universidad Yachay y autoridades locales realizaron recorridos e inspecciones técnicas.El 16/11/2021, SGR-CZ1 entregó asistencia humanitaria. El Informe del MAG indica que la afectación de los cultivos en total es de 12,43 ha de cultivos de la zona. GAD Cantonal de Pimampiro en apoyo del GAD Provincial Imbabura trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad, tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su cabecera cantonal.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.Desde enero de 2023 se inició con la instalación de las acometidas de los servicios básicos. El MIDUVI está a la espera de que el GAD termine de hacer las acometidas para iniciar con la construcción de las viviendas; ya que dispone de los recursos económicos para este proyecto.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservoirios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El GAD Cantonal de Pimampiro determinó un predio para la construcción del Proyecto de Vivienda, y realiza la instalación de servicios básicos.GAD Cantonal y Provincial de Imbabura habilitaron una vía alterna. La comunidad habilitó la vía a Mariano Acosta que pasa por la zona de riesgo de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SGR, exponiéndose a futuros riesgos vinculados a la zona propensa de deslizamiento.Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi / MIES, MIDUVI, GAD C Pimampiro - UGR.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 4 de 23

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/7d0b58bf348105bb9edfee106b7a5eded6741520cba982c40dc91908e8e9b4fb.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Napo/El Chaco/Sardinas/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 04/03/2023, debido a las lluvias e incremento del río Sardinas, se registran varias afectaciones</td></tr><tr><td>Situación actual:</td><td>El 05/03/2023, se reunió el COPAE para tratar temas referentes a los eventos suscitados en los sectores Los Ángeles y Los Pinos; pérdida de la vía a Los Ángeles de tercer orden y pérdida de la vía de tercer orden en el Sector San Andrés, vía Yahucana.Las vías se encuentran sin acceso a los sectores de San Marcos Alto, San Andrés vía Yahucana, Los Ángeles.</td></tr><tr><td>Afectaciones:</td><td>- 1 Puente carrozable destruido (privado acceso a finca del señor Mora)- 1 Puente peatonal destruido (por deterioro)- 36 familias afectadas (aisladas por las vías sin acceso)- 315 metros de vía de tercer orden destruido (San Andrés 185 m, San Marco Alto 60 m, Los Ángeles 70 m.)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR CZ2 conjuntamente con el GAD Parroquial Sardinas realizaron un recorrido elaboraron levantamiento de información por los sectores afectados.GAD Municipal El Chaco se encarga de los trabajos de la vía en el sector de San Marcos Alto.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Unidad de Monitoreo Napo-Orellana/Teniente Político de Sardinas/GAD Municipal El Chaco.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/2921c3cd9fab96f46a730dc81179a11497133361493d5d8cd46f7f1c009567a4.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda/en el tramo de la vía E45, río Marker.</td></tr><tr><td>Antecedentes:</td><td>El 22/02/2023, debido a las lluvias se produjo el colapso de un puente de primer orden en el tramo Reventador - Punto de Socavamiento de San Luis.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se encuentra cerrada en su totalidad.</td></tr><tr><td>Afectaciones:</td><td>-1 puente destruido (Puente sobre el río Marker).-1 bien público destruido (Torre de soporte de tubería Tipo H).-3 bienes públicos afectados: Oleoductos (SOTE, OCP) y Poliducto Shushufindi-Quito.</td></tr><tr><td>Acciones de respuesta:</td><td>EP Petroecuador informó que luego de retomar el bombeo de crudo por el Sistema de Oleoducto Transecuatoriano (SOTE) y el Poliducto Shushufindi - Quito, el 5 de marzo de 2023, levantó la declaratoria de Fuerza Mayor que regía sobre sus actividades, con la finalidad de normalizar las operaciones.SGR CZ 2 realiza monitoreo del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Unidad de Monitoreo Napo-Orellana/OCP/CB El Chaco/Petroecuador.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/4b72ceb3a4356710e850d36b54ef2011aae1b17b4dc85ea6acfab5da4f070315.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.Se mantiene la declaratoria emitida mediante resolución SGR-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>Al momento el sector se encuentra nublado, sin presencia de lluvias.San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio.</td></tr><tr><td>Afectaciones:</td><td>Desde el 2020 a la fecha las afectaciones son las siguientes:- Personas Afectadas indirectas: 100-Personas Damnificadas: 51-Personas Afectadas: 76-Personas Evacuadas: 63-Viviendas destruidas: 2-Metros de vía afectadas: 1040-Puentes destruidos: 3 (Puente sobre el río Motana, Puente Ventana 2 y Puente Piedra Fina)- Puente afectados: 1 (Puente Piedra Fina)- Bienes Afectados: 4 (tuberías del SOTE, Poliducto Shushufindi- Quito y OCP; Sistema de Agua Potable de San Luis)- Ha de Cultivo perdida: 100.03-Animales de granja afectados y muertos: 3448</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria de MTOP se encuentra en el sector pero no se encuentran realizando trabajos.SGR CZ2 mantiene monitoreo constante con puntos focales en San Luis. La CTC Río Coca realizan el monitoreo del proceso erosivo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/CELEC EP/GAD Municipal El Chaco/CB Chaco/MTOP/PPNN Chaco.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 5 de 23

ZONA 3 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/ce2f0306713399a294f3e317d88f7b16032c92bc84c98593561b8121cec88f7a.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Chimborazo/Pallatanga/Pallatanga/Caserío Guapo, vía Colta -Pallatanga [E-487], Barrios: Jiménez, María de Lourdes, Municipal, Central, El Ingenio, Cornelio Dávalos, Santa Ana Norte, El Progreso, Morera.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023, a causa de las lluvias suscitadas en horas de la madrugada, se suscitó un aluvión.</td></tr><tr><td>Situación actual:</td><td>SGR realizó Informe de inspección técnica preliminar para el análisis de amenazas a fenómenos de remoción en masa e inundaciones en los sectores: El Guapo, río Huitsitse y Santa Ana del cantón Pallatanga, provincia de Chimborazo.</td></tr><tr><td>Afectaciones:</td><td>- 4 personas fallecidas- 2 personas heridas- 2 personas damnificadas- 2 personas evacuadas- 113 familias afectadas (9 familias por afectaciones a viviendas y 104 familias por afectaciones a cultivos y animales).- 438 personas afectadas (22 personas por afectaciones a viviendas y 416 personas por afectaciones a cultivos y animales).- 700 personas afectadas indirectamente- 40 metros de vía afectada.- 6 bienes privados afectados (bus, camión, local comercial, propiedades)- 1 bien público afectados (poste)- 1 bien público destruido (manguera de conducción de agua)- Los Barrios: Jiménez, María de Lourdes, Municipal, Central y El Ingenio se encuentran sin abastecimiento de agua.- 7 viviendas en riesgo- 2 viviendas afectadas- 1 vivienda destruida.- 214 animales muertos- 13.5 ha de cultivos afectados.- 28 ha de cultivos destruidos.- 120 animales afectados.- 120 animales muertos.- 1 puente afectado.- 10 metros de vía de tercer orden.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD realizó la reparación de la tubería de agua potable afectada al momento los barrios afectados se encuentra al 100% con el abastecimiento de agua potable.GAD Pallatanga reparó la vía de tercer orden Azafrán - San Rafael donde se produjo un hundimiento, se encuentra completamente habilitada.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/COE P.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/8977ef7d0d8cf46d5f20e6ae7027fb75e7518c961e672ea91277ab08022c31c8.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Alausí, Cabecera Cantonal/Casual, vía Guamote - Alausí [E-35].</td></tr><tr><td>Antecedentes:</td><td>El 01/01/2023, se produjo un hundimiento en la vía de primer orden, que al momento está cerrada por personas que procedieron a poner obstáculos.SGR informa en cumplimiento a la Resolución Nro. SGR-039-2023 del 19/02/2023, declara el estado de ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua; el mismo que comprende un área de aproximadamente 247 hectáreas.</td></tr><tr><td>Situación actual:</td><td>UPREA SGR CZ3 realizó reunión de trabajo con el equipo técnico de la UGR del GAD Municipal Alausí, para realizar hoja ruta para el asesoramiento en la elaboración del plan de Respuesta y guion para un ejercicio de simulacro.</td></tr><tr><td>Afectaciones:</td><td>- 40 metros de vía afectada.- 1 ha de cultivo destruido.- 1 familia afectada (4 personas).</td></tr><tr><td>Acciones de respuesta:</td><td>SGR mantiene reuniones de trabajo con el GAD Alausí.MTOP realizó el levantamiento de informe de acciones realizadas en el sector.Unidad de Fortalecimiento de Capacidades por parte de SGR CZ3, está dando cumplimiento a la solicitud del GAD Alausí, donde mantuvo reunión con técnicos de la UGR con el propósito de capacitar y entregar el material de difusión para que sea replicado a la ciudadanía, actividades establecidas en el cronograma de intervención.MTOP informa que levantó informe de trabajos realizados en el sector dando cumplimiento a la resolución 2 del COE Provincial.MTT4 en reunión procedió a activar albergue temporal por prevención en el convento de la Iglesia Matriz.SGR monitoreo el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MTOP Chimborazo/MAG.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 6 de 23

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/4bfc7bb5f90410f04e33ec2587b38bbc89e353b64d9f74c05453ea821f4bc367.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Portoviejo/Calderón/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2023 por lluvias suscitadas en horas de la tarde se produjo una inundación que afectó a varias viviendas-</td></tr><tr><td>Situación actual:</td><td>Cuerpo de Bomberos Portoviejo Cuartel Calderón colaboraron con la limpieza y evacuación del agua ingresada en las viviendas.</td></tr><tr><td>Afectaciones:</td><td>-16 viviendas-16 familias</td></tr><tr><td>Acciones de respuesta:</td><td>CB realizó trabajos de limpieza y evacuación de agua y lodo de las viviendas.UGR Cantonal realizará el levantamiento de información.SGR realiza el seguimiento del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Monitoreo Manabí/Cuerpo de Bomberos de Portoviejo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/23a630983da6f0b59be698b97b40046af28d4ee8753f4b47a24e1c5e21dc20c5.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/San Antonio/San Pablo, Puente Cativo. Badeal, Rancho Viejo, La Playita, Culebra, Copetón, Cativo Adentro.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo una inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/2023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Personal del Departamento Productivo del GAD Chone realizó levantamiento de información en el área agrícola y pecuaria indicando afectaciones significantes para los productores, las estadísticas pueden variar.</td></tr><tr><td>Afectaciones:</td><td>-195 viviendas afectadas (5 no habitables por el momento).-196 familias afectadas (667 personas afectadas).-5 familias damnificadas (15 personas damnificadas)-1243 ha cultivos afectados. 220 ha cultivos perdidos.-15.735 afectaciones en aves, porcinos y chame.</td></tr><tr><td>Acciones de respuesta:</td><td>Departamento de Desarrollo Social del GAD Cantonal realizó el levantamiento de información de las familias afectadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/931633f1a3df3eebda32108f488ec57bfa1542d646385070f9cf9d5242e7a8c5.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Canuto/varios sectores</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo una inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/20023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Cuerpo de Bomberos de Chone reporta mediante el primer informe afectaciones en los sectores: Narciso, Suchi, se procede a actualizar las cifras.</td></tr><tr><td>Afectaciones:</td><td>- 144 viviendas afectadas- 144 familias afectadas (461 personas afectadas)</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Chone continúan los trabajos de limpieza y evacuación de agua y lodo de las viviendas y sectores afectados.SGR realiza el seguimiento del evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/4b481425936e2b6488d4d368ad859ee08a2570cbe8a052c8d4fa26e77b357404.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Chone/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo el desbordamiento del Río Chone, provocando inundación con afectación en varias viviendas del sector.Se realizó la evacuación de los pacientes del Hospital IESS de Chone a otras casas de salud, adicional encontraron a una persona desaparecida en estado inerte.</td></tr><tr><td>Situación actual:</td><td>Cuerpo de Bomberos de Chone reporta mediante el primer informe afectaciones en los sectores: Sector Cdla. Aray, Cdla. Fátima Vera, Cdla. La Victoria, Cdla. La Gallardo, se procede a actualizar las cifras.El estado actual del río está normal</td></tr><tr><td>Afectaciones:</td><td>- 185 viviendas afectadas- 188 familias afectadas (668 personas afectadas)- 1 persona fallecida- 1 bien público afectado. (HOSPITAL IESS CHONE)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR CZ4 realiza entrega de AH.Levantamiento de información por parte del GAD Cantonal y GAD Provincial.Cuerpo de Bomberos de Chone continúan los trabajos de limpieza y evacuación de agua y lodo de las viviendas y sectores afectados.SGR realiza el seguimiento del evento.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 7 de 23

Fuentes de información: 

SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/a398be6baacb1277e4a9259bc6f7f96287d6ffbddfca4a8201f8ad802972c759.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Santa Rita/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo el desbordamiento del río Mosquito, provocando inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/2023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Personal del Departamento Productivo del GAD Chone realizó levantamiento de información en el área agrícola y pecuaria indicando afectaciones significantes para los productores, las estadísticas pueden variar.</td></tr><tr><td>Afectaciones:</td><td>-472 viviendas afectadas.-477 familias afectadas (1774 personas afectadas).-1878 ha cultivos afectados.-540 ha cultivos perdidos.-3065 afectaciones en aves, porcinas y bovinas.</td></tr><tr><td>Acciones de respuesta:</td><td>Levantamiento de información por parte del Departamento de Desarrollo Productivo del GAD Chone.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/ae8b5603e49d9202f625105fb67eebe2ca0ba46e85a517c45f11f77ea57e1b06.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Ricaurte/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo el desbordamiento del río Garrapata, provocando inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/2023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Personal del Departamento Productivo del GAD Chone realizó levantamiento de información en el área agrícola y pecuaria indicando afectaciones significantes para los productores, las estadísticas pueden variar.</td></tr><tr><td>Afectaciones:</td><td>-134 Familias Afectadas (495 Personas Afectadas)-134 Viviendas Afectadas.-1879 ha Cultivos Afectados.-220 ha Cultivos Perdidos.-7.000 afectaciones en aves y chame.</td></tr><tr><td>Acciones de respuesta:</td><td>Levantamiento de información por parte del Departamento de Desarrollo Productivo del GAD Chone.SGR realiza el seguimiento del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/7d1fe7b64db6d23fef103481acdac433c7696de138e0a3f5942e64be9bf4a3bd.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Bolívar/San Miguel/San Pablo /Logmapamba, vía San Pablo - Chillanes [E495],</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en la noche del 10/03/2023, se produjo un deslizamiento de tierra en la vía de primer orden, que obstaculizó totalmente al tránsito vehicular.En horas de la tarde del 11/03/2023, se originó un aluvión obstaculizando en su totalidad a la vía de primer orden.</td></tr><tr><td>Situación actual:</td><td>UGR del GAD San Miguel, informa que el aluvión de la tarde del 11/03/2023 arrasó una vivienda, un molino de granos y pérdida de animales de granja, la cual estaba construida en la parte baja del sector de Logmapamba.La familia se encuentra en hogar acogiente donde un familiar por el mismo sector.Al momento la vía se encuentra parcialmente habilitada al tránsito vehicular; sin embargo, se recomienda transitar con precaución durante el día y en la noche no transitar por cuanto está muy inestable la quebrada y en cualquier momento desciende flujos de lodo.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda destruida- 1 familia, 3 personas damnificadas- 1 bien privado destruido- 20 animales de granja muertos (cerdos, gallinas, bovinos)- 130 metros lineales</td></tr><tr><td>Acciones de respuesta:</td><td>- UGR del GAD Cantonal San Miguel realizó el levantamiento de información (EVIN).- Maquinaria del MTOP-Bolívar continúa realizando trabajos de limpieza de la vía.</td></tr><tr><td>Fuentes de información:</td><td>AD San Miguel, MTOP, SGR Unidad de Monitoreo Bolívar</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 8 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/524e0f931866b67a3dbe3f38a26038e1cad08a1a4d17b1880529fcb921dd3d1c.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Bolívar/Guaranda/San Lorenzo/Huapungoto, Planta de Tratamiento de Agua del cantón Chimbo</td></tr><tr><td>Antecedentes:</td><td>UGR del GAD Chimbo menciona que a causa de las lluvias registradas en la madrugada del 10/03/2023, se produjo un aluvión y el ingreso de lodo espeso que va desde el río a la Planta de Tratamiento de Agua, el cual causa el desabastecimiento del líquido vital en la toda la parroquia urbana del cantón Chimbo y la parroquia rural San Sebastián.</td></tr><tr><td>Situación actual:</td><td>El evento se encuentra bajo evaluación.</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público afectado (Planta de Tratamiento de Agua)- 100% de servicio de Agua Potable afectado- 1233 familias, 4932 personas afectadas indirectamente</td></tr><tr><td>Acciones de respuesta:</td><td>Desde el 10/03/2023 personal de la EMAPA Chimbo, realiza trabajos de limpieza para restablecer el líquido vital en el cantón.El 11/03/2023 C.B. Chimbo en conjunto con C.B Guaranda y San Miguel realizaron abastecimiento de agua a la población de la parroquia urbana del cantón Chimbo y la parroquia rural San Sebastián.UGR del GAD Cantonal realiza seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>GAD Chimbo, EMAPA Chimbo, C.B, SGR Unidad de Monitoreo Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/7fbd0b73929ac9634560a05cf2af281a5d878df7b444902b634ad432a1d0e6b1.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Los Ríos/Montalvo/Montalvo/Vía a La Vitalia - 1er orden</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2023 debido a las lluvias suscitadas y al crecimiento del río Cristal, se reportó el socavamiento de 1 Puente en una vía de 1er orden a las orillas del caudal, dejándolo destruido con el paso cerrado</td></tr><tr><td>Situación actual:</td><td>Personal técnico en el sitio reportó la desconexión de luminarias en el sitio, colocación de cintas para recalcar el cierre del puente y personal de tránsito colaborando con la novedad del evento.</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público destruido (puente)</td></tr><tr><td>Acciones de respuesta:</td><td>- CNEL realizó la desconexión de luminarias en el puente.- CTE se mantiene en el sitio colaborando con el paso vehicular.</td></tr><tr><td>Fuentes de información:</td><td>CTE/CNEL/SGR Unidad de Monitoreo Los Ríos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/748f6399487d141c3262a6dbce5e5dd5c36565d559f59af31858c5fbd1136dd2.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas / Naranjito / Naranjito, Cabecera Cantonal / Recinto La Primavera</td></tr><tr><td>Antecedentes:</td><td>El 10/03/2023, a causa de las lluvias de la madrugada se produjo el desborde del estero El hediondo, provocando el socavamiento de las bases de un puente que es la única vía de acceso del recinto La Primavera - al recinto San Francisco</td></tr><tr><td>Situación actual:</td><td>Se reporta afectaciones en cultivos y viviendas que se encuentran al borde del estero.</td></tr><tr><td>Afectaciones:</td><td>-1 puente afectado-cultivos afectados (se encuentra bajo evaluación)-Viviendas afectadas (se encuentra bajo evaluación.)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal se moviliza al lugar a realizar levantamiento de información</td></tr><tr><td>Fuentes de información:</td><td>UGR GAD Naranjito/ SGR Unidad de Monitoreo Guayas</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/2b731d2b1914a6d778bd9fcc3403e8c75efc7af2d721cc356c21208231e9bc32.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Simón Bolívar/Simón Bolívar, cabecera cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023, por lluvias registradas la noche de ayer y madrugada de hoy, se desbordó el río Los Amarillos ocasionando inundación en el sector.</td></tr><tr><td>Situación actual:</td><td>UGR informa que se está realizando recorridos con CB, Cruz Roja en las zonas afectadas, adicional menciona que al momento solo se puede transitar por la vía Mariscal Sucre-Lorenzo Garaicoa - Simón Bolívar, para llegar a la cabecera cantonalEl río Los Amarillos se mantiene con tendencia a disminuir de nivel.</td></tr><tr><td>Afectaciones:</td><td>- 20 viviendas afectadas- 23 familias, 84 personas afectadas (las familias se mantienen en sus inmuebles- 1 vía con acumulación de agua</td></tr><tr><td>Acciones de respuesta:</td><td>Presidente Parroquial del GAD Posorja se encuentra realizando recorrido.GAD Cantonal Cruz Roja y CB Simón Bolívar se encuentran realizando recorridos por los sectores afectados y haciendo levantamiento de información.MSP se encuentra con una brigada médica en la Cdla. Santa Martha Maquinarias de Obras Públicas realizando trabajos de limpiezas en las riberas del río COE Cantonal se mantiene activo</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Simón Bolívar.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 9 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/fc0c1b5dc6f383359d3a2928238fdd9db6e62514fe55906db58f52bfa26f2cde.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas / Milagro /Cabecera Cantonal, Milagro /calle Guayaquil y Pedro Carbo, la Cda. Acuarela de Rio, las margaritas, Av. Paquisha, El Chobo</td></tr><tr><td>Antecedentes:</td><td>Por las fuertes precipitaciones suscitadas en la tarde del 08/03/2023 al momento se reportan calles afectadas con acumulación de agua. CB informa que por producto de las lluvias constante que se están generando se han visto afectados nuevos sectores por inundaciones.</td></tr><tr><td>Situación actual:</td><td>GAD Cantonal informa que Personal de SGR en coordinación con Cruz Roja y entidades locales realizan levantamientos de información EVIN, en los sectores afectados por época lluviosa, así mismo se realiza la apertura de un albergue en un establecimiento Educativo el Colegio 17 de septiembre.</td></tr><tr><td>Afectaciones:</td><td>-1 vivienda afectada (datos se encuentra en levantamiento de EVIN, para clasificar afectados y damnificados-1 familias afectadas (datos en proceso de levantamiento de Información)-60% servicio de alcantarillado afectado</td></tr><tr><td>Acciones de respuesta:</td><td>GAD cantonal realiza levantamiento de información EVINCruz roja realizan levantamiento de informaciónSGR realizan levantamiento de información y adecuación del albergueEII0/03/2023 a las 10:30, se llevó acabo la sesión de COE Cantonal en la que estuvieron las siguientes s instituciones PPNN, EPAMEL EP, Jefatura Política, Bomberos, CTE, MINEDUC, Cruz Roja, MIES, Centro Agrícola, GAD Cantonal y de evaluador SGR, donde se resolvió:-Declarar en emergencia al cantón-Solicitar maquinarias al GAD Municipal para trabajos de taponamientos de la red de alcantarillado-Habilitar un albergue provisional para las personas que no dispongan familias acogientes-Solicitar a las instituciones de gobiernos recursos para atender la emergencia y mantener la sesión permanente mientras dure la emergencia.</td></tr><tr><td>Fuentes de información:</td><td>GAD Cantonal Milagro / SGR Unidad de Monitoreo Guayas</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/7d563171c4da56ae150a0fb1403d97dd4e5bcef71f3099fbd4daa0c4dac539a7.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/El Triunfo/El Triunfo/Calle Juan Montalvo y Av. 9 de Octubre.</td></tr><tr><td>Antecedentes:</td><td>por lluvias registradas la noche y madrugada del 09/03/2023, se desbordó el Estero Galápagos ocasionando inundación en el sector.</td></tr><tr><td>Situación actual:</td><td>SGR en conjunto con GAD Cantonal realizaron recorridos para el levantamiento de información (EVIN) en varias zonas afectadas por el desbordamiento del Estero Galápagos</td></tr><tr><td>Afectaciones:</td><td>--</td></tr><tr><td>Acciones de respuesta:</td><td>CTE confirma la novedadGAD Cantonal acudió al sitio para el levantamiento de información.SGR acudió al sitio para el levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/CTE.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/6542394f5051f847ba5ca5387ffa550300f818f4de54887535454403d4b499fa.jpg)



Inundación


<table><tr><td>Localización:</td><td>Guayas/Guayaquil/Tarqui/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2023, por lluvias suscitadas en la tarde, se reportan varios sectores con calles anegadas, con mayor impacto, Samanes, Sergio Toral, La entrada de la 8, Bastión Popular, vía Daule.</td></tr><tr><td>Situación actual:</td><td>GAD Cantonal coordina acciones con INTERAGUA para el drenaje de aguas lluvias en varios sectores, ATM se encuentra en puntos estratégicos dirigiendo el tránsito, para evitar el congestionamiento vehicular.</td></tr><tr><td>Afectaciones:</td><td>- 5 Viviendas afectadas- 5 familias, 15 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>INTERAGUA realizó limpieza de alcantarillas.GAD Cantonal realiza el levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/GAD Cantonal.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/27ae40188e4b75e9260df62932ca69eee385a01d81c4dafe2b93b73d279d7871.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>Los Ríos/Montalvo/Montalvo, Cabecera Cantonal/ Santa Marianita - vía a Balsapamba.</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2023 debido a las fuertes lluvias suscitadas en el sitio, se reportó un deslizamiento de tierra, provocando la caída de un poste de luz con un árbol en la vía de 1er orden, dejando sin energía a gran parte del sector</td></tr><tr><td>Situación actual:</td><td>Un carril se encuentra parcialmente habilitado para el paso vehicular.</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público afectado (poste de luz)- 45 metros lineales afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP, CTE, CNEL se encuentran en el sitio colaborando con el evento.</td></tr><tr><td>Fuentes de información:</td><td>SNGRE CZ5 Unidad de Monitoreo Los Ríos/SGR-UPREA/Cuerpo de Bomberos de Montalvo/GAD Montalvo.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 10 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/8a097f886b788525672bd1bbbe589ea436c8d6a5f83d1ac4b1917ba9b2dbe4d0.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Isidro Ayora/Cabecera Cantonal/San Agustín.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias registradas el día 07/03/2023, se produjo el desbordamiento del río Bachillero, mismo que afecta a varias viviendas y a cultivos de ciclo corto, (maíz, Sandía, Melón, etc.).</td></tr><tr><td>Situación actual:</td><td>Directora zonal realizó entrega de asistencia humanitaria a las familias afectadas, UGR Cantonal indica que el río Bachillero al momento se encuentra con tendencia a disminuir su nivel y el agua ha drenado de las viviendas, por lo que las familias se mantienen en sus inmuebles.Adicional indicó que aún existen sectores con acumulación de agua, la cual se espera que con el transcurso de las horas siga drenando.</td></tr><tr><td>Afectaciones:</td><td>- 116 Viviendas afectadas-116 familias, 464 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>10/03/2023SGR realizó entrega de asistencia humanitaria a 45 familias que resultaron más afectadas.GAD Cantonal, CB Cantonal realizaron apoyo en la entrega de asistencia humanitaria.MSP acudió con una brigada médica para realizar atención a las familias afectadas 09/03/2023GAD Cantonal realizó levantamiento de información en los sectores afectadosOOPP Municipal realizó trabajos de limpieza de caminos y riberas del río 08/03/2023GAD Cantonal realizó levantamiento de información en los sectores afectadosOOPP Municipal realizó trabajos de limpieza de caminos y riberas del ríoGAD Provincial realizó inspección</td></tr><tr><td>Fuentes de información:</td><td>Directora zonal 5 SGR /GAD Cantonal Isidro Ayora / SGR Unidad de Monitoreo Guayas.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/5eb976848f92593b68dbdaf6ce819c7cff04cc6ec36af74e842b81dab1dbb55e.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Balzar/Cabecera Cantonal/varios sectores, Quiebradroga, Chimborazo, Santa Genara, El Modelo.</td></tr><tr><td>Antecedentes:</td><td>El 05/03/2023, técnico de la UGR del GAD Cantonal de Balzar informa que a causa de las lluvias registradas en la madrugada, se produjo el desbordamiento del río Puca, mismo que afectó parcialmente a un puente peatonal que une el camino principal Balzar, Las Trampas y Santa Genara. Además menciona que existen afectaciones a las plantaciones de arroz, maíz, cacao, verde y naranja. El río se encuentra desbordado en el sector El Modelo.</td></tr><tr><td>Situación actual:</td><td>Mediante informe EVIN técnico de la UGR indica que realizó levantamiento de información e indica que las familias afectadas siguen pernoctando en sus mismas viviendas.El río Puca se encuentra con tendencia a disminuir de nivel</td></tr><tr><td>Afectaciones:</td><td>- Cultivos afectados (Se encuentra en la fase de levantamiento en hectáreas)- 1 puente peatonal afectado.- 111 viviendas afectadas- 111 familias, 444 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>UGR del GAD Cantonal de Balzar realizó el respectivo levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Balzar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/bdce5250fdff66b1baf34b601464a01d1126cefc6ea312919d1e82007d9d8554.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Guayaquil/Juan Gómez Rendón Progreso/Cerecita - varios sectores.</td></tr><tr><td>Antecedentes:</td><td>EL 07/03/20233, a causa de las lluvias registradas en el lugar, se produjo el desbordamiento del río La Camarona, mismo que afectó a la vía de primer orden, la cual al momento se encuentra habilitada.</td></tr><tr><td>Situación actual:</td><td>Mediante informe EDAN técnico de la UGR indica que realizó levantamiento de información y entrega de asistencia humanitaria a las familias afectadas, las mismas que realizaron las debidas limpiezas de sus inmuebles para seguir pernoctando.El río La Camarona se encuentra con tendencia a disminuir su caudal</td></tr><tr><td>Afectaciones:</td><td>- 10 Viviendas afectadas- 10 familias, 43 personas afectadas- 100 metros de vía, se encuentra habilitada</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial se encuentra en el punto realizando trabajos.Técnicos de GAD Cantonal realizaron el respectivo levantamiento de información y entrega de asistencia humanitaria a las familias afectadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/UGR - GAD Cantonal Guayaquil/Ministerio de Salud Pública.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 11 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/040a99e18b67e9d37a7757ce7e7b5dd9d26c4a3d53f483385386eb05b50898dc.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Santa Elena / Santa Elena / Chanduy / Bajada de Chanduy.</td></tr><tr><td>Antecedentes:</td><td>El 06/03/2023, a causa del desborde del río La Camarona, se vió afectado el recinto Bajada de Chanduy, varias viviendas resultaron inundadas y familias damnificadas.</td></tr><tr><td>Situación actual:</td><td>Mediante EVIN, UGR identificó 9 recintos que se encuentran aislados por la creciente de río, estas son: Las Cruces, San Jerónimo, San Francisco, Santa Isabel, Primero de Mayo, La Camarona, El Mamey, Vía a la Ciénega y Caimito, a las mismas que se les entregoraciones de alimentos.El caudal del río se mantiene alto</td></tr><tr><td>Afectaciones:</td><td>- 300 familias afectadas (1200 personas)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR coordinó con Fuerzas Armadas movilización para traslado de raciones hasta la comunidad San Jerónimo.FFAA colaboró con camión 6x6 para trasladado de racionesGAD Sata Elena entrego 300 raciones de alimentos para las familias afectadasMSP atendió a 50 personas de los grupos prioritarios y vulnerables de los sectores afectadosUMEVA se mantiene en monitoreo constante.</td></tr><tr><td>Fuentes de información:</td><td>SGR Unidad de Monitoreo Santa Elena / UGR Cantonal / MSP Distrito 24D01.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/524bc3ba0f3516ad01d9fda6f904a29e3c77a5141b83855e80b8a7ddd43eb3ec.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Alfredo Baquerizo Moreno (Jujan)/Alfredo Baquerizo Moreno (Jujan), Cabecera Cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en la madrugada del 21/02/2023 se desbordó el Río Chilintomo; la madrugada del 22/02/2023, se desbordó el río Los Amarillos. Jefe Político realizó recorridos en el sector e informó que debido al desbordamiento se produjo el colapso del muro de contención afectando cultivos de arroz y cacao; también se produjo el ingreso de agua a varias viviendas y a la Escuela Fiscal Eduardo Alarcón Soto, por lo que se suspendieron las clases en la jornada matutina.</td></tr><tr><td>Situación actual:</td><td>UGR - GAD Cantonal informa que en el sector San Antonio se realizó la colocación de sacos con material pétreo en la ribera del río.</td></tr><tr><td>Afectaciones:</td><td>- 1 establecimiento educativo afectado (Ingreso de agua al predio)- Cultivos afectados (la cantidad de cultivos está bajo verificación)- Calles inundadas- 283 viviendas afectadas- 283 familias, 889 personas afectadas (se mantienen en los mismos inmuebles)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal coordinó la colocación de sacos de arena en las riberas del río en el sector El Tránsito.Prefectura se encarga de los trabajos de Mitigación y limpieza del caudal.SGR - Umeva Guayas dará seguimiento al evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas UGR - GAD Cantonal Alfredo Baquerizo Moreno (Jujan)</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/01795f35a2eab64148ad6f3bd6f12cdd097cc62d2c40a8ec1a6fafd7cab94b5d.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Febres Cordero/ Rcto. Plaza De Chilintomo - Rcto. La Lidia - Rcto. Las Tolas - Rcto. La Alambra - Rcto. Las Cañitas - Rcto. Las Jaguas - Sector La Avelina - Río Chilintomo.</td></tr><tr><td>Antecedentes:</td><td>Debido a las lluvias suscitadas en la noche del 25/02/2023, se reportó ingreso de agua en las viviendas a causa del desbordamiento del río Chilintomo, actualmente el río continúa desbordado con presencia de agua en las viviendas y las familias se mantienen en sus hogares.</td></tr><tr><td>Situación actual:</td><td>Luego de culminar el respectivo levantamiento de información en la zona afectada, se realizó la dotación de ayuda humanitaria a las familias del lugar, actualmente el río descendió en el sitio, pero existe agua estancada en los alrededores, las familias afectadas se mantienen en sus hogares y la familia damnificada se encuentra en casa acogiente.</td></tr><tr><td>Afectaciones:</td><td>- 86 viviendas afectadas (caña y madera)- 86 familias afectadas.- 240 personas afectadas.- 1 vivienda destruida (caña-madera)- 1 familia damnificada- 5 personas damnificadas (casa acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>- UGR Babahoyo realizó entrega de ayuda humanitaria el 01/03/2023.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Babahoyo.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 12 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/60de5ded14b0bd1fdac70f62bcb2e0990ca5cb6df9700279f36ade1b40574a57.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Santa Elena/Santa Elena/Cabecera cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023, debido a las lluvias suscitadas en el cantón, se reportó varias viviendas afectadas, calles anegadas y comunidad aislada.Por reporte de la UGR cantonal, el recinto La Frutilla de la parroquia Simón Bolívar se encuentra aislada, la única vía de acceso se vio interrumpida por un corte en un pase de río de la zona que por la fuerte lluvia del 25/02/2023 aumento su caudal.</td></tr><tr><td>Situación actual:</td><td>Por solicitud de la UGR cantonal, SGR entregó asistencia humanitaria a 3 familias afectadas por inundaciones en la cabecera cantonal.Mediante articulación entre el Ministerio de Defensa y la SGR se contó con un helicóptero para movilizar 120 raciones alimenticias para las 120 familias del recinto La Frutilla de la parroquia Simón Bolívar que se encuentran aisladas por corte de vía.</td></tr><tr><td>Afectaciones:</td><td>- 123 Familias afectadas (315 personas).- 3 Viviendas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>COE cantonal se mantiene activo.SGR entregó asistencia humanitaria (kits de dormir, aseo y KPRH)UGR cantonal realizó la entrega de raciones de alimentos a las familias afectadas por Aislamiento.FFAA colaboró con helicóptero para movilidad humana y logística.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Santa Elena/UGR Cantonal/Gobernación de Santa Elena.</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/e1b960358b9aeb5c36054fed501725a537bda7383784a2b9816fa4cc332c754e.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Cañar/Biblián/Biblián/Cuitun</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 a causa de las lluvias se suscitó un deslizamiento que afecta 1 vivienda de un piso construcción mixta (bloque y teja), en la misma habitaban 2 familias que fueron evacuadas a la Casa Comunal de Cuitun por precaución.</td></tr><tr><td>Situación actual:</td><td>Al momento las familias pernoctan en la casa comunal por precaución.</td></tr><tr><td>Afectaciones:</td><td>-1 vivienda afectada-2 familias afectadas-6 personas afectadas (evacuadas a la casa comunal)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Biblián de forma conjunta con técnicos de la SGR CZ6 realizaron levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>UGR Biblián/SGR Unidad de Monitoreo Azuay-Cañar</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/bb67190a8747f1e1759421031b526d970db45dd25eb3355405e3d6283bf23f4a.jpg)


## Colapso estructural

<table><tr><td>Localización:</td><td>Cañar/La Troncal/Pancho Negro/Entrada a La Colonia 10 de agosto</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 a causa de las lluvias se suscitó la creciente del río Ruidoso mismo que ocasionó el colapso del puente (s/n). Vía alterna La Puntilla-Colonia 10 de Agosto</td></tr><tr><td>Situación actual:</td><td>Con fecha 10/03/2023 se realizó la reunión del COE Cantonal para realizar un análisis de la situación actual del cantón por las lluvias suscitadas. Adicional el caudal del río ruidoso ha retornado a su cauce normal.</td></tr><tr><td>Afectaciones:</td><td>-1 Puente destruido</td></tr><tr><td>Acciones de respuesta:</td><td>Personal de la Unidad de Gestión de Riesgos La Troncal realizaron inspección en el lugar del evento</td></tr><tr><td>Fuentes de información:</td><td>UGR La Troncal/ SGE Unidad de Monitoreo Azuay-Cañar</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/2e9c54badfd7be2c1f3308350249274351fb23a803450d66e1446131ba6f4159.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Morona Santiago/Morona/Macas/Puente sobre el río Upano-Puente sobre el río Copueno, vía Macas-Puyo [E45].</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas durante la madrugada del 04/03/2023, se produjo el descenso de lahares y la posterior acumulación en la confluencia del río Volcán y río Upano generando el represamiento del mismo, el cual se liberó de manera natural, sin embargo, durante las horas de la noche se presentó el incremento de caudal que provocó el desbordamiento y la posterior inundación de la variante que se encuentra establecida en el lecho del río.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se encuentra parcialmente habilitada al tránsito vehicular y peatonal., la vía alterna es Puyo-Y de Santa Ana-Sevilla Don Bosco-Seipa-Sucua-Macas.</td></tr><tr><td>Afectaciones:</td><td>- 240 Metros lineales.</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP en coordinación con el Cuerpo de Ingenieros del Ejército, Gobierno Provincial de Morona Santiago y Empresa Privada se mantienen realizando actividades de reconstrucción de la variante sobre el lecho del río Upano, recomiendan conducir con precaución debido a la presencia de maquinaria en el lugar.</td></tr><tr><td>Fuentes de información:</td><td>SGR-CZ6 Unidad de Monitoreo Morona Santiago/SIS-ECU911-Macas/MTOP/PPNN.</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 13 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/51bbe1a21856fa0a7a74a9bd99e95699c96e3b390be23b4c769a31c8e4be9063.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Morona Santiago/Limón Indanza/San Antonio /Puente sobre el río Namangoza.</td></tr><tr><td>Antecedentes:</td><td>Producto de las lluvias del 28/02/2023 se produjo un deslizamiento que generó el colapso estructural de un puente colgante tipo peatonal sobre el río Namangoza,</td></tr><tr><td>Situación actual:</td><td>Al momento el paso peatonal se encuentra interrumpido por lo cual no hay paso para las personas pertenecientes a varias comunidades del sector.</td></tr><tr><td>Afectaciones:</td><td>- 15 metros lineales- 1 Puente destruido</td></tr><tr><td>Acciones de respuesta:</td><td>Tenencia Política de la Parroquia Santa Susana de Chiviaza confirmó el evento.SGR coordina con el GAD-Cantonal el levantamiento de información y se mantiene en constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR-CZ6 Umeva-Morona Santiago/ Tenencia Política/ UGR-GAD-Cantonal Limón Indanza.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/6ac8a51c5ed28ea53518b72e561a8be4bd5655e16a4f9c10d84fb4ce71d38dbc.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/Rosas, Bellavista, Tamboloma, Chunazana.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Secretaría de Gestión de Riesgos declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 06/03/2023 técnico de la UGR Nabón informa que la segunda etapa de las obras de mitigación iniciaron con la construcción del primero de cinco muros de contención hasta el momento con un avance del 3%, los trabajos ocasionan el cierre temporal de la vía Ramada-Nabón sector trancapata, vía alterna La Ramada-Chunazana-El Salado-Nabón</td></tr><tr><td>Afectaciones:</td><td>- 50 metros de vía afectada (vía habilitada, sector El Progreso)- 84 familias afectadas (238 personas afectadas)- 60 familias damnificadas (162 personas damnificadas)- 40 metros de vía afectados (vía Cerrada, sector Trancapata)- 60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)- 1 Casa comunal afectada con cuarteaduras- 84 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 59 viviendas destruidas.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)- Iglesia demolida por los daños estructurales presentados- Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>El 25/11/2022, UGR Nabón realizó un nuevo levantamiento de información y se mantiene en monitoreo constante.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/a91673a0616fd09dbccea6b73a42930b11910eb636ca2dc641d645f3347a8a55.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Cañar/Cañar/Cañar/Cuchucun-Cruz Loma.</td></tr><tr><td>Antecedentes:</td><td>GAD Cantonal de Cañar informó que a partir del 13 de Octubre de 2022 por la época lluviosa y mal manejo del agua de riego se reportó un deslizamiento que afecta viviendas del sector. Con fecha 14 de Febrero del 2023 se activó el COE Cantonal donde la máxima autoridad del cantón solicita la activación de las mesas técnicas y grupos de trabajo para la atención de la emergencia. Intervención del MIDUVI y GAD PROVINCIAL.</td></tr><tr><td>Situación actual:</td><td>Con fecha 03/03/2023 se reunió el COE Cantonal para realizar un análisis de las acciones que se van a realizar por el evento.</td></tr><tr><td>Afectaciones:</td><td>-22 viviendas afectadas-4 viviendas destruidas-6 familias damnificadas-16 personas damnificadas (permanecen en casa de familia acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR mantiene un monitoreo constante del evento y levantamiento de información. SGR realizó inspección técnica para levantamiento de información, Director y Técnico asisten a la reunión del COE.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Cañar.</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/f10eb83ded75850f7d3fdbe0abff8b19bd3485602e48ec970119e74921e2a91e.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Arenillas/Chacras/Sector La Isla.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias intensas regiastradas en la madrugada del 09/03/2023, provocó el desbordamiento de río Zarumilla perteneciente a Perú, ha afectado cultivos en la zona agrícola de la provincia de El Oro.</td></tr><tr><td>Situación actual:</td><td>Mediante reporte remitido por parte del MAG, se rectifica afectaciones de destruidos a afectados parcialmente. Además, al momento el río Zarumilla se encuentra con tendencia a disminuir.</td></tr><tr><td>Afectaciones:</td><td>- 20 hectáreas de cultivo afectados parcialmente (8 ha. de plátano, 8 ha. de cacao y 4 ha. de limón). - 30 productores afectados.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 

Código postal: 092302 / Samborondón-Ecuador 

Teléfono: +593-4-259 3500 

www.gestionderiesgos.gob.ec 

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo. 12 de marzo de 2023 - 21:05:15 / Página 14 de 23

Acciones de respuesta: 

SGR mantiene monitoreo con MAG para gestionar acciones a los productores afectados. 

Fuentes de información: 

SGR Unidad de Monitoreo El Oro / MAG 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/d9a9840897a0a03c9d411c8b90320de877120f62609258228ab67f9adfae7ecb.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>El Oro/Pasaje/Uzhcurrumi/Cune, Vía Pasaje - Uzhcurrumi.</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2023 por lluvias, se suscitó el colapso de una alcantarilla y la pérdida de la mesa vial de tercer orden; además se registra la caída de un vehículo hacia la quebrada (NN), su ocupante se encuentra en buen estado de salud.Cabe mencionar que esta vía estaba siendo utilizada como alterna por el cierre de la Vía Cuenca - Girón - Pasaje - Gramalote.</td></tr><tr><td>Situación actual:</td><td>SGE realizó inspección y conjuntamente con autoridades cantonales y parroquiales presenció reunión convocada por GAD parroquial de Uzhcurrumi, para coordinar acciones de respuesta al evento.La vía se mantiene cerrada al tránsito vehicular</td></tr><tr><td>Afectaciones:</td><td>- 10 de vía afectada (Cerrada al tránsito vehicular)- 1 bien privado afectado</td></tr><tr><td>Acciones de respuesta:</td><td>SGR realizó inspección técnica en el sitio del evento.MDG, SGR, GAD Cantonal, PPNN, ANT GAD Parroquial de Guanazán, Uzhcurrumi asistieron a reunión para coordinar acciones de respuesta al evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/GAD Parroquial/Cuerpo de Bomberos de Pasaje.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/01edcfa0a764fa663f19063a8a83481bddec7e5904f86577bb1df3a94ca73e81.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Loja/Saraguro/Manu/Manú, vía Manú-Udushi.</td></tr><tr><td>Antecedentes:</td><td>El 19/02/2023, por lluvias presentadas durante la madrugada, se produjo el colapso del puente en la vía de tercer orden (Vía Manú-Udushi).</td></tr><tr><td>Situación actual:</td><td>Técnicos del GAD-P Loja - VIALSUR, realizaron inspección técnica a la vía Manú - Udushi con el objeto de realizar estudios para construcción de vía alterna.La vía de tercer orden se encuentra cerrada.</td></tr><tr><td>Afectaciones:</td><td>- 01 puente colapsado. (Río Panasco).- 01 puente afectado. (Quebrada Sigsipamba).</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial - VIALSUR, se encuentra realizando los trabajos de construcción de una plataforma metálica ya que una de las pantallas de la alcantarilla de cajón se ha deslizado de su posición y la calzada está en peligro de hundirse, dicha plataforma será colocada en los próximos días en el puente sobre la quebrada Sigsipamba, en la vía Manú - Udushi, con la finalidad de poder trasladar la maquinaria y material para la reconstrucción del puente sobre el río Panasco</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/Consola de Servicios Municipales.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/8f9fb741ce697629f9ade2118f47496403aa3a7f5dd43634e0180ecaa2a68480.jpg)



Inundación


<table><tr><td>Localización:</td><td>El Oro/Portovelo/Salatí/Sitio Los Amarillos.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias registradas en la noche del 18/02/2023, se registró el aumento y desbordamiento del río Pindo, provocando afectación en varias viviendas y el colapso de 6 puentes peatonales, los cuales eran acceso y salida de los habitantes del sector hacia los sitios aledaños.</td></tr><tr><td>Situación actual:</td><td>Mediante reporte remitido por MAG, reportan afectaciones causadas por presente evento peligroso en el sitio Los Amarillos.</td></tr><tr><td>Afectaciones:</td><td>- 6 puentes destruidos (3 puentes peatonales de hormigón y 3 puentes colgantes de madera)- 11 familias de 26 personas afectadas indirectamente (aisladas).- 3 viviendas afectadas (en sus estructuras).- 3 familias de 5 personas damnificadas (continúan en casa de familia acogiente).- 3 hectáreas de cultivo de limones afectados.- 2 hectáreas de cultivo de limón con pérdida total (destruidos).- 5 productores afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>SGR mantiene monitoreo con puntos focales, para verificar los avances en los trabajos de remediación en los distintos sitios afectados.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/MAG.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/ded79050cfb3dac2120576775fe5f1d3dc8a1f2b268895b82cd56e743f40673c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Portovelo/Salatí/Varios Sectores (Ambocas, El Chunchi, El Vado Ancho).</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias registradas durante la noche, se registró el desbordamiento de los ríos Ambocas y Granadillo causando afectaciones en puentes, casas y calles de distintos sectores.</td></tr><tr><td>Situación actual:</td><td>Mediante reporte remitido por MAG, reportan afectaciones causadas por presente evento peligroso en el Sitio Chunchi.</td></tr><tr><td>Afectaciones:</td><td>- 2 puentes destruidos (1 puente vehicular en el sitio Chunchi y 1 puente peatonal en el sitio Vado Ancho).- 24 familias de 96 personas afectadas indirectamente (13 familias de 52 personas en Chunchi y 11 familias de 44 personas en Vado Ancho).</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 15 de 23

<table><tr><td></td><td>- 2 puentes afectados (Puente vehicular de Ambocas está habilitado y puente de Lourdes habilitado).- 4 viviendas afectadas (por ingreso de agua, lodo y presentan en la parte posterior socavamiento, sector Ambocas).- 4 familias de 17 personas afectadas directamente (3 familias de 14 que fueron evacuadas a refugio temporal retornaron a sus viviendas).- 2 bienes privados destruidos (1 chanchera y 1 moto en Chunchi).- 1 bien público afectado (sistema de captación de agua en el sitio Lourdes).- 7 hectáreas de cultivo de yucas afectadas.- 32 productores afectados (21 productores de los cultivos y 11 propietarios de animales).- 52 animales muertos (12 bovinos, 5 caballos, 5 cerdos, 30 gallinas).</td></tr><tr><td>Acciones de respuesta:</td><td>SGR mantiene monitoreo con puntos focales, para verificar los avances en los trabajos de remediación en los distintos sitios afectados.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/Uprea El Oro.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/dd9220131a03b85a0427a4255f386653bfbf5f8d79f0c3e9a5eb106c12bba60a.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Loja/Chaguarpamba/El Rosario/Trapiche, vía a la costa [E50].</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias presentadas en la tarde, se produjo el desbordamiento del río Pindo provocando la inundación de una vivienda y la afectación a la vía principal.</td></tr><tr><td>Situación actual:</td><td>Una vez revisada el Acta de Sesión del COE Cantonal, se descartó la Declaratoria de Emergencia en el cantón y resolvió: ACTIVAR El COE cantonal de Chaguarpamba por época lluviosa con la finalidad de poner en funcionamiento todos los componentes del mismo para dar la atención y respuesta efectiva a la emergencia.02 familias conformadas por 07 personas se encuentran albergadas por seguridad en las instalaciones de la Escuela Olimpia Mendieta.</td></tr><tr><td>Afectaciones:</td><td>- 3 familias damnificadas conformadas por 06 personas.- 24 familias afectadas conformadas por 70 personas.- 6 puentes peatonales colapsados (puentes de conexión entre comunidades del sector).- 3 viviendas destruidas.- 24 viviendas afectadas.- 01 puente vehicular afectado (vía de segundo orden).- 20 metros de longitud aproximadamente de vía- 01 bien privado destruido (vehículo arrastrado por la corriente).</td></tr><tr><td>Acciones de respuesta:</td><td>El COE Cantonal se encuentra activadoCuerpo de Bomberos de Chaguarpamba realiza labores de limpieza de las viviendas afectadasGAD Chaguarpamba realiza labores de limpieza en los sectores afectados por la inundación.Autoridades y personal técnico de SGR coordinó reunión de mesa intersectorial con las diferentes carteras de estadoMTOP realizó trabajos de limpieza en la vía principal Chaguarpamba - Río Pindo (Vía habilitada)GAD Provincial Loja (VIALSUR) realizó trabajos de limpieza y habilitación vial</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/Cuerpo de Bomberos de Chaguarpamba/VIALSUR.</td></tr></table>

## ZONA 8

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/f5aad04c34b758463f3ee739ea6f5746a092cae68a7333927318652476628d59.jpg)


<table><tr><td>Localización:</td><td>Guayas / Guayaquil /Posorja / Varios Sectores (Barrios Quito, Paquito Lotización San Francisco, Nueva Posorja, Nuevo Amanecer, 8 de Julio)</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023, a causa de las lluvias que se registran al momento, se produjo el desbordamiento de tres canales de aguas lluvias, al momento se reporta calles y viviendas inundadas.</td></tr><tr><td>Situación actual:</td><td>Presidente Parroquial del GAD Posorja informa que los canales de aguas lluvias han disminuido su nivel y al momento no se visualiza agua estancadas por los sectores que resultaron afectados, adicional informa que en la reunión del COPAE que se llevó ayer quedaron con los siguientes acuerdos: Interagua realizará limpieza de los canales y GAD Parroquial y VPC realizaran levantamiento de información por afectaciones en viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 12Viviendas afectadas-12 familias afectadas, 48 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>Técnica de SGR realizó recorridos por sectores afectadosPresidente Parroquial del GAD Posorja realizó recorrido.</td></tr><tr><td>Fuentes de información:</td><td>Presidente de la Junta Parroquial Posorja/ SGR Unidad de Monitoreo Guayas</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 16 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/de88daead76ec4e38c854737bddbee376ed948b0d7bafcd534a5619c01f6c81c.jpg)



Inundación


<table><tr><td>Localización:</td><td>Guayas / San Jacinto Yaguachi y El Triunfo/ Varias parroquias /Varios sectores</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023, por lluvias, se produjo el desborde del río Bulubulu, provocando inundación en dos cantones:-Yaguachi en las parroquias Pedro J. Montero (Boliche) y Virgen de Fátima - Varios sectores (Base Taura), Recinto San Mateo-El Triunfo -Cabecera Cantonal- Recinto Las Vegas y Payo-Durán - Eloy Alfaro - Recinto Las Margarita</td></tr><tr><td>Situación actual:</td><td>Jefe Político de Durán informa sobre el colapso de un puente colgante (peatonal), que une Durán con Yaguachi, donde atraviesa el río Bulubulu. UGR de ambos cantones realizaran la respectiva coordinación de acuerdo a sus jurisdicciones.Actualmente el río se mantiene desbordado en los tres cantones donde pasa</td></tr><tr><td>Afectaciones:</td><td>El Triunfo-Calles y avenidas (inundadas)- 20 Viviendas afectadas (información preliminar)Yaguachi-cultivos de banano afectados (bajo evaluación)-15 viviendas afectadas (información preliminar)- 1 bien público afectado (Recinto militar afectado).Durán-1 puente colapsado</td></tr><tr><td>Acciones de respuesta:</td><td>Jefe Político Durán confirma novedadGAD Cantonal Durán se movilizará al sitio para realizar un informe de inspección del puente y verificar afectaciones en posibles viviendas afectadas por el desborde del río</td></tr><tr><td>Fuentes de información:</td><td>GAD Cantonales Duran y Yaguachi /Jefes Políticos / SGR Unidad de Monitoreo Guayas</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/5f09ce08a2f4da50a9fb96027ef7cb7c03e0ef316371640e5e26351107095856.jpg)


## Vendaval

<table><tr><td>Localización:</td><td>Pichincha / San Miguel de los Bancos/ Los Bancos/ Barrios Nuevo Amanecer y 6 de Diciembre</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2023, producto de las condiciones climáticas se produjo un vendaval que afectó a 2 viviendas en los barrios mencionados ocasionando que sus techos se desprendan.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas permanecen en las mismas en un área que no se vio afectada</td></tr><tr><td>Afectaciones:</td><td>- 2 viviendas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos Los Bancos colaboraron con la confirmación y una inspección.Se solicitó la presencia del GAD Cantonal de Los Bancos para que realice una evaluación de daños y colaborar con materiales para la reconstrucción de ser necesario.</td></tr><tr><td>Fuentes de información:</td><td>CB Los Bancos/ SGR Unidad de Monitoreo Pichincha</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/1eada0525d1fe2a967b0aea9e670dc2ea749a0bb3076f7f1c7a6823b90aaa767.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Pichincha/Quito/Nayón/Vía hacia el Rancho San Francisco.</td></tr><tr><td>Antecedentes:</td><td>El 01/03/2023 debido a la inestabilidad del talud se suscitó un deslizamiento en el sitio, este tipo evento es recurrente en el sector, por lo que se solicitó una inspección técnica debido a que en la parte alta del mismo existen viviendas que podrían ser afectadas.</td></tr><tr><td>Situación actual:</td><td>El día 07/03/2023, GAD Cantonal (EPMAPS y EP EM SEGURIDAD) iniciaron con los trabajos de acceso al rio Machángara, que luego permitirá el ingreso de maquinaria al encauzamiento del rio y evitar el taponamiento del cauce del río Monjas.</td></tr><tr><td>Afectaciones:</td><td>--</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal EPMAPS y EP EMSEGURIDAD movilizaron maquinaria y realizan trabajos en el cauce del rio.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ9 Unidad de Monitoreo Pichincha EPMAPS/GAD Cantonal COEM.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 17 de 23

3. Monitoreo de estado de vías afectadas por eventos peligrosos 

VÍAS DE PRIMER ORDEN: 

10 vías de primer orden cerradas 

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Bolívar</td><td>Chillanes</td><td>Chillanes</td><td>varios sectores: a la altura de Loma de Pacay, San Francisco, vía Chillanes-Bucay [E495]</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>entrada a la vía Alterna</td><td>DESLIZAMIENTO</td><td>15</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>Vía a La Vitalia - 1er orden</td><td>SOCAVAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Bolívar</td><td>San Miguel</td><td>Balsapamba</td><td>Varios Sectores: Alungoto, La Ceiba, vía San Miguel-Balzapamba [E 491]</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz de Pineda</td><td>vía El Salado - San Luis [E45]</td><td>ALUVION</td><td>---</td><td>04/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Napo</td><td>Chaco</td><td>Gonzalo Díaz de Pineda</td><td>Puente sobre el río Marker, vía E45 San Luis -El Reventador</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>22/02/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Gramalote, km. 112 vía Cuenca-Girón - Pasaje</td><td>INUNDACIÓN</td><td>50</td><td>22/02/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Manabí</td><td>Manta</td><td>San Lorenzo</td><td>Ruta del Spondiylus San Lorenzo - Santa Rosa [E15]</td><td>OLEAJE</td><td>1200</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>875</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>

## 42 vías de primer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>La Piedra vía Guanujo-Echeandía [E494]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td></td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Salida de Santa Rufina hacia, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>Chimbo</td><td>La Magdalena</td><td>Gualasay, vía Chimbo - El Cristal</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Tena</td><td>Puerto Misahualli</td><td>Sector Venecia, vía Ahuano [E436]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo</td><td>A 200 metros de la Y del Huayco, vía Chimbo -San Miguel [E 491]</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Vía Arenillas - Las Lajas [E25]</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 28, vía Cuenca-Girón-Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>50</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>San Juan Bosco</td><td>Sector Chone, vía San Juan Bosco-Gualaquiza [E45]</td><td>DESLIZAMIENTO</td><td>70</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Pepinales, vía Alausí - Huigra [E-47]</td><td>DESLIZAMIENTO</td><td>---</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Loja</td><td>Calvas</td><td>Colaisaca</td><td>Asanuma, vía Cariamanga-Sozoranga[E69]</td><td>DESLIZAMIENTO</td><td>40</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Cañar</td><td>La Troncal</td><td>Manuel J. Calle</td><td>El Gogo km 50, Vía Cañar-Zhud-Cochancay [E-35]</td><td>DESLIZAMIENTO</td><td>40</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Chimborazo</td><td>Chunchi</td><td>Llagos</td><td>Joyagshi, Zhud, Chunchi - Cuenca [E35]</td><td>DESLIZAMIENTO</td><td>--</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo, Cabecera Cantonal</td><td>Santa Marianita - vía a Balzapamba</td><td>DESLIZAMIENTO</td><td>45</td><td>08/03/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0142
Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 18 de 23


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>La Piedra vía Guanujo-Echeandía [E494]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td></td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Salida de Santa Rufina hacia, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>Chimbo</td><td>La Magdalena</td><td>Gualasay, vía Chimbo - El Cristal</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Tena</td><td>Puerto Misahuali</td><td>Sector Venecia, vía Ahuano [E436]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo</td><td>A 200 metros de la Y del Huayco, vía Chimbo -San Miguel [E 491]</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Vía Arenillas - Las Lajas [E25]</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 28, vía Cuenca-Girón-Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>50</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>San Juan Bosco</td><td>Sector Chone, vía San Juan Bosco-Gualaquiza [E45]</td><td>DESLIZAMIENTO</td><td>70</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Pepinales, vía Alausí - Huigra [E-47]</td><td>DESLIZAMIENTO</td><td>---</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Loja</td><td>Calvas</td><td>Colaisaca</td><td>Asanuma, vía Cariamanga-Sozoranga[E69]</td><td>DESLIZAMIENTO</td><td>40</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Cañar</td><td>La Troncal</td><td>Manuel J. Calle</td><td>El Gogo km 50. Vía Cañar-Zhud-Cochancay [E-35]</td><td>DESLIZAMIENTO</td><td>40</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Chimborazo</td><td>Chunchi</td><td>Llagos</td><td>Joyagshi, Zhud, Chunchi - Cuenca [E35]</td><td>DESLIZAMIENTO</td><td>--</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>Km 61, vía Paute Guarumales Méndez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Manabí</td><td>Puerto López</td><td>Salango</td><td>La Rinconada 5 Cerros, vía Puerto López - Santa Elena [E15].</td><td>HUNDIMIENTO</td><td>4</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>Km 61, vía Paute Guarumales Méndez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Manabí</td><td>Puerto López</td><td>Salango</td><td>La Rinconada 5 Cerros, vía Puerto López - Santa Elena [E15].</td><td>HUNDIMIENTO</td><td>4</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>28</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>29</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>30</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>31</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0142
Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 19 de 23


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>La Piedra vía Guanujo-Echeandía [E494]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td></td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Salida de Santa Rufina hacia, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>Chimbo</td><td>La Magdalena</td><td>Gualasay, vía Chimbo - El Cristal</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Tena</td><td>Puerto Misahuali</td><td>Sector Venecia, vía Ahuano [E436]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Bolívar</td><td>Chimbo</td><td>San José de Chimbo</td><td>A 200 metros de la Y del Huayco, vía Chimbo -San Miguel [E 491]</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Vía Arenillas - Las Lajas [E25]</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 28, vía Cuenca-Girón-Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>50</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>San Juan Bosco</td><td>Sector Chone, vía San Juan Bosco-Gualaquiza [E45]</td><td>DESLIZAMIENTO</td><td>70</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Alausí</td><td>Sibambe</td><td>Pepinales, vía Alausí - Huigra [E-47]</td><td>DESLIZAMIENTO</td><td>---</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Loja</td><td>Calvas</td><td>Colaisaca</td><td>Asanuma, vía Cariamanga-Sozoranga[E69]</td><td>DESLIZAMIENTO</td><td>40</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Cañar</td><td>La Troncal</td><td>Manuel J. Calle</td><td>El Gogo km 50, Vía Cañar-Zhud-Cochancay [E-35]</td><td>DESLIZAMIENTO</td><td>40</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Chimborazo</td><td>Chunchi</td><td>Llagos</td><td>Joyagshi, Zhud, Chunchi - Cuenca [E35]</td><td>DESLIZAMIENTO</td><td>--</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>32</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>33</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guellupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tucán - Ibarra 2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>34</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>35</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>36</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>38</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>39</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>40</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>41</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 20 de 23

VÍAS DE SEGUNDO ORDEN 

## 14 vías de segundo orden cerradas

<table><tr><td></td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Pasaje</td><td>Tres cerritos</td><td>Tres Cerritos, vía Pasaje - Cuenca [E-59]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>Las Guardias, vía a Pailaloma</td><td>DESLIZAMIENTO</td><td>8</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Santa Martha de Trigoloma, vía Pallatanga - Guayaquil [E-487]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Zamora Chinchipe</td><td>Yanzatza</td><td>Los Encuentros</td><td>Vía Los Encuentros - El Zarza.</td><td>DESLIZAMIENTO</td><td>--</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Loja</td><td>Sozoranga</td><td>Sozoranga</td><td>Nueva Fátima, vía Sozoranga - Nueva Fátima.</td><td>DESLIZAMIENTO</td><td>50</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>El Oro</td><td>Santa Rosa</td><td>Victoria</td><td>Km 18, vía Buenavista - San Juan de Cerro Azul [E-585]</td><td>ALUVION</td><td>150</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Loja</td><td>Catamayo</td><td>Zambi</td><td>Varios Sectores (Chorrera y Peña Azúl), vía a Portovelo.</td><td>DESLIZAMIENTO</td><td>--</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Manabí</td><td>Chone</td><td>Santa Rita</td><td>El Pueblito vía a la Tablada de Sánchez</td><td>DESLIZAMIENTO</td><td>--</td><td>07/03/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>KM47, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>25</td><td>06/03/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Imbabura</td><td>San Miguel de Urcuqui</td><td>San Blas</td><td>Santa Cecilia</td><td>SOCAVAMIENTO</td><td>20</td><td>26/10/2022</td><td>Vía antigua de Santa Cecilia - Timbuyacu.</td></tr><tr><td>11</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>14</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>


10 vías de segundo orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Chimborazo</td><td>Colta</td><td>Juan de Velasco</td><td>Sector Hierba Buena, Vía Riobamba - Guayaquil / tramo Colta - Pallatanga [E-487]</td><td>DESLIZAMIENTO</td><td>--</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>La Soberana, vía Pallatanga - Cumandá [E-487].</td><td>SOCAVAMIENTO</td><td>--</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Sitio La Alcantarilla, vía Guanazan - Uzhcurrumi</td><td>DESLIZAMIENTO</td><td>--</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Guapo, vía Colta -Pallatanga [E-487]</td><td>ALUVIÓN</td><td>40</td><td>21/02/2023</td><td>Riobamba - Guaranda - Babahoyo - Guayaquil</td></tr><tr><td>5</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>15</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr></table>

## VÍAS DE TERCER ORDEN:

## 16 vías de tercer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Imbabura</td><td>Cotacachi</td><td>Apuela</td><td>La Delicia, vía Cotacachi - Apuela</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>El Oro</td><td>Zaruma</td><td>Sinsao</td><td>El Roble, Vía Sinsao-Ortega.</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Bolívar</td><td>Las Naves</td><td>Cabecera Cantonal</td><td>Recinto La Unión - vía Voluntad de Dios.</td><td>DESLIZAMIENTO</td><td>100</td><td>09/03/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No 0142
Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 21 de 23


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>4</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>La Valdivia - río Clementina</td><td>INUNDACIÓN</td><td>30</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>La Estrella - Cdla. Felipe Abud - río Cristal</td><td>SOCAVAMIENTO</td><td>60</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Cañar</td><td>Biblián</td><td>Nazón</td><td>Capulisloma</td><td>SOCAVAMIENTO</td><td>30</td><td>08/03/2023</td><td>La Hacienda.</td></tr><tr><td>7</td><td>Cotopaxi</td><td>La Maná</td><td>El Triunfo</td><td>Estero Hondo, vía La Maná - Pangua</td><td>SOCAVAMIENTO</td><td>--</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Cune, Vía Pasaje - Uzhcurrumi</td><td>COLAPSO ESTRUCTURAL</td><td>10</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Los Ríos</td><td>Valencia</td><td>El Vergel</td><td>vía Federico Intriago El Vergel</td><td>DESLIZAMIENTO</td><td>40</td><td>08/03/2023</td><td>Buena Fe vía Fumisa hacia camarones y por el río gallinas.</td></tr><tr><td>10</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur</td><td>INUNDACIÓN</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>15</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>16</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>955.9</td><td>20/01/2021</td><td>Ninguna</td></tr></table>

## 10 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Piñas</td><td>Piñas</td><td>Puente de Buza, Vía al Pache - Puente de Buza</td><td>DESLIZAMIENTO</td><td>40</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Caserío Guanando, Vía a Guanando - Cahuaji Bajo</td><td>DESLIZAMIENTO</td><td>--</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Sitio Quera, vía Quera - Chilla.</td><td>DESLIZAMIENTO</td><td>10</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Cañar</td><td>Biblián</td><td>Nazón</td><td>Ayapamba</td><td>DESLIZAMIENTO</td><td>50</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Chilla</td><td>Chilla</td><td>Playas de Daucay, Vía Playas de Daucay - Chilla</td><td>DESLIZAMIENTO</td><td>6</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>El Oro</td><td>Marcabelí</td><td>El Ingenio</td><td>La Palmerita, Vía La Palmerita - El Ingenio</td><td>SOCAVAMIENTO</td><td>8</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Portovelo</td><td>Morales</td><td>Vía Morales - La Chorrera</td><td>DESLIZAMIENTO</td><td>20</td><td>27/02/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>

## 4. Declaratorias emitidas por el SGR (vigentes en orden cronológico)

<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/056dbf9c198cd6657050d115fce1badbfe148fc3727e96c8db63d3dcd3a12a07.jpg"/></td><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua.</td><td>Amarilla</td><td>17/02/2023</td><td>Resolución No. SGR-039-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/2ac7476f644e46398acbfd0c4eec29c1b4bf3370a50b81d94da557122c1e16b0.jpg"/></td><td>Incremento Actividad Volcánica Cotopaxi</td><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SGR-0311-2022</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/5744107aba4957b7df396234a69d323d619e41fae79fed95bc851f14f7c7fc0b.jpg"/></td><td>Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo.</td><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SGR-182-2022</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/ec251ef4fd27a1726bce22ccc5fb98c21c8f1453e832c8c66a04b0536c87deaa.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/0f52fa7a0e71344026be1beeb056c33046d0b7d5a5fb8e716672cd33bc65ce22.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/c3cb4a89a9cf20d87f41a37ef2c002f45743c734a9c053a3c3b9ee963f096bae.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/3b8e8c0b68b27b156d9dee6d01a55fd071310c6a0d7cb237a415b290d075538e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/c7366afc911a1434fe23f24be5a09a6547850a96a7ee042fc98c1adb4ae551e0.jpg)



Reporte de monitoreo de amenazas y eventos peligrosos - No 0142
Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 22 de 23


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/2797695db6265ee3c03d17c2e183297ce54cfd376588f7b4928158a0753195ff.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa en los sectores: Pasán y Namza Chico, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo.</td><td>Amarilla</td><td>20/05/2022</td><td>Resolución No. SGR-118-2022</td></tr><tr><td>Movimiento en masa barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SGR-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SGR-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SGR-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Rio Upano- Parroquías Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SGR-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SGR-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SGR-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SGR-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="2">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td colspan="2">Inundaciones Babahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/c43c8052709a649e251f801cab8cbf8ae2fb2c82686481a3387147b001d18dda.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/80a9fdde2c9d6853cb2d81b20f35c36c1c219f8ff7cdbe7a96bf76b04bb76a6c.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/e31e9a26847d4cba39b09df6efd5dd4488a0e5495faf1d835e162d18389fd112.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/24b6888a101c62eb6eed5d8d3dabd53c5a3eed03da44fad4aa0107b68ff75db2.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/867aaafa5247f37aea1df5096712939888b7c9dc90d60d0b22556244590a73a9.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/ce0e61a70eecae010277e70959aaa457b08e34375b7a5121d261e732659702a6.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/29728a8984f69dd8c74313eee533ad96d6824dc3f05eaa3384b9ca3cdf66023b.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/37cf15404e505da544eeecc34d92643dd350cf85fdca185a0b3e6623f9bdec54.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/018feaf5c71b99d37d7cf94af9cb8e2f977313b00e1c83cb1292e88b43c48134.jpg)


## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0142 Fecha y Hora de actualización: domingo, 12 de marzo de 2023 - 21:05:15 / Página 23 de 23

<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/8f0e90af-6ff3-4e4a-8db5-e26207e13539/bc208f57b378e08a5315ac4330cb6e53208ada4b21b795d6b515c5e040c79d12.jpg)


Hundimiento, 

Zaruma, El Oro 

07/03/2017 

Resolución No. SGR-029-2015 

Elaborado por. Carlos Álvarez / Fernando Saltos, - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. Revisado por. Javier Sarango- Analista Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. Enviado por.- Fernando Saltos - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 