# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 1 de 21

Periodo de Monitoreo: 

Desde: 09h00 14/03/2023 

Hasta: 21h00 14/03/2023 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/7e6d1a1ac7a4586946f3e049583dfc229faf0b6c6dc2df207a7e68e07fef9ddc.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="3">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/b298feb390cfae9f647c9f64c01318bc18d9ce063443bf2333441764780c1d68.jpg"/></td><td rowspan="2"></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/69717650fb04546c4a6571c2c3c8be6a2ba01c143f72150dfccea01414bb0405.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18:21 Mediante cámaras se visualiza el volcán nublado.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/c8b3161f44095a42d4d7c514e05c26110b7c12488aeabd1c5df6fff8d4f9b8fe.jpg"/></td><td rowspan="4"></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>11:00 La mayor parte del tiempo el volcán permaneció nublado, en la mañana de hoy se registró una emisión principalmente de gases, con dirección hacia el Sureste, la misma que alcanzó 1000 metros sobre la cumbre.</td><td>AMARILLA</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/8fcfccb72afe65813123307d511a7133a5471577fa8cb9dd07cb6ee5e39ee2eb.jpg"/></td><td>Volcán Tungurahua</td><td>SIN ALERTA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/030d62870e3e16b4899444c5e9dd841e8a7fd1f70a62973441ceb3df629fa1e4.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18:00 Sin reporte de actividad superficial.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/1dbe266eaa6d98f1025220303e9ad1c809a57bd8f2851135c8cc86d21d79bae9.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>18:22 Mediante cámaras se visualiza Se visualiza emisión de material piroclástico.</td><td>AMARILLA</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/fd7d7530f247449079ba6a84df56c772b65ac346339bcd14280670adede3c9a5.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">05 Cuerpos de agua desbordados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del cuerpo de agua</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>Rcto. Las Malvinas</td><td>La Clementina</td></tr><tr><td>Los Ríos</td><td>Babahoyo</td><td>Dr. Camilo Ponce</td><td>Sol Brisa 2</td><td>Sabana</td></tr><tr><td>Azuay</td><td>Santa Isabel</td><td>Abdón Calderón (La Unión)</td><td>Chantaco</td><td>Chantaco</td></tr><tr><td>Guayas</td><td>Pedro Carbo</td><td>Pedro Carbo, Cabecera Cantonal</td><td>varios sectores</td><td>Jerusalén</td></tr><tr><td>Manabí</td><td>Chone</td><td>San Antonio</td><td>Badeal</td><td>Rio Colorado</td></tr><tr><td colspan="5">22 Cuerpos de Agua con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del cuerpo de agua</td></tr><tr><td rowspan="7">Esmeraldas</td><td rowspan="2">Quinindé</td><td>Malimpia</td><td>Malimpia</td><td>Blanco</td></tr><tr><td>Rosa Zárate (Quinindé), Cabecera Cantonal</td><td>Malecón de Quinindé</td><td>Quinindé</td></tr><tr><td>Esmeraldas</td><td>5 De Agosto</td><td>Vías Los Puentes</td><td rowspan="3">Esmeraldas</td></tr><tr><td>Esmeraldas</td><td>5 De Agosto</td><td>Isla Roberto Luis Cervantes</td></tr><tr><td>Quinindé</td><td>Chura (Chancama) (Cab. En El Yerbero)</td><td>Salinas</td></tr><tr><td>Quinindé</td><td>Viche</td><td>Puente de Viche</td><td>Viche</td></tr><tr><td>Quinindé</td><td>Rosa Zárate (Quinindé), Cabecera Cantonal</td><td>Boca de Mache</td><td>Mache</td></tr><tr><td rowspan="3">Guayas</td><td>Daule</td><td>Los Lojas (Enrique Baquerizo Moreno)</td><td>Recinto La Majada</td><td rowspan="3">Los Tintos</td></tr><tr><td>Daule</td><td>Juan Bautista Aguirre (Los Tintos)</td><td>Sector cabecera Parroquial</td></tr><tr><td>Daule</td><td>Juan Bautista Aguirre (Los Tintos)</td><td>Recinto El Porvenir</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 2 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/13a4df7918f86d67e59cbeb796d6c8ae99f048cd0dd071668806393f52f5168c.jpg)


PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS 

<table><tr><td rowspan="6"></td><td>Nobol</td><td>Narcisa De Jesús, Cabecera Cantonal</td><td>Cabecera Cantonal</td><td>Bijahual</td></tr><tr><td>Isidro Ayora</td><td>Isidro Ayora, Cabecera Cantonal</td><td>San Agustín</td><td>Bachillero</td></tr><tr><td>San Jacinto De Yaguachi</td><td>Yaguachi Viejo (Cone)</td><td>Vía Vuelta Larga</td><td>Chimbo</td></tr><tr><td>El Triunfo</td><td>El Triunfo, Cabecera Cantonal</td><td>Frontera by Pass hacia Yaguachi</td><td>Payo</td></tr><tr><td>Durán</td><td>Eloy Alfaro (Durán)</td><td>Varios Sectores</td><td rowspan="2">Bulubulu</td></tr><tr><td>San Jacinto De Yaguachi</td><td>Gral. Pedro J. Montero (Boliche)</td><td>Cabecera parroquial</td></tr><tr><td rowspan="10">Los Ríos</td><td>Babahoyo</td><td>Babahoyo, Cabecera Cantonal</td><td>Camilo Ponce</td><td>Babahoyo</td></tr><tr><td>Vinces</td><td>Vinces, Cabecera Cantonal</td><td>Vinces</td><td>Vinces</td></tr><tr><td>Ventanas</td><td>Zapotal</td><td>Zapotal</td><td>El Lechugal</td></tr><tr><td>Quevedo</td><td>San Camilo</td><td>San Camilo</td><td>Quevedo</td></tr><tr><td>Babahoyo</td><td>Clemente Baquerizo</td><td>El Palmar</td><td>San Pablo</td></tr><tr><td>Buena Fé</td><td>San Jacinto de Buena Fé, Cabecera Cantonal</td><td>Pto. Bajaña</td><td>Pto. Bajaña</td></tr><tr><td>Ventanas</td><td>Los Ángeles</td><td>Puente de Ventanas</td><td>Sibimbe</td></tr><tr><td>Urdaneta</td><td>Catarama, Cabecera Cantonal</td><td>Catarama</td><td>Catarama</td></tr><tr><td>Palenque</td><td>Palenque, Cabecera Cantonal</td><td>Palenque</td><td>La Revesa</td></tr><tr><td>Mocache</td><td>Mocache, Cabecera Cantonal</td><td>Mocache</td><td>Mocache</td></tr><tr><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Sector Puente sobre el río Upano</td><td>Upano</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/e2eaf8374da2b620fe43faa41058921a98c50c03a22c3fb7d3c769c402978455.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 incendio controlado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/9e811001d941ddef4cb8a32a22f7fe79bc05bb3ea18a5987ecd510152100dfcf.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td></td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td></td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>78.90</td><td>85.00</td><td>08:09</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>116.28</td><td>117.00</td><td>08:51</td><td>VERDE</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>59.79</td><td>66.00</td><td>14:25</td><td>VERDE</td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>102.50</td><td>106.50</td><td>14:25</td><td>VERDE</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>62.08</td><td>68.50</td><td>14:25</td><td>VERDE</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td></td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td></td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 3 de 21

## SITUACIÓN HIDROMETEREOLÓGICA

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/8be0bbc5b0626a23a70db1ecdc4df0d930c35f800b96ab5fb965b04bc96664b2.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/8d19354dc7c346e486776153ed14f4682e72874df6e88bf978a5a0071fea8c76.jpg)


## ADVERTENCIA

AMENAZA: LLUVIAS Y TORMENTAS - ADVERTENCIA
METEOROLÓGICA N°12 

Vigente desde 20H00 del 13 hasta las 19H00 del 15 de marzo de 2023 

SITUACIÓN: Durante la noche del 13 y extendiéndose hasta el 15 de marzo, se mantendrán los episodios de precipitación intensas con tormentas eléctricas en distintos sectores del país, en especial la noche del 13 de marzo en la región Litoral. 

- Región Litoral: Se pronostican lluvias de variable intensidad, con mayor énfasis en el interior de la región. 

- Región Interandina: Las mayores intensidades se pueden generar al sur de la región y en estribaciones de cordillera oriental. 

- Región Amazónica: Las precipitaciones se enfocarán en las estribaciones de cordillera, mayor énfasis en la zona norte y sur. 

FUENTE: INAMHI 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/14357fc8be73c554c1dc751146dee6973c81bf1046944d7710bd14d7943a90e9.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/7686f174bf676c2e2364acc3d6eb38a26ccdef431670201ef30d72a10a8ad449.jpg)



Inundación


<table><tr><td>Localización:</td><td>Esmeraldas/Atacames/Súa/Ciudadela Alonso de Illescas y Nuevo Porvenir.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 por lluvias se produjo el desbordamiento del río Súa, el cual provocó una inundación en el sector.</td></tr><tr><td>Situación actual:</td><td>El río Súa se encuentra en su cauce normal.</td></tr><tr><td>Afectaciones:</td><td>- 56 familias, 214 personas afectadas (directas).- 24 familias, 106 personas afectadas (indirectas).- 80 viviendas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>SGR Esmeraldas realizó la entrega de asistencia humanitaria en el sector Nuevo Porvenir y El Mangal.Coordinador Zonal 1, Gobernador de la Provincia, GAD Cantonal Tenencia Política se encuentra en sitio brindando apoyo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Esmeraldas.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/0f87674ab87a9e356f45e587c40d7e3f13d2b87ac3b3cf842daa79265a1642b6.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El 26/11/2021, de acuerdo al informe del SGR se indicó que el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.Se informa que el SGR CZ1, geólogos de la Prefectura, Universidad Central, Universidad Yachay y autoridades locales realizaron recorridos e inspecciones técnicas.El 16/11/2021, SGR-CZ1 entregó asistencia humanitaria. El Informe del MAG indica que la afectación de los cultivos en total es de 12,43 ha de cultivos de la zona. GAD Cantonal de Pimampiro en apoyo del GAD Provincial Imbabura trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad, tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su cabecera cantonal.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.Desde enero de 2023 se inició con la instalación de las acometidas de los servicios básicos. El MIDUVI está a la espera de que el GAD termine de hacer las acometidas para</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 4 de 21

<table><tr><td></td><td>iniciar con la construcción de las viviendas; ya que dispone de los recursos económicos para este proyecto.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservorios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El GAD Cantonal de Pimampiro determinó un predio para la construcción del Proyecto de Vivienda, y realiza la instalación de servicios básicos.GAD Cantonal y Provincial de Imbabura habilitaron una vía alterna. La comunidad habilitó la vía a Mariano Acosta que pasa por la zona de riesgo de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SGR, exponiéndose a futuros riesgos vinculados a la zona propensa de deslizamiento.Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi / MIES, MIDUVI, GAD C Pimampiro - UGR.</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/f5dce27889732f01db72305af5baff683dfb3d04e4f682f42b8fd9854f4df025.jpg)



Socavamiento


<table><tr><td>Localización:</td><td>Napo/El Chaco/Sardinas/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 04/03/2023, debido a las lluvias e incremento del río Sardinas, se registran varias afectaciones</td></tr><tr><td>Situación actual:</td><td>Al momento la vía alterna provisional vía a Yaucana de acceso a los sectores de San Marcos Alto, San Andrés y Los Ángeles se encuentra habilitada.</td></tr><tr><td>Afectaciones:</td><td>- 1 Puente carrozable destruido (privado acceso a finca del señor Mora)- 1 Puente peatonal destruido (por deterioro)- 36 familias afectadas (aisladas por las vías sin acceso)- 315 metros de vía de tercer orden destruido (San Andrés 185 m, San Marco Alto 60 m, Los Ángeles 70 m.).</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Municipal El Chaco realizó trabajos en la habilitación de una vía alterna provisional.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Unidad de Monitoreo Napo-Orellana/Teniente Político de Sardinas/GAD Municipal El Chaco.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/b961660f7761f55affc5a74d14a8d9a9e5653711cc2643120ffd9672ea9beac1.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda/en el tramo de la vía E45, río Marker.</td></tr><tr><td>Antecedentes:</td><td>El 22/02/2023, debido a las lluvias se produjo el colapso de un puente de primer orden en el tramo Reventador - Punto de Socavamiento de San Luis.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se encuentra cerrada en su totalidad.</td></tr><tr><td>Afectaciones:</td><td>- 1 puente destruido (Puente sobre el río Marker).- 1 bien público destruido (Torre de soporte de tubería Tipo H).- 3 bienes públicos afectados: Oleoductos (SOTE, OCP) y Poliducto Shushufindi-Quito.</td></tr><tr><td>Acciones de respuesta:</td><td>EP Petroecuador informó que luego de retomar el bombeo de crudo por el Sistema de Oleoducto Transecuatoriano (SOTE) y el Poliducto Shushufindi - Quito, el 5 de marzo de 2023, levantó la declaratoria de Fuerza Mayor que regía sobre sus actividades, con la finalidad de normalizar las operaciones.SGR CZ 2 realiza monitoreo del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Unidad de Monitoreo Napo-Orellana/OCP/CB El Chaco/Petroecuador.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/c4ef3b0f50d2060d71e3c28809057b4764c765c552b729eaeb561d29fe6a9897.jpg)



Socavamiento


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.Se mantiene la declaratoria emitida mediante resolución SGR-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>Al momento el sector se encuentra nublado, sin presencia de lluvias.San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 5 de 21

<table><tr><td>Afectaciones:</td><td>Desde el 2020 a la fecha las afectaciones son las siguientes:- Personas Afectadas indirectas: 100- Personas Damnificadas: 51- Personas Afectadas: 76- Personas Evacuadas: 63- Viviendas destruidas: 2- Metros de vía afectadas: 1040- Puentes destruidos: 3 (Puente sobre el río Motana, Puente Ventana 2 y Puente Piedra Fina)- Puente afectados: 1 (Puente Piedra Fina)- Bienes Afectados: 4 (tuberías del SOTE, Poliducto Shushufindi- Quito y OCP; Sistema de Agua Potable de San Luis)- Ha de Cultivo perdida: 100.03- Animales de granja afectados y muertos: 3448</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria de MTOP se encuentra en el sector pero no se encuentran realizando trabajos.SGR CZ2 mantiene monitoreo constante con puntos focales en San Luis. La CTC Río Coca realizan el monitoreo del proceso erosivo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/CELEC EP/GAD Municipal El Chaco/CB Chaco/MTOP/PPNN Chaco.</td></tr></table>

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/68dad582ae90de384e461ac032691d6ef99079143ae18e8e93c6a2c2af716c5e.jpg)


<table><tr><td>Localización:</td><td>Chimborazo/Pallatanga/Pallatanga/Caserío Guapo, vía Colta -Pallatanga [E-487], Barrios: Jiménez, María de Lourdes, Municipal, Central, El Ingenio, Cornelio Dávalos, Santa Ana Norte, El Progreso, Morera.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023, a causa de las lluvias suscitadas en horas de la madrugada, se suscitó un aluvión.</td></tr><tr><td>Situación actual:</td><td>SGR realizó Informe de inspección técnica preliminar para el análisis de amenazas a fenómenos de remoción en masa e inundaciones en los sectores: El Guapo, río Huitsitse y Santa Ana del cantón Pallatanga, provincia de Chimborazo.</td></tr><tr><td>Afectaciones:</td><td>- 4 personas fallecidas- 2 personas heridas- 2 personas damnificadas- 2 personas evacuadas- 113 familias afectadas (9 familias por afectaciones a viviendas y 104 familias por afectaciones a cultivos y animales).- 438 personas afectadas (22 personas por afectaciones a viviendas y 416 personas por afectaciones a cultivos y animales).- 700 personas afectadas indirectamente- 40 metros de vía afectada.- 6 bienes privados afectados (bus, camión, local comercial, propiedades)- 1 bien público afectados (poste)- 1 bien público destruido (manguera de conducción de agua)- Los Barrios: Jiménez, María de Lourdes, Municipal, Central y El Ingenio se encuentran sin abastecimiento de agua.- 7 viviendas en riesgo- 2 viviendas afectadas- 1 vivienda destruida.- 214 animales muertos- 13.5 ha de cultivos afectados.- 28 ha de cultivos destruidos.- 120 animales afectados.- 120 animales muertos.- 1 puente afectado.- 10 metros de vía de tercer orden.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD realizó la reparación de la tubería de agua potable afectada al momento los barrios afectados se encuentra al 100% con el abastecimiento de agua potable.GAD Pallatanga reparó la vía de tercer orden Azafrán - San Rafael donde se produjo un hundimiento, se encuentra completamente habilitada.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/COE P.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/07b61f937fca9505eb7833f40da3e5041caec15ef9a5aec3cfeea27ef3b54104.jpg)


## Hundimiento

Antecedentes: El 01/01/2023, se produjo un hundimiento en la vía de primer orden, que al momento está cerrada por personas que procedieron a poner obstáculos.
SGR informa en cumplimiento a la Resolución Nro. SGR-039-2023 del 19/02/2023, declara el estado de ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua; el mismo que comprende un área de aproximadamente 247 hectáreas. 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 6 de 21

<table><tr><td>Situación actual:</td><td>Con fecha 10 de marzo el COE Provincial mantuvo una reunión con la finalidad de dar seguimiento a los informes y acciones de las instituciones del SNDGR en atención a la zona afectada.</td></tr><tr><td>Afectaciones:</td><td>- 150 metros de vía afectada.- 1 ha de cultivo destruido.- 1 familia afectada (4 personas).</td></tr><tr><td>Acciones de respuesta:</td><td>El COE Provincial resolvió: Solicitar al MTOP un informe técnico sobre el riesgo en carretera por el tránsito del transporte pesado.Requerir a la SGR la entrega oficial del INFORME respecto del movimiento de masas en el cantón Alausí.Exhortar a las instituciones que forman parte de la Mesa Técnica de Trabajo - 3 Provincial participar de todas las convocatorias.Sugerir bajo el principio de subsidiariedad al GAD cantonal de Alausí analice la pertinencia para declararse en emergencia institucional.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MTOP Chimborazo/MAG.</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/b42d9e1d0b83a16ddfe45a1edcbca09bc2135b1d572986c87bf2396c4311c132.jpg)



Inundación


<table><tr><td>Localización:</td><td>Manabí/Sucre/Leónidas Plaza/Acuarela 1 y 2, Los Jardines.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2023, por lluvias suscitadas en horas de la madrugada se produjo el desbordamiento de la quebrada El Toro provocando la inundación y colapso de viviendas en el sector.</td></tr><tr><td>Situación actual:</td><td>SGR CZ4 indica que sumó al alojamiento temporal (FANCA) 3 familias con 15 personas más, procede a cambiar las estadísticas.Siendo las 16h00 se activó el COE Cantonal, mismo que se mantendrá activo por el evento reportado.</td></tr><tr><td>Afectaciones:</td><td>- 12 viviendas afectadas, (4 no habitables).- 12 familias afectadas, (4 familias damnificadas).- 56 personas afectadas, (14 personas damnificadas).</td></tr><tr><td>Acciones de respuesta:</td><td>Activación de COE Cantonal.SGR CZ4 realizó levantamiento de información con personal de la UGR Cantonal, asimismo el equipamiento del alojamiento temporal.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Sucre/Cuerpo de Bomberos de Sucre.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/11bcf49abccb72036619be02b8c7cdf75aaddbf7f1eaf30c021a7fb4cdcb894e.jpg)



Inundación


<table><tr><td>Localización:</td><td>Manabí/Portoviejo/Calderón/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2023 por lluvias suscitadas en horas de la tarde se produjo una inundación que afectó a varias viviendas-</td></tr><tr><td>Situación actual:</td><td>Cuerpo de Bomberos Portoviejo Cuartel Calderón colaboraron con la limpieza y evacuación del agua ingresada en las viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 16 viviendas.- 16 familias.</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos realizó trabajos de limpieza y evacuación de agua y lodo de las viviendas.UGR Cantonal realizará el levantamiento de información.SGR realiza el seguimiento del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Monitoreo Manabí/Cuerpo de Bomberos de Portoviejo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/d7a569f4a91e44c3c0a5701bf6b4c2ca141f1c0c33fbdfdab474b34e80fc41fa.jpg)



Inundación


<table><tr><td>Localización:</td><td>Manabí/Chone/San Antonio/San Pablo, Puente Cativo. Badeal, Rancho Viejo, La Playita, Culebra, Copetón, Cativo Adentro.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo una inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/2023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Distrito de Educación realizó el levantamiento de información de las unidades educativas afectadas, al momento solo reportan afectación funcional, asimismo indica que se sumó una familia al alojamiento temporal.A la espera de que CB termine de realizar actividades pendientes para su colaboración con las Unidades educativas.</td></tr><tr><td>Afectaciones:</td><td>- 196 viviendas afectadas (6 no habitables por el momento).- 196 familias afectadas (667 personas afectadas).- 6 familias damnificadas (17 personas damnificadas).- 1243 ha cultivos afectados. 310 ha cultivos perdidos.- 15.735 afectaciones en aves, porcinos y chame.- 3 unidades educativas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Levantamiento de información por parte del distrito de educación.SGR realiza el seguimiento del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 7 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/d14ea96aba94a1ce49c4d672b5f110dc00100b78c4ac3dbf4a92348e8cb4e93b.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Canuto/varios sectores</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo una inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/20023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Cuerpo de Bomberos de Chone reporta mediante el primer informe afectaciones en los sectores: Narciso, Suchi, se procede a actualizar las cifras.</td></tr><tr><td>Afectaciones:</td><td>- 144 viviendas afectadas- 144 familias afectadas (461 personas afectadas)</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Chone continúan los trabajos de limpieza y evacuación de agua y lodo de las viviendas y sectores afectados.SGR realiza el seguimiento del evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/1e7726ef9b9aef8f3258dc4716dbec96d91f8224e403701be9451abebd1c8695.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Chone/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo el desbordamiento del Río Chone, provocando inundación con afectación en varias viviendas del sector.Se realizó la evacuación de los pacientes del Hospital IESS de Chone a otras casas de salud, adicional encontraron a una persona desaparecida en estado inerte.</td></tr><tr><td>Situación actual:</td><td>Distrito de Educación realizó el levantamiento de información de las unidades educativas afectadas, al momento solo reportan afectación funcional. A la espera de que CB termine de realizar actividades pendientes para su colaboración con las Unidades educativas.</td></tr><tr><td>Afectaciones:</td><td>- 185 viviendas afectadas- 188 familias afectadas (668 personas afectadas)- 1 persona fallecida- 1 bien público afectado. (HOSPITAL IESS CHONE)-18 unidades educativas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Levantamiento de información por parte del distrito de educación.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/0eb18dde979f11ea17d95c3db03e60778e269ec388afe843897d6f0168ea192c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Santa Rita/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo el desbordamiento del río Mosquito, provocando inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/2023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Distrito de Educación realizó el levantamiento de información de las unidades educativas afectadas, al momento solo reportan afectación funcional. A la espera de que CB termine de realizar actividades pendientes para su colaboración con las Unidades educativas.</td></tr><tr><td>Afectaciones:</td><td>- 472 viviendas afectadas.- 477 familias afectadas (1774 personas afectadas).- 1878 ha cultivos afectados.- 540 ha cultivos perdidos.- 3065 afectaciones en aves, porcinas y bovinas.- 07 educativas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Levantamiento de información por parte del distrito de educación.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/f312a1f8e6dd2aacccce60a3629128eef7fcc3c273e96839e612d25588bf3e08.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Ricaurte/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 07/03/20223 por lluvias suscitadas en horas de la madrugada se produjo el desbordamiento del río Garrapata, provocando inundación con afectación en varias viviendas del sector.El COE Cantonal Chone se activó el 07/03/2023 a las 10h00 debido a las emergencias suscitadas por la época lluviosa.</td></tr><tr><td>Situación actual:</td><td>Distrito de Educación realizó el levantamiento de información de las unidades educativas afectadas, al momento solo reportan afectación funcional. A la espera de que CB termine de realizar actividades pendientes para su colaboración con las Unidades educativas.</td></tr><tr><td>Afectaciones:</td><td>- 134 Familias Afectadas (495 Personas Afectadas)- 134 Viviendas Afectadas.- 1879 ha Cultivos Afectados.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 8 de 21

<table><tr><td></td><td>- 220 ha Cultivos Perdidos.- 7.000 afectaciones en aves y chame.- 18 unidades educativas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>Levantamiento de información por parte del Departamento de Desarrollo Productivo del GAD Chone.SGR realiza el seguimiento del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone/Cuerpo de Bomberos de Chone.</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/0e612cb3bcb67ff30fb631bfd7539f2e087e155d7363921298c46b79ca104165.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Crnel. Marcelino Maridueña/Crnel. Marcelino Maridueña, Cabecera Cantonal / Recinto Playita Mia.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en la madrugada 10/03/2023, se produjo el desbordamiento del río Barranco Alto. GAD Cantonal realizó recorridos por el sector, reportando afectación en cultivos de cacao y verde.</td></tr><tr><td>Situación actual:</td><td>SGR y GAD Cantonal indican que las familias que se encontraban en el albergue y en familia de acogida luego de las debidas limpiezas retornaron a sus inmuebles. El nivel del río se mantiene con tendencia a disminuir su caudal.</td></tr><tr><td>Afectaciones:</td><td>- 9 viviendas afectadas- 9 Familias, 28 personas afectadas- 2 familia, 5 personas se encuentran en el Albergue Municipal- 1 familia, 2 personas en familia acogiente</td></tr><tr><td>Acciones de respuesta:</td><td>SGR se movilizó al sitio a realizar la entrega de asistencia humanitaria. UGR - GAD Cantonal realizó el acompañamiento a la entrega de asistencia humanitaria Umeva Guayas dio seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/UGR Cantonal.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/f2da891939044caa5a94f798f72e09ac3320ce19cece71c185e74f790d5e84c7.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Bolívar/Chimbo/La Magdalena/comunidad de Achachi.</td></tr><tr><td>Antecedentes:</td><td>Presidente del GAD Parroquial y Teniente Político informan que, a causa de las lluvias registradas en la noche del 13/03/2023, se produjo un aluvión que arrasó ganado bovino.</td></tr><tr><td>Situación actual:</td><td>El evento se encuentra bajo evaluación</td></tr><tr><td>Afectaciones:</td><td>- 6 animales bovinos muertos (vacas)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Parroquial se encuentra en el sector, realizando desalojo de escombros y abriendo el camino.Teniente político se encuentra en el lugar.La SGR coordina con la UGR del GAD Chimbo para el levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD Parroquial La Magdalena/TEPOL.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/b84879dcde5d04e51005d8ab2e031a2ebe641fe800d4f9ab5d8ca475f240afa2.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Caluma/Caluma/recintos Plomovado y Pasagua</td></tr><tr><td>Antecedentes:</td><td>UGR del GAD Caluma informa que, a causa de las lluvias registradas en la noche del 12/03/2023 y madrugada del 13/03/2023, se produjo el desbordamiento del río Escaleras afectando a los recintos Plomovado y Pasagua.</td></tr><tr><td>Situación actual:</td><td>UGR indica que alrededor de las 17:40 empezó a llover en la parte alta del recinto Pasagua y el río aumentó su caudal, lo que provocó el colapso de una parte de la escuela del sector.El COE Cantonal de Caluma se activó la tarde de hoy 13/03/2023 para atender los eventos por la época lluviosa.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda afectada (ingreso de agua y lodo)- 1 familia, 4 personas afectadas- 13 animales de granja muertos (cerdos, cuyes)- 1 escuela afectadaLa afectación del recinto Pasagua está bajo evaluación</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria de la Empresa Privada realiza trabajos de encauzamiento del río, para retomar su dirección.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD Caluma.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/9777b4abc9abf5e36612e3970a8355f5fe07cd2f9a90a34609bb63e6a38c6b07.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/San Jacinto Yaguachi, Durán y El Triunfo/varias parroquias/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias, se produjo el desborde del río Bulubulu, provocando inundación en dos cantones:San Jacinto de Yaguachi en las parroquias Pedro J. Montero (Boliche) y Virgen de Fátima - Varios sectores (Base Taura), Recinto San MateoEl Triunfo -Cabecera Cantonal- Recinto Las Vegas y PayoDurán - Eloy Alfaro - Recinto Las Margarita</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 9 de 21

<table><tr><td>Situación actual:</td><td>GAD Cantonal San Jacinto de Yaguachi y Durán indican que el río se mantiene con tendencia a aumentar su nivel, mientras que en El Triunfo el río se encuentra con tendencia a disminuir su caudal</td></tr><tr><td>Afectaciones:</td><td>El Triunfo- 22 viviendas afectadas- 22 familias con 72 personas afectadas en sus viviendas Calles y avenidas (inundadas)- 20 Viviendas afectadas (información preliminar)San Jacinto de Yaguachi- Cultivos de banano afectados (bajo evaluación)- 15 viviendas afectadas (información preliminar)- 1 bien público afectado (Recinto militar afectado).Durán- 202 viviendas afectadas- 202 Familias afectadas con un total de 814 personas en sus viviendas*- 1 Bien Público afectado- 2 Centros Educativos afectados- 1 puente afectado</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal realiza las inspecciones de los sectores afectados.Umeva Guayas realiza monitoreo del evento.El 11/03/2023, se llevó a cabo la sesión del COE Cantonal San Jacinto de Yaguachi, donde se resolvió:Declarar en emergencia al cantónMantener activas las mesas técnicas de trabajo de Atención Humanitaria.Acoger los informes presentados por autoridades parroquiales y sus recomendaciones.Solicitar a las instituciones de gobiernos recursos para atender la emergencia y mantener la sesión permanente mientras dure la emergencia.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/UGR - GAD Cantonales El Triunfo, Durán y San Jacinto de Yaguachi/Jefes Políticos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/3e1efa2b37ee6a16a1880a7148ba1521600ae339f2fdb02b320da4c65b8c2883.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Bolívar/San Miguel/Regulo de Mora/varios sectores: El Consuelo, La Montaña, vía Las Guardias-Regulo de Mora</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2023 a causa de las lluvias registradas en los últimos días, se produjo un deslizamiento de tierra en el sector El Consuelo que destruyó la tubería del agua dejando sin líquido vital a la parroquia.</td></tr><tr><td>Situación actual:</td><td>En el sector La Montaña se ocasionó un deslizamiento de tierra que obstaculiza en su totalidad a la vía de segundo orden; la vía se encuentra cerrada.Se recomienda utilizar una vía alterna Las Guardias-El Consuelo-Regulo de Mora</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público afectado (tubería)- 90 familias, 360 personas afectadas indirectamente</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria del GAD Provincial realiza labores de limpieza de la vía.Junta de Agua de la parroquia realizará inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD San Miguel.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/3523bfdf71e6a5fee865bbe09157af6d10e45d1450b3216953930aac803fd96d.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Bolívar/San Miguel/San Pablo /Logmapamba, vía San Pablo - Chillanes [E495],</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en la noche del 10/03/2023, se produjo un deslizamiento de tierra en la vía de primer orden, que obstaculizó totalmente al tránsito vehicular.Director del MTOP indica que en horas de la mañana del 12/03/2023 a unos 3 km del sector reportado inicialmente, se suscitó un nuevo aluvión que obstaculizó totalmente a la vía.</td></tr><tr><td>Situación actual:</td><td>UGR del GAD San Miguel, informa que el aluvión de la tarde del 11/03/2023 arrasó una vivienda, un molino de granos y pérdida de animales de granja, la cual estaba construida en la parte baja del sector de Logmapamba.La familia se encuentra en hogar acogiente donde un familiar por el mismo sector.Al momento la vía se encuentra parcialmente habilitada al tránsito vehicular; sin embargo, se recomienda transitar con precaución durante el día y en la noche no transitar por cuanto está muy inestable la quebrada y en cualquier momento desciende flujos de lodo.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda destruida- 1 familia, 3 personas damnificadas- 1 bien privado destruido- 20 animales de granja muertos (cerdos, gallinas, bovinos)- 130 metros lineales</td></tr><tr><td>Acciones de respuesta:</td><td>UGR del GAD Cantonal San Miguel realizó el levantamiento de información (EVIN).MTOP-Bolívar continúa realizando trabajos de limpieza de la vía.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD San Miguel, MTOP.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 10 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/f718c91c265e5ffb5761bfa11cbefcd97a02a9c088ec4585611cc1830fd270ae.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Los Ríos/Montalvo/Montalvo/vía a La Vitalia - 1er orden.</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2023 debido a las lluvias suscitadas y al crecimiento del río Cristal, se reportó el socavamiento de 1 Puente en una vía de 1er orden a las orillas del caudal, dejándolo destruido con el paso cerrado</td></tr><tr><td>Situación actual:</td><td>Personal técnico en el sitio reportó la desconexión de luminarias en el sitio, colocación de cintas para recalcar el cierre del puente y personal de tránsito colaborando con la novedad del evento.</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público destruido (puente)</td></tr><tr><td>Acciones de respuesta:</td><td>CNEL realizó la desconexión de luminarias en el puente.CTE se mantiene en el sitio colaborando con el paso vehicular.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/CTE/CNEL.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/c142400908d85658090f73f5c6576b0f1d189b741573251f75d1c41d63119c10.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Naranjito/Naranjito, Cabecera Cantonal/Recinto La Primavera.</td></tr><tr><td>Antecedentes:</td><td>El 10/03/2023, a causa de las lluvias de la madrugada se produjo el desborde del estero El hediondo, provocando el socavamiento de las bases de un puente que es la única vía de acceso del recinto La Primavera - al recinto San Francisco</td></tr><tr><td>Situación actual:</td><td>GAD Cantonal realizó recorridos por el sector y menciona que el estero EL Hediondo se encuentra en su cauce normal, ya que ha dejado de llover, sin embargo el puente sigue inhabilitado.</td></tr><tr><td>Afectaciones:</td><td>- 1 puente afectado- cultivos afectados (se encuentra bajo evaluación)- viviendas afectadas (se encuentra bajo evaluación.)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal realizó recorrido por el sector para dar seguimiento del evento Se coordina con Prefectura para que realice los trabajos respectivos</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/UGR GAD Naranjito.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/6793dc4bd528547714a7a4f14276d47b92d615d3040f9b53ec4d05579ecd47e9.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Simón Bolívar/Simón Bolívar, cabecera cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023, por lluvias registradas la noche de ayer y madrugada de hoy, se desbordó el río Los Amarillos ocasionando inundación en el sector.</td></tr><tr><td>Situación actual:</td><td>GAD Cantonal realizó la apertura del albergue municipal “Centro Integral Gallo de Oro”, en donde se encuentra una familia albergada hasta que termine de drenar el agua completamente del sector, las demás familias afectadas se mantienen en su inmuebles, cabe mencionar que el río Los Amarillos, al momento se encuentra con tendencia a disminuir su nivel, pero siguen sectores con acumulación agua, personal de OOPP Municipal se mantiene realizando trabajos de limpieza a las riberas del río en los sectores que fueron afectados.</td></tr><tr><td>Afectaciones:</td><td>- 20 viviendas afectadas- 23 familias, 84 personas afectadas (las familias se mantienen en sus inmuebles</td></tr><tr><td>Acciones de respuesta:</td><td>Obras Públicas Municipal se encuentra realizando trabajos de limpiezas en las riberas del ríoMSP se encuentra con una brigada médica y fumigación por sectores afectados COE Cantonal se mantiene activo</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Simón Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/cfe3b601d48c68ff8ae561ec3df18a1ab4f9adc9f75fc6c949128d68f2ab5327.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Milagro/Milagro, Cabecera Cantonal/varios sectores (Calle Guayaquil y Pedro Carbo, Ciudadela Acuarela de Río, Las Margaritas, Av. Paquisha, El Chobo).</td></tr><tr><td>Antecedentes:</td><td>Por las fuertes precipitaciones suscitadas en la tarde del 08/03/2023 al momento se reportan calles afectadas con acumulación de agua. CB informa que por producto de las lluvias constante que se están generando se han visto afectados nuevos sectores por inundaciones.SGR en coordinación con Cruz Roja y entidades locales realizan levantamientos de información EVIN, en los sectores afectados por época lluviosa, así mismo se realiza la apertura de un albergue en un establecimiento Educativo el Colegio 17 de septiembre.</td></tr><tr><td>Situación actual:</td><td>GAD Cantonal indica que sigue realizando levantamiento de información y que el día de ayer ingresó cuatro familias, 10 personas al albergue. El nivel del río se mantiene con tendencia a disminuir su caudal.</td></tr><tr><td>Afectaciones:</td><td>- 44 viviendas afectadas- 47 familias afectadas (se encuentran en Alojamiento Temporal)- 170 personas evacuadas- 60% servicio de alcantarillado afectado</td></tr><tr><td>Acciones de respuesta:</td><td>GAD cantonal realiza levantamiento de información EVIN</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Milagro.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 11 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/f94235c6acd872e05fd97c8ccf0e068163b19fadb00dfda3e0109fe2fea23dd9.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Isidro Ayora/Cabecera Cantonal/San Agustín.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias registradas el día 07/03/2023, se produjo el desbordamiento del río Bachillero, mismo que afecta a varias viviendas y a cultivos de ciclo corto, (maíz, Sandía, Melón, etc.).</td></tr><tr><td>Situación actual:</td><td>UGR Cantonal indica que el río Bachillero al momento se encuentra con tendencia a disminuir su nivel y el agua ha drenado de las viviendas, por lo que las familias se mantienen en sus inmuebles.Adicional indicó que aún existen sectores con acumulación de agua, la cual se espera que con el transcurso de las horas siga drenando.</td></tr><tr><td>Afectaciones:</td><td>- 116 Viviendas afectadas- 116 familias, 464 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>Directora zonal del SGR realizó entrega de asistencia humanitaria a 45 familias que resultaron más afectadas.GAD Cantonal, CB Cantonal realizaron apoyo en la entrega de asistencia humanitaria.MSP acudió con una brigada médica para realizar atención a las familias afectadasGAD Cantonal realizó levantamiento de información en los sectores afectadosOOPP Municipal realizó trabajos de limpieza de caminos y riberas del ríoGAD Cantonal realizó levantamiento de información en los sectores afectadosOOPP Municipal realizó trabajos de limpieza de caminos y riberas del ríoGAD Provincial realizó inspección</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/Directora zonal 5 SGR/GAD Cantonal Isidro Ayora.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/ceacf2aa012a3f3a43054679c78b5c0a66f2ce02944f35168f0f73215086cc6c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Balzar/Cabecera Cantonal/varios sectores, Quiebradroga, Chimborazo, Santa Genara, El Modelo.</td></tr><tr><td>Antecedentes:</td><td>El 05/03/2023, técnico de la UGR del GAD Cantonal de Balzar informa que a causa de las lluvias registradas en la madrugada, se produjo el desbordamiento del río Puca, mismo que afectó parcialmente a un puente peatonal que une el camino principal Balzar, Las Trampas y Santa Genara. Además menciona que existen afectaciones a las plantaciones de arroz, maíz, cacao, verde y naranja. El río se encuentra desbordado en el sector El Modelo.</td></tr><tr><td>Situación actual:</td><td>Mediante informe EVIN técnico de la UGR indica que realizó levantamiento de información e indica que las familias afectadas siguen pernoctando en sus mismas viviendas.El río Puca se encuentra con tendencia a disminuir de nivel</td></tr><tr><td>Afectaciones:</td><td>- Cultivos afectados (Se encuentra en la fase de levantamiento en hectáreas)- 1 puente peatonal afectado.- 111 viviendas afectadas- 111 familias, 444 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>UGR del GAD Cantonal de Balzar realizó el respectivo levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/GAD Cantonal Balzar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/db2da0a7dd75ff4137fdebbd783ef378fe81e15c48a653981960c338ea82b329.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Santa Elena/Santa Elena/Chanduy/Bajada de Chanduy.</td></tr><tr><td>Antecedentes:</td><td>El 06/03/2023, a causa del desborde del río La Camarona, se vio afectado el recinto Bajada de Chanduy, varias viviendas resultaron inundadas y familias damnificadas.</td></tr><tr><td>Situación actual:</td><td>SGR reportó que el río “Bajada de Chanduy” se encuentra con caudal bajo pero existe un corte en la vía causado por la por erosión por lo que el acceso hacia los recintos es a pie.Personal técnico no pudo avanzar al considerar la distancia que hay entre la zona afectada y la comunidad.</td></tr><tr><td>Afectaciones:</td><td>- 300 familias afectadas (1200 personas)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR y Petroecuador realizaron avanzada hasta los recintos afectados por aislamiento.UPREA-SGR coordina con MTOP para asistencia en territorio</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Santa Elena/UGR Cantonal/MSP Distrito 24D01.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/be074e522d35cf4de59ebe73b7d0b5a25d51fb980bade54c67af779aa8f199c2.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Alfredo Baquerizo Moreno (Jujan)/Alfredo Baquerizo Moreno (Jujan), Cabecera Cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en la madrugada del 21/02/2023 se desbordó el Río Chilintomo; la madrugada del 22/02/2023, se desbordó el río Los Amarillos. Jefe Político realizó recorridos en el sector e informó que debido al desbordamiento se produjo el colapso del muro de contención afectando cultivos de arroz y cacao; también se produjo el ingreso de agua a varias viviendas y a la Escuela Fiscal Eduardo Alarcón Soto, por lo que se suspendieron las clases en la jornada matutina.</td></tr><tr><td>Situación actual:</td><td>UGR - GAD Cantonal informa que en el sector San Antonio se realizó la colocación de sacos con material pétreo en la ribera del río.</td></tr><tr><td>Afectaciones:</td><td>- 1 establecimiento educativo afectado (Ingreso de agua al predio)- Cultivos afectados (la cantidad de cultivos está bajo verificación)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 12 de 21

<table><tr><td></td><td>- Calles inundadas- 283 viviendas afectadas- 283 familias, 889 personas afectadas (se mantienen en los mismos inmuebles)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal coordinó la colocación de sacos de arena en las riberas del río en el sector El Tránsito.Prefectura se encarga de los trabajos de Mitigación y limpieza del caudal.SGR - Umeva Guayas dará seguimiento al evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas UGR - GAD Cantonal Alfredo Baquerizo Moreno (Jujan)</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/7941b384a82893bd49526d4ef4da369d5de024a12a4dc8ef8a2903d4052ca0f6.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/Febres Cordero/ Rcto. Plaza De Chilintomo - Rcto. La Lidia - Rcto. Las Tolas - Rcto. La Alambra - Rcto. Las Cañitas - Rcto. Las Jaguas - Sector La Avelina - Río Chilintomo.</td></tr><tr><td>Antecedentes:</td><td>Debido a las lluvias suscitadas en la noche del 25/02/2023, se reportó ingreso de agua en las viviendas a causa del desbordamiento del río Chilintomo, actualmente el río continúa desbordado con presencia de agua en las viviendas y las familias se mantienen en sus hogares.</td></tr><tr><td>Situación actual:</td><td>Luego de culminar el respectivo levantamiento de información en la zona afectada, se realizó la dotación de ayuda humanitaria a las familias del lugar, actualmente el río descendió en el sitio, pero existe agua estancada en los alrededores, las familias afectadas se mantienen en sus hogares y la familia damnificada se encuentra en casa acogiente.</td></tr><tr><td>Afectaciones:</td><td>- 86 viviendas afectadas (caña y madera)- 86 familias afectadas.- 240 personas afectadas.- 1 vivienda destruida (caña-madera)- 1 familia damnificada- 5 personas damnificadas (casa acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>- UGR Babahoyo realizó entrega de ayuda humanitaria el 01/03/2023.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Babahoyo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/1430823c631588d59c623cc22063926af1bab547a4b9fecd0f583164e499c883.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Santa Elena/Santa Elena/Cabecera cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 21/02/2023, debido a las lluvias suscitadas en el cantón, se reportó varias viviendas afectadas, calles anegadas y comunidad aislada.Por reporte de la UGR cantonal, el recinto La Frutilla de la parroquia Simón Bolívar se encuentra aislada, la única vía de acceso se vio interrumpida por un corte en un pase de río de la zona que por la fuerte lluvia del 25/02/2023 aumento su caudal.</td></tr><tr><td>Situación actual:</td><td>Por solicitud de la UGR cantonal, SGR entregó asistencia humanitaria a 3 familias afectadas por inundaciones en la cabecera cantonal.Mediante articulación entre el Ministerio de Defensa y la SGR se contó con un helicóptero para movilizar 120 raciones alimenticias para las 120 familias del recinto La Frutilla de la parroquia Simón Bolívar que se encuentran aisladas por corte de vía.</td></tr><tr><td>Afectaciones:</td><td>- 123 Familias afectadas (315 personas).- 3 Viviendas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>COE cantonal se mantiene activo.SGR entregó asistencia humanitaria (kits de dormir, aseo y KPRH)UGR cantonal realizó la entrega de raciones de alimentos a las familias afectadas por Aislamiento.FFAA colaboró con helicóptero para movilidad humana y logística.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Santa Elena/UGR Cantonal/Gobernación de Santa Elena.</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/c7fb583251905756bdd360c7c4080a190d906ba295d46d40b3994c6a37277c14.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Gualaceo/Gualaceo/Puente Certag.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2023, por causas de las lluvias se suscitó un deslizamiento que afectó en su totalidad una estructura de madera y zinc (aparentemente utilizada como bodega)</td></tr><tr><td>Situación actual:</td><td>Al momento del evento se encontraban dos personas al interior como resultado del mismo 1 persona fallecida y 1 persona herida.</td></tr><tr><td>Afectaciones:</td><td>- 1 persona fallecida.- 1 personal herida.- 1 bien privado destruido.</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Gualaceo colabora en el lugar del evento, SGR coordina con UGR Gualaceo para realizar levantamiento de información.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Cañar.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 13 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/e0ec038c9013e4c2880ff735b168568bcabf33505da43afc202a935680a4a346.jpg)


## Colapso estructural

<table><tr><td>Localización:</td><td>Cañar/La Troncal/Pancho Negro/Entrada a La Colonia 10 de agosto</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 a causa de las lluvias se suscitó la creciente del río Ruidoso mismo que ocasionó el colapso del puente (s/n). Vía alterna La Puntilla-Colonia 10 de Agosto</td></tr><tr><td>Situación actual:</td><td>Con fecha 10/03/2023 se realizó la reunión del COE Cantonal para realizar un análisis de la situación actual del cantón por las lluvias suscitadas. Adicional el caudal del río ruidoso ha retornado a su cauce normal.</td></tr><tr><td>Afectaciones:</td><td>-1 Puente destruido</td></tr><tr><td>Acciones de respuesta:</td><td>Unidad de Gestión de Riesgos La Troncal realizaron inspección en el lugar del evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR La Troncal.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/d0611acc788c147285cbaafe6decb577c156f5e5472aa03bc2e313a84e793521.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Morona Santiago/Morona/Macas/Puente sobre el río Upano-Puente sobre el río Copueno, vía Macas-Puyo [E45].</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas durante la madrugada del 04/03/2023, se produjo el descenso de lahares y la posterior acumulación en la confluencia del río Volcán y río Upano generando el represamiento del mismo, el cual se liberó de manera natural, sin embargo, durante las horas de la noche se presentó el incremento de caudal que provocó el desbordamiento y la posterior inundación de la variante que se encuentra establecida en el lecho del río.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se encuentra parcialmente habilitada al tránsito vehicular y peatonal., la vía alterna es Puyo-Y de Santa Ana-Sevilla Don Bosco-Seipa-Sucua-Macas.</td></tr><tr><td>Afectaciones:</td><td>- 240 Metros lineales.</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP en coordinación con el Cuerpo de Ingenieros del Ejército, Gobierno Provincial de Morona Santiago y Empresa Privada se mantienen realizando actividades de reconstrucción de la variante sobre el lecho del río Upano, recomiendan conducir con precaución debido a la presencia de maquinaria en el lugar.</td></tr><tr><td>Fuentes de información:</td><td>SGR-CZ6 Unidad de Monitoreo Morona Santiago/SIS-ECU911-Macas/MTOP/PPNN.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/61ee0071b85b8081e677432006a36041c4b6b0609ccabc7f61226a5b84b0f382.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Morona Santiago/Limón Indanza/San Antonio /Puente sobre el río Namangoza.</td></tr><tr><td>Antecedentes:</td><td>Producto de las lluvias del 28/02/2023 se produjo un deslizamiento que generó el colapso estructural de un puente colgante tipo peatonal sobre el río Namangoza,</td></tr><tr><td>Situación actual:</td><td>Al momento la vía permanece cerrada, las personas se mantienen haciendo uso de canoas con el fin de cruzar el río hacia las comunidades.</td></tr><tr><td>Afectaciones:</td><td>- 15 metros lineales- 1 Puente destruido</td></tr><tr><td>Acciones de respuesta:</td><td>El Alcalde del Cantón Limón Indanza junto al Prefecto de Morona Santiago y su equipo técnico realizaron una reunión para la elaboración de un informe, con la finalidad de evaluar y analizar los estudios para ejecutar como manera preventiva a corto plazo, la construcción de una tarabita. SGR se mantiene en constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR-CZ6 Umeva-Morona Santiago/ Tenencia Política/ UGR-GAD-Cantonal Limón Indanza.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/57bb209204f97057c42e7035e40741c5ce507a332a0a3e67eaadb1e63fd326c2.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/Rosas, Bellavista, Tamboloma, Chunazana.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Secretaría de Gestión de Riesgos declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 06/03/2023 técnico de la UGR Nabón informa que la segunda etapa de las obras de mitigación iniciaron con la construcción del primero de cinco muros de contención hasta el momento con un avance del 3%, los trabajos ocasionan el cierre temporal de la vía Ramada-Nabón sector trancapata, vía alterna La Ramada-Chunazana-El Salado-Nabón</td></tr><tr><td>Afectaciones:</td><td>- 50 metros de vía afectada (vía habilitada, sector El Progreso)- 84 familias afectadas (238 personas afectadas)- 60 familias damnificadas (162 personas damnificadas)- 40 metros de vía afectados (vía Cerrada, sector Trancapata)- 60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)- 1 Casa comunal afectada con cuarteaduras- 84 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 59 viviendas destruidas.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)- Iglesia demolida por los daños estructurales presentados- Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>El 25/11/2022, UGR Nabón realizó un nuevo levantamiento de información y se mantiene en monitoreo constante.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 14 de 21

Fuentes de información: 

SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/ec584403ffaa6c92ae4fef00ecbe7484930d1bd477102bb0cbd25596819483bd.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Cañar/Cañar/Cañar/Cuchucun-Cruz Loma.</td></tr><tr><td>Antecedentes:</td><td>GAD Cantonal de Cañar informó que a partir del 13 de Octubre de 2022 por la época lluviosa y mal manejo del agua de riego se reportó un deslizamiento que afecta viviendas del sector. Con fecha 14 de Febrero del 2023 se activó el COE Cantonal donde la máxima autoridad del cantón solicita la activación de las mesas técnicas y grupos de trabajo para la atención de la emergencia. Intervención del MIDUVI y GAD PROVINCIAL.</td></tr><tr><td>Situación actual:</td><td>Con fecha 03/03/2023 se reunió el COE Cantonal para realizar un análisis de las acciones que se van a realizar por el evento.</td></tr><tr><td>Afectaciones:</td><td>- 22 viviendas afectadas- 4 viviendas destruidas- 6 familias damnificadas- 16 personas damnificadas (permanecen en casa de familia acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR mantiene un monitoreo constante del evento y levantamiento de información. SGR realizó inspección técnica para levantamiento de información, Director y Técnico asisten a la reunión del COE.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Cañar.</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/8d087f386431d314fb78d944bf4d07bee2856036eee3bd3754e6f356b7e68f95.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Portovelo/Salatí/Sector Chunchi, Pueblo Viejo.</td></tr><tr><td>Antecedentes:</td><td>El 13/03/2023, por lluvias presentadas en la madrugada del lunes se produjo un deslizamiento de tierra que obstaculiza el caudal del río Granadillos.</td></tr><tr><td>Situación actual:</td><td>Al momento el río Granadillo continúa represado a causa del deslizamiento, poniendo en riesgo a los sectores bajos como Ambocas, Chunchi, Vado Alto, Los Amarillos y El Pindo.</td></tr><tr><td>Afectaciones:</td><td>---</td></tr><tr><td>Acciones de respuesta:</td><td>COE Cantonal de Portovelo se encuentra activo y en sesión permanente desde el 18/02/2023 y coordina acciones para realizar un plan de evacuación de personas que habitan en las riberas del río de los sectores bajos; y, gestiona recurso aéreo para realizar sobrevuelo en el sitio, para analizar situación y posterior articular las acciones pertinentes por el evento presente.SGR estuvo presente en la reunión de COE Cantonal y brindó asesoramiento a UGR del GAD Portovelo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/MDG/J.P Portovelo/Cuerpo de Bomberos de Portovelo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/de064109202f0c6c351895460c123319e11ceb6e17ae477422e72830d4df73b5.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Arenillas/Chacras/Sector La Isla.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias intensas registradas en la madrugada del 09/03/2023, provocó el desbordamiento de río Zarumilla perteneciente a Perú, ha afectado cultivos en la zona agrícola de la provincia de El Oro.</td></tr><tr><td>Situación actual:</td><td>Mediante reporte emitido y corregido del parte del MAG, se vuelve a rectificar los datos de afectaciones. Además, en relación al río Zarumilla se encuentra con tendencia a disminuir</td></tr><tr><td>Afectaciones:</td><td>- 12 hectáreas de cultivo afectados parcialmente (8 ha. de cacao y 4 ha. de limón).- 8 hectáreas de cultivo perdidos (8 ha. de plátanos destruidos)- 30 productores afectados por la pérdida total y parcial de sus cultivos</td></tr><tr><td>Acciones de respuesta:</td><td>SGR mantiene monitoreo con MAG para gestionar acciones a los productores afectados y dar seguimiento a la evacuación de aguas retenidas en el sitio.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/MAG.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/5c27f5af80c9bb72ee2172199445ef71196bb087f85f1077811c2ce51dd8ec58.jpg)


## Colapso estructural

<table><tr><td>Localización:</td><td>El Oro/Pasaje/Uzhcurrumi/Cune, Vía Pasaje - Uzhcurrumi.</td></tr><tr><td>Antecedentes:</td><td>El 08/03/2023 por lluvias, se suscitó el colapso de una alcantarilla y la pérdida de la mesa vial de tercer orden; además se registra la caída de un vehículo hacia la quebrada (NN), su ocupante se encuentra en buen estado de salud.Cabe mencionar que esta vía estaba siendo utilizada como alterna por el cierre de la Vía Cuenca - Girón - Pasaje - Gramalote.</td></tr><tr><td>Situación actual:</td><td>Por lluvias se registra el colapso del puente peatonal ubicado en el sitio mismo que era utilizado por moradores de la parroquia, así mismo se reporta el colapso del paso provisional realizado por la prefectura.La vía se mantiene cerrada al tránsito vehicular.</td></tr><tr><td>Afectaciones:</td><td>- 10 m de vía afectada. (Cerrada al tránsito vehicular)- 1 bien privado afectado. (Vehículo que calló a la quebrada NN)- 1 bien público afectado (alcantarilla)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 15 de 21

## - 1 puente colapsado

<table><tr><td>Acciones de respuesta:</td><td>J. P. de Pasaje confirmo el eventoSGR coordina con UGR GAD Provincial la atención en el sitio.Obras Públicas (OO.PP.) del GAD provincial realizan trabajos para remediación de la vía.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/GAD Parroquial/Cuerpo de Bomberos de Pasaje.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/d10fe4e8686a4c920fe6e8217cb81d655afdb20be76dcab140fcca14db93b8c1.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Loja/Saraguro/Manu/Manú, vía Manú-Udushi.</td></tr><tr><td>Antecedentes:</td><td>El 19/02/2023, por lluvias presentadas durante la madrugada, se produjo el colapso del puente en la vía de tercer orden (Vía Manú-Udushi).</td></tr><tr><td>Situación actual:</td><td>Director de VIALSUR confirmó que se encuentra en proyecto la reconstrucción del puente destruido mientras tanto los trabajos de mantenimiento de la vía alterna: Manú-Durazno-Udushi serán permanentes para garantizar el paso del tránsito vehicular.</td></tr><tr><td>Afectaciones:</td><td>- 01 puente colapsado. (Río Panasco).- 01 puente afectado. (Quebrada Sigsipamba).- vía de tercer orden cerrada. (Vía Manú-Udushi).</td></tr><tr><td>Acciones de respuesta:</td><td>GAD-P - VIALSUR, mantiene activo los trabajos de mantenimiento de vía alterna.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/GAD Provincial-VIALSUR.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/1a84f261ca1b85b6411f265b4f74a083b1af0447cd18717fe40389539c8e497a.jpg)


## Inundación

<table><tr><td>Localización:</td><td>El Oro/Portovelo/Salatí/Varios Sectores (Ambocas, El Chunchi, El Vado Ancho).</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias registradas durante la noche, se registró el desbordamiento de los ríos Ambocas y Granadillo causando afectaciones en puentes, casas y calles de distintos sectores.</td></tr><tr><td>Situación actual:</td><td>Mediante reporte remitido por MAG, reportan afectaciones causadas por presente evento peligroso en el Sitio Chunchi.</td></tr><tr><td>Afectaciones:</td><td>- 2 puentes destruidos (1 puente vehicular en el sitio Chunchi y 1 puente peatonal en el sitio Vado Ancho).- 24 familias de 96 personas afectadas indirectamente (13 familias de 52 personas en Chunchi y 11 familias de 44 personas en Vado Ancho).- 2 puentes afectados (Puente vehicular de Ambocas está habilitado y puente de Lourdes habilitado).- 4 viviendas afectadas (por ingreso de agua, lodo y presentan en la parte posterior socavamiento, sector Ambocas).- 4 familias de 17 personas afectadas directamente (3 familias de 14 que fueron evacuadas a refugio temporal retornaron a sus viviendas).- 2 bienes privados destruidos (1 chanchera y 1 moto en Chunchi).- 1 bien público afectado (sistema de captación de agua en el sitio Lourdes).- 7 hectáreas de cultivo de yucas afectadas.- 32 productores afectados (21 productores de los cultivos y 11 propietarios de animales).- 52 animales muertos (12 bovinos, 5 caballos, 5 cerdos, 30 gallinas).</td></tr><tr><td>Acciones de respuesta:</td><td>SGR mantiene monitoreo con puntos focales, para verificar los avances en los trabajos de remediación en los distintos sitios afectados.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo El Oro/Uprea El Oro.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/3bde9e55b46e64cf44ce2686a6b96433edd04edd04f25d95356d9b8b03eab4e7.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Loja/Chaguarpamba/El Rosario/Trapiche, vía a la costa [E50].</td></tr><tr><td>Antecedentes:</td><td>El 18/02/2023, por lluvias presentadas en la tarde, se produjo el desbordamiento del río Pindo provocando la inundación de una vivienda y la afectación a la vía principal.</td></tr><tr><td>Situación actual:</td><td>Una vez revisada el Acta de la Sesión del COE Cantonal, resolvió: ACTIVAR El COE cantonal de Chaguarpamba por época lluviosa con la finalidad de poner en funcionamiento todos los componentes del mismo para dar la atención y respuesta efectiva a la emergencia.02 familias conformadas por 07 personas se encuentran albergadas por seguridad en las instalaciones de la Escuela Olimpia Mendieta.</td></tr><tr><td>Afectaciones:</td><td>- 3 familias damnificadas conformadas por 06 personas.- 24 familias afectadas conformadas por 70 personas.- 6 puentes peatonales colapsados (puentes de conexión entre comunidades del sector).- 3 viviendas destruidas.- 24 viviendas afectadas.- 01 puente vehicular afectado (vía de segundo orden).- 20 metros de longitud aproximadamente de vía- 01 bien privado destruido (vehículo arrastrado por la corriente).</td></tr><tr><td>Acciones de respuesta:</td><td>El COE Cantonal se encuentra activadoCuerpo de Bomberos de Chaguarpamba realizó labores de limpieza de las viviendas afectadas*GAD Chaguarpamba realizó labores de limpieza en los sectores afectados por la inundación*</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 16 de 21

<table><tr><td></td><td>Autoridades y personal técnico de SGR coordinó reunión de mesa intersectorial con las diferentes carteras de estado_MTOP realiza trabajos de limpieza en la vía principal Chaguarpamba - Río Pindo (Vía parcialmente habilitada)GAD Provincial Loja (VIALSUR) realizó trabajos de limpieza y habilitación vial (vía de segundo orden)</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja-Zamora Chinchipe/Cuerpo de Bomberos de Chaguarpamba/VIALSUR.</td></tr></table>

## ZONA 8

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/05170e8b9a3c93235162a171991fa0910205476eaace718cbfa766003efaf601.jpg)



Inundación


<table><tr><td>Localización:</td><td>Guayas/Guayaquil/Posorja/varios sectores (Barrios Quito, Paquito Lotización San Francisco, Nueva Posorja, Nuevo Amanecer, 8 de Julio).</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023, a causa de las lluvias que se registran al momento, se produjo el desbordamiento de tres canales de aguas lluvias, al momento se reporta calles y viviendas inundadas.</td></tr><tr><td>Situación actual:</td><td>Presidente Parroquial del GAD Posorja informa que los canales de aguas lluvias han disminuido su nivel y al momento no se visualiza agua estancadas por los sectores que resultaron afectados, adicional informa que en la reunión del COPAE que se llevó ayer quedaron con los siguientes acuerdos: Interagua realizará limpieza de los canales y GAD Parroquial y VPC realizaran levantamiento de información por afectaciones en viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 12Viviendas afectadas- 12 familias afectadas, 48 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>SGR realizó recorridos por sectores afectadosPresidente Parroquial del GAD Posorja realizó recorrido.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ8 Unidad de Monitoreo Guayas/Presidente de la Junta Parroquial Posorja.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/828bd2e8ae577e3ba0d4fb79e95091558a2632418cd38783f256364777ca4bfd.jpg)



Inundación


<table><tr><td>Localización:</td><td>Guayas/Guayaquil/Juan Gómez Rendón Progreso/Cerecita - varios sectores.</td></tr><tr><td>Antecedentes:</td><td>EL 07/03/20233, a causa de las lluvias registradas en el lugar, se produjo el desbordamiento del río La Camarona, mismo que afectó a la vía de primer orden, la cual al momento se encuentra habilitada.</td></tr><tr><td>Situación actual:</td><td>Mediante informe EDAN técnico de la UGR indica que realizó levantamiento de información y entrega de asistencia humanitaria a las familias afectadas, las mismas que realizaron las debidas limpiezas de sus inmuebles para seguir pernoctando.El río La Camarona se encuentra con tendencia a disminuir su caudal</td></tr><tr><td>Afectaciones:</td><td>- 10 Viviendas afectadas- 10 familias, 43 personas afectadas- 100 metros de vía, se encuentra habilitada</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial se encuentra en el punto realizando trabajos.Técnicos de GAD Cantonal realizaron el respectivo levantamiento de información y entrega de asistencia humanitaria a las familias afectadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ8 Unidad de Monitoreo Guayas/UGR - GAD Cantonal Guayaquil/Ministerio de Salud Pública.</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/bc5ccad2be9b575e89960a135c3641bac97f68d2552adf7c32d7f25a3f271fc7.jpg)



Vendaval


<table><tr><td>Localización:</td><td>Pichincha/San Miguel de los Bancos/Los Bancos/Barrios Nuevo Amanecer y 6 de Diciembre.</td></tr><tr><td>Antecedentes:</td><td>El 11/03/2023, producto de las condiciones climáticas se produjo un vendaval que afectó a 2 viviendas en los barrios mencionados ocasionando que sus techos se desprendan.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas permanecen en las mismas en un área que no se vio afectada</td></tr><tr><td>Afectaciones:</td><td>- 2 viviendas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos Los Bancos colaboraron con la confirmación y una inspección.Se solicitó la presencia del GAD Cantonal de Los Bancos para que realice una evaluación de daños y colaborar con materiales para la reconstrucción de ser necesario.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ9 Unidad de Monitoreo Pichincha/Cuerpo de Bomberos de Los Bancos.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/e0fbff728531894fa7bd61d671208ac9984016df4a919cdba23a7e9eb2965b41.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Pichincha/Quito/Nayón/Vía hacia el Rancho San Francisco.</td></tr><tr><td>Antecedentes:</td><td>El 01/03/2023 debido a la inestabilidad del talud se suscitó un deslizamiento en el sitio, este tipo evento es recurrente en el sector, por lo que se solicitó una inspección técnica debido a que en la parte alta del mismo existen viviendas que podrían ser afectadas.</td></tr><tr><td>Situación actual:</td><td>El día de hoy 13/03/2023 debido a la fuerte lluvia de la tarde se produjo nuevamente un deslizamiento por lo que la EPMAPS suspendieron los trabajos debido a la fuerza del caudal en el rio Monjas, se planifica un sobrevuelo de evaluación para mañana 14 de marzo a partir de las 8 am.</td></tr><tr><td>Afectaciones:</td><td>--</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 17 de 21

Acciones de respuesta: 

GAD Cantonal EPMAPS realiza los trabajos de encausamiento del rio Monjas para mitigar los deslizamientos continuos en el sitio. 

Fuentes de información: 

SGR CZ9 Unidad de Monitoreo Pichincha EPMAPS/GAD Cantonal COEM. 

Monitoreo de estado de vías afectadas por eventos peligrosos 

VÍAS DE PRIMER ORDEN: 

## 09 vías de primer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Guayas</td><td>Guayaquil</td><td>Tarqui</td><td>Av. Modesto Apolo Ramírez en dirección al túnel San Eduardo para salir a la vía a Daule.</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Chimborazo</td><td>Alausí</td><td>Alausí</td><td>frente al barrio La Esperanza, vía Alausí - Chunchi - Cuenca [E-35]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>entrada a la vía Alterna</td><td>DESLIZAMIENTO</td><td>15</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>Vía a La Vitalia - 1er orden</td><td>SOCAVAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz de Pineda</td><td>vía El Salado - San Luis [E45]</td><td>ALUVION</td><td>---</td><td>04/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Napo</td><td>Chaco</td><td>Gonzalo Díaz de Pineda</td><td>Puente sobre el río Marker, vía E45 San Luis -El Reventador</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>22/02/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Gramalote, km. 112 vía Cuenca-Girón - Pasaje</td><td>INUNDACIÓN</td><td>50</td><td>22/02/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Manabí</td><td>Manta</td><td>San Lorenzo</td><td>Ruta del Spondiylus San Lorenzo - Santa Rosa [E15]</td><td>OLEAJE</td><td>1200</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>875</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>


Reporte de monitoreo de amenazas y eventos peligrosos - No 0146
Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 18 de 21



28 vías de primer orden parcialmente habilitadas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Pifo</td><td>10 minutos Virgen de Papallacta, vía Papallacta - Baeza [E20]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39, vía Cuenca-Girón-Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>50</td><td>14/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Bolívar</td><td>San Miguel</td><td>Balsapamba</td><td>Varios Sectores: Alungoto, La Ceiba, vía San Miguel-Balzapamba [E 491]</td><td>DESLIZAMIENTO</td><td>135</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>La Piedra vía Guanujo-Echeandía [E494]</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Salida de Santa Rufina hacia, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Bolívar</td><td>Chimbo</td><td>La Magdalena</td><td>Gualasay, vía Chimbo - El Cristal</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Vía Arenillas - Las Lajas [E25]</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>Km 61, vía Paute Guarumales Méndez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Manabí</td><td>Puerto López</td><td>Salango</td><td>La Rinconada 5 Cerros, vía Puerto López - Santa Elena [E15].</td><td>HUNDIMIENTO</td><td>4</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1- Ruta desde la E10 Gualupe - San Juan de Lachas (Carch) - por la E 182 Gualchan - Chical - Maldonado - Tullán - Ibarra 2- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cobhuasqui - Tumbabrio.</td></tr><tr><td>20</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>21</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>22</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>23</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>24</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>25</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>26</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>27</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>28</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago -San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0146 Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 19 de 21

VÍAS DE SEGUNDO ORDEN 

## 05 vías de segundo orden cerradas

<table><tr><td></td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Imbabura</td><td>San Miguel de Urcuqui</td><td>San Blas</td><td>Santa Cecilia</td><td>SOCAVAMIENTO</td><td>20</td><td>26/10/2022</td><td>Vía antigua de Santa Cecilia - Timbuyacu.</td></tr><tr><td>2</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>4</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>5</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 13 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Bolívar</td><td>Caluma</td><td>Caluma</td><td>Vía Charquiyacu - Pasagua</td><td>DESLIZAMIENTO</td><td>500</td><td>13/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>Las Guardias, vía a Pailaloma</td><td>DESLIZAMIENTO</td><td>8</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>La Soberana, vía Pallatanga - Cumandá [E-487].</td><td>SOCAVAMIENTO</td><td>--</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>El Oro</td><td>Santa Rosa</td><td>Victoria</td><td>Km 18, vía Buenavista - San Juan de Cerro Azul [E-585]</td><td>ALUVION</td><td>150</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Loja</td><td>Catamayo</td><td>Zambi</td><td>Varios Sectores (Chorrera y Peña Azúl), vía a Portovelo.</td><td>DESLIZAMIENTO</td><td>50</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>Km 47, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>25</td><td>06/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Guapo, vía Colta -Pallatanga [E-487]</td><td>ALUVIÓN</td><td>40</td><td>21/02/2023</td><td>Riobamba - Guaranda - Babahoyo - Guayaquil</td></tr><tr><td>8</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>15</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>9</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>10</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>11</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr></table>

## VÍAS DE TERCER ORDEN:


17 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Sitio Quera, vía Quera - Chilla</td><td>DESLIZAMIENTO</td><td>8</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>vía Las Guardias-Matapalo/Chaupiyacu</td><td>DESLIZAMIENTO</td><td>--</td><td>13/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Cotopaxi</td><td>Pangua</td><td>Ramón Campaña</td><td>Por el Puente de Angamarca.</td><td>DESLIZAMIENTO</td><td>--</td><td>12/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Bolívar</td><td>San Miguel</td><td>San Pablo</td><td>vía Sicoto-Guamalán, Sandalán, Pailaloma</td><td>DESLIZAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Bolívar</td><td>Las Naves</td><td>Cabecera Cantonal</td><td>Recinto La Unión - vía Voluntad de Dios.</td><td>DESLIZAMIENTO</td><td>100</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>La Valdivia - río Clementina</td><td>INUNDACIÓN</td><td>30</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>La Estrella - Cdla. Felipe Abud - río Cristal</td><td>SOCAVAMIENTO</td><td>800</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Cañar</td><td>Biblián</td><td>Nazón</td><td>Capulisloma</td><td>SOCAVAMIENTO</td><td>30</td><td>08/03/2023</td><td>La Hacienda.</td></tr><tr><td>9</td><td>Cotopaxi</td><td>La Maná</td><td>El Triunfo</td><td>Estero Hondo, vía La Maná - Pangua</td><td>SOCAVAMIENTO</td><td>--</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>Cune, Vía Pasaje - Uzhcurrumi</td><td>COLAPSO ESTRUCTURAL</td><td>10</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0146
Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 20 de 21


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>12</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur</td><td>INUNDACIÓN</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>14</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>16</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>17</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>955.9</td><td>20/01/2021</td><td>Ninguna</td></tr></table>

## 07 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Pasaje</td><td>Uzhcurrumi</td><td>El Limón, vía Uzhcurrumi - Chilla</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Caserío Guanando, Vía a Guanando - Cahuaji Bajo</td><td>DESLIZAMIENTO</td><td>--</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>El Oro</td><td>Marcabelí</td><td>El Ingenio</td><td>La Palmerita, Vía La Palmerita - El Ingenio</td><td>SOCAVAMIENTO</td><td>8</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>El Oro</td><td>Portovelo</td><td>Morales</td><td>Vía Morales - La Chorrera</td><td>DESLIZAMIENTO</td><td>20</td><td>27/02/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>7</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>


4. Declaratorias emitidas por el SGR (vigentes en orden cronológico)


<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/094fbc57f983b0392c5aa7dd31d03164fe06dab13ff3a83b38283e82024fd6d7.jpg"/></td><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua.</td><td>Amarilla</td><td>17/02/2023</td><td>Resolución No. SGR-039-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/c7cf86e6bbf1969a8abbb3f5a760eb9aa9e53e864be01946a17397bfd17323af.jpg"/></td><td>Incremento Actividad Volcánica Cotopaxi</td><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SGR-0311-2022</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/0ce0f0f182b5a6b7be47c7d525e14c8ff2e26deb1de8d8379434943ccc7af3e2.jpg"/></td><td>Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo.</td><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SGR-182-2022</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/180a64ce8ac8236a1c5411bca52b2e0f82262a2fa97268cd7a1213e1f0642c3d.jpg"/></td><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa en los sectores: Pasán y Namza Chico, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo.</td><td>Amarilla</td><td>20/05/2022</td><td>Resolución No. SGR-118-2022</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/ce6da79ac3eb924a8c907e120022da4181dd36985ba3a3d13fee062d76100d42.jpg"/></td><td>Movimiento en masa barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SGR-171-2021</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/6ad3c2c9d7d2e19c705a80e55a2d67953a2612882e8065ae520508160f017f83.jpg"/></td><td>Socavamiento por la erosión del río Coca y sus afluentes - El Chaco.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SGR-058-2021</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/6cf5867beb96c4855117b7bdbc8958bde49dd8aed6dad45c16af81901de4ad2a.jpg"/></td><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SGR-045-2020</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0146
Fecha y Hora de actualización: martes, 14 de marzo de 2023 - 20:59:42 / Página 21 de 21


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/1f5b2f6acb461f2dc95e8c279be30c78fb929503d501ef6ff70f5424f9f069fc.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/bf360440b24bcb56e4e59525b4cde2850ea0101f8e63233cedfe4225061ab8bb.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/4afa821ebcd321e27924a5f454cabc860b9e2b4d7ec1a4eaa615a2d7af283c52.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/2ef980ed650a75bde9898de19ac3d1ea5ceeeea99589f4446591059ccb93148e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/98b04ec44bd9dfd7bffb27ed1564ba2d582f794f04c322ad1632a3a37f6acd0c.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/59c2ddef345efd67bd81d034a0d0fa4b4d3ba5e92956024683d3729c1b2bf16e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/9b8800b2cd86f6bb30f566f62e80b143f8e052a684032658204919c219ee963f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/cfd87f311de39b24cf7a0e4c57a27a77fd779e7ccf313a184d4411dc336ccbf3.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/6c7f7593802f8d5dae0f713ef1bc01cac3c27e649d54c2fae4d55ab425af86c0.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/3206f27c7bf9d9d75ae1119ae93d36f13534b7928845d35ad30d96abe5f7ae65.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/de27846e56b8c098c00edfa7e2301b0a09b6f7ef6c1690b0755767e072666d69.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/d87cf153d1a78bce18c527bc282404b95d9cd92a6b6566b767b87d1e064c2964.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/4b8ba578-43ce-44ff-8fa6-204043894447/97eab7025418d1b3726bed37a99eba7eebe2f3788e119b906902e1eac1fa9897.jpg)


<table><tr><td>Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td>Aumento de sedimentos volcánicosRío Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SGR-140-2019</td></tr><tr><td>Incendios ForestalesImbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SGR-111-2019</td></tr><tr><td>Incremento de lluvias e inundacionesGuayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SGR-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS)Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SGR-005-2019</td></tr><tr><td>DeslizamientoSan José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales,Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="2">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td colspan="2">InundacionesBabahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td colspan="2">Hundimiento,Zaruma, El Oro</td><td>07/03/2017</td><td>Resolución No. SGR-029-2015</td></tr></table>


Elaborado por. Jorge Dután.- Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. Revisado por: Javier Sarango- Analista Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. Enviado por. Jorge Dután. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 
