# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 1 de 21

Periodo de Monitoreo: 

Desde: 09h00 20/05/2023 

Hasta: 21h00 20/05/2023 

## Monitoreo de amenazas naturales y antrópicas

Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

- Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/0d3217365a5265a694b0c7801fffc8350595bf8cfadbacac180b556717331bf7.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/73c65df2043b178e6425b4704f4ef4867e9519b31b79e57b58047784aa192c92.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:17 Reventador para la COMUNIDAD, Emisión de gases y ceniza, observada a través de satélites GOES-16con una altura de 700 metros sobre el nivel del cráter con dirección Nor-Oeste</td><td>AMARILLA</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/c69c3e0c99a7f5d0c7e2a2ee749774d06b6044bf6859f98d5b4541bde7239603.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>17:00 Se visualiza el volcán nublado.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/cccdc2c5998c82006f7a8c0aa7f56b253ff1d2fd42059d5ffb4a938a720f5675.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>16:51 Se visualiza parcialmente despejado durante la noche y madrugada de hoy.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/7b3245c1ea10d1e5e876fd3b4890dcbb56ef1a9798fc8f7f1be9e0a00bdbdc2f.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>17:00 Sin reporte de actividad superficial</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/a688a4ad088180aa684bac962fde9e8c60cf6af8da6fe2f2fa23e3e0c6b438f1.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>20:55 Sangay para la COMUNIDAD, Emisión de gases y ceniza, observada a través de satélites GOES-16con una altura de 2000 metros sobre el nivel del cráter con dirección Sur-Oeste</td><td>AMARILLA</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/998967bab18ef49ebc5c05ba832d966495c4f4f01fb4ed76841a4f6067ee381c.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">00 Cuerpos de Agua Desbordados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del Río</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">01 Cuerpo de Agua con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del Río</td></tr><tr><td>Guayas</td><td>Colimes</td><td>San Jacinto</td><td>&quot;Varios Sectores (San Jacinto La Alegría San Eduardo)&quot;</td><td>Daule</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/0e7847f58f08330390fc980e04187dbb4da68e4057551bde92654f8988e5d4f2.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 incendio activo</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 2 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/18c14b7c71806efa71b10d24180eb47abaf34f6035137bac7b5470f7bcb83b63.jpg)


PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS 

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td></td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td></td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>---</td><td>85.00</td><td>---</td><td></td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>---</td><td>117.00</td><td>---</td><td></td></tr><tr><td>Chongón, Guayas</td><td>44.50</td><td>---</td><td>51.15</td><td>---</td><td></td></tr><tr><td>El Azúcar, Santa Elena</td><td>40.00</td><td>---</td><td>45.09</td><td>---</td><td></td></tr><tr><td>San Vicente, Santa Elena</td><td>50.00</td><td>---</td><td>57.49</td><td>---</td><td></td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td></td></tr><tr><td>Poza Honda, Manabí</td><td>91.50</td><td>---</td><td>106.50</td><td>---</td><td></td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td></td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td></td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td></td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/a58886b5e9f558e5e5330067c5f7e16226d02783dea1c87f0b3563ebdf065a6b.jpg)


## SITUACIÓN HIDROMETEREOLÓGICA

## Advertencia Meteorológica N° 25


ALERTA POR LLUVIAS, TORMENTAS Y VIENTO


<table><tr><td>DESDE17:00 del 18 de mayo</td><td>HASTA09:00 del 26 de mayo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/091bbf2d449617b9b420dd3c68d610c416804f63e0848c99eb57cd07c9c13995.jpg)


<table><tr><td colspan="3">Cantidad máxima de precipitación diaria (mm/día)</td></tr><tr><td>REGIÓN</td><td>NIVEL MEDIO</td><td>NIVEL ALTO</td></tr><tr><td>Litoral/Insular</td><td>10 - 18</td><td>19 - 41</td></tr><tr><td>Interandina</td><td>8 - 11</td><td>12 - 27</td></tr><tr><td>Amazonia</td><td>22 - 31</td><td>-</td></tr></table>

## ADVERTENCIA

AMENAZA: LLUVIAS Y TORMENTAS Y RÁFAGAS DE VIENTO ADVERTENCIA METEOROLÓGICA N°25 Vigente desde las 17H00 del 18 de mayo hasta las 09H00 del 26 de mayo de 2023 


SITUACIÓN: Se incrementa la probabilidad de lluvias de variable intensidad acompañadas de tormentas y ráfagas de viento en la región litoral, estribaciones de cordillera y varias localidades de la sierra y amazonia. Los eventos se presentarían en horas de la tarde, noche o madrugada.



- Región Litoral: Se pronostica lluvias de variable intensidad durante las tardes, noches y madrugadas hacia el norte, interior y estribaciones de montaña de la región.



- Región Insular: La lluvias que se presentarían serían ligeras a puntualmente fuertes con mayor probabilidad en Isabela el día 20 en la tarde o noche.



- Región Amazónica: Se presentarían lluvias moderadas a puntualmente fuertes en horas de la noche o madrugada en la región.



- Región Interandina: Se esperan lluvias ocasionales y variables, durante horas de la tarde y parte de la noche, con mayor intensidad en estribaciones de cordillera occidental.


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/ec8aaefc130bdd83fb59e16e44ceda9c1840874985d18462618cb4bad82ff730.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

Sismo 

Localización: 

A 29.12 Km de Balao, Guayas. 

Antecedentes: 

Se produjo un sismo a las 12:12 del 18/03/2023 de Magnitud 6.5, profundidad 44.Km localizado a 29.12 km de Balao Guayas. 

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 3 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/e8494beca8999054bbbce46a43f87755c8c3335dfb3be51ba57623d659948812.jpg)


<table><tr><td></td><td>De acuerdo al barrido realizado por la SGR el sismo fue sentido a nivel nacional con mayor intensidad en las provincias: de El Oro, Guayas, Los Ríos, Manabí, Chimborazo y Azuay.</td></tr><tr><td>Situación actual:</td><td>Según reporte del IG-EPN, el evento telúrico suscitado a las 00h35 del 25/04/2023 tuvo su epicentro a 36 km en dirección noreste de la Isla Puna, del cantón Balao, en la provincia del Guayas, de magnitud 5.7 (Mlv), a una profundidad de 60 km.Se han activado los COE Provinciales de Guayas, Azuay, Cañar y El Oro, así como los COE Cantonales: El Guabo, Pasaje, Machala, Huaquillas y Santa Rosa en El Oro; Cuenca y Santa Isabel en Azuay.Se encuentran declarados en emergencia los cantones de Pasaje y El Guabo en la provincia de El Oro y Naranjal en la provincia del Guayas.La Agencia de Regulación y Control del Agua en la provincia de El Oro y en el cantón Cuenca se reestableció el servicio de agua potable al 100%.Se encuentran activos los refugios temporales: Casa Comunal 24 de Mayo (14 personas) y el Refugio Temporal en la Casa Comunal Coop. 10 de Agosto en El Guabo (63 personas), donde al momento pernoctan las familias por precaución.</td></tr><tr><td>Afectaciones:</td><td>-Personas fallecidas: 14 personas - 12 El Oro (10 Machala, 1 El Guabo, 1 Pasaje), 2 Azuay (1 Cuenca,1 Molleturo) - (Ajustes de cifras de acuerdo a COE Provincial de El Oro)-Personas heridas: 494-Personas afectadas: 3774-Personas damnificadas: 1017-Viviendas afectadas: 1050-Viviendas destruidas: 291-Unidades Educativas afectadas: 331-Establecimientos de Salud afectados: 57-Bienes públicos afectados: 61-Bienes públicos destruidos: 8-Bienes privados afectados: 77-Bienes privados destruidos: 3</td></tr><tr><td>Acciones de respuesta:</td><td>MTT1 La Agencia de Regulación y Control del Agua indica que en la provincia de El Oro y en el cantón Cuenca se reestableció el servicio de agua potable al 100%.MTT2 MSP levantó información de establecimientos de salud afectados. Adicionalmente brindaron atenciones psicológicas por crisis hipertensivas y atenciones preventivas en los albergues activados en la provincia de El Oro. • MSP desplegó brigadas médicas de atención a las comunidades de la Isla Puná, e islotes del Golfo de Guayaquil. • Se activó personal de contingencia en establecimientos de salud tipo C para atención a la comunidad. • Cruz Roja Ecuatoriana brindó apoyo al MSP en atención pre-hospitalaria.MTT3 GAD Provincial coordinó con Capitanía de Puerto Bolívar, la limpieza de escombro en el barrio 4 de Abril desde el mar por medio de gabarras. • GAD Machala, GAD Pasaje y GAD El Guabo realizaron la limpieza de vías que tenían acumulación de escombros de estructuras colapsadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR Unidades de Monitoreo/Cuerpo de Bomberos/MINEDUC/MIDUVI</td></tr></table>

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/cf30f46d03ef86a716b16c0a4fac4e9e74aa57249f85635dd98451a63b9919ea.jpg)


## Inundación

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/2733c64fc3ff51d070be95a9d34c9a74d6609185db3ff58da5408f1db8b27af8.jpg)


<table><tr><td>Localización:</td><td>Esmeraldas/Muisne/San Gregorio/Guadurnal.</td></tr><tr><td>Antecedentes:</td><td>El 10/05/2023, por lluvias, se suscitó el desbordamiento del río Canuto, suscitándose una inundación en la comunidad Guadurnal.</td></tr><tr><td>Situación actual:</td><td>El río Canuto se encuentra con tendencia a disminuir su caudal.</td></tr><tr><td>Afectaciones:</td><td>- 40 viviendas afectadas.- 70 familias (285 personas).</td></tr><tr><td>Acciones de respuesta:</td><td>Líder de la comunidad reportó la novedad.SGR coordina la atención del evento con el MAG.Policía Nacional realizó inspección.SGR coordinó la atención del evento con el personal de la UGR GAD Cantonal Muisne.Presidente de la Junta Parroquial San Gregorio confirmó el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Esmeraldas/PPNN/UGR Esmeraldas/Junta Parroquial San Gregorio/ Comunidad.</td></tr><tr><td colspan="2">Contaminación</td></tr><tr><td>Localización:</td><td>Sucumbíos /Lago Agrio/Nueva Loja / Vía a Quito Km 12 frente a campus Sucumbíos.</td></tr><tr><td>Antecedentes:</td><td>El 10/05/2023, debido a la rotura del SOTE suscitada en el km 12 de la vía Lago Agrio-Quito; se produjo derrame de crudo, lo que ocasiona la contaminación en el sector de Santa Cecilia Km 12 siguiendo el curso del río Conejo.</td></tr><tr><td>Situación actual:</td><td>Se observan residuos de sustancias de petróleo en los sectores indicados, EP Petroecuador está encargada de los trabajos de reparación del SOTE y se activaron los contingentes de limpieza y remediación</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público afectado (tubería del SOTE)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 4 de 21

<table><tr><td>Acciones de respuesta:</td><td>EP Petroecuador realizó suspensión inmediata de las operaciones; activación del Plan de Emergencia y contingencia, adicional se instalaron barreras a lo largo del río Conejo y 2 puntos de control con equipos y materiales de contingencia.Ministerio del Ambiente realizará inspección en el sitio.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Sucumbíos/Petroecuador.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/e2d7bb6b1fe6cfe44c6510edc2f92965ecfd14ac6c1a1c49dd8c06b05ca3b993.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Imbabura/Cotacachi/Vacas Galindo/Balsapamba.</td></tr><tr><td>Antecedentes:</td><td>El 05/04/2023, producto de las fuertes precipitaciones, se registró un aluvión que descendió por la quebrada Guayacanal que acarreó flujos de lodo, escombros, material pétreo, afectando a la vía tercer orden que al momento se encuentra cerrada.</td></tr><tr><td>Situación actual:</td><td>Se continúa brindando agua por medio de tanqueros</td></tr><tr><td>Afectaciones:</td><td>- 4 viviendas destruidas; 4 familias y 13 personas damnificadas- 4 viviendas afectadas, 4 familias y 15 personas afectadas- 0.15 hectáreas de cultivos de naranjilla afectados- 30 metros de vía afectada al momento cerrada.- 2 bienes públicos destruidos (sistema de alcantarillado tipo puente y sistema de agua potable destruido)- 450 personas afectadas indirectas por falta de servicio de agua de consumo humano en los sectores de Apuela, Cristopamba y Nangulvi.</td></tr><tr><td>Acciones de respuesta:</td><td>Bomberos Cotacachi continúa con la distribución de agua por tanqueros.SGR entregó asistencia humanitaria a las familias damnificadas y afectadas.Técnicos del GAD Cantonal y SGR realizaron el levantamiento de las afectaciones del evento peligroso.El GAD Municipal, con las instituciones competentes está a cargo de la coordinación de las acciones para solucionar el problema del agua, la habilitación vial y atención de la población.Personal y maquinaria del GAD Provincial de Imbabura y GAD Parroquial realizan la remoción de escombros y habilitación vial</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/GAD C Cotacachi/SIS ECU 911 Ibarra.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/4765c5dccfd6f73e4e5859986c4c68205c62af81769b2cc5c7e0b882371fcfee.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El 26/11/2021, de acuerdo al informe del SGR se indicó que el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.Se informa que el SGR CZ1, geólogos de la Prefectura, Universidad Central, Universidad Yachay y autoridades locales realizaron recorridos e inspecciones técnicas.El 16/11/2021, SGR-CZ1 entregó asistencia humanitaria. El Informe del MAG indica que la afectación de los cultivos en total es de 12,43 ha de cultivos de la zona. GAD Cantonal de Pimampiro en apoyo del GAD Provincial Imbabura trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad, tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su cabecera cantonal.</td></tr><tr><td>Situación actual:</td><td>MIDUVI Bolívar mediante inspección realizada en el sector indica las siguientes recomendaciones.Las familias deben ser reubicadas por cuanto el suelo de casi toda la comunidad presenta hundimientos fuertes, fisuras, grietas, cuarteamientos, desplazamientos horizontales.Solicitar al GAD Municipal del Cantón Chillanes la donación de un terreno para la reubicación de estas familias por deslizamiento, hundimiento grietas en el suelo en la entrada a la comunidad cuarteamientos y grietas en las gradas de la capilla, capilla con cuarteamientos de paredes en riesgo de colapsar.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservoirios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 5 de 21

<table><tr><td>Acciones de respuesta:</td><td>El GAD Cantonal de Pimampiro determinó un predio para la construcción del Proyecto de Vivienda, y realiza la instalación de servicios básicos.GAD Cantonal y Provincial de Imbabura habilitaron una vía alterna. La comunidad habilitó la vía a Mariano Acosta que pasa por la zona de riesgo de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SGR, exponiéndose a futuros riesgos vinculados a la zona propensa de deslizamiento.Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.El 02/05/2023, MIDUVI realizó la inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/MIES, MIDUVI, GAD C Pimampiro - UGR.</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/34709ce844a963f0c224d52391729cced7e3b045ac65de8d1c1c6eaa50782ee2.jpg)


<table><tr><td colspan="2">Socavamiento</td></tr><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.Se mantiene la declaratoria emitida mediante resolución SGR-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>El 16/05/2023, la Comisión Ejecutora del Río Coca, CERC, informó que el frente de erosión se encuentra en la abscisa 7+560 por 64 días. Visualmente no hay cambios morfológicos y los bloques rocosos de referencia no han cambiado de posición, por lo que se presume que no hay avance en el frente de erosión, sin embargo, aguas abajo en el sector de San Carlos, entre el km 8+000 y 10+000, continúan los cambios del eje del río y desplazamiento hacia la margen izquierda; se visualiza erosión regresiva local en el río Loco y erosión lateral en los taludes.San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio.</td></tr><tr><td>Afectaciones:</td><td>Desde el 2020 a la fecha las afectaciones son las siguientes:- Personas Afectadas indirectas: 100-Personas Damnificadas: 51-Personas Afectadas: 76-Personas Evacuadas: 63-Viviendas destruidas: 2-Metros de vía afectadas: 1040-Puentes destruidos: 3 (Puente sobre el río Motana, Puente Ventana 2 y Puente Piedra Fina)- Puente afectados: 1 (Puente Piedra Fina)- Bienes Afectados: 4 (tuberías del SOTE, Poliducto Shushufindi- Quito y OCP; Sistema de Agua Potable de San Luis)- Ha de Cultivo perdida: 100.03- Animales de granja afectados y muertos: 3448</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP a través de la Empresa contratista CONSTRUCPIEDRA SA continúa trabajando en la construcción de una vía de servicio de 2.2 km.La CTC Río Coca realizan el monitoreo del proceso erosivo.SGR CZ2 y CCGR San Luis realizan monitoreo constante del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/CELEC EP/GAD Municipal El Chaco/MTOP/Teniente Político Gonzalo Díaz de Pineda</td></tr></table>

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/d0d05de5b0af40d198ea1137fbceb9626ae19d04534fa10b3e998f06a9be2a80.jpg)


<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Multitud/varios sectores, vía Pallatanga-Cumandá [E-487].</td></tr><tr><td>Antecedentes:</td><td>El 09/05/2023, por causas desconocidas se produjo un hundimiento en la vía de segundo orden, que posiblemente afecte a viviendas del sector.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía secundaria se encuentra parcialmente habilitada. UGIAR SGR CZ3 mediante informe de análisis de amenaza recomienda:Se recomienda al Gobierno Autónomo Descentralizado Municipal del Cantón Alausí para que conjuntamente con la Junta Parroquial de Multitud y los representantes de la Comunidad Las Rocas realicen la construcción de medidas estructurales para reducir la amenaza en el sector, principalmente para disponer de un adecuado sistema de drenaje y el encausamiento de las aguas provenientes de las precipitaciones en la zona hacia la quebrada que desemboca al Río Chimbo.De conformidad a lo mencionado en el presente informe, se deberán implementar trabajos de mitigación para reducir la inestabilidad del talud inspeccionado, por tanto,</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 6 de 21

<table><tr><td></td><td>se deberá elaborar el estudio técnico que determine las características geológicas del suelo y en base al mismo definir el ángulo de estabilidad para el diseño de taludes.Se recomienda al MTOP, GAD de la provincia de Chimborazo que en coordinación con el GAD Parroquial De Multitud adopten las medidas necesarias para mejorar la vialidad del sector, acorde a su competencia, especialmente en la vía de acceso hacia las antenas y zona alta poblada de Las Rocas.Se recomienda al MINEDUC considerar el presente informe ya que la UE Bilingüe 15 de octubre se ubica dentro del Polígono preliminar delimitado.</td></tr><tr><td>Afectaciones:</td><td>- 100 m. de vía afectada- 20 viviendas afectadas (Es un número estimado hasta el levantamiento del informe EVIN)- 1 Unidad educativa afectada (Escuela Bilingüe 15 de Octubre)- 2 Bienes públicos afectados (iglesia y tanque de agua potable)</td></tr><tr><td>Acciones de respuesta:</td><td>UGIAR SGR CZ3 socializó con la población de la Comunidad Las Rocas, parroquia Multitud del Cantón Alausí el informe técnico levantado por la presencia de grietas y asentamiento en la comunidad que conllevó a la delimitación de un polígono de Alta susceptibilidad.Se realiza una inspección de posibles albergues para la comunidad de las Rocas perteneciente a la parroquia Multitud del cantón Alausí.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGR Cantonal/GAD Parroquial.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/23c77abb6b4d7268c762b948dfbf51a9ac8e33560daed50956830814d6f013de.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Huigra/Cerro Pasan y Namza Chico.</td></tr><tr><td>Antecedentes:</td><td>De acuerdo a informe técnico de la SGR del 11 de junio del 2018 indican que debido a la litología y a la sobre saturación de material se produjo grietas en los sectores señalados por lo que la SGR declara el estado de ALERTA NARANJA el 09 de abril del 2023 debido al incremento de amenaza de movimiento de masa en Pasan y Namza Chico, además, de acuerdo a informe del INAMHI en el que se indicó que en el mes de abril se incrementarán las lluvias. La evacuación de la población se da bajo el principio de autoprotección, considerando la continuidad de las grietas y el carácter activo de movimientos en masa de 152,22 ha, que comprende los sectores de Namza Chico, Pasan, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chanchán.Mediante Resolución MINEDUC Alausí – Chunchi dispone al rector y planta docente de la Unidad Educativa Eloy Alfaro, que se suspendan las actividades pedagógicas presenciales debido a la DECLARATORIA del estado de ALERTA NARANJA.</td></tr><tr><td>Situación actual:</td><td>GAD Provincial Huigra realizó actividades de relleno para evitar el incremento de amenaza.SGR realizará una inspección para determinar si continúa el estado de ALERTA NARANJA.</td></tr><tr><td>Afectaciones:</td><td>- 117 personas evacuadas (27 familias):- Hotel Huigra: 48 personas (16 familias) (retornaron a sus viviendas)- Hotel Rosero Resort: 4 personas (1 familia) (retornaron a sus viviendas)- Familias acogientes: 65 personas (10 familias)</td></tr><tr><td>Acciones de respuesta:</td><td>Mediante apoyo interinstitucional entre SGR, IGM e IIGE realizaron mediciones en la parroquia Huigra con la finalidad de monitorear un potencial deslizamiento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/GAD P. Huigra.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/7aa7299d49daa7267a5ea727929f23aee055bd5cde90300526336ffd0785717f.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Alausí, Cabecera Cantonal/Casual, vía Guamote - Alausí [E-35].</td></tr><tr><td>Antecedentes:</td><td>El 09/12/2022, se produjo un hundimiento en la vía de primer orden, que al momento está cerrada.Mediante RESOLUCIÓN Nro. SGR-111-2023, se determina CAMBIAR EL NIVEL DE ALERTA AMARILLA A NARANJA por movimientos en masa en el área de 214 hectáreas, que comprende el sector: Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua, del cantón Alausí y RATIFICAR el estado de ALERTA AMARILLA en el área de 38,07 hectáreas, considerando la actualización del análisis y observaciones técnicas realizadas en campo.El día 26/03/2023, debido al hundimiento, se produjo un deslizamiento en la E35 se bajó la montaña afectando completamente la vía de primer orden y viviendas aledañas.Se activaron alojamientos temporales en: Iglesia La Matriz, Coliseo Municipal, Aypud, Iglesia Ministro del Nuevo Pacto y Asociación de Artesanos, al momento se tiene 33 personas en el alojamiento Coliseo Municipal.</td></tr><tr><td>Situación actual:</td><td>GT1, GT2 y GT3 continúan con las labores de búsqueda y rescate de las personas desaparecidas por el deslizamiento, además el GADM Riobamba y la Iglesia Católica de Quito entregaron asistencia humanitaria.</td></tr><tr><td>Afectaciones:</td><td>- 54 personas fallecidas- 581 personas afectadas- 44 personas heridas.- 34 personas desaparecidas.- 1034 personas damnificadas (evacuadas hacia los alojamientos temporales).- 163 viviendas afectadas- 57 viviendas destruidas</td></tr></table>

## Secretaría de Gestión de Riesgos


Hundimiento


## Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 7 de 21

<table><tr><td></td><td>- 2 bienes privados destruidos (Asadero Don Fausto y Damada - cafetería se encuentra destruido)- 1 bien privado afectado (Hostería Pircapamba)- 1 Unidad Educativa afectada (U.E. Federico Gonzales Suarez)- 2 bienes públicos destruidos (1 Estadio y 1 coliseo).- Vías destruidas:- Primer Orden: 1,12 Km- Segundo orden: 1,20 Km- Total: 2.32 Km- 3 bienes públicos afectados (25% de red público afectado y 60 % de servicio de agua potable afectado, 20 % de servicio de alcantarillado afectado).- 6 ha de cultivos y pasto destruidos.- 20 ha de cultivos afectados.- 230 Animales afectados.- 427 metros de línea férrea destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>GADM Riobamba realizó la entrega de asistencia humanitaria.MTT y GT continúan con sus labores de acuerdo a sus competencias.SGR monitorea el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MTOP.</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/64226bfe08f62ee7878c6a424ab19264f34f8631188999bb8fc9a04a9ffdda84.jpg)


<table><tr><td>Localización:</td><td>Santo Domingo de Los Tsáchilas/Santo Domingo/Valle Hermoso/sector San Luis. Vía Flor del Valle - Valle Hermoso.</td></tr><tr><td>Antecedentes:</td><td>Producto de las lluvias suscitadas el día 10/05/2023, se suscitó el desbordamiento del río Bayanbien.</td></tr><tr><td>Situación actual:</td><td>Al momento, el río se encuentra en su cauce, con tendencia a disminuir de nivel.</td></tr><tr><td>Afectaciones:</td><td>El evento se encuentra en evaluación</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Parroquial de Valle Hermoso, confirmó el evento.SGR coordinó con personal UGR GAD Cantonal y Patronato, para que realice la evaluación de daños y necesidades.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Santo Domingo/Tenencia Política de Valle Hermoso.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/bcf8505a65ae1ccd38a13546a1ad8c9b6058a40cf0bdccd61d964c9e9350d5a7.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/f72871b45926b0700372027cb300d1a372ae2d1aa01798263d08089866b8c11a.jpg)


<table><tr><td>Localización:</td><td>Manabí/Paján/Campuzano/Estero Ciego</td></tr><tr><td>Antecedentes:</td><td>El 09/05/2023, personal técnico de la SGR CZ4 indica que producto de las lluvias y desestabilización del terreno se ha suscitado un hundimiento afectando una vía de segundo orden</td></tr><tr><td>Situación actual:</td><td>La vía de segundo orden se encuentra parcialmente habilitada, y se han visto afectadas varias viviendas y familias las cuales se encuentran en familia acogiente, asimismo indican afectación en cultivos.</td></tr><tr><td>Afectaciones:</td><td>- 8 viviendas afectadas.- 8 familias afectadas.- 32 personas afectadas.- 10 ha afectadas (maíz, cacao, plátano).- 250 metros de vía afectada.</td></tr><tr><td>Acciones de respuesta:</td><td>Jefatura Política y Tenencia Política de Campuzano ayudaron a la evacuación de las familias.Se coordina con GAD Provincial para arreglo de la vía.SGR CZ4 coordina entrega de AH las familias y entrega de bonos de contingencia a las familias afectadas.SGR monitorea el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/SGR CZ4/MDG.</td></tr><tr><td>Deslizamiento</td><td></td></tr><tr><td>Localización:</td><td>Manabí/Paján/Cascol/San Alejo.</td></tr><tr><td>Antecedentes:</td><td>El 05/05/2023 producto de las lluvias y desestabilización del terreno se suscitó un deslizamiento afectando a varias viviendas y familias, de las familias afectadas dos se encuentra en familias acogiente, el resto permanecen en sus mismas viviendas, también hubo afectación a cultivos, Jefa Política del Cantón y Tenienta política de Cascol ayudaron a la evacuación de las familias.</td></tr><tr><td>Situación actual:</td><td>SGR CZR coordina entrega de AH y bonos de contingencia para las familias afectadas.</td></tr><tr><td>Afectaciones:</td><td>- 8 viviendas afectadas.- 2 viviendas destruidas.- 8 familias afectadas (43 personas afectadas).- 2 familias damnificadas (5 personas damnificadas).- 200 ha afectadas (maíz</td></tr><tr><td>Acciones de respuesta:</td><td>Se realizó levantamiento fotogramétrico del area afectada y levantamiento de EVIN digital.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 8 de 21

<table><tr><td></td><td>Jefatura Política y Tenencia Política de Campuzano ayudaron a la evacuación de las familias.SGR CZ4 coordina entrega de AH las familias y entrega de bonos de contingencia a las familias afectadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/SGR CZ4/MDG.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/cd4f7aabd42d5afe84b944b42cb39d4d9c5f59d3fcf8cb7230f1176a3a602962.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Manabí/Santa Ana/Honorato Vásquez/sectores Vainilla y La Laguna.</td></tr><tr><td>Antecedentes:</td><td>El 18/04/2023, por las lluvias suscitadas en los últimos días, se produjo el deslizamiento de una ladera afectando a varias viviendas en los sectores mencionados.Las familias afectadas permanecen en casas de familias acogientes.</td></tr><tr><td>Situación actual:</td><td>UGR Cantonal Santa Ana y Tenencia Política del Cantón, continúan con las inspecciones en los sitios afectados, ya que siguen llegando alertas de deslizamiento y apertura del suelo, las familias continúan evacuando a familias acogientes, Municipio gestionó la apertura de un alojamiento temporal en La Casa Comunal, para continuar acogiendo a los afectados de seguir produciéndose deslizamientos.</td></tr><tr><td>Afectaciones:</td><td>-21 viviendas afectadas-25 familias afectadas (84 personas afectadas)-2 familias evacuadas (alojamiento temporal)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR realiza el monitoreo del evento.Se está a la espera por parte de Técnicos del IG para determinar cambio de alerta de amarilla a naranja.UGR GAD Cantonal realiza la Evaluación de Daños y Análisis de Necesidades.Tenencia Política confirmó el evento.SGR CZ4 realiza evaluación técnica</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Santa Ana/Tenencia Política.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/4a285770b67d87c4be03543f17ef45c594129519bdd94bf56b4deccc2fa257c6.jpg)


## Colapso estructural

<table><tr><td>Localización:</td><td>Santo Domingo de Los Tsáchilas/Santo Domingo/Valle Hermoso /sector Sarayacu.</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2023, producto de la lluvia y el aumento del caudal del río Blanco, se produjo el colapso del puente que brindaba acceso al sector de Sarayacu, lo que provocó la incomunicación de la comunidad.</td></tr><tr><td>Situación actual:</td><td>Los moradores del sector, construyeron una tarabita para el ingreso de víveres y de personas al sitio.</td></tr><tr><td>Afectaciones:</td><td>- 1 puente destruido.- 35 Familias afectadas. (incomunicadas)</td></tr><tr><td>Acciones de respuesta:</td><td>Patronato Municipal coordinó con el Cuerpo de Bomberos para entregar kit alimenticios a las familias incomunicadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Santo Domingo/ECU 911/ACM/C.B.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/23b6f3b68e36d92669525b4ec4a52be9f2a8216c3f320aa6c82d6df4a06f3135.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Santo Domingo de Los Tsáchilas/La Concordia/La Concordia/Sector del Camal.</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2023, producto de las lluvias de la madrugada se produjo el aumento del caudal del río Blanco, provocando la ruptura de la tubería principal de la planta de tratamiento de agua potable, afectando la distribución de agua en el Cantón.</td></tr><tr><td>Situación actual:</td><td>Se realizan los trabajos de reparación de la tubería principal de agua potable.La empresa de agua potable habilitó dos pozos de agua donde la ciudadanía pueda acudir a solicitar agua.Se continúa con el suministro agua a la población con tanqueros.</td></tr><tr><td>Afectaciones:</td><td>- La afectación de la distribución de agua de la planta es del 100%- 2 bienes Públicos afectados (Planta de Agua Potable y Camal Municipal).- 51 animales de granja fallecidos (cerdos, Reses).- Aproximadamente 170.000 personas afectadas indirectamente por el suministro de agua</td></tr><tr><td>Acciones de respuesta:</td><td>GAD La Concordia continúa con la entrega de agua, con tanqueros.Empresa privada realiza trabajos de reparación de la tubería principal de agua potable.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Santo Domingo/UGR GAD La Concordia.</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/1d467d1067cce224ac9dbc95ee3b3712c82160ca949aaa7337e1e585d4529239.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Baba/Guare/Las Piedras - El Edén - La Florida - San Joaquín - La Semira 1 - Guayaquil Chiquito - Coop. La Estrella - Legua de los Indios - El Espejo de San Joaquín - La Juanita - Versales - río Correntoso - río Arenal - río Junquillo.</td></tr><tr><td>Antecedentes:</td><td>El 27/04/2023, debido a la presencia de lluvias fuertes provocó el desbordamiento de los ríos Correntoso, Arenal y Junquillo, afectando a varias viviendas del lugar.</td></tr><tr><td>Situación actual:</td><td>los caudales están en su nivel normal, actualmente se visualiza agua estancada en el sitio, las familias afectadas se mantienen en sus hogares.</td></tr><tr><td>Afectaciones:</td><td>- 398 viviendas afectadas (caña-cemento-madera)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 9 de 21

- 398 familia afectada 

- 1366 personas afectados 

Acciones de respuesta: 

UGR Baba realizó verificación de novedades. 

SGR realizó gestión del bono por el decreto 316 a las 398 familias. 

Fuentes de información: SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Baba. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/4b221b9733ca880ba910d5caba7cb61083578cfd9e5c8bb39fa96539b1526d50.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Bolívar/Chimbo/Telimbela/varios sectores: centro de Telimbela, El Valle, La Alsacia, Copalillo, Chonta Pucará, Mususan, Ashcoaca, Atio Bajo</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias del 26/04/2023, se originó un deslizamiento en la parte alta en el sector de Mususan y produjo el represamiento y desborde del río Telimbela, el cual afectó al puente socavando las bases.Existen afectaciones a puentes y vías en algunos sectores de la parroquia.De las familias del sector de El Valle 5 familias que salieron la noche del 26/04/2023 a pernoctar en la iglesia, regresaron a sus viviendas el 27/04/2023, y otras 5 a familias fueron a casa de familias acogientes, sin embargo las viviendas de las familias se encuentran en zona de riesgo debido a que están ubicadas en la ribera del río.El 04/05/2023 maquinaria del GAD Provincial habilitó un paso provisional por el río (badén) en el centro de Telimbela, hasta realizar los trabajos definitivos en el sector.</td></tr><tr><td>Situación actual:</td><td>SGR realizó la entrega de asistencia humanitaria a las familias que se encontraban evacuadas y a las que están en zona de riesgo, además indica que las 5 familias evacuadas han retornado a sus viviendas.GAD Provincial continúa con los trabajos de recuperación de la plataforma vial en el sector Ashcoaca.La vía a los sectores Chonta Pucará, Ashcoaca continúa cerrada.El río Telimbela se encuentra en su cauce normal.</td></tr><tr><td>Afectaciones:</td><td>- 5 familias, 16 personas evacuadas (retornaron a sus mismas viviendas).- 2 puentes vehiculares afectados (colapso parcial del puente, vía Telimbela-Cochabamba; socavamiento de las aletas y parte de la vía, sector Alsacia vía a Caluma)- 2 puentes vehiculares destruidos (sector Copalillo, sector Chonta Pucará)- 415 metros lineales de pérdida de la plataforma de la vía(sector de Ashcoaca, Chonta Pucará)- 1 bien público afectado (alcantarilla de agua taponado en San Francisco Chico)- 350 metros de muro de gaviones destruidos (sector el Valle).- 4.50 ha de cultivos afectados (banano, pasto, café)- 3.00 ha de cultivos perdidos (banano, pasto, café)- 4 animales muertos (porcinos, bovinos)- 4 animales afectados (porcinos, bovinos)- 6 productores, 24 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>SGR Bolívar en conjunto con GAD Chimbo realizó la entrega de asistencia humanitaria. Maquinaria del GAD Provincial continúa con los trabajos de recuperación de la plataforma vial en el sector Ashcoaca.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD Chimbo/SGR Unidad de Respuesta.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/904f40ef0e04937fbed324621e871e4f906e55e2aed391114e4a28ca872d9c3a.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Quinsaloma/Quinsaloma/12 de Octubre - Las Palmitas - Río Umbe.</td></tr><tr><td>Antecedentes:</td><td>El 25/04/2023, debido a las fuertes lluvias suscitadas se reportó el desbordamiento del río Umbe, afectando a varias viviendas del lugar, las familias se mantuvieron en sus viviendas</td></tr><tr><td>Situación actual:</td><td>Actualmente las familias afectadas se mantienen en sus viviendas sin presencia de agua y a la espera del bono por el Decreto 316.</td></tr><tr><td>Afectaciones:</td><td>- 21 viviendas afectadas.- 21 familias afectadas.- 75 personas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Quinsaloma realizó verificación de novedades.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/Cuerpo de Bomberos Quinsaloma/GAD Quinsaloma/Ministerio de Gobierno- Jefatura Política de Quinsaloma.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/de51efb9c483700f771cd0fcf9eff1ddd3d90925b3fe63ebd855f7da7827abdf.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Valencia/Valencia/ Lulo de Hamburgo - Mirador de Valencia - Ni un paso atrás - Copal Monte Nuevo - estero El Pope - río lulo.</td></tr><tr><td>Antecedentes:</td><td>El 23/04/2023, debido a las fuertes lluvias suscitadas en la madrugada se reportó desbordamiento del estero El Pope, provocando ingreso de agua a viviendas, afectando a los lados de dos puentes del lugar, con fuertes filtraciones que socavaron la vía de 3er orden, misma que conecta a La Segunda con Tercera Banquera hacia La Maná, maquinaria del GAD colaboró con el relleno a los lados de los dos puentes, actualmente la vía de 3er orden se encuentra cerrada.</td></tr><tr><td>Situación actual:</td><td>Mediante inspección técnica el 10/05/2023, se verificó que los niveles del estero El Pope con el Río Lulo permanecen en su caudal normal, la vía afectada se encuentra habilitada al tránsito vehicular y las familias continúan en sus viviendas a la espera de la entrega del bono otorgado por el Decreto 316.</td></tr></table>

## Secretaría de Gestión de Riesgos

<table><tr><td>Afectaciones:</td><td>- 93 viviendas afectadas- 93 familias afectadas- 305 personas afectadas- 200 metros lineales afectados- 2 puentes afectados</td></tr><tr><td>Acciones de respuesta:</td><td>- UGR Valencia realizó verificación de novedades.- SGR realizó gestión del bono por el Decreto 316.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/GAD Valencia.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 10 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/a0a6fa7d996ced6fafda95f1c9c3f1bc9f6124146447086a603e07c11201c823.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Santa lucía/Santa lucía Cabecera Cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 15/04/2023 y madrugada del 16/04/2023, por lluvias con tormentas eléctricas se registró algunos sectores con calles y avenidas anegadas por acumulación de agua. COE Cantonal con fecha 22 de abril del 2023, sugirió al GAD Cantonal de Santa Lucía se declare la situación de emergencia al cantón; acogiendo dicha sugerencia GAD Cantonal declara en emergencia al cantón Santa Lucía, adicionalmente indica que se realizó recorridos por los sectores afectados en conjunto al alcalde y personal de Cuerpo de Bomberos, Jefatura Política, MIES y SGR. Las familias se mantienen en el albergue y familias acogidas.</td></tr><tr><td>Situación actual:</td><td>UGR del GAD Santa Lucia informa que 3 familias, 9 personas salieron del albergue Municipal Santa Rosa y han retornado a sus viviendas, las demás familias se mantienen en los alojamientos temporales, adicional indicó que al momento el nivel de la cota del río Daule y Pula se encuentran disminuyendo su caudal.</td></tr><tr><td>Afectaciones:</td><td>- 1024 viviendas afectadas- 1024 familias, 3944 personas afectadas (21 familias, 58 personas en el Albergue Temporal Santa Rosa, 7 familias, 31 personas en CDI San Pablo, 4 familias, 8 personas en Junta Higuerón El Porvenir / 100 familias, 315 personas en familias acogientes / 892 familias, 3532 personas se mantienen en sus viviendas)- 4500 hectáreas de arroz afectadas- 25 instituciones educativas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal Santa Lucía dio seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/SGR - UPREA/UGR GAD Cantonal Santa Lucia.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/84c6ed27cc8b929e1d4396076ee07ce072b0f4b02e3c38daeb3f15f829f04b54.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Bolívar/Chillanes/Cabecera Cantonal/San Francisco de Azapi.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 a causa de las lluvias registradas en el sector, se ha producido grietas en un terreno.Geólogo de la SGR realizó inspección en la zona e indica que visualizó agrietamientos y asentamientos formando una corona de escape, además realizaron una tomografía del suelo de la zona afectada.Por seguridad y prevención las tres familias han decidido salir de la zona de riesgo.SGR Bolívar mediante inspección indica que evidenciaron que las grietas existentes han aumentado significativamente su ancho y profundidad, presencia de agua superficial sobre el terreno, nuevos deslizamientos en la parte posterior a la capilla del recinto y la vivienda de la familia Cobos Yupa, agrietamiento transversal sobre la vía estatal Chillanes - Bucay y varios cambios paisajísticos del sector, lo cual evidencia el movimiento de masa activo del sector.La Escuela Ciudad de Latacunga del recinto San Francisco de Azapi se encuentra en zona de riesgo.El 05/05/2023, Personal de la SGR realizó la socialización y concientización del nivel de riesgo alto por el deslizamiento en el sector dirigido a la comunidad, Alcaldesa electa, técnicos de las UGR de los cantones de Bucay - &quot;Guayas&quot;, Cumandá - &quot;Chimborazo&quot;, Chillanes - &quot;Bolívar&quot; y Gobernación de Bolívar.</td></tr><tr><td>Situación actual:</td><td>MIDUVI Bolívar mediante inspección realizada en el sector indica las siguientes recomendaciones.- Las familias deben ser reubicadas por cuanto el suelo de casi toda la comunidad presenta hundimientos fuertes, fisuras, grietas, cuarteamientos, desplazamientos horizontales.- Solicitar al GAD Municipal del Cantón Chillanes la donación de un terreno para la reubicación de estas familias, deslizamiento, hundimiento grietas en el suelo en la entrada a la comunidad cuarteamientos y grietas en las gradas de la capilla, capilla con cuarteamientos de paredes en riesgo de colapsar.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas- 3 familias, 15 personas afectadas (de las cuales 1 familia, 4 personas se encuentran en otra vivienda de su propiedad y las 2 familias, 11 personas se encuentran arrendando por el mismo sector en una zona segura)- 1 bien público afectado (cancha de la comunidad)- 1 bien privado afectado (capilla)</td></tr><tr><td>Acciones de respuesta:</td><td>El 05/05/2023, SGR realizó la socialización y concientización del nivel de riesgo de la zona afectada.MIDUVI realizó la inspección en la zona.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 11 de 21

Fuentes de información: 

SGR CZ5 Unidad de Monitoreo Bolívar/SGR Unidad de Respuesta y Unidad de Monitoreo Bolívar. 

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/85cc6cac6211899025e2b28f5f5ca044d075785e6500d3f6994d74bfa3be40cf.jpg)


<table><tr><td>Localización:</td><td>Morona Santiago/Limón Indanza/San Antonio (cabecera en San Antonio Centro)/San Salvador, Mayapis, Serembo, El Cisne, 12 de Febrero.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas durante el 17/04/2023, se produjo un deslizamiento que provocó varias afectaciones y la obstaculización total de la vía de tercer orden.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se mantiene cerrada debido al gran volumen de tierra deslizado, no se registra precipitaciones.Se gestiona asistencia humanitaria (110 kits de alimentos-SGR) para las familias afectadas indirectamente, debido a que se encuentran aisladas 10 días y no se han podido abastecer de alimentos, para lo cual se está solicitando a Fuerzas Armadas el apoyo de un recurso especial para ejecutar la entrega de la misma.</td></tr><tr><td>Afectaciones:</td><td>- 2 kilómetros de vía afectada- 1 puente afectado (riesgo de colapso)- 1 puente destruido- 2 bienes públicos (sistema de agua y alcantarillado vial)- 2 animales de granja muertos (ganado)- 5 bienes privados afectados (peceras)- 42 ha de vegetación afectada (40 de pasto y 2 de cultivos)- 18 familias (78 personas) afectadas directamente (pérdida de ganado y peceras)- 107 familias (535 personas) afectadas indirectamente (no pueden sacar sus productos ni ingresar</td></tr><tr><td>Acciones de respuesta:</td><td>MAG realizó una inspección y evaluación de afectaciones.COE-Provincial se activó el 27/04/2023 mantuvieron una reunión con el fin de coordinar acciones para atender el evento.SGR se mantiene en constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ 6 Unidad de Monitoreo Morona Santiago/GAD-Cantonal de Limón Indanza.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/cdb3b454404c56732cae9003f0f1d4db53eff0efaa73c184aa8b9f008f472608.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Santa Isabel/Santa Isabel/La Cría</td></tr><tr><td>Antecedentes:</td><td>El 03/06/2022, Se suscitó un deslizamiento producto de la saturación del suelo originado por la combinación deficiente del riego del sector, el taponamiento de diferentes quebradas y la deficiencia del drenaje del terreno.Con fecha 31/03/2023 la SGR declaró la ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa, el cual tiene un área de 526.22 hectáreas que se extiende sobre la comunidad La Cría, cantón Santa Isabel, provincia del Azuay.El 06/04/2023 la SGR emite el cambio a ALERTA NARANJA de acuerdo al informe elaborado por Técnico de Análisis de Riesgos de la Coordinación Zonal 6 de Gestión de Riesgos.</td></tr><tr><td>Situación actual:</td><td>Técnico de repuesta de la SGR CZ6 informa la entrega de asistencia humanitaria a las familias que se encuentran en el albergue.</td></tr><tr><td>Afectaciones:</td><td>- 38 familias evacuadas.- 130 personas evacuadas (albergue temporal, con fecha 08/05/2023 se encuentran en el albergue 39 familias 112 personas)- 3 bienes privado afectado (capilla, casa comunal, cancha central)- 1 bien público afectado- 44 familias afectadas (178 personas)- 44 familias afectadas- 8 viviendas destruidas- 8 familias damnificadas (25 personas que permanecen en casa de familias acogientes)- 3 bienes privados afectados (predios)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Santa Isabel se mantiene en monitoreo constante del evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/a7f0db13dd7514401873bb5931f47a18a840c998c516bca97826cc601487e291.jpg)


## Deslizamiento

Localización: Cañar/Cañar/Cañar/Cuchucun-Cruz Loma-Quilloac.
Antecedentes: GAD Cantonal de Cañar informó que a partir del 13 de Octubre de 2022 por la época lluviosa y mal manejo del agua de riego se reportó un deslizamiento que afecta viviendas del sector. Con fecha 14 de Febrero del 2023 se activó el COE Cantonal donde la máxima autoridad del cantón solicita la activación de las mesas técnicas y grupos de trabajo para la atención de la emergencia. Intervención del MIDUVI y GAD PROVINCIAL.
Con fecha 31/03/2023 la SGR declaró la ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa, con un área de 330.56 hectáreas pertenecientes al sector Cuchucún, el cual comprende las comunidades: Quilloac, Cruz Loma y Cuchucún, del cantón Cañar, provincia de Cañar
Situación actual: Con fecha 03/05/2023 personal técnico de la SGR de forma conjunta con GAD Cañar y el uso de equipos geofísicos realizaron una inspección técnica con el objetivo de 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 12 de 21

<table><tr><td></td><td>caracterizar el subsuelo en función de la conductividad de las rocas debido que se trata de un movimiento complejo, complementando así el levantamiento de información realizado en días anteriores con la técnica sísmica de refracción.</td></tr><tr><td>Afectaciones:</td><td>- 22 viviendas afectadas- 4 viviendas destruidas- 6 familias damnificadas- 16 personas damnificadas (permanecen en casa de familia acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR en coordinación con el GAD Cañar, realizó levantamiento de información</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/Directora SGR CZ6.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/ec4ffdbbd6b3d25c597c9df6e39a13ab3a922ac9230150fe888cbafb77b7a044.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/Rosas, Bellavista, Tamboloma, Chunazana.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Secretaría de Gestión de Riesgos declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 09/05/2023 técnico de la UGR Nabón informa que la segunda etapa de las obras de mitigación tiene un avance del 35%. La vía Ramada-Nabón sector Trancapata continúa cerrada, vía alterna La Ramada-Chunazana-El Salado-Nabón.</td></tr><tr><td>Afectaciones:</td><td>- 50 metros de vía afectada (vía habilitada, sector El Progreso)- 84 familias afectadas (238 personas afectadas)- 60 familias damnificadas (162 personas damnificadas)- 40 metros de vía afectados (vía Cerrada, sector Trancapata)- 60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)- 1 Casa comunal afectada con cuarteaduras- 84 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 59 viviendas destruidas.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)- Iglesia demolida por los daños estructurales presentados- Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Nabón se mantiene en continuo monitoreo de la zona afectada</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/4ef164b5369344421d3ed61d4ffc7ee1db6ae56926c6b19ef1f2d9c364464e4f.jpg)


<table><tr><td>Localización:</td><td>Loja/Puyango/El Limo/varios sectores (3 de Noviembre, La Bocana, La Palmira).</td></tr><tr><td>Antecedentes:</td><td>Por presencia de lluvias en la tarde del viernes 28/04/2023, se produjo el desbordamiento de la quebrada del sector ocasionando daños a viviendas y vehículos que se encontraban estacionados y fueron arrastrados por el sedimento originado por dicho desbordamiento, adicional se reportó el cierre temporal de una vía de tercer orden.GAD Cantonal de Puyango se declaró en situación de emergencia el 29/04/2023 para coordinar acciones oportunas con las entidades de respuesta y poder dar una rápida atención al evento por inundación</td></tr><tr><td>Situación actual:</td><td>Se realiza la gestión para los bonos de contingencia a las familias afectadasEn relación a las vías afectadas, al momento el tramo que conduce hacia Añalcal - Caucho se encuentra cerrada debido al socavamiento presentado y el tramo que conduce hacia La Bocana se encuentra habilitada.</td></tr><tr><td>Afectaciones:</td><td>- 14 viviendas destruidas (datos preliminares)- 4 viviendas afectadas (datos preliminares)- 60 familias 300 personas afectadas (datos preliminares)- 19 bienes privados destruidos. (10 carros arrastrados y 9 motocicletas)- 30 metros de vía afectada.</td></tr><tr><td>Acciones de respuesta:</td><td>SGR realiza la gestión para los bonos de contingencia a las familias afectadas</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/GAD Cantonal Puyango.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/a68b2bde35f5aaa2706d2e68b31ffd594b6f7b56ea19462864ad3d7f80674be7.jpg)


## Inundación

Localización: Loja/Zapotillo/varias Parroquias (Cazaderos, Mangahurco, Bolaspamba y Paletillas).
Antecedentes: El 17/04/2023 por lluvias suscitadas en días anteriores se produjo el desbordamiento de varias quebradas: (Cazaderos, Mangahurco, El Guabo y quebrada Paletillas); causando afectaciones en viviendas, cultivos, vías, bienes privados en varias parroquias del cantón; en la Parroquia Cazaderos existe el riesgo de perder 30 mil plantas de tomate y en la Parroquia Bolaspamba existen 10 viviendas con riesgo de colapsar; así mismo COE Cantonal con fecha 17 de abril del 2023, sugirió al GAD Cantonal de Zapotillo se declare la situación de emergencia al cantón Zapotillo. 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 13 de 21

<table><tr><td>Situación actual:</td><td>La familia damnificada permanecerá de manera indefinida en casa de familia acogienteVía de segundo orden habilitada al tránsito vehicular</td></tr><tr><td>Afectaciones:</td><td>Parroquia Cazaderos:- 120 hectáreas de cultivo de maíz perdido- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 1 vivienda destruidaParroquia Mangahurco:- 70 hectáreas de cultivo de maíz perdido- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 50 familias afectadas- 1 vía de segundo orden cerrada (Y de Mangahurco a Cazaderos)Parroquia Bolaspamba:-10 familias conformadas por 35 personas afectadas-1 familia damnificada conformada por 4 personas-3 viviendas afectadas (Sector El Guabo)-7 viviendas afectadas (Sector Chaquino)-1 vivienda destruida (Sector Transito Mangahurquillo)-Vía de segundo orden (habilitada)Parroquia Paletillas:- Pérdida de cultivos en fase de ciclo productivo (En fase de levantamiento de información)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Zapotillo conjuntamente con personal técnico de SGR realizó el levantamiento de información.Personal de Gobierno Provincial (VIALSUR), GAD Cantonal y moradores de la parroquia Bolaspamba, realizaron los trabajos de rehabilitación vial.SGR coordinó la atención del evento y realiza constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/UGR Zapotillo/GAD-P (VIALSUR).</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/930251144f78cbfab41be79d5ee6091033ff1ebc2760fa44c1c98880062fc7f0.jpg)


<table><tr><td>Localización:</td><td>Pichincha/Quito/Calderón/Quebrada Chaquiscahuaico.</td></tr><tr><td>Antecedentes:</td><td>El 13/05/2022, debido a las lluvias ocurridas en días anteriores se reporta un deslizamiento de tierra que afecta la escalinata y parte del mirador “Gruta de La virgen”.</td></tr><tr><td>Situación actual:</td><td>Se realizó una inspección por parte del Operativo Zonal quién reportó que no existe represamiento de agua, ni viviendas afectadas.</td></tr><tr><td>Afectaciones:</td><td>- 2 bienes públicos afectados (Escalinata del mirador y tendido eléctrico del sector)</td></tr><tr><td>Acciones de respuesta:</td><td>EEQ informa que solo un 40 % del sector se encuentra al momento con servicio de energía eléctrica, se continúa trabajando en el lugar, por desconexión de la Red Primaria. Se realizó la colocación de señalética por parte de la EPMMOP, AMT realiza el control de vehículos pesados. Se espera el informe técnico por parte de la DMGR.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ9 Unidad de Monitoreo Pichincha/COEM/EEQ/EPMMOP.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/26f645032b266369d4fef4b07b2430b4134dce5f5f39697a376ba6cdeeae122e.jpg)


<table><tr><td>Localización:</td><td>Pichincha/ Mejía/Manuel Cornejo Astorga/ Km 47 vía Alóag - Unión del Toachi -Tandapí.</td></tr><tr><td>Antecedentes:</td><td>El 22/04/2023, A causa de las lluvias ocurridas se produjo el desbordamiento del río del sector al igual que las cascadas pertenecientes a la parroquia, se indica de varias viviendas afectadas, una unidad educativa y las familias fueron evacuadas.</td></tr><tr><td>Situación actual:</td><td>Se realizó evaluación de la unidad educativa afectada y, en una minga, con el apoyo de la comunidad atendieron las afectaciones mediante la limpieza de los espacios y la reparación del cerramiento, luego se coordinó el presupuesto necesario para hacer trabajos de mitigación, las personas que evacuaron en la noche pernoctan en el albergue, pero en las mañanas retornan a sus viviendas, también se les entregó asistencia humanitaria.</td></tr><tr><td>Afectaciones:</td><td>- 14 familias evacuadas (3 familias evacuadas compuestas de 11 personas permanecen en el albergue y las 11 familias restante retornaron a sus viviendas)- 14 viviendas afectadas (se solicitó una evaluación técnica de 9 viviendas para una posible reubicación)- 1 unidad educativa afectada (Dr. José Ricardo Chiriboga Villagómez, Se solicitó Evaluación técnica por parte del MINEDUC para una posible reubicación de la unidad educativa)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal entregó asistencia humanitaria, realizó el seguimiento de las personas albergadas y con GAD Provincial realizaron limpieza y retiro de escombros, MINEDUC realizó inspección y coordina procesos administrativos para ejecutar obras de mitigación.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Unidad de Monitoreo Pichincha/GAD Provincial de Pichincha/GAD Parroquial de Tandapi.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 14 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/f0528bf4149e7ba602c6c3521abc97e681e0e238b9c27c562c7da20f6477f47a.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Pichincha/Quito/La Concepción/La Pulida.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias ocurridas el 22/04/2023, se produjo el desbordamiento de la quebrada Zabala y Antonio Reyes que afectó a varias viviendas del sector. Se reportan los siguientes cierres de vía: avenidas Mariscal Sucre, Melchor Valdez y Carlos Arteta/Virgilio Corral y Melchor Valdez / Melchor Valdez y Manuel Zabala / Carlos Arteta y Manuel Zabala / Carlos Arteta y Virgilio Corral</td></tr><tr><td>Situación actual:</td><td>En el sector de La Pulida Alta se bajaron 5 metros de agua en represamiento se construyó un dique en la parte de atrás para bombear el agua y así evitar que esta ingrese a la estructura para desalojar todo el lodo que se retuvo en la misma, se tiene planificado concluir con todos los trabajos de limpieza el 20 de mayo.</td></tr><tr><td>Afectaciones:</td><td>- 20 viviendas afectadas- 13 familias afectadas (7 familias damnificadas)- 25 personas afectadas (21 personas damnificadas)- 50 metros de vía de segundo orden</td></tr><tr><td>Acciones de respuesta:</td><td>GAD DMQ y EMAPS indican los trabajos en La Pulida Chica, concluyeron. La estructura se encuentra limpia al igual que los colectores, y se están alzando los pozos que se encontraban perdidos por el relleno. Adicional se realizó la construcción de un dique.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ9 Unidad de Monitoreo Pichincha/GAD Cantonal DMQ/EPMAPS-</td></tr></table>

## Monitoreo de estado de vías afectadas por eventos peligrosos

VÍAS DE PRIMER ORDEN: 

## 10 vías de primer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Bolívar</td><td>Guaranda</td><td>Guanujo</td><td>El Mirador, Km 18 vía Guanujo-Echeandia [E494]</td><td>DESLIZAMIENTO</td><td>--</td><td>17/05/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Pichincha</td><td>Mejía</td><td>Alóag</td><td>Km 43+850, vía Alóag Unión del Toachi [E20]</td><td>DESLIZAMIENTO</td><td>--</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Guayas</td><td>Pedro Carbo</td><td>Sabanilla</td><td>Recinto Villao</td><td>SOCAVAMIENTO</td><td>10</td><td>11/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Puerto Quito</td><td>Puerto Quito</td><td>Puente que limita entre Pichincha y Esmeraldas, Los Bancos [E28]</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>18/03/2023</td><td>Quito, Alóag - Unión del Toachi - Santo Domingo.----Puerto Quito-La Sexta - Quinindé-----Calacalí-Los Bancos-Las Mercedes-Santo Domingo</td></tr><tr><td>5</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>Vía Rcto. La Estrella Rcto. La Vitalia de ler orden - Pisagua Alto - La Constancia</td><td>SOCAVAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz de Pineda</td><td>vía El Salado - San Luis [E45]</td><td>ALUVION</td><td>---</td><td>04/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Napo</td><td>Chaco</td><td>Gonzalo Díaz de Pineda</td><td>Puente sobre el río Marker, vía E45 San Luis -El Reventador</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>22/02/2023</td><td>El Reventador-Lago Agrio-El Coca-Loreto -Y de Narupa-Y de Baeza-Quito o viceversa.</td></tr><tr><td>8</td><td>Manabí</td><td>Manta</td><td>San Lorenzo</td><td>Ruta del Spondiylus San Lorenzo - Santa Rosa [E15]</td><td>OLEAJE</td><td>1200</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Chimborazo</td><td>Alausí</td><td>Alausí, Cabecera Cantonal</td><td>Casual, vía Guamote - Alausí [E-35].</td><td>HUNDIMIENTO</td><td>1120</td><td>09/12/2022</td><td>- Vehículos livianos: Alausí - García Moreno - Guamote- Vehículos pesados: Zhud - El Triunfo - Cumandá - Pallatanga - Riobamba</td></tr><tr><td>10</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>1040</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>

## 44 vías de primer orden parcialmente habilitadas

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0280
Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 15 de 21


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Calacali</td><td>Km 30, vía Mitad del Mundo -Río Blanco [E28]</td><td>DESLIZAMIENTO</td><td>--</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Orellana</td><td>Loreto</td><td>San Vicente de Huaticocha</td><td>Límite provincial Napo-Orellana, Pasohurco, vía Loreto - Y de Narupa [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>km 24, Km 26, vía Y de Narupa - Y de Baeza [E20-E45A].</td><td>DESLIZAMIENTO</td><td>250</td><td>09/05/2023</td><td>Km vía parcialmente habilitada</td></tr><tr><td>4</td><td>Loja</td><td>Puyango</td><td>Alamor</td><td>Sector &quot;La Y&quot;, vía a B Balsones [E25]</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 90, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>El Oro</td><td>Balsas</td><td>Balsas</td><td>Km4, vía Balsas - Saracay [E-50]</td><td>DESLIZAMIENTO</td><td>15</td><td>26/04/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Colta</td><td>Juan de Velasco (Pangor)</td><td>Guangopuc, Rumipamba, Vía Colta - Pallatanga [E487]</td><td>DESLIZAMIENTO</td><td>100</td><td>24/04/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Bolívar</td><td>Chillanes</td><td>Chillanes</td><td>Varios sectores: a la altura de la hacienda de San Juan de Azapi, Vista Alegre, San Francisco de Azapi, vía Chillanes-Bucay [E495]</td><td>DESLIZAMIENTO</td><td>300</td><td>22/04/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Pichincha</td><td>Mejía</td><td>Alóag Manuel Cornejo Astorga (Tandapi)</td><td>km 56, vía Alóag - Unión del Toachi [E35]</td><td>SOCAVAMIENTO</td><td>40</td><td>22/04/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>El Oro</td><td>Las Lajas</td><td>La Victoria</td><td>El Tigre, Vía El Tigre - Puyango [E-25]</td><td>DESLIZAMIENTO</td><td>10</td><td>20/04/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 13, vía Coca - Dayuma [E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>20/04/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Loja</td><td>Célica</td><td>Sabanilla</td><td>Cabuyo, vía Redondel de la Aduana a Pindal - Troncal de la Costa [E25]</td><td>DESLIZAMIENTO</td><td>50</td><td>14/04/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Pichincha</td><td>Mejía</td><td>Alóag</td><td>Manuel Cornejo Astorga (Tandapi), km 17 + 300, vía Alóag - Unión del Toachi [E20]</td><td>SOCAVAMIENTO</td><td>--</td><td>10/04/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Los Ríos</td><td>Montalvo</td><td>La Esmeralda</td><td>La Guayaba - río La Esmeralda</td><td>SOCAVAMIENTO</td><td>60</td><td>05/04/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>km 92, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>--</td><td>05/04/2023</td><td>Ninguna</td></tr><tr><td>16</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 91, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>--</td><td>04/04/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Santo Domingo de los Tsáchilas</td><td>Santo Domingo</td><td>Abraham Calazacón</td><td>Coop. Modelo Av. Los Colonos, calle Río Verde, Junto al UPC.</td><td>INUNDACIÓN</td><td>30</td><td>01/04/2023</td><td>Ninguna</td></tr><tr><td>18</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 64, vía Cuenca-Molleturo-Naranjal [E-582</td><td>DESLIZAMIENTO</td><td>--</td><td>28/03/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Loja</td><td>Las Lajas</td><td>La Victoria</td><td>El Tigre, Vía El Tigre - Puyango [E-25]</td><td>DESLIZAMIENTO</td><td>8</td><td>26/03/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 92-96-97-98, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>80</td><td>18/03/2023</td><td>Ninguna</td></tr><tr><td>21</td><td>Pichincha</td><td>Quito</td><td>Pifo</td><td>10 minutos Virgen de Papallacta, vía Papallacta - Baeza [E20]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2023</td><td>Ninguna</td></tr><tr><td>22</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Salida de Santa Rufina hacía, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>23</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Vía Arenillas - Las Lajas [E25]</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>24</td><td>Bolívar</td><td>San Miguel</td><td>San Miguel</td><td>El Calzado-Abs.27+800, vía San Miguel-Balzapamba [E 491]</td><td>DESLIZAMIENTO</td><td>100</td><td>23/02/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0280
Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 16 de 21


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>25</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>Km 61, vía Paute Guarumales Méndez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>28</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>29</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>30</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>31</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>32</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>33</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>34</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>35</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tulcán - Ibarra 2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>36</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>37</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>38</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>39</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>40</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>41</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>42</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>43</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 17 de 21

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>44</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago -San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>

VÍAS DE SEGUNDO ORDEN 

## 08 vías de segundo orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>Km 37, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Loja</td><td>Loja</td><td>Gualel</td><td>San Francisco, vía Gualel-Chuquiribamba.</td><td>SOCAVAMIENTO</td><td>--</td><td>15/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>vía urbana a Camino Real</td><td>DESLIZAMIENTO</td><td>50</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Imbabura</td><td>San Miguel de Urcuqui</td><td>San Blas</td><td>Santa Cecilia</td><td>SOCAVAMIENTO</td><td>20</td><td>26/10/2022</td><td>Vía antigua de Santa Cecilia - Timbuyacu.</td></tr><tr><td>5</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>7</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>8</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 21 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Unión Manabita, vía Lomas del Perú, vía El Mirador, vía Maracayairo</td><td>DESLIZAMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Morona Santiago</td><td>Morona</td><td>General Proaño</td><td>Kilómetro 105, vía Macas-Ríobamba [E465]</td><td>DESLIZAMIENTO</td><td>15</td><td>12/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Manabí</td><td>Paján</td><td>Campuzano</td><td>Estero Ciego</td><td>HUNDIMIENTO</td><td>250</td><td>09/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Chimborazo</td><td>Alausí</td><td>Multitud</td><td>Varios Sectores, vía Pallatanga-Cumandá [E-487].</td><td>HUNDIMIENTO</td><td>100</td><td>09/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>El Oro</td><td>Zaruma</td><td>Muluncay</td><td>Via Zaruma - Atahualpa [E585].</td><td>DESLIZAMIENTO</td><td>8</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Imbabura</td><td>Ibarra</td><td>Caranqui</td><td>Guayaquil de Caranqui</td><td>DESLIZAMIENTO</td><td>20</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Imbabura</td><td>Cotacachi</td><td>Imantag</td><td>Sector quebrada Quitubi - vía Imantag - Quitumba Coñaqui</td><td>DESLIZAMIENTO</td><td>30</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío San Francisco de Trigoloma, vía Pallatanga - Guayaquil [E-487]</td><td>SOCVAMIENTO</td><td>--</td><td>13/04/2023</td><td>Ríobamba - Ambato - Latacunga- Alóag - Santo Domingo. Ríobamba - Guaranda - Babahoyo.</td></tr><tr><td>9</td><td>El Oro</td><td>Piñas</td><td>Piedras</td><td>El Recuerdo, vía Saracay - Piedras.</td><td>SOCAVAMIENTO</td><td>5</td><td>13/04/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Imbabura</td><td>Ibarra</td><td>Angochagua</td><td>El Cunro, vía Ibarra - Zuleta.</td><td>ALUVIÓN</td><td>70</td><td>07/04/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Pichincha</td><td>Quito</td><td>El Condado</td><td>La Roldós, calle Rumihurco vía a Chicahuaico</td><td>SOCAVAMIENTO</td><td>--</td><td>19/03/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Los Ríos</td><td>Quinsaloma</td><td>Quinsaloma</td><td>Rcto. San Gabriel - Rcto. San Vicente - Rcto. Oro Verde - Río Calope</td><td>INUNDACIÓN</td><td>72</td><td>18/03/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>El Oro</td><td>Santa Rosa</td><td>Victoria</td><td>Km 18, vía Buenavista - San Juan de Cerro Azul [E-585]</td><td>ALUVION</td><td>150</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>Km 47, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>25</td><td>06/03/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


23 vías de tercer orden cerradas


## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos - No 0280
Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 18 de 21


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>15</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Guapo, vía Colta -Pallatanga [E-487]</td><td>ALUVIÓN</td><td>40</td><td>21/02/2023</td><td>Ríobamba -Guaranda -Babahoyo -Guayaquil</td></tr><tr><td>16</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>15</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>17</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr></table>

## VÍAS DE TERCER ORDEN:

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Chillogallo</td><td>Buena Aventura, calle Agustín Albán Borja</td><td>DESLIZAMIENTO</td><td>--</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Valle del Sade.</td><td>HUNDIMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>vía de ingreso al recinto Chaupicruz</td><td>DESLIZAMIENTO</td><td>--</td><td>11/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Loja</td><td>Puyango</td><td>El Limo</td><td>Añalcal - Caucho</td><td>SOCAVAMIENTO</td><td>30</td><td>28/04/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Imbabura</td><td>Otavalo</td><td>Selva Alegre</td><td>San Luis, vía Selva Alegre - San Luis.</td><td>SOCAVAMIENTO</td><td>20</td><td>26/04/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Bolívar</td><td>Guaranda</td><td>San Luis de Pambil</td><td>La Playita, Pisis, Ingreso al Complejo Turistico el Faraón</td><td>INUNDACIÓN</td><td>--</td><td>25/04/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Los Ríos</td><td>Urdaneta</td><td>Ricaurte</td><td>Rcto. Barranco hacia Rcto. Salampe - río Catarama</td><td>SOCAVAMIENTO</td><td>300</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Cotopaxi</td><td>La Maná</td><td>La Maná</td><td>Barrio 26 de Octubre</td><td>INUNDACIÓN</td><td>--</td><td>22/04/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Cañar</td><td>Deleg</td><td>Deleg</td><td>Sector Camal Municipal</td><td>SOCAVAMIENTO</td><td>--</td><td>21/04/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Morona Santiago</td><td>Limón Indanza</td><td>San Antonio (cabecera en San Antonio Centro)</td><td>San Salvador, Mayapis, Serembo, El Cisne, 12 de Febrero</td><td>DESLIZAMIENTO</td><td>2000</td><td>17/04/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Guayas</td><td>Alfredo Baquerizo Moreno (Jujan)</td><td>Cabecera Cantonal</td><td>Recinto El Tránsito</td><td>SOCAVAMIENTO</td><td>60</td><td>06/04/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Imbabura</td><td>Cotacachi</td><td>Vacas Galindo</td><td>Balsapamba - Pan de Azúcar.</td><td>ALUVIÓN</td><td>30</td><td>06/04/20223</td><td>Ninguna</td></tr><tr><td>13</td><td>Bolívar</td><td>Guaranda</td><td>San Luis de Pambil</td><td>Varios sectores; María Aurora, Rosa Elvira - vía a las Comunidades de San Luis de Pambil.</td><td>COLAPSO ESTRUCTURAL</td><td>28</td><td>24/03/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Bolívar</td><td>Chimbo</td><td>La Magdalena</td><td>vía El Carmen a Cochabamba</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>La Valdivia - río Clementina</td><td>INUNDACIÓN</td><td>30</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>16</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>La Estrella - Cda. Felipe Abud - río Cristal</td><td>SOCAVAMIENTO</td><td>800</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur</td><td>INUNDACIÓN</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 19 de 21

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Chillogallo</td><td>Buena Aventura, calle Agustín Albán Borja</td><td>DESLIZAMIENTO</td><td>--</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>22</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>23</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>955.9</td><td>20/01/2021</td><td>Ninguna</td></tr></table>

## 09 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Quinindé</td><td>La Unión</td><td>El Tambo.</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Esmeraldas</td><td>Atacames</td><td>La Unión</td><td>Recinto Tazone, Agua Fría.</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Imbabura</td><td>Cotacachi</td><td>Peñaherrera</td><td>Villa flora</td><td>HUNDIMIENTO</td><td>30</td><td>05/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>El Oro/Piñas</td><td>Moromoro</td><td>El Palto</td><td>Via El Palto - La Libertad</td><td>SOCAVAMIENTO</td><td>8</td><td>04/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Imbabura</td><td>Cotacachi</td><td>Imantag</td><td>El Potrerillo</td><td>SOCAVAMIENTO</td><td>40</td><td>24/04/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Cotopaxi</td><td>Pangua</td><td>Ramón Campaña</td><td>Miligua, vía Ramón Campaña - El Corazón</td><td>DESLIZAMIENTO</td><td>50</td><td>12/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>8</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>9</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>


4. Declaratorias emitidas por el SGR (vigentes en orden cronológico)


<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/15abd4805603771bf4d78f30b4cb68d99fec88ee77b56850ebc9acdbc1353d4e.jpg"/></td><td>Declaratoria de ALERTA AMARILLA Fenómeno El Niño: Oscilación del Sur (ENOS), en los territorios ubicados a una altitud igual y menor a 1500 msnm, que comprende 17 provincias, 143 cantones, y 489 parroquias</td><td>Amarilla</td><td>15/05/2023</td><td>Resolución No. SGR-156-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/093a9d66e7539703f887d08eb2e512ec9caeacc159a9d2c1c409ac58a1fc978b.jpg"/></td><td>Declaratoria de Cambio de ALERTA AMARILLA por movimientos en masa al área de 11,50 hectáreas en el sector Astillero, de la parroquia Bahía de Caráquez, cantón Sucre, provincia de Manabí; considerando que las condiciones y parámetros indican que puede presentarse un evento que produzca afectaciones en la población e infraestructura.</td><td>Amarilla</td><td>10/04/2023</td><td>Resolución No. SGR-110-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/6fd9d68f67171e4ce5fd32dfea43965e3c00890069e3fc2fba38b97718e270a6.jpg"/></td><td>Declaratoria de Cambio de ALERTA AMARILLA a NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua.</td><td>Naranja</td><td>10/04/2023</td><td>Resolución No. SGR-111-2023</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0280 Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 20 de 21

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/81aaab59f331eabe0e0336f2287834b51f0d0a327ef97640bb79a36e3238e4ec.jpg)


Declaratoria del estado de ALERTA NARANJA por movimientos en masa al área de 152,22 hectáreas que comprende los sectores: Namza Chico, Pasán, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chachán, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/71514d4cfe7d9e2e5fdf613d9b726f397f3dd7d734f5b41564b2ee7fb6256a9d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/f9d20ff7cefcce59c6b803697bec838efefd9acb9df4e5d028a1c10d200751d8.jpg)


Declaratoria del estado de ALERTA NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa el cual tiene un área de 442.62 hectáreas que se extiende sobre la comunidad La Cría - Cantón: Santa Isabel, Provincia: Azuay. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/db8b888bb40a61ecdf201a10d8f19c666f150f57ae40943a7efc5e0003064a64.jpg)


Declaratoria del estado de ALERTA NARANJA por movimientos en masa, el área de influencia equivalente a 53132.993 m², ubicada en la ciudadela El Fátima, parroquia Francisco Pacheco, del cantón Portoviejo, Provincia de Manabí, debido a que la materialización del evento peligroso por movimientos en masa es inminente, lo que afectaría a la población. 

Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa con un área de 330.56 hectáreas pertenecientes al sector Cuchucún, el cual comprende las comunidades: Quilloac, Cruz Loma y Cuchucún. Cantón: Cañar, Provincia: Cañar. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/fc90528f5ed22d57e5ae23ce01ffc9c1a111eb2a8b20a3a93fd56704cc2f3b04.jpg)


## Incremento Actividad Volcánica Cotopaxi

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/ce9490ae51fdadc52f2aac8b36bddaebf16d1d4131ec8ddc3a6108873152fa69.jpg)


Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/9a8c7f8823dda66481b2e80088cc5723bee1fb147938bc85d0dfbacf0e70fa02.jpg)


## Movimiento en masa

barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/db8d48353a902690edaa138d088319056686cc6376120fcdfd48fb9f986af741.jpg)


Socavamiento por la erosión del río Coca y sus afluentes -Cantón: El Chaco, Provincia: Napo. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/b234294db59ff391e2ac11a50e193e670dad8c50dff5822e0d92220e3b867874.jpg)


Actividad Volcánica Sangay: Caída de ceniza
Provincia de Chimborazo 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/d293a07c0477b33c47f1ea330d1c29f5cfdd26c650286882f18fca41a3475beb.jpg)


Aumento de sedimentos volcánicos
Río Upano- Parroquias Sinaí y Sevilla de Don Bosco,
cantón Morona, Morona Santiago 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/26972dd3e925019b2ab1b6f609a59146ce1bfeff1d8e9407834d8c04b6ff3f99.jpg)


Incendios Forestales
Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/1c19ea59e9c5376b1d558dce2de4f9821c4c3ca965e045366e92e88171738eaa.jpg)


Incremento de lluvias e inundaciones
Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo. 

## Secretaría de Gestión de Riesgos

<table><tr><td>Naranja</td><td>09/04/2023</td><td>Resolución No. SGR 106-023</td></tr><tr><td>Naranja</td><td>06/04/2023</td><td>Resolución No. SGR-104-2023</td></tr><tr><td>Naranja</td><td>03/04/2023</td><td>Resolución No. SGR-099-2023</td></tr><tr><td>Amarilla</td><td>31/03/2023</td><td>Resolución No. SGR-091-2023</td></tr><tr><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SGR-0311-2022</td></tr><tr><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SGR-182-2022</td></tr><tr><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SGR-171-2021</td></tr><tr><td>Roja</td><td>21/05/2021</td><td>Resolución No. SGR-058-2021</td></tr><tr><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SGR-045-2020</td></tr><tr><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SGR-140-2019</td></tr><tr><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SGR-111-2019</td></tr><tr><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SGR-066-2019</td></tr></table>


Reporte de monitoreo de amenazas y eventos peligrosos - No 0280
Fecha y Hora de actualización: sábado, 20 de mayo de 2023 - 21:13:39 / Página 21 de 21


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/b1375f580b948f11e6fae3182645a09fb64fc77bcd2d7dcf93760eb933af0f3f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/405a3b06638c43731f24d895d645161b098bca6eff12143b6414942d0562fc83.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/6808aca6414e74e1879c2e5dee7db604449efba58b118b32ccf6afa9dbafe3d0.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/acd13b71aa168b61130ac132cd1de41ada0c6537be7f3726a3700ffee73971b7.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/e4f269dd1da1163887e8f4f3422086f2c022a7be44bf91503e5ecf8b6af19c04.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/af9ee8fee15b53f9ce6cdeda96514ffe4e975d7c3132d90e7925fb2d01e3b00d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/34586c8628e2e41b3b0acd29e7bb2b548180c7e973fd86e1542eaee82a1eea36.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/e06c8c74f6b893e4380b7bf6f6b80cd293c7070f1659c226833325a979f07ec8.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/35aa4228a5ba9e8a1360975f188f0f321659c8de163d90cbe85cc06e461d4b29.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6a9e0d8c-433c-49d2-9e8b-e20b511442d8/a4aafbff5900e952890666718104b93095492dcf48a96374ef1112033f19eaf4.jpg)


<table><tr><td>Fenómeno El Niño (ENOS)Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SGR-005-2019</td></tr><tr><td>DeslizamientoSan José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="2">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td colspan="2">InundacionesBabahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td colspan="2">Hundimiento,Zaruma, El Oro</td><td>07/03/2017</td><td>Resolución No. SzIGR-029-2015</td></tr></table>