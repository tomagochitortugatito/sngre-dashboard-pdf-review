# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 1 de 27

Periodo de Monitoreo: 

Desde: 09h00 09/06/2023 

Hasta: 21h00 09/06/2023 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

- Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/faba5350ae3ee1a8a1bdd9bd5b7b4ecee281d664fd4e2aaca93ef8de6feaf9b8.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/4d68c26043c80a0dfd8b862b37f5250bec61b248b692378b6a2ad390d4b22338.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/f519c4755e62090e84e889e486685c0e927ab34836ac86984b264f6a13ab5b13.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/d3749723669da8d4cb1c0f21a1c861cd98ad15210bf7b964ec7fff01a945891a.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/2d76728b1488c357c05b9f7ff5ae3c45a2fb3c172ffc443a51d7f26f41191491.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18:00 Sin reporte de actividad superficial</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/ebb0c2f640aa8ed944d049e7fdcc12ef88a611044a197ce41e2ee8d54c5baf8f.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/25581baf75d54abe468ca0fe8890ee7112eba063d262bffc5aeb32f8a6c48407.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">02 Cuerpos de Agua Desbordado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del Río</td></tr><tr><td rowspan="2">Los Ríos</td><td>Quinsaloma</td><td>Quinsaloma , Cabecera Cantonal</td><td>Rcto. San Vicente</td><td>Calope</td></tr><tr><td>Quevedo</td><td>La Esperanza</td><td>El Bartolo</td><td>Bartolo</td></tr><tr><td colspan="5">01 Cuerpo de Agua con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del Río</td></tr><tr><td>Manabí</td><td>Flavio Alfaro</td><td>Flavio Alfaro</td><td>Centro, varios sectores</td><td>Pescadillo</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/f5483732949c957e95b2613449c1ef295b3a8a628f4119fc56de579000466f02.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/cb147110d6f9799552acba29dab85b305716a306058b4215aa92320d820b7db1.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td></td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td></td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>83.73</td><td>85.00</td><td>09:06</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>116.15</td><td>117.00</td><td>09:06</td><td>VERDE</td></tr><tr><td>Chongón, Guayas</td><td>44.50</td><td>---</td><td>51.15</td><td>---</td><td></td></tr><tr><td>El Azúcar, Santa Elena</td><td>40.00</td><td>---</td><td>45.09</td><td>---</td><td></td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 2 de 27

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/7e73007dfc8ce3970166e955e91f6d4861e61eede07fd611779dfef730ce3a00.jpg)


<table><tr><td>San Vicente, Santa Elena</td><td>50.00</td><td>---</td><td>57.49</td><td>---</td><td></td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>62.74</td><td>66.00</td><td>09:51</td><td>VERDE</td></tr><tr><td>Poza Honda, Manabí</td><td>104.29</td><td>104.29</td><td>106.50</td><td>09:51</td><td>VERDE</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>62.72</td><td>68.50</td><td>09:51</td><td>VERDE</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td></td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td></td></tr></table>

## SITUACIÓN HIDROMETEREOLÓGICA

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/1a9abc995be4dd388638fafdf4e7124806eee8395f2ca4990b774d9e3747f35c.jpg)


## AMENAZA: LLUVIAS Y TORMENTAS Y RÁFAGAS DE VIENTO ADVERTENCIA METEOROLÓGICA N°28

Vigencia: desde las 17H00 del 06 de junio hasta las 10H00 del 10 de junio de 2023 

SITUACIÓN: Se prevé que continúen las precipitaciones de variable intensidad con tormentas en la región Litoral y estribación de cordillera. 

- Región Litoral: Los eventos más intensos se presentarán de manera dispersa entre las tardes y noches al norte e interior de la región. 

- Región Insular: Lluvias de mayor intensidad entre el lunes 5 y martes 6 de junio. Lluvias de mayor intensidad se presentarán al norte de las islas. 

- Región Interandina: Se esperan lluvias de mayor relevancia en localidades de estribaciones de cordillera occidental. 

## FUENTE: INAMHI

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/4cf93562bd518d5a5a47146713d322dfa2fc2f7fa6999a97233dd3357cd07cdc.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>--</td><td>--</td><td>--</td><td>---</td><td>----</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/e38bfeaedfbab2b097689921f9893412d2496744942f2f71c22d03a6393e6341.jpg)


<table><tr><td>Localización:</td><td>A 29.12 Km de Balao, Guayas.</td></tr><tr><td>Antecedentes:</td><td>Se produjo un sismo a las 12:12 del 18/03/2023 de Magnitud 6.5, profundidad 44.Km localizado a 29.12 km de Balao Guayas.De acuerdo al barrido realizado por la SGR el sismo fue sentido a nivel nacional con mayor intensidad en las provincias: de El Oro, Guayas, Los Ríos, Manabí, Chimborazo y Azuay.</td></tr><tr><td>Situación actual:</td><td>Según reporte del IG-EPN, el evento telúrico suscitado a las 00h35 del 25/04/2023 tuvo su epicentro a 36 km en dirección noreste de la Isla Puna, del cantón Balao, en la provincia del Guayas, de magnitud 5.7 (Mlv), a una profundidad de 60 km.Se han activado los COE Provinciales de Guayas, Azuay, Cañar y El Oro, así como los COE Cantonales: El Guabo, Pasaje, Machala, Huaquillas y Santa Rosa en El Oro; Cuenca y Santa Isabel en Azuay.Se encuentran declarados en emergencia los cantones de Pasaje y El Guabo en la provincia de El Oro y Naranjal en la provincia del Guayas.La Agencia de Regulación y Control del Agua en la provincia de El Oro y en el cantón Cuenca se reestableció el servicio de agua potable al 100%.Se encuentran activos los refugios temporales: Casa Comunal 24 de Mayo (14 personas) y el Refugio Temporal en la Casa Comunal Coop. 10 de Agosto en El Guabo (63 personas), donde al momento pernoctan las familias por precaución.</td></tr><tr><td>Afectaciones:</td><td>-Personas fallecidas: 14 personas - 12 El Oro (10 Machala, 1 El Guabo, 1 Pasaje), 2 Azuay (1 Cuenca,1 Molleturo) - (Ajustes de cifras de acuerdo a COE Provincial de El Oro)-Personas heridas: 494-Personas afectadas: 3774-Personas damnificadas: 1017-Viviendas afectadas: 1050</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 3 de 27

<table><tr><td></td><td>-Viviendas destruidas: 291-Unidades Educativas afectadas: 331-Establecimientos de Salud afectados: 57-Bienes públicos afectados: 61-Bienes públicos destruidos: 8-Bienes privados afectados: 77-Bienes privados destruidos: 3</td></tr><tr><td>Acciones de respuesta:</td><td>MTT1 La Agencia de Regulación y Control del Agua indica que en la provincia de El Oro y en el cantón Cuenca se reestableció el servicio de agua potable al 100%.MTT2 MSP levantó información de establecimientos de salud afectados. Adicionalmente brindaron atenciones psicológicas por crisis hipertensivas y atenciones preventivas en los albergues activados en la provincia de El Oro. • MSP desplegó brigadas médicas de atención a las comunidades de la Isla Puná, e islotes del Golfo de Guayaquil. • Se activó personal de contingencia en establecimientos de salud tipo C para atención a la comunidad. • Cruz Roja Ecuatoriana brindó apoyo al MSP en atención pre-hospitalaria.MTT3 GAD Provincial coordinó con Capitanía de Puerto Bolívar, la limpieza de escombro en el barrio 4 de Abril desde el mar por medio de gabarras. • GAD Machala, GAD Pasaje y GAD El Guabo realizaron la limpieza de vías que tenían acumulación de escombros de estructuras colapsadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR Unidades de Monitoreo/Cuerpo de Bomberos/MINEDUC/MIDUVI</td></tr></table>

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/1fe58997bc23aaed13cd005ba0859807b94e82e9a1f80b65234accfd8223448d.jpg)



Inundación


<table><tr><td>Localización:</td><td>Esmeraldas</td></tr><tr><td>Antecedentes:</td><td>Por fuertes lluvias suscitadas la noche del 03 y la madrugada del 04/06/2023, se produjo el desbordamiento de varios ríos que provocaron inundaciones en 6 cantones de la provincia.En Rioverde se reportó el desbordamiento del río Rioverde, hasta el momento no se tienen eventos reportados.En Esmeraldas, desbordamiento de los ríos Tabiazo y Teaone, provocaron las inundaciones en las parroquias Tabiazo, Simón Plata Torres, 05 de Agosto, Vuelta Larga y Esmeraldas; en la parroquia Tachina, un árbol cayó sobre el cableado eléctrico afectando las operaciones de la planta de captación del agua potable.En Atacames, desbordaron los ríos Súa, Tonchigüe y La Unión, suscitándose inundaciones en varios sectores. El servicio de agua potable fue suspendido debido a fallas en la planta de captación.En Muisne, los ríos Canuto, Matambal y Sucio se desbordaron; las parroquias Muisne y San Gregorio presentaron inundaciones.En Quinindé, parroquias Cube y Viche se suscitaron inundaciones, por el desbordamiento de los ríos Cube, Viche y Blanco.</td></tr><tr><td>Situación actual:</td><td>El COE Provincial, MTTP, GTP; COE Cantonal Esmeraldas, Atacames con las MTTC se encuentran activos.Los ríos reportados están con tendencia a disminuir de nivel.Se encuentran activos los siguientes alojamientos temporales:Esmeraldas: U. E Alfonso Quiñonez (227 personas), U. E Camilo Borja (203 personas), U. E Vicente Cueva (250 personas), U. E León Febres Cordero (162 personas); U. E Fausto Molina y U. E Edilfo Benett están activos sin personas.Muisne: U. E Kleper Reyna (100 personas).</td></tr><tr><td>Afectaciones:</td><td>Esmeraldas:-4067 familias (16256 personas afectadas).-4067 viviendas afectadas.-2 bien público afectado (pared de la cárcel de varones).-8 establecimientos educativos afectados.Atacames:-757 familias (2992 personas afectadas).-757 viviendas afectadas.-5 establecimientos educativos afectados.Quinindé:-150 familias (350 personas afectadas).-150 viviendas afectadas.-7 establecimientos educativos afectados.Muisne:-159 familias (615 personas afectadas); 61 familias (249 personas damnificadas).-159 viviendas afectadas.-10 establecimientos educativos afectados.- 61 viviendas destruidasRío Verde-281 familias (1125 personas afectadas).-281 viviendas afectadas.- 2 bienes públicos afectados</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 4 de 27

<table><tr><td>Acciones de respuesta:</td><td>Esmeraldas: CNEL suspendió del suministro eléctrico en el cantón Esmeraldas, el mismo que está siendo reestablecido luego de realizar inspección.Epmapse reestableció el servicio de agua potable en los cantones Atacames, Esmeraldas y Rioverde.SGR Esmeraldas realizó la entrega de asistencia humanitaria en los albergues activados.Atacames: UGR GAD Cantonal, Parroquial Súa y Cuerpo de Bomberos Atacames realizaron la evacuación de 50 personas.Muisne: UGR GAD Cantonal realizó levantamiento de necesidades en la parroquia San Francisco en conjunto con personal de la marina y se encuentra levantando la información en la parroquia San Gregorio.Quinindé: UGR GAD Cantonal y Cuerpo de Bomberos Quinindé continúan realizando inspección y levantamiento de información.Los alojamientos temporales activos serán implementados paulatinamente.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Esmeraldas/COE Esmeraldas/COE Atacames/GAD Atacames/GAD Muisne/GAD Quinindé/GAD Rioverde.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/7b419d24561ecefcc1b01893d99fa093a3947c874cc077d7e27f778efe260298.jpg)


## Contaminación

<table><tr><td>Localización:</td><td>Sucumbíos/Lago Agrio/Nueva Loja/vía a Quito Km 12 frente a campus Sucumbíos.</td></tr><tr><td>Antecedentes:</td><td>El 10/05/2023, debido a la rotura del SOTE suscitada en el km 12 de la vía Lago Agrio-Quito; se produjo derrame de crudo, lo que ocasiona la contaminación en el sector de Santa Cecilia Km 12 siguiendo el curso del río Conejo.</td></tr><tr><td>Situación actual:</td><td>Se observan residuos de sustancias de petróleo en los sectores indicados, EP Petroecuador está encargada de los trabajos de reparación del SOTE y se activaron los contingentes de limpieza y remediación</td></tr><tr><td>Afectaciones:</td><td>- 1 bien público afectado (tubería del SOTE)</td></tr><tr><td>Acciones de respuesta:</td><td>EP Petroecuador realizó suspensión inmediata de las operaciones; activación del Plan de Emergencia y contingencia, adicional se instalaron barreras a lo largo del río Conejo y 2 puntos de control con equipos y materiales de contingencia.Ministerio del Ambiente realizará inspección en el sitio.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Sucumbíos/Petroecuador.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/62df71324cfca27133dfdbf793e4a4dcf742a629e4a31c204efb092817a94a2f.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Carchi/Tulcán/González Suárez/Ciudadela Padre Carlos de la Vega, calle Manuel Machado y Adolfo Becker.</td></tr><tr><td>Antecedentes:</td><td>El 16/05/2023, producto de las fuertes precipitaciones, se presentaron movimientos en masa en un tramo de las riveras del Río Bobo, en este sector se encuentra asentada la ciudadela Padre Carlos de la Vega; y producto de esto existen varias viviendas en riesgo las cuales presentan fisuras y grietas.La SGR realizó 2 Informes Técnicos por parte de la Unidad de Análisis de Riesgo de la SGR, INFORME N°. SGR-IASR-01-2023-0029 e INFORME N°. SGR-IASR-01-2023-0032 que ha sido enviado a las autoridades del GAD C Tulcán; para que en base de sus competencias ejecuten acciones de prevención y mitigación.</td></tr><tr><td>Situación actual:</td><td>SGR realizó inspección técnica, en el que menciona que las viviendas afectadas han sido construidas en la zona de protección del río Bobo a 50 metros de la faja de protección y tienen una pendiente con una inclinación del 45 % por lo tanto son viviendas que se encuentran en zona de riesgo, y los propietarios se encuentran habitando en los mismos inmuebles.Se realizó la reunión del COE Cantonal el 05/06/2023; en donde se resuelve: 1. Recomendar al Sr. Alcalde del cantón se Declare en Emergencia, en base a los informes presentados por la SGR, EMAPA - T, UGR del GAD C Tulcán, entre otras resoluciones; y se proceda a atender la emergencia en base de las competencias y normativas vigentes. Al momento la vía de tercer orden está parcialmente habilitada</td></tr><tr><td>Afectaciones:</td><td>- 12 familias y 52 personas en riesgo.- 8 viviendas afectadas por fisuras y en riesgo de colapso.- 20 metros lineales de vía colapsada.</td></tr><tr><td>Acciones de respuesta:</td><td>El 05/06/2023 sesionó el COE Cantonal para la coordinación de acciones y la toma de decisiones.EMAPA - T realizó la evaluación técnica para realizar el proyecto denominado “Descarga del Sistema de Alcantarillado combinado del sector Cda. Padre Carlos de la Vega”.UAR de la SGR realizó dos Informes de Análisis de Riesgo.UGR del GAD Cantonal Tulcán realizó el informe técnico.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura-Carchi/UAR SGR CZ1/Gobernación de Carchi.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/45b6827a9f44146addba4ea173541cdee587fe73f4aa86c19fecd295fc098f24.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El 26/11/2021, de acuerdo al informe del SGR se indicó que el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 5 de 27

<table><tr><td></td><td>Se informa que el SGR CZ1, geólogos de la Prefectura, Universidad Central, Universidad Yachay y autoridades locales realizaron recorridos e inspecciones técnicas.El 16/11/2021, SGR-CZ1 entregó asistencia humanitaria. El Informe del MAG indica que la afectación de los cultivos en total es de 12,43 ha de cultivos de la zona. GAD Cantonal de Pimampiro en apoyo del GAD Provincial Imbabura trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad, tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su cabecera cantonal.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes. Desde enero de 2023 se inició con la instalación de las acometidas de los servicios básicos. El MIDUVI está a la espera de que el GAD termine de hacer las acometidas para iniciar con la construcción de las viviendas; ya que dispone de los recursos económicos para este proyecto.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservorios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El GAD Cantonal de Pimampiro determinó un predio para la construcción del Proyecto de Vivienda, y realizó la instalación de servicios básicos.GAD Cantonal y Provincial de Imbabura habilitaron una vía alterna. La comunidad habilitó la vía a Mariano Acosta que pasa por la zona de riesgo de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SGR, exponiéndose a futuros riesgos vinculados a la zona propensa de deslizamiento.Las familias afectadas continúan en los alojamientos temporales y en familias acogientes. El 02/05/2023, MIDUVI realizó la inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/MIES, MIDUVI, GAD C Pimampiro - UGR.</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/5cc51dafeeda6b424da8b9f7ee06bde5fee83783a419888e984a28d9bc700402.jpg)


<table><tr><td colspan="2">Socavamiento</td></tr><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.Se mantiene la declaratoria emitida mediante resolución SGR-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>El 20/05/2023, la Comisión Ejecutora del Río Coca, CERC, informó que el frente de erosión se encuentra en la abscisa 7+560 por 68 días. Visualmente no hay cambios morfológicos y los bloques rocosos de referencia no han cambiado de posición, por lo que se presume que no hay avance en el frente de erosión, sin embargo, aguas abajo en el sector de San Carlos, entre el km 8+000 y 10+000, continúan los cambios del eje del río, desplazamiento del cauce principal hacia la margen izquierda y profundización del cauce principal; se visualiza erosión regresiva local en el río Loco y erosión lateral en los taludes.En la zona del campamento La Loma, se aprecia degradación en el cauce central y en la margen derecha; la margen izquierda presenta cambios leves, pero el riesgo es bajo y el campamento se encuentra seguro. Se mantienen las condiciones de inestabilidad en la zona de Ventana 2 que amenazan los terrenos del antiguo campamento de SINOHYDRO, el sector del poblado de San Luis y las zonas ubicadas en la margen izquierda del cauce.</td></tr><tr><td>Afectaciones:</td><td>Desde el 2020 a la fecha las afectaciones son las siguientes:- Personas Afectadas indirectas: 100-Personas Damnificadas: 51-Personas Afectadas: 76-Personas Evacuadas: 63-Viviendas destruidas: 2-Metros de vía afectadas: 1040</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 6 de 27

<table><tr><td></td><td>- Puentes destruidos: 3 (Puente sobre el río Motana, Puente Ventana 2 y Puente Piedra Fina)- Puente afectados: 1 (Puente Piedra Fina)- Bienes Afectados: 4 (tuberías del SOTE, Poliducto Shushufindi- Quito y OCP; Sistema de Agua Potable de San Luis)- Ha de Cultivo perdida: 100.03- Animales de granja afectados y muertos: 3448</td></tr><tr><td>Acciones de respuesta:</td><td>SGR CZ2 y CCGR San Luis realizan monitoreo constante del evento.MTOP a través de la Empresa contratista CONSTRUCPIEDRA SA continúa trabajando en la construcción de una vía de servicio de 2.2 km, al momento el avance de los trabajos es del 90%</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/CELEC EP/GAD Municipal El Chaco/MTOP/Teniente Político Gonzalo Díaz de Pineda</td></tr></table>

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/68f23b3c843a376ded251b461c46738010e738af75b5e08e5fabe0188aa08aef.jpg)


<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Huigra/Las Violetas, Huigra Viejo, Barrio Azuay, Barrio Turístico, vía Huigra - El Triunfo [E-47].</td></tr><tr><td>Antecedentes:</td><td>El 28/05/2023, a causa de las lluvias registradas por la madrugada, se produjo el crecimiento del caudal del río Chanchán causando la destrucción de 1 puente peatonal de madera que cruzaba al otro extremo del río, el socavamiento de unas gradas y el colapso de un poste de la red eléctrica. Se ha dispuesto al presidente del COPAE de Huigra active los albergues que se encuentran en la ex unidad educativa Numa Pompillo Llona</td></tr><tr><td>Situación actual:</td><td>Las personas evacuadas pernoctaron en el alojamiento temporal el 28 y 29/05/2023, la mañana del 30/05/2023 se trasladaron a sus viviendas.El cauce del río se encuentra en su nivel normal.El COPAE de Huigra sesionó el 29/05/2023 y resolvió:1.- Solicitar al Presidente del COE Cantonal la activación de las mesas técnicas MTT3: Servicios básicos esenciales, MTT4: Alojamientos Temporales y asistencia humanitaria, MTT6: Medios de vida y Productividad y MTT7: Infraestructura esencial y vivienda, para solventar las necesidades de la población; 2.- Solicitar al GAD Provincial de Chimborazo y Gad Municipal Alausí la maquinaria necesaria para realizar el desazolvo y encauzamiento del río Chanchán en los puntos críticos. 3.- Comunicar a la ciudadanía que, bajo estricta responsabilidad de cada conductor y respetando los horarios establecidos por la comunidad, el paso vehicular por la panamericana E47 en el tramo que atraviesa la parroquia Huigra, únicamente se permite para vehículos livianos en el horario establecido de 6:00 a.m. a 19:00 p.m., coordinando el control con personal de Policía Nacional a excepción de transporte CTA y rutas cañaris podrán transitar previa autorización de la autoridad competente. 4.-Exhortar a la ciudadanía, no realizar actividades turísticas ni grabaciones en las orillas del río Chanchán. 5.- Solicitar al MTOP en base a sus competencias realizar los trabajos de protección de la vía E47 tramo del barrio turístico de la parroquia Huigra; 6.- Trasladar la feria libre de los días sábados y actividades comerciales que se realizaban en las canchas de vóley a la plaza 24 de mayo con el objetivo de precautelar la integridad física de las personas; 7.- Socializar con la comunidad el plan de evacuación frente a inundaciones; 8.- Solicitar a Policía Nacional, realizar el patrullaje nocturno para evitar posibles hurtos en las zonas evacuadas.</td></tr><tr><td>Afectaciones:</td><td>- 16 familias afectadas (70 personas aproximadamente), de las cuales 8 familias (32 personas) son afectadas en cultivos y animales.- 16 viviendas afectadas aproximadamente- 3 bienes públicos destruidos (poste de la red eléctrica, puente peatonal, gradas)- 3 bienes públicos afectados (muros de hormigón - piedras, cancha de vóley, plaza de feria)- 1 vía de segundo parcialmente afectada- 1 bien privado afectado (Complejo la Playita)- 6 familias evacuadas (57 personas).- 6 familias en alojamiento temporal (57 personas)- 3 ha de cultivos afectados- 2 ha de cultivos destruidos- 12 animales afectados- 1000 animales muertos</td></tr><tr><td>Acciones de respuesta:</td><td>MAG realizó el levantamiento de afectaciones a través de una MAAPEA.GAD Provincial realizó encauzamiento del río Chanchán.MSP brindó atención médica a 11 personas que se encontraban en el alojamiento temporal.UGR GADC Alausí con apoyo de la SGR CZ3 realizó el levantamiento de informe EVIN. UGR conjuntamente con CB, PPNN, FFAA, GAD Alausí, GADP Huigra, SGR, Consejo Cantonal de Protección de Derechos, Ministerio de Gobierno notificaron para evacuación voluntaria de las familias que se encontraban en la ribera del río Chanchán. PPNN realizó patrullajes preventivos de seguridad en el barrio Eduardo Morley.SGR monitorea el evento.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 7 de 27

Fuentes de información: 

SGR CZ 3 Unidad de Monitoreo Tungurahua/UGR GADC Alausí/GADP Huigra/Cuerpo de Bomberos de Alausí/PPNN/MSP/SGR Uprea Chimborazo. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/090ecdf7b6be1b75c2517536420b56f9e1af7dc91e6fdecfc16fb291a162dd7b.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Cotopaxi/Sigchos/Las Pampas/Recinto Las Juntas.</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023, por causa de las lluvias registradas la madrugada se evidenció el desbordamiento del Río Las Juntas causando la destrucción de 2 puentes, la afectación de una vivienda, la muerte de una animal de granja</td></tr><tr><td>Situación actual:</td><td>En base al levantamiento de información realizada por el Obras Públicas (OOPP) GAD Sigchos se procede a cambiar la afectación que produjo el evento. Además reportan que al momento que la vía de tercer orden se encuentra cerrada.</td></tr><tr><td>Afectaciones:</td><td>- 1 puente destruido (puente vehicular)- 1 animal de granja muerto.- 300 metros de vía destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD cantonal Sigchos realizó el levantamiento de informe de inspección.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/TP/OOPP/UGR.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/e0b571946a671e8db0eecb9f02bba66e5c7040f84598f6a6d98229d80a6233b4.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Multitud/varios sectores, vía Pallatanga-Cumandá [E-487].</td></tr><tr><td>Antecedentes:</td><td>El 09/05/2023, por causas desconocidas se produjo un hundimiento en la vía de segundo orden, que posiblemente afecte a viviendas del sector.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía secundaria se encuentra parcialmente habilitada. UGIAR SGR CZ3 mediante informe de análisis de amenaza recomienda:Se recomienda al Gobierno Autónomo Descentralizado Municipal del Cantón Alausí para que conjuntamente con la Junta Parroquial de Multitud y los representantes de la Comunidad Las Rocas realicen la construcción de medidas estructurales para reducir la amenaza en el sector, principalmente para disponer de un adecuado sistema de drenaje y el encausamiento de las aguas provenientes de las precipitaciones en la zona hacia la quebrada que desemboca al Río Chimbo.De conformidad a lo mencionado en el presente informe, se deberán implementar trabajos de mitigación para reducir la inestabilidad del talud inspeccionado, por tanto, se deberá elaborar el estudio técnico que determine las características geológicas del suelo y en base al mismo definir el ángulo de estabilidad para el diseño de taludes.Se recomienda al MTOP, GAD de la provincia de Chimborazo que en coordinación con el GAD Parroquial De Multitud adopten las medidas necesarias para mejorar la vialidad del sector, acorde a su competencia, especialmente en la vía de acceso hacia las antenas y zona alta poblada de Las Rocas.Se recomienda al MINEDUC considerar el presente informe ya que la UE Bilingüe 15 de octubre se ubica dentro del Polígono preliminar delimitado.</td></tr><tr><td>Afectaciones:</td><td>- 100 m. de vía afectada- 20 viviendas afectadas (Es un número estimado hasta el levantamiento del informe EVIN)- 1 Unidad educativa afectada (Escuela Bilingüe 15 de Octubre)- 2 Bienes públicos afectados (iglesia y tanque de agua potable)</td></tr><tr><td>Acciones de respuesta:</td><td>UGIAR SGR CZ3 socializó con la población de la Comunidad Las Rocas, parroquia Multitud del Cantón Alausí el informe técnico levantado por la presencia de grietas y asentamiento en la comunidad que conllevó a la delimitación de un polígono de Alta susceptibilidad.Unidad de Respuesta y Unidad de Fortalecimiento realizaron socialización del polígono de afectación, medidas de autoprotección y la entrega de material de difusión, además se está identificando posibles alojamientos temporales.Se realiza una inspección de posibles albergues para la comunidad las Rocas perteneciente a la parroquia Multitud del cantón Alausí.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGR Cantonal/GAD Parroquial.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/32997ef1e243d073c9fac2b16659ddd848d38afc189fb763afae31de513735e2.jpg)


## Socavamiento

<table><tr><td>Localización:</td><td>Chimborazo/Pallatanga/Pallatanga/Caserío San Francisco de Trigoloma, vía Balbanera - Pallatanga [E-487].</td></tr><tr><td>Antecedentes:</td><td>El 13/04/2023, a causa de las lluvias se produjo un socavamiento que afectó parcialmente la vía de segundo orden. Mediante comunicado MTOP informa que a partir del domingo 23 de abril desde las 07h00, habrá paso controlado en la vía Balbanera - Pallatanga - Cumandá debido a los trabajos de construcción de una variante en el sector de Trigoloma</td></tr><tr><td>Situación actual:</td><td>MTOP Chimborazo informa que a partir del lunes 05 de junio de 2023, desde las 08h00 cerraran hasta el día viernes la circulación vehicular en la vía E487 Balbanera-Pallatanga-</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 8 de 27

<table><tr><td></td><td>Cumandá, para ejecutar trabajos de mantenimiento vial en algunos sectores afectados por el invierno.Vías alternas transporte liviano:- Pallatanga - La Morena - Las Palmas -Panza RedondaVías alternas transporte pesado:- Pallatanga -Las Rosas - Guamote-Aloag - Santo Domingo de los Tsáchilas-Guaranda - Balsapamba - Babahoyo.</td></tr><tr><td>Afectaciones:</td><td>100 metros lineales de vía de segundo orden</td></tr><tr><td>Acciones de respuesta:</td><td>MTOP emitió comunicado oficial sobre las acciones realizadas</td></tr><tr><td>Fuente de información</td><td>SGR CZ3 Unidad de Monitoreo Chimborazo/MTOP Chimborazo/PPNN.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/19a6b0968082c5ab472a02cc879a4d3a279cba0f214356cc506c51a11ba07d79.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Alausí, Cabecera Cantonal/Casual, vía Guamote - Alausí [E-35].</td></tr><tr><td>Antecedentes:</td><td>El 09/12/2022, se produjo un hundimiento en la vía de primer orden, que al momento está cerrada.El día 26/03/2023, debido al hundimiento, se produjo un deslizamiento en la E35 se bajó la montaña afectando completamente la vía de primer orden y viviendas aledañas.Se activaron alojamientos temporales en: Iglesia La Matriz, Coliseo Municipal, Aypud, Iglesia Ministro del Nuevo Pacto y Asociación de Artesanos, al momento se tiene 33 personas en el alojamiento Coliseo Municipal.Mediante RESOLUCIÓN Nro. SGR-111-2023, se determina CAMBIAR EL NIVEL DE ALERTA AMARILLA A NARANJA por movimientos en masa en el área de 214 hectáreas, que comprende el sector: Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua, del cantón Alausí y RATIFICAR el estado de ALERTA AMARILLA en el área de 38,07 hectáreas, considerando la actualización del análisis y observaciones técnicas realizadas en campo.</td></tr><tr><td>Situación actual:</td><td>GT1, GT2 y GT3 continúan con las labores de búsqueda y rescate de las personas desaparecidas por el deslizamiento, varias familias damnificadas se encuentran habitando en el alojamiento temporal y otras se encuentran habitando con familias acogientes.Se mantiene activo el albergue temporal en el Coliseo Municipal con (21 personas)</td></tr><tr><td>Afectaciones:</td><td>- 62 personas fallecidas- 581 personas afectadas- 44 personas heridas.- 13 personas desaparecidas.- 1034 personas damnificadas (evacuadas hacia los alojamientos temporales).- 163 viviendas afectadas- 57 viviendas destruidas- 2 bienes privados destruidos (Asadero Don Fausto y Damada - cafetería se encuentra destruido)- 1 bien privado afectado (Hostería Pircapamba)- 1 Unidad Educativa afectada (U.E. Federico Gonzales Suarez)- 2 bienes públicos destruidos (1 Estadio y 1 coliseo).- Vías destruidas:- Primer Orden: 1,12 Km- Segundo orden: 1,20 Km- Total: 2.32 Km- 3 bienes públicos afectados (25% de red público afectado y 60 % de servicio de agua potable afectado, 20 % de servicio de alcantarillado afectado).- 6 ha de cultivos y pasto destruidos.- 20 ha de cultivos afectados.- 230 Animales afectados.- 427 metros de línea férrea destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>GADM Riobamba, GADC Alausí, Fundación Visión Mundial, MIES Y Fundación ACNUR realizaron entrega de asistencia humanitaria en el sector.MTT’s y GT’s continúan con sus labores de acuerdo a sus competencias.SGR monitorea el evento.Se encuentran activados el COE Provincial de Chimborazo y el COE Cantonal de Alausí.GAD Municipal Rumiñahui hizo la entrega de un pluviómetro digital de alta precisión al GAD Cantonal Alausí, para que realice las mediciones de precipitaciones en tiempo real de su territorio.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MTOP.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/669da0164be82f8ecb002439da6c170d7f1f886c2a0baf6479bc54b75c8d3b4a.jpg)


## Deslizamiento

## Chimborazo/Alausí/Huigra/Cerro Pasan y Namza Chico.

Antecedentes: De acuerdo a informe técnico de la SGR del 11 de junio del 2018 indican que debido a la litología y a la sobre saturación de material se produjo grietas en los sectores señalados por lo que la SGR declara el estado de ALERTA NARANJA el 09 de abril del 2023 debido al incremento de amenaza de movimiento de masa en Pasan y Namza Chico, además, de acuerdo a informe del INAMHI en el que se indicó que en el mes de abril se incrementarán las lluvias. La evacuación de la población se da bajo el principio de 

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 

Código postal: 092302 / Samborondón-Ecuador 

Teléfono: +593-4-259 3500 

www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 9 de 27

<table><tr><td></td><td>autoprotección, considerando la continuidad de las grietas y el carácter activo de movimientos en masa de 152,22 ha, que comprende los sectores de Namza Chico, Pasan, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chanchán.Mediante Resolución MINEDUC Alausí - Chunchi dispone al rector y planta docente de la Unidad Educativa Eloy Alfaro, que se suspendan las actividades pedagógicas presenciales debido a la DECLARATORIA del estado de ALERTA NARANJA.</td></tr><tr><td>Situación actual:</td><td>Al momento las 12 familias que se encontraban albergadas en el Hotel Huigra retornaron a sus viviendas y las otras 10 familias se encuentran con familiares acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 117 personas evacuadas (27 familias):- Hotel Huigra: 48 personas (16 familias) (retornaron a sus viviendas)- Hotel Rosero Resort: 4 personas (1 familia) (retornaron a sus viviendas)- Familias acogientes: 65 personas (10 familias)</td></tr><tr><td>Acciones de respuesta:</td><td>Mediante apoyo interinstitucional entre SGR, IGM e IIIGE realizaron mediciones en la parroquia Huigra con la finalidad de monitorear un potencial deslizamiento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGIAR.</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/e3c9fded2eda516ba7cc60da7c4534b0a6533904989f358bf27c1ef9a5e5140c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Chone/Santa Rita/Alianza, Mosquito</td></tr><tr><td>Antecedentes:</td><td>UGR GAD Chone informa que debido a la presencia de lluvias fuertes en la tarde de hoy 06/06/2023 se registró el desbordamiento del Rio Mosquito, causando inundación en el sector y afectaciones a viviendas.</td></tr><tr><td>Situación actual:</td><td>La quebrada ha disminuido está en sus cauces normales, una familia (3 personas) se encuentra en familia acogiente, las demás familias se encuentran en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>-15 familias afectadas-15 viviendas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Chone se encuentra en los sitios afectados, colaborando con las familias afectadasUGR Chone confirmó el evento.SGR-CZ4 Monitorea evento y gestiona levantamiento de información con UGR GAD Cantonal.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Chone.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/8c10f1f5bff9f3001eba78335f473c565acd4b7cbbcfebba383cab81ba3f1bd1.jpg)



Inundación


<table><tr><td>Localización:</td><td>Manabí/Portoviejo/Río chico/La Encantada</td></tr><tr><td>Antecedentes:</td><td>El 29/05/2023, producto de lluvias suscitadas se desbordó la quebrada la encantada se suscitó una inundación en el sitio mencionado.</td></tr><tr><td>Situación actual:</td><td>La quebrada ha disminuido está en sus cauces normales, una familia (3 personas) se encuentra en familia acogiente, las demás familias se encuentran en sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>-50 familias afectadas (200 personas)-50 viviendas afectada</td></tr><tr><td>Acciones de respuesta:</td><td>Cuerpo de Bomberos de Rio Chico confirmó el evento.SGR-CZ4 Coordina con UGR GAD Portoviejo gestiona Levantamiento de información y Evaluación de Daños y Necesidades.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/Cuerpo de Bomberos de Río-Chico-Portoviejo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/4d5eb914c9a374eb5cb7399869df5bb8838f1f9b284b4350ded67012116e783a.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>Manabí/Santa Ana/Honorato Vásquez/sectores Vainilla y La Laguna.</td></tr><tr><td>Antecedentes:</td><td>El 18/04/2023, por las lluvias suscitadas en los últimos días, se produjo el deslizamiento de una ladera afectando a varias viviendas en los sectores mencionados.Las familias afectadas permanecen en casas de familias acogientes.</td></tr><tr><td>Situación actual:</td><td>Técnico SGR-CZ4 informa que continuaran con el estudio del suelo, ya que aún se encuentran pendientes sitios con puntos de agrietamientos sin evaluación.</td></tr><tr><td>Afectaciones:</td><td>- 21 viviendas afectadas- 25 familias afectadas (84 personas afectadas)- 2 familias evacuadas (alojamiento temporal)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR realiza el monitoreo del evento.UGR GAD Cantonal realizó la Evaluación de Daños y Análisis de Necesidades.SGR emitió la RESOLUCIÓN Nro. SGR-169-2023 que DECLARA el estado de ALERTA AMARILLASGR CZ4 gestionó la entrega de AH a las familias afectadas por parte de Plan Internacional.SGR continúa con evaluación y monitoreo del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Santa Ana/Tenencia Política.</td></tr></table>

## Colapso estructural

Localización: 

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 10 de 27

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/2a0d28cb22e41bc851c2a5da8f52235dfc44a03ed5f7077169302658d8ffe8ec.jpg)


<table><tr><td>Antecedentes:</td><td>El 18/03/2023, producto de la lluvia y el aumento del caudal del río Blanco, se produjo el colapso del puente que brindaba acceso al sector de Sarayacu, lo que provocó la incomunicación de la comunidad.</td></tr><tr><td>Situación actual:</td><td>Los moradores del sector, construyeron una tarabita para el ingreso de viveres y de personas al sitio.</td></tr><tr><td>Afectaciones:</td><td>- 1 puente destruido.- 35 Familias afectadas. (incomunicadas)</td></tr><tr><td>Acciones de respuesta:</td><td>Patronato Municipal coordinó con el Cuerpo de Bomberos y se realizó la entrega de kit alimenticios a las familias incomunicadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Santo Domingo/ECU 911/ACM/C.B.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/e57a993ab1f8a88d2111a4a4822e2cfbca0762c95b1aafaeb44012cfd7df2c6c.jpg)


## Colapso estructural

<table><tr><td>Localización:</td><td>Santo Domingo de Los Tsáchilas/La Concordia/La Concordia/Sector del Camal.</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2023, producto de las lluvias de la madrugada se produjo el aumento del caudal del río Blanco, provocando la ruptura de la tubería principal de la planta de tratamiento de agua potable, afectando la distribución de agua en el Cantón.</td></tr><tr><td>Situación actual:</td><td>Se realizan los trabajos de reparación de la tubería principal de agua potable.La empresa de agua potable habilitó dos pozos de agua donde la ciudadanía pueda acudir a solicitar agua.Se continúa con el suministro agua a la población con tanqueros.</td></tr><tr><td>Afectaciones:</td><td>- La afectación de la distribución de agua de la planta es del 100%- 2 bienes Públicos afectados (Planta de Agua Potable y Camal Municipal).- 51 animales de granja fallecidos (cerdos, Reses).- Aproximadamente 170.000 personas afectadas indirectamente por el suministro de agua</td></tr><tr><td>Acciones de respuesta:</td><td>GAD La Concordia continúa con la entrega de agua, con tanqueros.Empresa privada realiza trabajos de reparación de la tubería principal de agua potable.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Santo Domingo/UGR GAD La Concordia.</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/c7ebf0c43f75d3257abeac808436b9e7f4f5ff9643e05e1859599da3c67d9d1f.jpg)



Inundación


<table><tr><td>Localización:</td><td>Los Ríos/Quinsaloma/ Quinsaloma/Barrio Las Palmitas -12 de octubre - Isla de Barbones - Rcto. Estero de Damas - río Umbe - río Calabí - Rcto. San Vicente - Rcto. San Gabriel Rcto. Achotillo -Rcto. San Francisco</td></tr><tr><td>Antecedentes:</td><td>Debido a las fuertes lluvias suscitadas en la madrugada del 25/05/2023, se reportó desbordamiento de los ríos Umbe con río Calabí, mismo que afectó a varias viviendas del cantón, dejando 1 persona adulta fallecida y afectaciones en la vía de 2do orden.</td></tr><tr><td>Situación actual:</td><td>Prefectura se mantiene colaborando con la reparación de la vía de segundo orden; las familias afectadas se mantienen en sus hogares, las familias damnificadas permanecen en casa acogiente, la vía permanece parcialmente habilitada y el río se mantiene en su caudal normal.</td></tr><tr><td>Afectaciones:</td><td>- 53 viviendas afectadas- 53 familias afectadas- 196 personas afectadas- 2 viviendas destruidas- 2 familias damnificadas- 10 personas damnificadas (casa acogiente)- 2 bienes públicos destruidos (alcantarillados)- 1 puente afectado- 200 metros lineales afectados.- 1 persona fallecida (mujer adulta)</td></tr><tr><td>Acciones de respuesta:</td><td>Prefectura de Los Ríos se mantiene con la reparación de la vía afectada.SGR realizó entrega de ayuda humanitaria en compañía de UGR Quinsaloma.Se coordina con MAG la inspección técnica para levantamiento de MAAPEA.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Quinsaloma/SGR-UPREA/MIES.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/405dd21dc39d86cd6183301242986c2cdd3835b19ce75de28c058131ed4fa13a.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/La Unión/La Puntilla Cdla. 5 de junio - La Cuarenta - 25 de diciembre- río Clementina</td></tr><tr><td>Antecedentes:</td><td>Debido a las fuertes lluvias suscitadas en la madrugada del 25/05/2023, se reportódesbordamiento del río Clementina, mismo que afectó a varias viviendas del lugar.</td></tr><tr><td>Situación actual:</td><td>Personal técnico realizó levantamiento de EVIN el 25/05/2023, en donde se actualizanlos datos de afectación, actualmente las familias afectadas se mantienen en susviviendas y el caudal del río Clementina se encuentra con tendencia a aumentar de nivel.</td></tr><tr><td>Afectaciones:</td><td>- 82 viviendas afectadas.- 82 familias afectadas.- 254 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>UGR realizó levantamiento de EVIN y facilitó el documento el 25/05/2023</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/ GAD Babahoyo.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 11 de 27

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/4c2044ca8f8c6c2b60432ebf0b18612312511f5949553add637976acba2a59be.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Ventanas/Zapotal/Rcto. San Francisco - Rcto. Estero Lindo - Rcto. El Cristal - La María - río Suquibí</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023, debido a la presencia de fuertes lluvias en la madrugada se reportó desbordamiento del Río Suquibí, mismo que dejó varias viviendas afectadas con 1 vivienda destruida.</td></tr><tr><td>Situación actual:</td><td>Mediante visita al sitio en la mañana del 31/05/203, se verificó que las familias afectadas se mantienen en sus hogares, la familia damnificada continúa en casa acogiente, puesto que el nivel del río se mantiene en su caudal normal.</td></tr><tr><td>Afectaciones:</td><td>- 225 viviendas afectadas- 225 familias afectadas- 767 personas afectados- 1 vivienda destruida- 1 familia damnificada- 3 personas damnificadas (casa acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Ventanas realizó verificación de novedades</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/ UGR Ventanas/Tenencia Política de Zapotal.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/9e72e584c7fc3e7bab4d09e9f51c24843f01d726aca4f3fc9c940069e694a30e.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Caluma/ Caluma/ varios sectores, Santa Teresita, Barrio Central-San Vicente (Caluma Viejo), Pita, Charquiyacu, Unión de Pacana, Hoyo Bravo, Agua Santa, Pasagua, Cumbilli Chico - Naranjapata, Cumbilli Chico (Y) y Cumbilli Grande, Guayabal, Guamaspungo, Barrio Nueva Esperanza, Barrio San José, Barrio Hemisferio-Guamaspungo, Unión de Pacana - Plomovado, Charquiyacu - retiro de Charquiyacu, Charquiyacu - Sub centro, Guamaspungo Copales, Estero del Pescado, San Vicente de Pacana.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en los sectores, se produjo el desbordamiento de los ríos Caluma, Escaleras, Naranja Pata, Choripungo y los Esteros S/N y Pescado, del cual se registra varias viviendas y locales comerciales afectados por el ingreso de agua y lodo.El 25/05/2023 se reunió el COE Cantonal de Caluma para coordinar acciones.El COE Cantonal el 26/05/2023, resolvió Declarar la situación de EMERGENCIA AL GOBIERNO AUTÓNOMO DESCENTRALIZADO MUNICIPAL DEL CANTÓN CALUMA, por el lapso de 60 días.El servicio eléctrico fue restablecido en el Barrio Central-San Vicente (Caluma Viejo) y en del sector de Pasagua.Se encuentra restablecido el servicio de líquido vital en el sector de Pasagua.En el sector de Pita los propietarios realizaron los trabajos de limpieza de las viviendas. La vía de segundo orden que conduce desde Charquiyacu, Unión de Pacana, Hoyo Bravo, Agua Santa y Pasagua se encuentra parcialmente habilitada al tránsito vehicular y las vías de tercer orden que conduce desde Pasagua, Cumbilli Chico y Naranjapata y la vía Cumbilli Chico (Y), Cumbilli Grande, se encuentran cerradas al tránsito vehicular y existen 37 familias aisladas del sector de Pasagua - Cumbilli Chico - Naranjapata y 17 familias en el sector Cumbilli Chico (Y) - Cumbilli Grande debido al cierre de las vías.En varios sectores del cantón existen 33 viviendas en riesgo.</td></tr><tr><td>Situación actual:</td><td>La SGR en conjunto con MIES, GAD Caluma y Policía Nacional realizaron la entrega de asistencia humanitaria a las familias afectadas, damnificadas y aisladas en los sectores afectados.MSP realizó la atención médica a personas en algunos sectores afectados.Continúan realizando trabajos de rehabilitación de la vía y muros de escollera tras el Mercado Municipal. En el sector de Pasagua se culminó con la limpieza de escombros de las viviendas y de las calles. En Charquiyacu a Pasagua continua la limpieza de alcantarillas y de la vía de segundo orden la cual está habilitada parcialmente. En Pasagua a Cumbilli Chico la vía de tercer orden se encuentra habilitada, sin embargo, a los otros sectores continúa cerrada.</td></tr><tr><td>Afectaciones:</td><td>- 9.260 metros lineales de vía.- 2 viviendas destruidas (1 en Pasagua; 1 en Unión de Pacana - Plomovado).- 2 familias, 8 personas damnificadas (mismas que se encuentran en hogar acogiente).- 122 viviendas afectadas por el ingreso de agua y lodo- 128 familias, 434 personas afectadas mismas que se encuentran en las mismas viviendas)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 12 de 27

<table><tr><td></td><td>- 31 bienes públicos afectados (16 alcantarillas, 5 postes, 2 canchas, 1 cementerio, 1 iglesia; 3 muro de contención; 1 mercado, 1 malecón).- 3 bienes públicos destruidos (2 muro de contención; 1 muro de gaviones).- 79 bienes privados afectados (1 tuberías del agua; 1 cerramiento; 1 iglesia; 73 locales comerciales; 3 centros turísticos).- 5 bienes privados destruidos (4 bienes de mercadería; 1 vehículo)- 5 puentes afectados- 4 puentes destruidos- 59 Ha de cultivos afectados (cacao y naranja)- 40 Ha de cultivos perdidos (cacao y naranja)- 43 animales afectados (porcinos y bovinos)- 12 animales muertos (porcinos y bovinos)- 8 productores afectados</td></tr><tr><td>Acciones de respuesta:</td><td>El 05/06/2023, GAD Caluma realizó la entrega de asistencia humanitaria donada por la Empresa Privada en varios sectores.- El 02/06/2023, SGR con apoyo de MIES, GAD Caluma y Policía Nacional realizaron la entrega de asistencia humanitaria a las familias afectadas y aisladas.- MSP dio atención a varias personas que se encontraban en estado de crisis emocional en la zona afectada.- Cuerpo de Bomberos de Caluma, moradores y propietarios finalizaron los trabajos de limpieza de los escombros de las casas en el sector de Pasagua.- GAD Parroquial de Santa Fé finalizó con la limpieza en las calles y en las viviendas en el sector de Pasagua.- GAD Provincial continúa realizando limpieza de las alcantarillas y la vía de segundo orden desde Charquiyacu a Pasagua.- GAD Caluma realizó trabajos de limpieza en la vía de tercer orden desde Pasagua a Cumbilli Chico dejando habilitada- GAD Caluma y la del GAD Provincial continúan realizando el muro de piedra escollera a la orilla del río Caluma en el Barrio Central - San Vicente (Caluma Viejo).- Maquinaria de Empresa Privada contratada por el GAD Caluma paralizó los trabajos de encauzamiento de río Caluma en la vía Guamapungo - Hemisferio por daño en la maquinaria.</td></tr><tr><td>Euentos de información:</td><td>SGR CZ5 Unidad de Monitoroo Bolívar/LIPREA/GAD Caluma/C.B.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/33da56e92294081c2230660954f739f699b60bc67d5829744a484587330032f6.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Echeandía/Echeandía/El Malecón Alto</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en el sector la noche del 24 y madrugada del 25/05/2023, se produjo el aumento del caudal del río Soloma y originó el socavamiento de las bases de varias viviendas que se encuentran ubicadas a la ribera del río, ocasionando el colapso parcial de las mismas, viviendas colapsadas en su totalidad en la cual perdieron todos sus enseres del hogar, bienes privados afectados y un puente afectado en la aleta de la margen derecha.</td></tr><tr><td>Situación actual:</td><td>UGR del GAD Echeandía mediante informe EVIN señala que a causa del aumento del caudal del río Soloma se produjo un socavamiento a las riberas del río ocasionando la afectación total y parcial de viviendas, puente, bien público y privado, cabe mencionar que en algunas viviendas habitaban 2 familias.Además indica que maquinaria de la Empresa Privada realiza trabajos de encauzamiento y reforzamiento de los muros de contención en el río Soloma.El 31/05/2023, volvió a sesionar el COE Cantonal Echeandía donde resolvió:Se recomienda Declarar en situación de Emergencia Institucional al Municipio del Cantón Echeandía debido a las fuertes precipitaciones presentado en el cantón Echeandía.Por estado de emergencia quedará el COE Cantonal de Echeandía en sesión permanente.El río Soloma se encuentra con tendencia a disminuir de nivel.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas destruidas- 4 familias 18 personas damnificadas (se encuentran en hogares acogientes)- 10 viviendas afectadas- 16 familias 47 personas afectadas (de las cuales 2 familias 7 personas se encuentran arrendando por un mes pagado por la Empresa Privada Hnos. Viscarra y Acción Social Larry Viscarra; 3 familias 4 personas se encuentran en sus mismos predios y las 11 familias, 36 personas restantes se encuentran en hogares acogientes)- 1 puente afectado (vehicular en la aleta del lado derecho)- 3 bienes privados afectados (Local comercial, La Asociación de artistas y el Centro de Artesanos 26 de Julio)- 1 bien público afectado (un muro de contención de escollera 100 metros)</td></tr><tr><td>Acciones de respuesta:</td><td>- UGR del GAD Echeandía realizó levantamiento de información EVIN.Maquinaria de la Empresa Privada contratada por el GAD Echeandía realiza trabajos de encauzamiento y reforzamiento de los muros de contención en el río Soloma.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/ GAD Echeandía, UPREA,</td></tr></table>

## Inundación

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 13 de 27

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/562289be0adfbb5ccbf8ed2a67386a26c492c11766efbbf63001a9abf6e67eeb.jpg)


<table><tr><td>Localización:</td><td>Bolívar/Las Naves/Las Naves/varios sectores: La Playita, el Paraíso, Buenos Aires, La 40; Suquibi Viejo, El Mirador Bajo, ciudadela Elisita vía a Las Mercedes, Suquibi Nuevo, San Pedro y La Isla.</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023 a causa de las lluvias registradas en el sector, se produjo el desbordamiento del río Suquibi.Alcaldesa del GAD Las Naves informa que debido al desbordamiento del río Suquibi, resultó viviendas destruidas, afectadas por el ingreso de agua y lodo y dejó una persona fallecida en el sector La Playita debido al arrastre de la corriente.Además indica que propietarios de las viviendas afectadas realizaron trabajos de limpieza de los inmuebles.En horas de la tarde del 25/05/20023 se reunió el COE Cantonal de Las Naves para la evaluación de las afectaciones y coordinar acciones para atender el evento.</td></tr><tr><td>Situación actual:</td><td>UGR mediante informe EVIN indica que a causa del desbordamiento de los ríos Naves Medio y Suquibi se originó el colapsó de muro de gaviones, viviendas destruidas y afectadas, puentes afectados, alcantarillas destruidas y afectadas, cultivos agrícolas perdidos y afectados en varios sectores, además la vía de segundo orden que conduce de Buenos Aires - Bellavista fue afectada por acumulación de escombros y lodo, misma que al momento se encuentra habilitada.Señala también que existen 3 viviendas en riesgo debido que se encuentran asentadas en las riberas del río en el barrio Paraíso.GAD Cantonal Las Naves y de la Prefectura de Bolívar realizan trabajos de desazolve del río Suquibi en algunos frentes.MAG Bolívar mediante MAAPEA menciona que se registra afectaciones agrícolas en varios sectores.</td></tr><tr><td>Afectaciones:</td><td>- 1 persona fallecida (Adulto Mayor)- 5 viviendas destruidas- 5 familias, 18 personas damnificadas (de las cuales 4 familias 15 personas La Playita, 1 familia 3 personas del Paraíso, todos se encuentran en hogares acogientes por el mismo sector)- 62 viviendas afectadas (por ingreso de agua, lodo y colapso parcial)- 62 familias, 193 personas afectadas (de las cuales 1 familia 1 persona en el Paraíso, 5 familias 9 personas Buenos Aires, 17 familias 61 personas La 40, 3 familias 10 personas Suquibi Viejo, 1 familia 1 persona El Mirador Bajo, 27 familias 83 personas La Playita, 2 familias 8 personas ciudadela Elisita vía a Las Mercedes, 2 familias 7 personas Suquibi Nuevo, 3 familias 8 personas San Pedro y 1 familia 5 personas La Isla, todos se encuentran en las mismas viviendas)- 2 puentes vehiculares afectados (1 metálico vía Las Naves-San Luis de Pambil y 1 hormigón armado vía a Selva Alegre)- 3 bienes públicos afectados (alcantarillas por taponamiento sector de Buenos Aires)- 2 bienes públicos destruido (1 alcantarilla vía a Selva Alegre, 1 muro de gaviones 300m en Buenos Aires)- 200 metros lineales de vía.- 169 ha de cultivos afectados (cacao, naranja, plátano)- 18 ha de cultivos perdidos (cacao, naranja, plátano, mencionar que algunas plantas son de vivero)- 65 productores, 260 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>El 06/06/2023 GAD Cantonal realizó la entrega de asistencia humanitaria de la SGR a las familias afectadas.- El 05/06/2023 MIES realizó la entrega de asistencia humanitaria a las familias afectadas y damnificadas.- MAG Bolívar realizaron el levantamiento de información mediante MAAPEA.- GAD Provincial de Bolívar y de la Empresa Privada contratada por el GAD Cantonal Las Naves realizan trabajos de desazolve del río Suquibi a la altura del Subcentro de Salud aguas arriba; otro frente de trabajo se encuentra a la altura de los terrenos del Sr. Manobanda aguas arriba y finalmente a la altura del Samán 7 aguas arriba.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD Cantonal/C.B</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/15d7f1ce28ec0e5652b6f8c4ff35c6166122694b64c15e76a950a0cca1e0e413.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Guaranda/San Luis de Pambil/varios sectores: La Playita, La Delicia, El Faraón, Moraspungo, Barrio Los Negritos, Bosque de Oro, San Luis de Las Mercedes, Suquibi Viejo, Pisis, Las Minas.</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023 a causa de las lluvias registradas en el sector, se produjo el desbordamiento del río Suquibi, el cual destruyó el puente al ingreso de la parroquia y varias viviendas destruidas.Cuerpo de Bomberos de San Luis apoyaron a la evacuación de dos familias a hogar acogiente.El Servicio eléctrico se encuentra restablecidoEl 25/05/2023 se reunió el COE Cantonal de Guaranda en la parroquia de San Luis de Pambil para analizar las afectaciones y coordinar acciones.Se recomienda tomar la ruta alterna vía de tercer orden de San Luis de Pambil - Las NavesEl 26/05/2023, fue restablecido el líquido vital en el centro de la parroquia de San Luis de Pambil.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 14 de 27

<table><tr><td></td><td>Se recomienda tomar la ruta alterna vía de tercer orden de San Luis de Pambil - Las Naves</td></tr><tr><td>Situación actual:</td><td>MIES Bolívar realizó la entrega de asistencia humanitaria a las familias afectadas y damnificadas en varios sectores.Presidente del GAD Parroquial de San Luis de Pambil informa que realizan trabajos de conformación del área para armar los muros de gaviones que serán el soporte del puente Bailey en el sector la Playita mismo que será instalado en los próximos días con el fin de rehabilitar el paso vehicular.Se recomienda tomar la ruta alterna de la vía de tercer orden para vehículos livianos (Las Naves, Puente Caído, La Esperanza, Suquibi Nuevo y San Luis de Pambil) y para vehículos pesados (Las Naves, Buenos Aires, La Libertad y San Luis de Pambil).El caudal del río Suquibi se encuentra normal.</td></tr><tr><td>Afectaciones:</td><td>- 4 vivienda destruidas- 4 familias, 21 personas damnificadas- 13 viviendas afectadas- 13 familias, 55 personas afectadas- 1 puente destruido vehicular- 3 puentes afectados vehicular (colapso parcial)- 1 bien privado destruido (vehículo)- 3 bienes públicos afectados(Postes)- 1 bien privado afectado (la captación y tuberías)- 330 Ha de cultivos afectados (cacao, naranja, pasto y café)- 680 Ha de cultivos perdidos (cacao, naranja, pasto y café)- 100 animales afectados (cuyes y gallinas)- 600 animales muertos (cuyes y gallinas)- 30 productores afectados</td></tr><tr><td>Acciones de respuesta:</td><td>El 05/06/2023 personal del MIES realizó la entrega de asistencia humanitaria a las familias afectadas y damnificadas.Maquinaria del GAD Provincial de Bolívar y del GAD Cantonal de Guaranda en conjunto con moradores del sector realizan trabajos de conformación del área para armar los muros de gaviones que serán el soporte del puente Bailey en el sector la Playita, mismo que será instalado en los próximos días con el fin de rehabilitar el paso vehicular. Además, realizan reconformación de la vía que conectará con el puente.</td></tr><tr><td>Fuentes de información:</td><td>PP. NN, TEPOL, SGR Unidad de Monitoreo Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/b3efb2645c48995d55bda6d168c239b8f6567d9725f6bf728be2e0fe256e4e40.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Santa lucía/Santa lucía Cabecera Cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 15/04/2023 y madrugada del 16/04/2023, por lluvias con tormentas eléctricas se registró algunos sectores con calles y avenidas anegadas por acumulación de agua.GAD Cantonal declara en emergencia al cantón Santa Lucía, adicionalmente indica que se realizó recorridos por los sectores afectados en conjunto al alcalde y personal de Cuerpo de Bomberos, Jefatura Política, MIES y SGR. Las familias se mantienen en el albergue y familias acogidas.Con fecha 22/05/2023 UGR del GAD Santa Lucia informa que se realizó el cierre de los alojamientos temporales “Junta Higuerón - El Porvenir” y del “CDI San Pablo”, ya que las familias han retornado a sus viviendas.</td></tr><tr><td>Situación actual:</td><td>UGR del GAD Santa Lucia informa que el Albergue Temporal “Santa Rosa” aun continua familias albergadas, adicional indicó que el nivel de la cota del río Daule y Pula se encuentran disminuyendo su caudal.</td></tr><tr><td>Afectaciones:</td><td>- 1024 viviendas afectadas- 1024 familias, 3944 personas afectadas (21 familias, 58 personas en el Albergue Temporal “Santa Rosa).- 4500 hectáreas de arroz afectadas- 25 instituciones educativas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal Santa Lucía dio seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/SGR - UPREA/UGR GAD Cantonal Santa Lucia.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/3c26ac52dfea012f19b1e26f27d1b2a90719fefc8a0355bf3c4a01e646bab2fd.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Bolívar/Chillanes/Cabecera Cantonal/San Francisco de Azapi.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 a causa de las lluvias registradas en el sector, se ha producido grietas en un terreno.Geólogo de la SGR realizó inspección en la zona e indica que visualizó agrietamientos y asentamientos formando una corona de escape, además realizaron una tomografía del suelo de la zona afectada.Por seguridad y prevención las tres familias han decidido salir de la zona de riesgo.SGR Bolívar mediante inspección indica que evidenciaron que las grietas existentes han aumentado significativamente su ancho y profundidad, presencia de agua superficial sobre el terreno, nuevos deslizamientos en la parte posterior a la capilla del recinto y la vivienda de la familia Cobos Yupa, agrietamiento transversal sobre la vía estatal Chillanes - Bucay y varios cambios paisajísticos del sector, lo cual evidencia el movimiento de masa activo del sector.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 15 de 27

<table><tr><td></td><td>La Escuela Ciudad de Latacunga del recinto San Francisco de Azapi se encuentra en zona de riesgo.El 05/05/2023, Personal de la SGR realizó la socialización y concientización del nivel de riesgo alto por el deslizamiento en el sector dirigido a la comunidad, Alcaldesa electa, técnicos de las UGR de los cantones de Bucay - &quot;Guayas&quot;, Cumandá - &quot;Chimborazo&quot;, Chillanes - &quot;Bolívar&quot; y Gobernación de Bolívar.MIDUVI indica que las familias deben ser reubicadas por cuanto el suelo de casi toda la comunidad presenta hundimientos fuertes, fisuras, grietas, cuarteamientos, desplazamientos horizontales. Solicitar al GAD Municipal del Cantón Chillanes la donación de un terreno para la reubicación de estas familias.</td></tr><tr><td>Situación actual:</td><td>IIGE realiza actividades de geología y de aerofotogrametría en la zona afectada.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas- 3 familias, 15 personas afectadas (de las cuales 1 familia, 4 personas se encuentran en otra vivienda de su propiedad y las 2 familias, 11 personas se encuentran arrendando por el mismo sector en una zona segura)- 1 bien público afectado (cancha de la comunidad)- 1 bien privado afectado (capilla)</td></tr><tr><td>Acciones de respuesta:</td><td>Personal técnico del IIGE en conjunto con GAD Cantonal Chillanes realizaron toma de datos geológicos a detalle, medición de parámetros morfo métricos, colocación de mojones y toma de sus respectivas coordenadas con equipo GNSS en San Francisco de Azapi.SGR realizó la socialización y concientización del nivel de riesgo de la zona afectada.MIDUVI realizó la inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/SGR Unidad de Respuesta y Unidad de Monitoreo Bolívar.</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/36f1c94db4386c6e35936a8ae61f2f1a1fe03ce56397b157ca9c61e6e5e7b9f3.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Azuay/Cuenca/Baños/La Inmaculada-Lirio.</td></tr><tr><td>Antecedentes:</td><td>El 26/05/2023, por lluvias se suscitó un aluvión que afectó 1 vivienda parcialmente (colapso parcial de una pared), adicional 4 viviendas se encuentran en la zona de riesgo.</td></tr><tr><td>Situación actual:</td><td>Con fecha 27/05/2023 Directora Zonal de la SGR CZ6 informa de 2 familias integradas por 9 personas (1 familia afectada y 1 familia evacuada por precaución) en Alojamiento Temporal (Iglesia de la Inmaculada), adicional 25 personas evacuadas por precaución a casas de familias acogientes. Con fecha 01/06/2023 DGR Cuenca informa que 19 de las 25 personas evacuadas por precaución retornaron a sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda afectada- 1 familia afectada- 3 personas afectadas, (Iglesia de la Inmaculada)- 6 personas evacuadas, (Iglesia de la Inmaculada)- 3 bienes privados afectados (galpones)</td></tr><tr><td>Acciones de respuesta:</td><td>Con fecha 27/05/2023 SGR CZ6 coordinó con FFAA, GAD Parroquial, GAD Provincial, CELEC, GAD Cantonal, Gobernación y MIES para atención del evento, Directora Zonal del SGR CZ6 realizó asesoría en AT y levantamiento de información de familias en AT, DGR Cuenca realiza monitoreo constante al evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/Cuerpo de Bomberos de Cuenca/DGR Cuenca.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/c757d7f1e6620cdb3ff9a44567987530973f8d318390a7b0fb427150b7a0221c.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Morona Santiago/Limón Indanza/San Antonio (cabecera en San Antonio Centro)/San Salvador, Mayapis, Tserembo, El Cisne, 12 de Febrero</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas durante el 17/04/2023, se produjo un deslizamiento que provocó varias afectaciones y la obstaculización total de la vía de tercer orden.</td></tr><tr><td>Situación actual:</td><td>SGR y GAD-Cantonal de Limón Indanza con el apoyo del Batallón de Selva No. 61 Santiago y el Grupo Aéreo No. 45 Pichincha, en una aeronave tipo helicóptero LAMA SA315B/AEE-319 realizaron la entrega de asistencia humanitaria de 120 kits de alimentación KPRH en tres sectores donde confluyeron los pobladores los días 30/04/2023 (2 vuelos) y el 31/05/2023 (1 vuelo).</td></tr><tr><td>Afectaciones:</td><td>- 2 kilómetros de vía afectada- 1 puente afectado (riesgo de colapso)- 1 puente destruido- 2 bienes públicos (sistema de agua y alcantarillado vial)- 2 animales de granja muertos (ganado)- 5 bienes privados afectados (peceras)- 42 ha de vegetación afectada (40 de pasto y 2 de cultivos)- 18 familias (78 personas) afectadas directamente (pérdida de ganado y peceras)- 107 familias (535 personas) afectadas indirectamente (no pueden sacar sus productos ni ingresar</td></tr><tr><td>Acciones de respuesta:</td><td>SGR y GAD-Cantonal de Limón Indanza con el apoyo del Batallón de Selva No. 61 Santiago y el Grupo Aéreo No. 45 Pichincha, en una aeronave tipo helicóptero LAMA SA315B/AEE-319 realizaron la entrega de asistencia humanitaria de 120 kits de</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 16 de 27

<table><tr><td></td><td>alimentación KPRH en tres sectores donde confluyeron los pobladores los días 30/04/2023 (2 vuelos) y el 31/05/2023 (1 vuelo).</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ 6 Unidad de Monitoreo Morona Santiago/GAD-Cantonal de Limón Indanza.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/1ec740648a0bfc2e324bee96685ca671a35c8d7026282c5af2e3e5fdd6afdc97.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Santa Isabel/Santa Isabel/La Cría</td></tr><tr><td>Antecedentes:</td><td>El 03/06/2022, Se suscitó un deslizamiento producto de la saturación del suelo originado por la combinación deficiente del riego del sector, el taponamiento de diferentes quebradas y la deficiencia del drenaje del terreno.Con fecha 31/03/2023 la SGR declaró la ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa, el cual tiene un área de 526.22 hectáreas que se extiende sobre la comunidad La Cría, cantón Santa Isabel, provincia del Azuay.El 06/04/2023 la SGR emite el cambio a ALERTA NARANJA de acuerdo al informe elaborado por Técnico de Análisis de Riesgos de la Coordinación Zonal 6 de Gestión de Riesgos.</td></tr><tr><td>Situación actual:</td><td>UGR Santa Isabel informa que al momento en el albergue se encuentran 39 familias integradas por 111 personas, ya que 1 menor de 17 años falleció en un accidente de tránsito</td></tr><tr><td>Afectaciones:</td><td>- 38 familias evacuadas.-130 personas evacuadas (albergue temporal) (Con fecha 30/05/2023 se encuentran en el albergue 39 familias 111 personas)- 3 bienes privado afectado (capilla, casa comunal, cancha central)- 1 bien público afectado- 44 familias afectadas (178 personas)- 44 familias afectadas- 8 viviendas destruidas- 8 familias damnificadas (25 personas que permanecen en casa de familias acogientes)- 3 bienes privados afectados (predios)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Santa Isabel se mantiene en monitoreo constante del evento adicional brinda soporte psicológico a la familia de la menor fallecida</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/896626f4710783cf4ae857d361031c6fabcb35d00d3c005a2849517fc682d9d4.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Cañar/Cañar/Cañar/Cuchucun-Cruz Loma-Quilloac.</td></tr><tr><td>Antecedentes:</td><td>GAD Cantonal de Cañar informó que a partir del 13 de Octubre de 2022 por la época lluviosa y mal manejo del agua de riego se reportó un deslizamiento que afecta viviendas del sector. Con fecha 14 de Febrero del 2023 se activó el COE Cantonal donde la máxima autoridad del cantón solicita la activación de las mesas técnicas y grupos de trabajo para la atención de la emergencia. Intervención del MIDUVI y GAD PROVINCIAL.Con fecha 31/03/2023 la SGR declaró la ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa, con un área de 330.56 hectáreas pertenecientes al sector Cuchucún, el cual comprende las comunidades: Quilloac, Cruz Loma y Cuchucún, del cantón Cañar, provincia de Cañar</td></tr><tr><td>Situación actual:</td><td>Con fecha 03/05/2023 personal técnico de la SGR de forma conjunta con GAD Cañar y el uso de equipos geofísicos realizaron una inspección técnica con el objetivo de caracterizar el subsuelo en función de la conductividad de las rocas debido que se trata de un movimiento complejo, complementando así el levantamiento de información realizado en días anteriores con la técnica sísmica de refracción.</td></tr><tr><td>Afectaciones:</td><td>- 22 viviendas afectadas- 4 viviendas destruidas- 6 familias damnificadas- 16 personas damnificadas (permanecen en casa de familia acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR en coordinación con el GAD Cañar, realizó levantamiento de información</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/Directora SGR CZ6.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/7b4fc43d6eaafbd159c756d16ee612b389726948b237aaf39ed842b4d534ecbc.jpg)


## Deslizamiento

Antecedentes: El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Secretaría de Gestión de Riesgos declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay. 

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 17 de 27

<table><tr><td>Situación actual:</td><td>Con fecha 09/05/2023 técnico de la UGR Nabón informa que la segunda etapa de las obras de mitigación tiene un avance del 35%. La vía Ramada-Nabón sector Trancapata continúa cerrada, vía alterna La Ramada-Chunazana-El Salado-Nabón.</td></tr><tr><td>Afectaciones:</td><td>- 50 metros de vía afectada (vía habilitada, sector El Progreso)- 84 familias afectadas (238 personas afectadas)- 60 familias damnificadas (162 personas damnificadas)- 40 metros de vía afectados (vía Cerrada, sector Trancapata)- 60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)- 1 Casa comunal afectada con cuarteaduras- 84 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 59 viviendas destruidas.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)- Iglesia demolida por los daños estructurales presentados- Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Nabón se mantiene en continuo monitoreo de la zona afectada</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/8808310094cbd510b370b902d79307567f1b3236bbe0c0ce576810f8aa6bef07.jpg)


<table><tr><td>Localización:</td><td>Loja/Puyango/El Limo/varios sectores (3 de Noviembre, La Bocana, La Palmira).</td></tr><tr><td>Antecedentes:</td><td>Por presencia de lluvias en la tarde del viernes 28/04/2023, se produjo el desbordamiento de la quebrada del sector ocasionando daños a viviendas y vehículos que se encontraban estacionados y fueron arrastrados por el sedimento originado por dicho desbordamiento, adicional se reportó el cierre temporal de una vía de tercer orden.GAD Cantonal de Puyango se declaró en situación de emergencia el 29/04/2023 para coordinar acciones oportunas con las entidades de respuesta y poder dar una rápida atención al evento por inundación</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan habitando sus viviendas mientras continúan realizando trabajos de restauración y limpiezaEl tramo que conduce hacia Añalcal - Caucho continúa cerrada debido al socavamiento presentado y el tramo que conduce hacia La Bocana se encuentra habilitada</td></tr><tr><td>Afectaciones:</td><td>- 18 viviendas destruidas- 29 viviendas afectadas- 18 familias damnificadas conformadas por 53 personas permanecen en casa de familia acogiente- 60 familias 300 personas afectadas.- 19 bienes privados destruidos. (10 carros arrastrados y 9 motocicletas)- 30 metros de vía afectada.- 25 hectáreas de cultivos de maíz afectados</td></tr><tr><td>Acciones de respuesta:</td><td>SGR realizó el levantamiento de información y la entrega de Asistencia Humanitaria. GAD Provincial de Loja (VIALSUR E.P.) y GAD Cantonal de Puyango continúan realizando trabajos de habilitación vial.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/GAD Cantonal Puyango.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/1390758a0ed997165ce79a69eab375a4acc459945ed355ecbae17df67e80f971.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Loja/Zapotillo/varias Parroquias (Cazaderos, Mangahurco, Bolaspamba y Paletillas).</td></tr><tr><td>Antecedentes:</td><td>El 17/04/2023 por lluvias suscitadas en días anteriores se produjo el desbordamiento de varias quebradas: (Cazaderos, Mangahurco, El Guabo y quebrada Paletillas); causando afectaciones en viviendas, cultivos, vías, bienes privados en varias parroquias del cantón; en la Parroquia Cazaderos existe el riesgo de perder 30 mil plantas de tomate y en la Parroquia Bolaspamba existen 10 viviendas con riesgo de colapsar; así mismo COE Cantonal con fecha 17 de abril del 2023, sugirió al GAD Cantonal de Zapotillo se declare la situación de emergencia al cantón Zapotillo.</td></tr><tr><td>Situación actual:</td><td>La familia damnificada permanecerá de manera indefinida en casa de familia acogiente Vía de segundo orden habilitada al tránsito vehicular</td></tr><tr><td>Afectaciones:</td><td>Parroquia Cazaderos:- 120 hectáreas de cultivo de maíz perdido- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 1 vivienda destruidaParroquia Mangahurco:- 70 hectáreas de cultivo de maíz perdido</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 18 de 27

<table><tr><td></td><td>- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 50 familias afectadas- 1 vía de segundo orden cerrada (Y de Mangahurco a Cazaderos)Parroquia Bolaspamba:-10 familias conformadas por 35 personas afectadas-1 familia damnificada conformada por 4 personas-3 viviendas afectadas (Sector El Guabo)-7 viviendas afectadas (Sector Chaquino)-1 vivienda destruida (Sector Transito Mangahurquillo)-Vía de segundo orden (habilitada)Parroquia Paletillas:- Pérdida de cultivos en fase de ciclo productivo (En fase de levantamiento de información)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Zapotillo conjuntamente con personal técnico de SGR realizó el levantamiento de información.Personal de Gobierno Provincial (VIALSUR), GAD Cantonal y moradores de la parroquia Bolaspamba, realizaron los trabajos de rehabilitación vial.SGR coordinó la atención del evento y realiza constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/UGR Zapotillo/GAD-P (VIALSUR).</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/9e5e9f03240711ad34a28663b2f2b884e596dac48713328e1b0072660d743cb2.jpg)


<table><tr><td>Localización:</td><td>Pichincha/Mejía/Uyumbicho/Barrio Laureles, Chaquibamba, Pilopata.</td></tr><tr><td>Antecedentes:</td><td>Por lluvias del 22/05/2023, se reportó el desbordamiento de las Quebradas Curiquingue, Monjas y Sambache ocasionando la afectación del centro parroquial de acopio de leche en el barrio Pilopata donde se reportó ingreso de agua y lodo, así como la afectación de un puente que conecta las parroquias de Tambillo a Uyumbicho. La vía alterna es por Amaguaña -Uyumbicho- Tambillo.</td></tr><tr><td>Situación actual:</td><td>Se realizó evaluación estructural al puente afectado, se emitirá un informe para desarrollar estudios que permitirán coordinar acciones de restitución del mismo, se realizó limpieza en el centro de acopio de leche (no existió afectaciones estructurales), limpieza de quebradas y se informó que no existieron afectación a vías ni viviendas por lo que no se realizará entrega de asistencia humanitaria.</td></tr><tr><td>Afectaciones:</td><td>- 1 puente afectado- 1 bien público afectado (centro de acopio de leche)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal Mejía y GAD Parroquial de Uyumbicho realizaron limpieza de quebradas así como un recorrido por los sectores afectados, GAD Provincial realizó evaluación estructural al puente en el sector de la quebrada Sambache y coordina intervención a la estructura afectada.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ9 Unidad de Monitoreo Pichincha/GAD Cantonal Mejía UGR/GAD Provincial de Pichincha.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/c6d4c255a6bdc9b4cf538839836a51accef1638a5098df6113fcf861e4478e29.jpg)



Colapso Estructural


<table><tr><td>Localización:</td><td>Pichincha/Puerto Quito/Puerto Quito/Puente que limita entre Pichincha y Esmeraldas, Los Bancos [E28].</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas en horas de la madrugada del 18/03/2023, se produjo el aumento del caudal del río Blanco, causando el colapso del puente de la vía de primer orden que limita entre Pichincha y Esmeraldas. Se declaró en emergencia vial.</td></tr><tr><td>Situación actual:</td><td>Inician el armado y montaje del puente delta sobre el Río Blanco, adicional se instaló un campamento de trabajo y almacenamiento de materiales/ maquinaria al margen derecho del río. La vía se encuentra cerrada al tránsito vehicular.Las vías alternas habilitadas son:• Quito, Alóag - Unión del Toachi - Santo Domingo• Puerto Quito-La Sexta - Quinindé• Calacali-Los Bancos-Las Mercedes-Santo Domingo- 1 puente destruido</td></tr><tr><td>Afectaciones:</td><td></td></tr><tr><td>Acciones de respuesta:</td><td>MTOP trabaja en el armado y montaje de puente provisional en el lugar.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ9 Unidad de Monitoreo Pichincha/MTOP.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 19 de 27

Monitoreo de estado de vías afectadas por eventos peligrosos 

VÍAS DE PRIMER ORDEN: 

## 08 vías de primer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Manabí</td><td>Flavio Alfaro</td><td>Flavio Alfaro</td><td>Las Cumbres, vía El Carmen [E38]</td><td>DESLIZAMIENTO</td><td>--</td><td>07/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Guayas</td><td>Pedro Carbo</td><td>Sabanilla</td><td>Recinto Villao</td><td>SOCAVAMIENTO</td><td>55</td><td>11/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>Puerto Quito</td><td>Puerto Quito</td><td>Puente que limita entre Pichincha y Esmeraldas, Los Bancos [E28]</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>18/03/2023</td><td>Quito, Alóag - Unión del Toachi - Santo Domingo.----Puerto Quito-La Sexta - Quinindé----Calacalí-Los Bancos-Las Mercedes-Santo Domingo</td></tr><tr><td>4</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>Vía Rcto. La Estrella Rcto. La Vitalia de ler orden - Pisagua Alto - La Constancia</td><td>SOCAVAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>Chaco</td><td>Gonzalo Díaz de Pineda</td><td>Puente sobre el río Marker, vía E45 San Luis -El Reventador</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>22/02/2023</td><td>El Reventador-Lago Agrio-El Coca-Loreto -Y de Narupa-Y de Baeza-Quito o viceversa.</td></tr><tr><td>6</td><td>Manabí</td><td>Manta</td><td>San Lorenzo</td><td>Ruta del Spondiylus San Lorenzo - Santa Rosa [E15]</td><td>OLEAJE</td><td>1200</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Alausí</td><td>Alausí, Cabecera Cantonal</td><td>Casual, vía Guamote - Alausí [E-35].</td><td>HUNDIMIENTO</td><td>1120</td><td>09/12/2022</td><td>- Vehículos livianos: Alausí - García Moreno - Guamote- Vehículos pesados: Zhud - El Triunfo - Cumandá - Pallatanga - Rióbamba</td></tr><tr><td>8</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>1040</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>

## 54 vías de primer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Atacames</td><td>Tonchigüe</td><td>Recinto El Aguacate</td><td>SOCAVAMIENTO</td><td>--</td><td>04/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Pichincha</td><td>San Miguel de los Bancos</td><td>Mindo</td><td>pasando la Y de Mindo</td><td>DESLIZAMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 74, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>30</td><td>01/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Partidero, La Libertad, Baden, vía Guarumales-Méndez [E40]</td><td>DESLIZAMIENTO</td><td>190</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>Quijos</td><td>Baeza</td><td>Sector la curva de Cumandá, vía &quot;Y&quot; de Baeza - El Chaco - Santa Rosa - Puente El Salado - límite provincial Napo/Sucumbíos - El Reventador [E45].</td><td>DESLIZAMIENTO</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Esmeraldas</td><td>Esmeraldas</td><td>Simón Plata Torres</td><td>Y del León, La Victoria y Tolita 1 [E] 15</td><td>INUNDACIÍON</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 96, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>40</td><td>27/05/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos – No 0320
Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 20 de 27


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>8</td><td>Azuay</td><td>Sevilla de Oro</td><td>Amaluza</td><td>Sopladora, vía Paute-Guarumales-Méndez [E-40]</td><td>DESLIZAMIENTO</td><td>50</td><td>26/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Bolívar</td><td>Echeandía</td><td>Cabecera cantonal</td><td>La Dolorosa, vía Guanujo-Echeandia [E494]</td><td>DESLIZAMIENTO</td><td>300</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Vivar, km 117 vía Cuenca-Girón -Pasaje [E-59]</td><td>SOCAVAMIENTO</td><td>20</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>Comunidad Wamaní, vía a Loreto-Coca (Narupa) Archidona [E45].</td><td>DESLIZAMIENTO</td><td>--</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 111, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>---</td><td>22/05/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Napo</td><td>Tena</td><td>Tena</td><td>Tereré, Puente sobre el río Tena, vía Perimetral, Tena-Puyo [E45]</td><td>SOCAVAMIENTO</td><td>--</td><td>20/05/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Orellana</td><td>Loreto</td><td>San Vicente de Huaticocha</td><td>Límite provincial Napo-Orellana, Pasohurco, vía Loreto - Y de Narupa [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/05/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>km 24, Km 26, vía Y de Narupa - Y de Baeza [E20-E45A].</td><td>DESLIZAMIENTO</td><td>250</td><td>09/05/2023</td><td>Km vía parcialmente habilitada</td></tr><tr><td>16</td><td>Loja</td><td>Puyango</td><td>Alamor</td><td>Sector &quot;La Y&quot;, vía a B Balsones [E25]</td><td>DESLIZAMIENTO</td><td>20</td><td>28/04/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 90, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>18</td><td>El Oro</td><td>Balsas</td><td>Balsas</td><td>Km4, vía Balsas - Saracay [E-50]</td><td>DESLIZAMIENTO</td><td>15</td><td>26/04/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Chimborazo</td><td>Colta</td><td>Juan de Velasco (Pangor)</td><td>Guangopuc, Rumipamba Vía Colta - Pallatanga [E487]</td><td>DESLIZAMIENTO</td><td>100</td><td>24/04/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Bolívar</td><td>Chillanes</td><td>Chillanes</td><td>Varios sectores: a la altura de la hacienda de San Juan de Azapi, Vista Alegre, San Francisco de Azapi, vía Chillanes-Bucay [E495]</td><td>DESLIZAMIENTO</td><td>300</td><td>22/04/2023</td><td>Ninguna</td></tr><tr><td>21</td><td>Pichincha</td><td>Mejía</td><td>Alóag Manuel Cornejo Astorga (Tandapi)</td><td>km 56, vía Alóag - Unión del Toachi [E35]</td><td>SOCAVAMIENTO</td><td>40</td><td>22/04/2023</td><td>Ninguna</td></tr><tr><td>22</td><td>El Oro</td><td>Las Lajas</td><td>La Victoria</td><td>El Tigre, Vía El Tigre - Puyango [E-25]</td><td>DESLIZAMIENTO</td><td>10</td><td>20/04/2023</td><td>Ninguna</td></tr><tr><td>23</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 13, vía Coca - Dayuma [E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>20/04/2023</td><td>Ninguna</td></tr><tr><td>24</td><td>Loja</td><td>Célica</td><td>Sabanilla</td><td>Cabuyo, vía Redondel de la Aduana a Pindal - Troncal de la Costa [E25]</td><td>DESLIZAMIENTO</td><td>50</td><td>14/04/2023</td><td>Ninguna</td></tr><tr><td>25</td><td>Los Ríos</td><td>Montalvo</td><td>La Esmeralda</td><td>La Guayaba - río La Esmeralda</td><td>SOCAVAMIENTO</td><td>60</td><td>05/04/2023</td><td>Ninguna</td></tr><tr><td>26</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 92, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>--</td><td>05/04/2023</td><td>Ninguna</td></tr><tr><td>27</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 91, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>--</td><td>04/04/2023</td><td>Ninguna</td></tr><tr><td>28</td><td>Santo Domingo de los Tsáchilas</td><td>Santo Domingo</td><td>Abraham Calazacón</td><td>Coop. Modelo Av. Los Colonos, calle Río Verde, Junto al UPC.</td><td>INUNDACIÓN</td><td>30</td><td>01/04/2023</td><td>Ninguna</td></tr><tr><td>29</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 64, vía Cuenca-Molleturo-Naranjal [E-582</td><td>DESLIZAMIENTO</td><td>--</td><td>28/03/2023</td><td>Ninguna</td></tr><tr><td>30</td><td>Loja</td><td>Las Lajas</td><td>La Victoria</td><td>El Tigre, Vía El Tigre - Puyango [E-25]</td><td>DESLIZAMIENTO</td><td>8</td><td>26/03/2023</td><td>Ninguna</td></tr><tr><td>31</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 92-96-97-98, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>80</td><td>18/03/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos – No 0320
Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 21 de 27


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>32</td><td>Pichincha</td><td>Quito</td><td>Pifo</td><td>10 minutos Virgen de Papallacta, vía Papallacta - Baeza [E20]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2023</td><td>Ninguna</td></tr><tr><td>33</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Salida de Santa Rufina hacía, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>34</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Vía Arenillas - Las Lajas [E25]</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>35</td><td>Bolívar</td><td>San Miguel</td><td>San Miguel</td><td>El Calzado-Abs.27+800, vía San Miguel-Balzapamba [E 491]</td><td>DESLIZAMIENTO</td><td>100</td><td>23/02/2023</td><td>Ninguna</td></tr><tr><td>36</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>Km 61, vía Paute Guarumales Méndez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>37</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>38</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>39</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>40</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>41</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>42</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>43</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>44</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>45</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>45</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tulcán - Ibarra 2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>46</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>47</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>48</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>49</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos – No 0320
Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 22 de 27


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>50</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>51</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>52</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>53</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>54</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago -San José de Morona [E40]</td><td>COLAPSO ESTRUC TURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>

## VÍAS DE SEGUNDO ORDEN

## 07 vías de segundo orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Manabí</td><td>Jama</td><td>Jama</td><td>Sitio El Colorado, vía a El Colorado Arriba vía a Convento</td><td>ALUVIÓN</td><td>--</td><td>29/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>Km 37, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Loja</td><td>Loja</td><td>Gualel</td><td>San Francisco, vía Gualel-Chuquiribamba.</td><td>SOCAVAMIENTO</td><td>--</td><td>15/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>7</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>50130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 23 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Manabí</td><td>Santa Ana</td><td>Honorato Vázquez</td><td>Comunidad las Mercedes</td><td>DESLIZAMIENTO</td><td>1000</td><td>06/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Unión Manabita, vía Lomas del Perú, vía El Mirador, vía Maracayairo</td><td>DESLIZAMIENTO</td><td>300</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío San Francisco de Trigoloma, vía Balbanera - Pallatanga [E-487]</td><td>SOCVAMIENTO</td><td>100</td><td>13/04/2023</td><td>- Aloag - Santo Domingo de los Tsáchilas - Guaranda - Balsapamba - Babahoyo.</td></tr><tr><td>4</td><td>Morona Santiago</td><td>Morona</td><td>General Proaño</td><td>Kilómetro 105, vía Macas-Riobamba [E465]</td><td>DESLIZAMIENTO</td><td>15</td><td>12/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Manabí</td><td>Paján</td><td>Campuzano</td><td>Estero Ciego</td><td>HUNDIMIENTO</td><td>250</td><td>09/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Chimborazo</td><td>Alausí</td><td>Multitud</td><td>Varios Sectores, vía Pallatanga-Cumandá [E-487].</td><td>HUNDIMIENTO</td><td>100</td><td>09/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>El Oro</td><td>Zaruma</td><td>Muluncay</td><td>Via Zaruma - Atahualpa [E585].</td><td>DESLIZAMIENTO</td><td>8</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Imbabura</td><td>Ibarra</td><td>Caranqui</td><td>Guayaquil de Caranqui</td><td>SOCVAMIENTO</td><td>20</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío San Francisco de Trigoloma, vía Pallatanga - Guayaquil [E-487]</td><td>SOCVAMIENTO</td><td>--</td><td>13/04/2023</td><td>Riobamba - Ambato - Latacunga- Alóag - Santo Domingo.</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos – No 0320
Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 23 de 27


<table><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Ríobamba -Guaranda -Babahoyo.</td></tr><tr><td>10</td><td>El Oro</td><td>Piñas</td><td>Piedras</td><td>El Recuerdo, vía Saracay - Piedras.</td><td>SOCAVAMIENTO</td><td>5</td><td>13/04/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Imbabura</td><td>Ibarra</td><td>Angochagua</td><td>El Cunro, vía Ibarra - Zuleta.</td><td>ALUVIÓN</td><td>70</td><td>07/04/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Pichincha</td><td>Quito</td><td>El Condado</td><td>La Roldós, calle Rumihurco vía a Chicahuico</td><td>SOCAVAMIENTO</td><td>--</td><td>19/03/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Los Ríos</td><td>Quinsaloma</td><td>Quinsaloma</td><td>Rcto. San Gabriel - Rcto. San Vicente - Rcto. Oro Verde - Río Calope</td><td>INUNDACIÓN</td><td>72</td><td>18/03/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>vía urbana a Camino Real</td><td>DESLIZAMIENTO</td><td>50</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>El Oro</td><td>Santa Rosa</td><td>Victoria</td><td>Km 18, vía Buenavista - San Juan de Cerro Azul [E-585]</td><td>ALUVION</td><td>150</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>16</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>Km 47, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>25</td><td>06/03/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Guapo, vía Colta -Pallatanga [E-487]</td><td>ALUVIÓN</td><td>40</td><td>21/02/2023</td><td>Ríobamba -Guaranda -Babahoyo -Guayaquil</td></tr><tr><td>18</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>15</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr></table>


VÍAS DE TERCER ORDEN:



28 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Napo</td><td>Tena</td><td>Puerto Misahuallí</td><td>Sector Santa Marta, vía Puerto Misahaullí-Palmeras.</td><td>DESLIZAMIENTO</td><td>--</td><td>05/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Esmeraldas</td><td>Esmeraldas</td><td>Camarones</td><td>Recinto Santa Lucía.</td><td>HUNDIMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Morona Santiago</td><td>Santiago</td><td>Santiago de Méndez, cabecera cantonal</td><td>Singuiantza, vía Mendez-Sinquiantza.</td><td>DESLIZAMIENTO</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Chimborazo</td><td>Pallatanga</td><td>Matriz</td><td>Jiménez</td><td>COLAPSO ESTRUCTURAL.</td><td>--</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Esmeraldas</td><td>Quinindé</td><td>Cube</td><td>Tachina, sector Boca Grande.</td><td>DESLIZAMIENTO</td><td>--</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Cotopaxi</td><td>Pangua</td><td>El Corazón</td><td>Mulligua vía El Corazón - Ramón Campaña</td><td>DESLIZAMIENTO</td><td>80</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Cotopaxi</td><td>Sigchos</td><td>Las Pampas</td><td>Recinto Las Juntas.</td><td>INUNDACIÓN</td><td>300</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Cotopaxi</td><td>Pangua</td><td>Moraspungo</td><td>La Providencia Alta y Baja, vía Libertadores de Sillagua - La Providencia Alta; vía La Providencia Alta - Agua Santa; y Vía La Providencia Baja - San Francisco de Sillagua - Jesús del Gran Poder - Guapara</td><td>DESLIZAMIENTO</td><td>103</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Cotopaxi</td><td>Pangua</td><td>El Corazón</td><td>Vía San Francisco - Chaca.</td><td>SOCAVAMIENTO</td><td>150</td><td>25/05/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos – No 0320
Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 24 de 27


<table><tr><td>10</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza, cabecera cantonal</td><td>San Luis, vía Gualaquiza- San Luis de Yantsas</td><td>ALUVIÓN.</td><td>30</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza, cabecera cantonal</td><td>San Luis, vía Gualaquiza- San Luis de Yantsas</td><td>DESLIZAMIENTO</td><td>--</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Estero Piedra</td><td>DESLIZAMIENTO</td><td>--</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Puyango</td><td>El Limo</td><td>Añalcal - Caucho</td><td>SOCAVAMIENTO</td><td>30</td><td>28/04/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Imbabura</td><td>Otavalo</td><td>Selva Alegre</td><td>San Luis, vía Selva Alegre - San Luis.</td><td>SOCAVAMIENTO</td><td>20</td><td>26/04/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Los Ríos</td><td>Urdaneta</td><td>Ricaurte</td><td>Rcto. Barranco hacia Rcto. Salampe - río Catarama</td><td>SOCAVAMIENTO</td><td>300</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>16</td><td>Cañar</td><td>Deleg</td><td>Deleg</td><td>Sector Camal Municipal</td><td>SOCAVAMIENTO</td><td>--</td><td>21/04/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Morona Santiago</td><td>Limón Indanza</td><td>San Antonio (cabecera en San Antonio Centro)</td><td>San Salvador, Mayapis, Serembo, El Cisne, 12 de Febrero</td><td>DESLIZAMIENTO</td><td>2000</td><td>17/04/2023</td><td>Ninguna</td></tr><tr><td>18</td><td>Guayas</td><td>Alfredo Baquerizo Moreno (Jujan)</td><td>Cabecera Cantonal</td><td>Recinto El Tránsito</td><td>SOCAVAMIENTO</td><td>60</td><td>06/04/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Bolívar</td><td>Guaranda</td><td>San Luis de Pambil</td><td>Varios sectores; María Aurora, Rosa Elvira - vía a las Comunidades de San Luis de Pambil.</td><td>COLAPSO ESTRUCTURAL</td><td>28</td><td>24/03/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>La Valdivia - río Clementina</td><td>INUNDACIÓN</td><td>30</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>21</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>La Estrella - Cdla. Felipe Abud - río Cristal</td><td>SOCAVAMIENTO</td><td>800</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>22</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur</td><td>INUNDACIÓN</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>27</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>28</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>955.9</td><td>20/01/2021</td><td>Ninguna</td></tr></table>

## 14 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Eloy Alfaro</td><td>Borbón</td><td>vía San Pedro - Anchayacu</td><td>DESLIZAMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Barrio El Cisne, via El Cisne - Santa Marianita</td><td>DESLIZAMIENTO</td><td>8</td><td>29/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Esmeraldas</td><td>Muisne</td><td>Galera</td><td>Estero de Plátano.</td><td>DESLIZAMIENTO</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Chilcaplaya</td><td>SOCAVAMIENTO</td><td>--</td><td>24/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Carchi</td><td>Tulcán</td><td>González Suárez</td><td>Ciudadela Padre Carlos de la Vega, calle Manuel Machado y Adolfo Becker.</td><td>DESLIZAMIENTO</td><td>20</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Quito</td><td>Chillogallo</td><td>Buena Aventura, calle Agustín Albán Borja</td><td>DESLIZAMIENTO</td><td>--</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Valle del Sade</td><td>HUNDIMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Esmeraldas</td><td>Quinindé</td><td>La Unión</td><td>El Tambo</td><td>HUNDIMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Dirección de Monitoreo de Eventos Adversos


Reporte de monitoreo de amenazas y eventos peligrosos – No 0320
Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 25 de 27


<table><tr><td>9</td><td>Imbabura</td><td>Cotacachi</td><td>Peñaherrera</td><td>Villa flora</td><td>HUNDIMIENTO</td><td>30</td><td>05/05/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>El Oro/Piñas</td><td>Moromoro</td><td>El Palto</td><td>Via El Palto - La Libertad</td><td>SOCAVAMIENTO</td><td>8</td><td>04/05/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Cotopaxi</td><td>Pangua</td><td>Ramón Campaña La Estrella</td><td>Miligua, vía Ramón Campaña - El Corazón</td><td>DESLIZAMIENTO</td><td>50</td><td>12/03/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>14</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>


4. Declaratorias emitidas por el SGR (vigentes en orden cronológico)


<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/32273c352ada8f34edf253e48f12f9206a11948b3c815281ba5f6ca8f3b4cf3e.jpg"/></td><td>Declaratoria de ALERTA AMARILLA Movimientos en masa en La Vainilla y La LagunaParroquia: Honorato Vásquez, Cantón: Santa Ana, Provincia: Manabí.</td><td>Amarilla</td><td>23/05/2023</td><td>Resolución No. SGR-169-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/965ec33c94caec04ad7476cbda499ebd652c2a1516ba139d8f6ebd5651e56478.jpg"/></td><td>Declaratoria de ALERTA AMARILLA Fenómeno El Niño: Oscilación del Sur (ENOS), en los territorios ubicados a una altitud igual y menor a 1500 msnm, que comprende 17 provincias, 143 cantones, y 489 parroquias</td><td>Amarilla</td><td>15/05/2023</td><td>Resolución No. SGR-156-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/ec77d379ce3a243079f2744c266dbd744892ae2305d13f9d36c17e84172974ab.jpg"/></td><td>Declaratoria de ALERTA AMARILLA Fenómeno El Niño: Oscilación del Sur (ENOS), en los territorios ubicados a una altitud igual y menor a 1500 msnm, que comprende 17 provincias, 143 cantones, y 489 parroquias</td><td>Amarilla</td><td>15/05/2023</td><td>Resolución No. SGR-166-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/9e84c4d4e8d32ba97d28135e5473b99052d7327fffa7a6217e89c61e8c0b190a.jpg"/></td><td>Declaratoria de Cambio de ALERTA AMARILLA por movimientos en masa al área de 11,50 hectáreas en el sector Astillero, de la parroquia Bahía de Caráquez, cantón Sucre, provincia de Manabí; considerando que las condiciones y parámetros indican que puede presentarse un evento que produzca afectaciones en la población e infraestructura.</td><td>Amarilla</td><td>10/04/2023</td><td>Resolución No. SGR-110-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/7b36337213a13f5600a603fca7f30e10f572dd67f53c39b2e54d970fa7a78833.jpg"/></td><td>Declaratoria de Cambio de ALERTA AMARILLA a NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua.</td><td>Naranja</td><td>10/04/2023</td><td>Resolución No. SGR-111-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/4d26919fca6883c7c7d281b5e5c9c54f8620048996c365c2a491a009ecbddaf3.jpg"/></td><td>Declaratoria del estado de ALERTA NARANJA por movimientos en masa al área de 152,22 hectáreas que comprende los sectores: Namza Chico, Pasán, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chachán,</td><td>Naranja</td><td>09/04/2023</td><td>Resolución No. SGR 106-023</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos – No 0320 Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 26 de 27

de la parroquia Huigra, cantón Alausí, provincia de Chimborazo 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/a0f59df9f0f10566036b2652c823da56f2bb6435af9e7570f34d4d068858a6cd.jpg)


Declaratoria del estado de ALERTA NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa el cual tiene un área de 442.62 hectáreas que se extiende sobre la comunidad La Cría - Cantón: Santa Isabel, Provincia: Azuay. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/66fcc97306e0301b9a57febdd5408bd1d726e9d896e3df39cfa99b8b84c053e6.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/f015bd0c1757cb92d95993d76e4d58b62e3bdf799194ec5e8c72ded86308b4a1.jpg)


Declaratoria del estado de ALERTA NARANJA por movimientos en masa, el área de influencia equivalente a 53132.993 m², ubicada en la ciudadela El Fátima, parroquia Francisco Pacheco, del cantón Portoviejo, Provincia de Manabí, debido a que la materialización del evento peligroso por movimientos en masa es inminente, lo que afectaría a la población. 

Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa con un área de 330.56 hectáreas pertenecientes al sector Cuchucún, el cual comprende las comunidades: Quilloac, Cruz Loma y Cuchucún. Cantón: Cañar, Provincia: Cañar. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/3352f6c7225a7298c3fc5e3d3077103c6a12f58be3609fbe824209c07f91596c.jpg)


## Incremento Actividad Volcánica Cotopaxi

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/6aa86db87c006127c87c0f2d2264157e8e2b693ba7f2e908e9d693e68be0e2fd.jpg)


Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/efe2e175d8e8f89f71318551e5fda84976bae631e2f696406d78652a40635750.jpg)


## Movimiento en masa

barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/3a7601f0ebe94bca844dfa9d658b4b0a472cfadcf2dc58ffcb1162c89f65a1db.jpg)


Socavamiento por la erosión del río Coca y sus afluentes –Cantón: El Chaco, Provincia: Napo. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/5e35e6ef8afb02f790535f1fe2170a64b7647f8f5beca41be47274c2f401bb03.jpg)


Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/958322545f308b722bfacd4d4fd85415016804e0e3fc4028a965dce5f0fa804a.jpg)


Aumento de sedimentos volcánicos
Río Upano- Parroquias Sinaí y Sevilla de Don Bosco,
cantón Morona, Morona Santiago 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/090fc88e0b9841fa9f2fc54becfbafa297cc85e3da8d5813cb268721d8481d04.jpg)


Incendios Forestales
Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/b29da38a1a674960788dfebd8264e79b593cf2b6063ce73998512e00cb3b5494.jpg)


Incremento de lluvias e inundaciones
Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/73b102cd0f2ab5557e87a444cb81180411341ed97848e10eb689f1475f89dfdb.jpg)


Fenómeno El Niño (ENOS)
Provincias del Litoral e Insular 

## Secretaría de Gestión de Riesgos


Reporte de monitoreo de amenazas y eventos peligrosos - No 0320
Fecha y Hora de actualización: viernes, 09 de junio de 2023 - 21:08:00 / Página 27 de 27


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/f03a49f2d7062a8c726ba5a650a87720338e1bee99b111ee4e4034ba6a533c72.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/728fc351bd067fca09450b3fe0b41f81a5e35ba252fe487a2de961b62c24bd7c.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/0cbf93da6fb296da9d0dd6927fdf63b3bb0476f00338433bbed154d2f34384bb.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/7ed1402bad5b1bfc6851d0123165b6f62cc5427f680e0636415c9903a684a965.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/036cf7e9955d6e130a4608d28865bfb17013807810f864849521e3fb85ae1ecd.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/ca20b027bb318e2dcb69f6a082f1d161c6fe53ce9ec26dae52ad32baf97ea7d4.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/46e6956adeed61a8f8158a520b9f9a29a69422abd4ea396ffbf93a3ec911dea6.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/308fb02ce1b091647acb85235689aec222911ce0f812d8235433d8d3f5354e7a.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/6f7ea80ac3e9d7bdc12b8169a109b70d9f569d21bbdcd461966fe647c751ff89.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/6234eae6-a8b4-4dc6-819e-65244b29cacb/1e07828f7b7a348fe9d3adb83529fc1dd12802dfda9c4f6f4f14e13c6c143865.jpg)


Elaborado por Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón.
Revisado por. -- Analista Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón.
Enviado por - Víctor Yagual P. - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 