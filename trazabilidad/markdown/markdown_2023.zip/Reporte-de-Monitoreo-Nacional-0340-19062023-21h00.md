# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 1 de 25

Periodo de Monitoreo: 

Desde: 09h00 19/06/2023 

Hasta: 21h00 19/06/2023 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

- Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/21b020abbd264caac031bb1713ed640b208057d4a52b2a431b624ec7256d1a66.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/4d68c26043c80a0dfd8b862b37f5250bec61b248b692378b6a2ad390d4b22338.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>18:00 Reventador para la COMUNIDAD, Emisión de ceniza. Altura de la nube igual a 1010 metros sobre el nivel del cráter con dirección Sur-Oeste</td><td>AMARILLA</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/f519c4755e62090e84e889e486685c0e927ab34836ac86984b264f6a13ab5b13.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/d3749723669da8d4cb1c0f21a1c861cd98ad15210bf7b964ec7fff01a945891a.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>18:00 Se visualiza volcán despejado, Se brinda apoyo visual</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/7ea2917d5f588f562318cdd4915dbb6dd96d79e8b0ac38ac227ba11b4f6f6e3e.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>18:00 Sin reporte de actividad superficial</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/ebb0c2f640aa8ed944d049e7fdcc12ef88a611044a197ce41e2ee8d54c5baf8f.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>18:00 Mediante cámaras se visualiza el volcán nublado, sin novedad</td><td>VERDE</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/34351b79f900bd39d642d8cfdd81e003d94c8fa533e5caf3ec03655f07a791fd.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">01 Cuerpo de Agua Desbordado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del Río</td></tr><tr><td>Morona Santiago</td><td>Morona</td><td>Macas</td><td>Tramo puente sobre el río Upano-puente sobre el río Copueno</td><td>Upano</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/82c2ae7777e48c5071841a9ae2624fdabffc1d06057409ef7d33cf0a88652d89.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">01 incendio activo</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>Azuay</td><td>Cuenca</td><td>Paccha</td><td>Quituiña</td><td>--</td></tr><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/8fe7970b33c8253664b297ef55f33dd352404000148f980200a53c40753c2592.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/92d562aaacdc6a4f14777efe8280e5f8870fffedf6df70c236be161ec7961d92.jpg)


<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td>VERDE</td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td>VERDE</td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>83.73</td><td>85.00</td><td>---</td><td>VERDE</td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>116.15</td><td>117.00</td><td>---</td><td>VERDE</td></tr><tr><td>Chongón, Guayas</td><td>44.50</td><td>---</td><td>51.15</td><td>---</td><td>VERDE</td></tr><tr><td>El Azúcar, Santa Elena</td><td>40.00</td><td>---</td><td>45.09</td><td>---</td><td>VERDE</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 2 de 25

<table><tr><td>San Vicente, Santa Elena</td><td>50.00</td><td>---</td><td>57.49</td><td>---</td><td>VERDE</td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td>VERDE</td></tr><tr><td>Poza Honda, Manabí</td><td>104.29</td><td>---</td><td>106.50</td><td>---</td><td>VERDE</td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td>VERDE</td></tr><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>---</td><td>---</td><td>VERDE</td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td>VERDE</td></tr></table>


SITUACIÓN HIDROMETEREOLÓGICA


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/715feda8bc00f58d0bf7b0718d6ef380642ca0e106edbb9fe8946b684cd36d95.jpg)


<table><tr><td colspan="3">Registro de Temperatura Diurna (°C)</td></tr><tr><td>REGIÓN</td><td>NIVEL MEDIO</td><td>NIVEL ALTO</td></tr><tr><td>Litoral</td><td>27 - 30 °C</td><td>31 - 33 °C</td></tr><tr><td>Interandina</td><td>21 a 23 °C</td><td>24 - 25 °C</td></tr><tr><td>Amazonía</td><td>28 - 30 °C</td><td>--</td></tr></table>

## ADVERTENCIA

AMENAZA: ALTA TEMPERATURA EN EL DÍA - RÁFAGAS DE VIENTO 

ADVERTENCIA METEOROLÓGICA N°30- Vigente desde las 10H00 del 18 de junio hasta las 16H00 del 23 de junio de 2023 

SITUACIÓN: Se prevén temperaturas altas durante el día e índices de radiación UV entre alto y extremadamente alto. 

- Región Litoral: Las altas temperaturas serán recurrentes en los próximos días. 

- Región Interandina: Las temperaturas más altas se esperan en los días domingo 18 y lunes 19 

- Región Amazónica: Las temperaturas altas se presentarán a partir del lunes 19 de junio. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/7f3e8b3a6b51181479da9d4d38417b7846efabe3fdb9660e904daff861d9c691.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## 2. Monitoreo de eventos peligrosos (emergencias y desastres)

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/9b97d71bf9c9751b5607ffa317f4ef3b0a1874d08feb220e23ac4dddb597bed4.jpg)


## Sismo

<table><tr><td>Localización:</td><td>A 29.12 Km de Balao, Guayas.</td></tr><tr><td>Antecedentes:</td><td>Se produjo un sismo a las 12:12 del 18/03/2023 de Magnitud 6.5, profundidad 44.Km localizado a 29.12 km de Balao Guayas.De acuerdo al barrido realizado por la SGR el sismo fue sentido a nivel nacional con mayor intensidad en las provincias: de El Oro, Guayas, Los Ríos, Manabí, Chimborazo y Azuay.</td></tr><tr><td>Situación actual:</td><td>Según reporte del IG-EPN, el evento telúrico suscitado a las 00h35 del 25/04/2023 tuvo su epicentro a 36 km en dirección noreste de la Isla Puna, del cantón Balao, en la provincia del Guayas, de magnitud 5.7 (Mlv), a una profundidad de 60 km.Se han activado los COE Provinciales de Guayas, Azuay, Cañar y El Oro, así como los COE Cantonales: El Guabo, Pasaje, Machala, Huaquillas y Santa Rosa en El Oro; Cuenca y Santa Isabel en Azuay.Se encuentran declarados en emergencia los cantones de Pasaje y El Guabo en la provincia de El Oro y Naranjal en la provincia del Guayas.La Agencia de Regulación y Control del Agua en la provincia de El Oro y en el cantón Cuenca se reestableció el servicio de agua potable al 100%.Se encuentran activos los refugios temporales: Casa Comunal 24 de Mayo (14 personas) y el Refugio Temporal en la Casa Comunal Coop. 10 de Agosto en El Guabo (63 personas), donde al momento pernoctan las familias por precaución.</td></tr><tr><td>Afectaciones:</td><td>-Personas fallecidas: 14 personas - 12 El Oro (10 Machala, 1 El Guabo, 1 Pasaje), 2 Azuay (1 Cuenca,1 Molleturo) - (Ajustes de cifras de acuerdo a COE Provincial de El Oro)-Personas heridas: 494-Personas afectadas: 3774</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 3 de 25

<table><tr><td></td><td>-Personas damnificadas: 1017-Viviendas afectadas: 1050-Viviendas destruidas: 291-Unidades Educativas afectadas: 331-Establecimientos de Salud afectados: 57-Bienes públicos afectados: 61-Bienes públicos destruidos: 8-Bienes privados afectados: 77-Bienes privados destruidos: 3</td></tr><tr><td>Acciones de respuesta:</td><td>MTT1 La Agencia de Regulación y Control del Agua indica que en la provincia de El Oro y en el cantón Cuenca se reestableció el servicio de agua potable al 100%.MTT2 MSP levantó información de establecimientos de salud afectados. Adicionalmente brindaron atenciones psicológicas por crisis hipertensivas y atenciones preventivas en los albergues activados en la provincia de El Oro. • MSP desplegó brigadas médicas de atención a las comunidades de la Isla Puná, e islotes del Golfo de Guayaquil. • Se activó personal de contingencia en establecimientos de salud tipo C para atención a la comunidad. • Cruz Roja Ecuatoriana brindó apoyo al MSP en atención pre-hospitalaria.MTT3 GAD Provincial coordinó con Capitanía de Puerto Bolívar, la limpieza de escombro en el barrio 4 de Abril desde el mar por medio de gabarras. • GAD Machala, GAD Pasaje y GAD El Guabo realizaron la limpieza de vías que tenían acumulación de escombros de estructuras colapsadas.</td></tr><tr><td>Fuentes de información:</td><td>SGR Unidades de Monitoreo/Cuerpo de Bomberos/MINEDUC/MIDUVI</td></tr></table>

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/1fb0d1de206a22e5fde614eb1d85ea44a7f92e58f33b5bd94337c55aed4831d7.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Esmeraldas</td></tr><tr><td>Antecedentes:</td><td>Por fuertes lluvias suscitadas la noche del 03 y la madrugada del 04/06/2023, se produjo el desbordamiento de varios ríos que provocaron inundaciones en 6 cantones de la provincia.En Esmeraldas, desbordamiento de los ríos Tabiazo y Teaone, provocaron las inundaciones en las parroquias Tabiazo, Simón Plata Torres, 05 de Agosto, Vuelta Larga y Esmeraldas;En Atacames, desbordaron los ríos Súa, Tonchigüe y La Unión, suscitándose inundaciones en varios sectores. El servicio de agua potable fue suspendido debido a fallas en la planta de captación.En Muisne, los ríos Canuto, Matambal y Sucio se desbordaron; las parroquias Muisne y San Gregorio presentaron inundaciones.En Quinindé, parroquias Cube y Viche se suscitaron inundaciones, por el desbordamiento de los ríos Cube, Viche y Blanco.</td></tr><tr><td>Situación actual:</td><td>El río Teaone, está con tendencia a disminuir de nivel.1986 personas de 570 familias afectadas por la inundación se encuentran albergadas en alojamientos temporales.Existen 8 alojamientos temporales y 1 refugio activos.El COE Provincial, MTTP, GTP; COE Cantonal Esmeraldas, Atacames, Muisne y Quinindé con las MTTC se encuentran activos.</td></tr><tr><td>Afectaciones:</td><td>Esmeraldas:- 3256 familias (13577 personas afectadas); 811 familias (2679 personas damnificadas).- 3793 viviendas afectadas; 292 viviendas destruidas.- 3 bienes públicos afectados.- 8 establecimientos educativos afectados.- 1 establecimientos educativos destruidos.- 11744 animales muertos.Rioverde- 5 Establecimientos educativos impactados.- 281 familias (1125 personas afectadas).- 281 viviendas afectadas.- 2 Bienes públicos (1 coliseo y 1 cancha).- 1 centro de salud afectado.</td></tr></table>

## Atacames:

- 804 familias (3242 personas afectadas). 

- 852 viviendas afectadas. 

- 48 familias damnificadas. 

- 174 personas afectadas. 

- 3 Vivienda destruidas. 

- 45 bienes privados afectados. 

- 1 bien público afectado (subestación eléctrica). 

- 1 bien público destruido (tubería). 

- 1 vía parcialmente habilitada (20 metros lineales). 

- 7 establecimientos educativos afectados. 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 4 de 25

## Quinindé:

-192 familias (619 personas afectadas). 

- 5 familias (20 personas afectadas). 

- 192 viviendas afectadas. 

- 5 viviendas destruidas. 

- 1 bien público afectado. 

- 520 hectáreas de cultivo afectadas. 

- 56 hectáreas cultivo destruidas. 

-5 establecimientos educativos afectados. 

-2 establecimientos educativos destruidos. 

## Muisne:

- 315 familias (1230 personas afectadas); 74 familias (314 personas damnificadas). 

- 315 viviendas afectadas. 

- 81 viviendas destruidas. 

- 74 familias damnificadas. 

- 314 familias Personas damnificadas. 

- 74 bienes privados afectados. 

-7 centros de salud afectados. 

- 28 bienes privados destruidos (camaroneras). 

- 482 hectáreas cultivo afectadas. 

- 20 hectáreas cultivo destruidas. 

-10 establecimientos educativos afectados. 

## Eloy Alfaro:

- 4 familias (15 personas afectadas.) 

- 2 establecimientos educativos afectados. 

## San Lorenzo:

- 1 establecimiento educativo afectado. 

Nota aclaratoria: Toda la información de cifras mostradas en el presente informe, está sujeta a variación en virtud del levantamiento continuo de información. 

## Acciones de respuesta:

MAATE continúa conjuntamente con los directivos de la Junta Administradora de Agua Potable de la Parroquia Carlos Concha, la limpieza de la captación de agua y cuarto donde se ubican los tableros electrónicos y clarificador. 

La Prefectura Esmeraldas continúa con la limpieza de las alcantarillas y recolección de desechos sólidos; además, la distribución de agua mediante tanqueros en los alojamientos temporales y en varios sectores afectados. 

La CRE mantiene la limpieza de las clorinadoras para continuar con la elaboración de hipoclorito de sodio al 1% en las 5 máquinas clorinadoras a disposición. 

La ARCSA realiza el monitoreo de parámetros físico químico para verificar la calidad de agua y cloración de las cisternas de los 9 alojamientos temporales activos. 

El MSP ha realizado 4542 atenciones en salud en los siguientes cantones afectados Quinindé (70) atenciones, Esmeraldas (3107), Atacames (936) y Muisne (429). 

El MSP activó 19 EAIS (Equipos de Atención Integral de Salud) que realizan inspecciones, evaluaciones y búsqueda para la atención en salud en los alojamientos temporales y zonas afectadas por la emergencia. 

El MSP continúa con las actividades de control vectorial (fumigación) en los alojamientos temporales y en las zonas afectadas. 

La Prefectura de Esmeraldas coordinó con el MTOP la atención inmediata en las vías de tercer orden afectadas en las parroquias Galera, San Gregorio y Cabo San Francisco, adicional. 

El MSP abasteció con medicamentos e insumos médicos a los alojamientos temporales activos. 

MIES, CRE y Secretaría Técnica Ecuador Crece sin Desnutrición Infantil apoyan en la digitalización de las fichas EVIN levantadas desde el centro implementado en la Cruz Roja. 

El Ministerio de Desarrollo Urbano y Vivienda (MIDUVI) coordina el apoyo técnico para el levantamiento de información en los sectores afectados. 

FFAA continúa brindando seguridad con personal en los traslados de ayuda humanitaria a los diferentes sectores, así como también, en los centros de acopio y alojamientos temporales. 

La Policía Nacional (PPNN) se encuentra reforzando con capital humano y medios de movilización institucionales provenientes de otras zonas y subzonas, a los distritos afectados. 

## Esmeraldas:

MAATE gestionó 1 hidrocleaner de la ciudad de Quito y 4 tanqueros con EP - PETROECUADOR continúan con la limpieza de pozos sépticos sector Vuelta Larga. MAATE con los tanqueros con EP - PETROECUADOR abastece de agua sector La Victoria, parroquia Simón Plata Torres. 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 5 de 25

EPMAPSE realizó la distribución de agua mediante tanqueros en los alojamientos temporales y en sectores de la zona sur de Esmeraldas. 

El MSP mantiene la Unidad Móvil activa en el alojamiento temporal Alfonso Quiñonez. CNT es responsable de la planificación, operación y mantenimiento de los sistemas de transmisión, asegurando así la entrega confiable y eficiente de los servicios de telefónica fija y móvil, internet fijo y móvil. 

El GAD C Esmeraldas abastece a los alojamientos temporales y realiza socialización de La Violencia de Genero a los Gestores de los alojamientos. 

El MAG, IEPS, Agrocalidad y del MPCEIP se encuentran desplazados en distintos sectores del cantón Esmeraldas realizando el levantamiento de información sobre las afectaciones y pérdidas de cultivos y animales. 

La PPNN está realizando el levantamiento y tratamiento de información ante posibles intentos de evasión del Centro de Privación de Libertad en la ciudad de Esmeraldas. 

## Atacames:

La Cooperativa de Producción Pesquera BAHIA-SUA reporta al MPCEIP que existen 210 miembros de su gremio que han sufrido afectaciones en embarcaciones y domicilios. MPCEIP mediante la Subsecretaria de Recursos Pesqueros realizó el levantamiento de información en cuanto a daños en la infraestructura de sus domicilios y embarcaciones determinando 48 miembros afectados. 

## Muisne:

El MSP reportó 7 establecimientos de salud afectados. 

MPCEIP y la Federación Nacional de Cooperativas Pesqueras del Ecuador (FENACOPEC) realizaron el levantamiento de información de los afectados en el cantón Muisne. 

La UGR GAD Cantonal Muisne continua realizando el levantamiento de información y daños, adicional remitió varios EVINES. 

MPCEIP mediante la Subsecretaria de Recursos Pesqueros realizó entregas de asistencia humanitaria en el cantón Atacames, Parroquia Súa y en el cantón Muisne.
Rioverde: 

El MSP reportó 1 establecimiento de salud afectado. 

## Fuentes de información:

MTT Provinciales, GAD's Cantonales/ SGR Umeva Esmeraldas. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/1356c41cb356c27825b4a0ef239e8af3e70edcbb16d102182d46ccfdfd5cbdd8.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Carchi/Tulcán/González Suárez/Ciudadela Padre Carlos de la Vega, calle Manuel Machado y Adolfo Becker.</td></tr><tr><td>Antecedentes:</td><td>El 16/05/2023, producto de las fuertes precipitaciones, se presentaron movimientos en masa en un tramo de las riveras del Río Bobo, en este sector se encuentra asentada la ciudadela Padre Carlos de la Vega; y producto de esto existen varias viviendas en riesgo las cuales presentan fisuras y grietas.</td></tr><tr><td>Situación actual:</td><td>Se realizó la reunión del COE Cantonal el 05/06/2023; en donde se resuelve: 1. Recomendar al Sr. Alcalde del cantón se Declare en Emergencia, en base a los informes presentados por la SGR, EMAPA - T, UGR del GAD C Tulcán, entre otras resoluciones; y se proceda a atender la emergencia en base de las competencias y normativas vigentes. Al momento la vía de tercer orden está parcialmente habilitada</td></tr><tr><td>Afectaciones:</td><td>- 12 familias y 52 personas en riesgo.- 8 viviendas afectadas por fisuras y en riesgo de colapso.- 20 metros lineales de vía colapsada.</td></tr><tr><td>Acciones de respuesta:</td><td>El 05/06/2023 sesionó el COE Cantonal para la coordinación de acciones y la toma de decisiones.UGR del GAD Cantonal Tulcán realizó el informe técnico.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura-Carchi/UAR SGR CZ1/Gobernación de Carchi.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/ff09360a840e81e4ad0be232407297422586efa93bd83d6edcdc8ef40ec8f3f3.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imaburo, Pimampiro, Pimampiro, San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El 26/11/2021, de acuerdo al informe del SGR se indicó que el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.Se informa que el SGR CZ1, geólogos de la Prefectura, Universidad Central, Universidad Yachay y autoridades locales realizaron recorridos e inspecciones técnicas.El 16/11/2021, SGR-CZ1 entregó asistencia humanitaria. El Informe del MAG indica que la afectación de los cultivos en total es de 12,43 ha de cultivos de la zona. GAD Cantonal de Pimampiro en apoyo del GAD Provincial Imbabura trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad, tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su cabecera cantonal.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.Desde enero de 2023 se inició con la instalación de las acometidas de los servicios básicos. El MIDUVI está a la espera de que el GAD termine de hacer las acometidas para</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 6 de 25

<table><tr><td></td><td>iniciar con la construcción de las viviendas; ya que dispone de los recursos económicos para este proyecto.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservorios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El GAD Cantonal de Pimampiro determinó un predio para la construcción del Proyecto de Vivienda, y realizó la instalación de servicios básicos.GAD Cantonal y Provincial de Imbabura habilitaron una vía alterna. La comunidad habilitó la vía a Mariano Acosta que pasa por la zona de riesgo de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SGR, exponiéndose a futuros riesgos vinculados a la zona propensa de deslizamiento.Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.EI 02/05/2023, MIDUVI realizó la inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/MIES, MIDUVI, GAD C Pimampiro - UGR.</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/33c838159e10a716ae16a62896f9b69a06065161193b114688dddaa51739dcb2.jpg)


<table><tr><td colspan="2">Sismo</td></tr><tr><td>Localización:</td><td>Zonal 2/ Napo /45.1 km de Tena</td></tr><tr><td>Antecedentes:</td><td>Debido al sismo de MAGNITUD 5.3 con EPICENTRO a 45.1 km de Tena y PROFUNDIDAD 4 Km, se percibió de forma moderada en Archidona, Quijos, El Chaco, Tena y Arosemena Tola.-Cantón Archidona: Una persona resultó herida debido a que el vidrio de una puerta cayó sobre la pierna de una guía en el CPL.-Cantón Quijos: Se observan fisuras en paredes de las instalaciones del GAD Municipal de Quijos-Cantón El Chaco: Moradores escucharon un ruido de desprendimiento de tierra en el sector afectado por la erosión del río Quijos.</td></tr><tr><td>Situación actual:</td><td>Moradores escucharon un ruido de desprendimiento de tierra en el sector afectado por la erosión del río Quijos. Teniente Político informa que coordinará una verificación de novedades con la luz del día. CELEC EP realizarán una inspección durante el día. Hasta el momento no se registran afectaciones.</td></tr><tr><td>Afectaciones:</td><td>1 Persona herida.1 Bien público afectado.</td></tr><tr><td>Acciones de respuesta:</td><td>CELEC EP informa que después de realizar la inspección a su infraestructura no se observó novedades. Teniente Político de Gonzalo Diaz de Pineda indicó que se verificaron pequeños desprendimientos que no causaron afectaciones en el sector de San Luis. MTOP confirmó que realizó un recorrido por la Red Estatal Vial, la misma está habilitada.</td></tr><tr><td>Fuentes de información:</td><td>ECU 911 Tena/SGR-Unidad de Napo-Orellana/MDG/MTOP/CELEC EP</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/f4860be6a53797c1a81b9d511941454d8a33d776138dc514f8c653190a378caa.jpg)


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.Se mantiene la declaratoria emitida mediante resolución SGR-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>El 12/06/2023, la Comisión Ejecutora del Río Coca, CERC, informó que el frente de erosión se encuentra en la abscisa 7+560 por 91 días. Entre el km 9+000 y 10+000, el</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 7 de 25

<table><tr><td></td><td>río continúa erosionando el margen y desplazando su cauce principal hacia la izquierda; además, se mantiene el avance de la erosión regresiva local en el río Loco y erosión lateral en los taludes; en el río Malo, la erosión local y su frente de erosión se mantiene sin cambios. En la zona del campamento La Loma, se aprecia degradación en el cauce central y en el margen derecho; el margen izquierdo se mantiene sin cambios y el riesgo es bajo para el campamento. Se mantienen las condiciones de inestabilidad en la zona de Ventana 2 que amenazan los terrenos del antiguo campamento de SINOHYDRO, , el sector del poblado de San Luis y las zonas ubicadas en la margen izquierda del cauce. El río Coca presentó los siguientes registros de caudales: máximo 89.4 m3/seg; mínimo 25.6 m3/seg; medio 60.0 m3/seg.</td></tr><tr><td>Afectaciones:</td><td>Desde el 2020 a la fecha las afectaciones son las siguientes:- Personas Afectadas indirectas: 100- Personas Damnificadas: 51- Personas Afectadas: 76- Personas Evacuadas: 63- Viviendas destruidas: 2- Metros de vía afectadas: 1040- Puentes destruidos: 3 (Puente sobre el río Motana, Puente Ventana 2 y Puente Piedra Fina)- Puente afectados: 1 (Puente Piedra Fina)- Bienes Afectados: 4 (tuberías del SOTE, Poliducto Shushufindi- Quito y OCP; Sistema de Agua Potable de San Luis)- Ha de Cultivo perdida: 100.03- Animales de granja afectados y muertos: 3448</td></tr><tr><td>Acciones de respuesta:</td><td>CELEC EP En el campamento la Loma, se aprecia degradación en el cauce central y en la margen derecha; la margen izquierda se mantiene sin cambios y el riesgo es bajo para el campamento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/CELEC EP/GAD Municipal El Chaco/MTOP/Teniente Político Gonzalo Díaz de Pineda</td></tr></table>

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/937e493efe8b92cffd4328956d22ca655ae25464286f7fdf5e6799da05d89cf9.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Huigra/Las Violetas, Huigra Viejo, Barrio Azuay, Barrio Turístico, vía Huigra - El Triunfo [E-47].</td></tr><tr><td>Antecedentes:</td><td>El 28/05/2023, a causa de las lluvias registradas por la madrugada, se produjo el crecimiento del caudal del río Chanchán, el socavamiento de unas gradas y el colapso de un poste de la red eléctrica.</td></tr><tr><td>Situación actual:</td><td>Las personas evacuadas regresaron a sus respectivas viviendas, 3 familias se encuentran con familiares acogientes.El COPAE de Huigra sesionó el 29/05/2023 y resolvió:</td></tr><tr><td>Afectaciones:</td><td>- 8 familias afectadas (70 personas aproximadamente),-8 familias (32 personas) son afectadas en cultivos y animales.- 16 viviendas afectadas aproximadamente- 4 bienes públicos destruidos (poste de la red eléctrica, puente peatonal, gradas, puente carrozable)- 3 bienes públicos afectados (muros de hormigón - piedras, cancha de vóley, plaza de feria)- 1 vía de primer orden afectado parcialmente (Tramo vial de la vía [E-47]- 1 vía de tercer orden parcialmente afectada (Barrio Turístico)- 1 bien privado afectado (Complejo la Playita)- 6 familias evacuadas (57 personas).- 6 familias en alojamiento temporal (57 personas)- 3 ha de cultivos afectados- 2 ha de cultivos destruidos- 12 animales afectados- 1000 animales muertos</td></tr><tr><td>Acciones de respuesta:</td><td>MAG realizó el levantamiento de afectaciones a través de una MAAPEA.UGR GADC Alausí con apoyo de la SGR CZ3 realizó el levantamiento de informe EVIN.UGR conjuntamente con CB, PPNN, FFAA, GAD Alausí, GADP Huigra, SGR, Consejo Cantonal de Protección de Derechos, Ministerio de Gobierno notificaron para evacuación voluntaria de las familias que se encontraban en la ribera del río Chanchán.SGR monitorea el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ 3 Unidad de Monitoreo Tungurahua/UGR GADC Alausí/GADP Huigra/Cuerpo de Bomberos de Alausí/PPNN/MSP/SGR Uprea Chimborazo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/14eb9cb491f9f80396d3a707f3ced8a96408d24155ea485ac49f7e9d773e121b.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Multitud/varios sectores, vía Pallatanga-Cumandá [E-487].</td></tr><tr><td>Antecedentes:</td><td>El 09/05/2023, por causas desconocidas se produjo un hundimiento en la vía de segundo orden, que posiblemente afecte a viviendas del sector. Además en varios sectores se evidencian grietas en el suelo.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 8 de 25

<table><tr><td></td><td>Se recomienda al Gobierno Autónomo Descentralizado Municipal del Cantón Alausí para que conjuntamente con la Junta Parroquial de Multitud y los representantes de la Comunidad Las Rocas realicen la construcción de medidas estructurales para reducir la amenaza en el sector, principalmente para disponer de un adecuado sistema de drenaje y el encausamiento de las aguas provenientes de las precipitaciones en la zona hacia la quebrada que desemboca al Río Chimbo.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía secundaria se encuentra parcialmente habilitada.Se realizó el reconocimiento de un albergue temporal en la Casa Comunal de la Junta Parroquial de Multitud, para proceder con la respectiva activación, también se movilizaron personal del IG al lugar, en coordinación junto a la SGR, UGR GAD Alausí y personas de la comunidad, para levantar inspección técnica y medir la deformación del lugar.</td></tr><tr><td>Afectaciones:</td><td>- 100 m. de vía afectada- 20 viviendas afectadas (Es un número estimado hasta el levantamiento del informe EVIN)- 1 Unidad educativa afectada (Escuela Bilingüe 15 de Octubre)- 2 Bienes públicos afectados (iglesia y tanque de agua potable)</td></tr><tr><td>Acciones de respuesta:</td><td>UGIAR SGR CZ3 socializó con la población de la Comunidad Las Rocas, parroquia Multitud del Cantón Alausí el informe técnico levantado por la presencia de grietas y asentamiento en la comunidad que conllevó a la delimitación de un polígono de Alta susceptibilidad.IG, junto con SGR, UGR GAD Alausí realizaron inspección técnica en el lugar.SGR realizó el reconocimiento de un albergue temporal y monitorea el evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGR Cantonal/GAD Parroquial.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/2972568b53e64a8a21ad489d82d3538e90df563203fde23036ea5d11a7a7e71e.jpg)



Deslizamiento


<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Alausí, Cabecera Cantonal/Casual, vía Guamote - Alausí [E-35].</td></tr><tr><td>Antecedentes:</td><td>El 09/12/2022, se produjo un hundimiento en la vía de primer orden, que al momento está cerrada.El día 26/03/2023, debido al hundimiento, se produjo un deslizamiento en la E35 se bajó la montaña afectando completamente la vía de primer orden y viviendas aledañas.Mediante RESOLUCIÓN Nro. SGR-111-2023, se determina CAMBIAR EL NIVEL DE ALERTA AMARILLA A NARANJA por movimientos en masa en el área de 214 hectáreas, que comprende el sector: Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua, del cantón Alausí y RATIFICAR el estado de ALERTA AMARILLA en el área de 38,07 hectáreas, considerando la actualización del análisis y observaciones técnicas realizadas en campo.</td></tr><tr><td>Situación actual:</td><td>Mediante resolución, el 15/06/2023 el COE Cantonal resolvió:Comunicar a la ciudadanía que, bajo estricta responsabilidad de cada conductor, el paso vehicular en el tramo Pueblo Viejo - Alausí (Zona Cero) únicamente se permite para vehículos no mayores a 3.5 toneladas, las 24 horas del día.Exhortar a la Policía Nacional realizar el estricto control del tránsito de vehículos en el sector de Totorillas (cantón Guamote), sector Charicando, Guasuntos y centro de la cuidad de Alausí, respetando el peso vehicular, considerando la recomendación de la SGR, que el paso sea únicamente de vehículos livianos por la vía Pueblo Viejo - Alausí.Solicitar al Ministerio de Transporte y Obras Públicas colocar la señalética de prohibición de paso de vehículos pesados en la vía estatal E35 en el sector de Totorillas, Charicando y Guasuntos y a la Prefectura de Chimborazo la instalación de la señalética en las vías de acuerdo a su competencia.Recomendar al Gobierno Autónomo Descentralizado Municipal del Cantón Alausí previo análisis técnico de las Mesas de Trabajo y criterio jurídico para que el concejo en pleno resuelva sobre la declaratoria de estado de emergencia institucional para solventar las necesidades de la parroquia de Huigra.</td></tr><tr><td>Afectaciones:</td><td>- 65 personas fallecidas- 581 personas afectadas- 44 personas heridas.- 10 personas desaparecidas.- 1034 personas damnificadas (evacuadas hacia los alojamientos temporales).- 163 viviendas afectadas- 57 viviendas destruidas- 2 bienes privados destruidos (Asadero Don Fausto y Damada - cafetería se encuentra destruido)- 1 bien privado afectado (Hostería Pircapamba)- 1 Unidad Educativa afectada (U.E. Federico Gonzales Suarez)- 2 bienes públicos destruidos (1 Estadio y 1 coliseo).- Vías destruidas:- Primer Orden: 1,12 Km- Segundo orden: 1,20 Km- Total: 2.32 Km- 3 bienes públicos afectados (25% de red público afectado y 60 % de servicio de agua potable afectado, 20 % de servicio de alcantarillado afectado).- 6 ha de cultivos y pasto destruidos.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 9 de 25

<table><tr><td></td><td>- 20 ha de cultivos afectados.- 230 Animales afectados.- 427 metros de línea férrea destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>COE Cantonal mantuvo sesión extraordinaria el 15/06/2023, donde participaron las diferentes Mesas Técnicas de Trabajo para tomar las respectivas resoluciones.GADM Riobamba, GADC Alausí, Fundación Visión Mundial, MIES Y Fundación ACNUR realizaron entrega de asistencia humanitaria en el sector.MTT’s y GT’s continúan con sus labores de acuerdo a sus competencias.SGR monitorea el evento.Se encuentran activados el COE Provincial de Chimborazo y el COE Cantonal de Alausí.GAD Municipal Rumiñahui hizo la entrega de un pluviómetro digital de alta precisión al GAD Cantonal Alausí, para que realice las mediciones de precipitaciones en tiempo real de su territorio.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MTOP.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/696bfe97cf96d211c1359d186ceb84e21609c5024899b5b03b2d6aa752110a4d.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Huigra/Cerro Pasan y Namza Chico.</td></tr><tr><td>Antecedentes:</td><td>De acuerdo a informe técnico de la SGR del 11 de junio del 2018 indican que debido a la litología y a la sobre saturación de material se produjo grietas en los sectores señalados por lo que la SGR declara el estado de ALERTA NARANJA el 09 de abril del 2023 debido al incremento de amenaza de movimiento de masa en Pasan y Namza Chico, además, de acuerdo a informe del INAMHI en el que se indicó que en el mes de abril se incrementarán las lluvias. La evacuación de la población se da bajo el principio de autoprotección, considerando la continuidad de las grietas y el carácter activo de movimientos en masa de 152,22 ha, que comprende los sectores de Namza Chico, Pasan, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chanchán.Mediante Resolución MINEDUC Alausí - Chunchi dispone al rector y planta docente de la Unidad Educativa Eloy Alfaro, que se suspendan las actividades pedagógicas presenciales debido a la DECLARATORIA del estado de ALERTA NARANJA.</td></tr><tr><td>Situación actual:</td><td>Al momento las 12 familias que se encontraban albergadas en el Hotel Huigra retornaron a sus viviendas y las otras 10 familias se encuentran con familiares acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 117 personas evacuadas (27 familias):- Hotel Huigra: 48 personas (16 familias) (retornaron a sus viviendas)- Hotel Rosero Resort: 4 personas (1 familia) (retornaron a sus viviendas)- Familias acogientes: 65 personas (10 familias)</td></tr><tr><td>Acciones de respuesta:</td><td>Mediante apoyo interinstitucional entre SGR, IGM e IIIGE realizaron mediciones en la parroquia Huigra con la finalidad de monitorear un potencial deslizamiento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGIAR.</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/31550ac26f18bacf71e6db46ad1eab2abca1f1d7070d23d4afad47635dafb90f.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Flavio Alfaro/ Flavio Alfaro/ centro, varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 08/06/2023, producto de lluvias presentadas en horas de la noche y el desbordamiento del río pescadillo se suscitó una inundación que afectó la zona baja centro del Cantón Flavio Alfaro, se reportan familias y viviendas afectadas en el punto y familias evacuadas, Personal de Bomberos, Cruz Roja, UGR Cantonal Policía Nacional colaboraron con la evacuación de las personas, el COE se activó frente a la emergencia presentada en el Cantón.</td></tr><tr><td>Situación actual:</td><td>UGR Cantonal Flavio Alfaro realizó el levantamiento de información de las familias afectadas, se procede a cambiar el numero de las afectaciones, se indica que las familias que evacuaron regresaron a sus viviendas, se coordina atención con la SGR CZ4 para la entrega de AH, al momento el río se encuentra con caudal normal.</td></tr><tr><td>Afectaciones:</td><td>-110 familias afectadas.-550 personas afectadas.-110 viviendas afectadas.</td></tr><tr><td>Acciones de respuesta:</td><td>UGR GAD Cantonal realizó el levantamiento de información de las afectaciones.SGR monitorea el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR Cantonal.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/6ab324b9ff476a84c5df5af9dd198dc9ce00904f35b6f171cf4665a07e4580b3.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Manabí/Portoviejo/Rio chico/La Encantada</td></tr><tr><td>Antecedentes:</td><td>El 29/05/2023, producto de lluvias suscitadas se desbordó la quebrada la encantada se suscitó una inundación en el sitio mencionado.</td></tr><tr><td>Situación actual:</td><td>Personal de la UGR Cantonal Portoviejo realizó el levantamiento de información de las familias afectadas, se procede a cambiar el número de las afectaciones, incluyendo afectaciones en el sector agrícola, se coordina atención con la SGR CZ4 para la entrega de AH.</td></tr><tr><td>Afectaciones:</td><td>-47 familias afectadas, 139 personas afectadas.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 10 de 25

<table><tr><td></td><td>-47 viviendas afectadas.-10 ha afectada de maíz</td></tr><tr><td>Acciones de respuesta:</td><td>Levantamiento de información por parte de la UGR GAD Cantonal.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/Cuerpo de Bomberos de Río-Chico-Portoviejo.</td></tr><tr><td>Deslizamiento</td><td></td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/c9524eb367fb9c80591d842b20cd3a5102d0cb298b0452af06ed958f776b9527.jpg)


<table><tr><td>Localización:</td><td>Manabí/Santa Ana/Honorato Vásquez/sectores Vainilla y La Laguna.</td></tr><tr><td>Antecedentes:</td><td>El 18/04/2023, por las lluvias suscitadas en los últimos días, se produjo el deslizamiento de una ladera afectando a varias viviendas en los sectores mencionados.Las familias afectadas permanecen en casas de familias acogientes.</td></tr><tr><td>Situación actual:</td><td>Técnico SGR-CZ4 informa que continuaran con el estudio del suelo, ya que aún se encuentran pendientes sitios con puntos de agrietamientos sin evaluación.</td></tr><tr><td>Afectaciones:</td><td>- 21 viviendas afectadas- 25 familias afectadas (84 personas afectadas)- 2 familias evacuadas (alojamiento temporal)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR GAD Cantonal realizó la Evaluación de Daños y Análisis de Necesidades.SGR emitió la RESOLUCIÓN Nro. SGR-169-2023 que DECLARA el estado de ALERTA AMARILLASGR CZ4 gestionó la entrega de AH a las familias afectadas por parte de Plan Internacional.SGR continúa con evaluación y monitoreo del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Santa Ana/Tenencia Política.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/39621c1f0098e60a6854864da97f04a69d0f12e34e42cd217749a4e4f7ec1017.jpg)



Colapso estructural


<table><tr><td>Localización:</td><td>Santo Domingo de Los Tsáchilas/La Concordia/La Concordia/Sector del Camal.</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2023, producto de las lluvias de la madrugada se produjo el aumento del caudal del río Blanco, provocando la ruptura de la tubería principal de la planta de tratamiento de agua potable, afectando la distribución de agua en el Cantón.</td></tr><tr><td>Situación actual:</td><td>Se realizan los trabajos de reparación de la tubería principal de agua potable.La empresa de agua potable habilitó dos pozos de agua donde la ciudadanía pueda acudir a solicitar agua.Se continúa con el suministro agua a la población con tanqueros.</td></tr><tr><td>Afectaciones:</td><td>- La afectación de la distribución de agua de la planta es del 100%- 2 bienes Públicos afectados (Planta de Agua Potable y Camal Municipal).- 51 animales de granja fallecidos (cerdos, Reses).- Aproximadamente 170.000 personas afectadas indirectamente por el suministro de agua</td></tr><tr><td>Acciones de respuesta:</td><td>GAD La Concordia continúa con la entrega de agua, con tanqueros.Empresa privada realiza trabajos de reparación de la tubería principal de agua potable.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Santo Domingo/UGR GAD La Concordia.</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/9b8cc4239e632087ae16898f043ea1f374f9e2f5190ced42ebf44f980531a510.jpg)


<table><tr><td>Localización:</td><td>Los Ríos/Quinsaloma/ Quinsaloma/Barrio Las Palmitas - 12 de octubre - Isla de Barbones - Rcto. Estero de Damas - río Umbe - río Calabí - Rcto. San Vicente - Rcto. San Gabriel Rcto. Achotillo -Rcto. San Francisco</td></tr><tr><td>Antecedentes:</td><td>Debido a las fuertes lluvias suscitadas en la madrugada del 25/05/2023, se reportó desbordamiento de los ríos Umbe con río Calabí,.</td></tr><tr><td>Situación actual:</td><td>Prefectura se mantiene colaborando con la reparación de la vía de segundo orden; las familias afectadas se mantienen en sus hogares, las familias damnificadas permanecen en casa acogiente, la vía permanece parcialmente habilitada y el río se mantiene en su caudal normal.</td></tr><tr><td>Afectaciones:</td><td>- 1 persona fallecida (mujer adulta)- 53 viviendas afectadas- 53 familias afectadas- 196 personas afectadas- 2 viviendas destruidas- 2 familias damnificadas- 10 personas damnificadas (casa acogiente)- 2 bienes públicos destruidos (alcantarillados)- 1 puente afectado- 200 metros lineales afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>Prefectura de Los Ríos se mantiene con la reparación de la vía afectada.SGR realizó entrega de ayuda humanitaria en compañía de UGR Quinsaloma.Se coordina con MAG la inspección técnica para levantamiento de MAAPEA.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/UGR Quinsaloma/SGR-UPREA/MIES.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 11 de 25

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/3274024ff7c4984112142baeec73fde1c4c828859f0d829c0c0421c511611357.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Los Ríos/Babahoyo/La Unión/La Puntilla Cdla. 5 de junio - La Cuarenta - 25 de diciembre - río Clementina</td></tr><tr><td>Antecedentes:</td><td>Debido a las fuertes lluvias suscitadas en la madrugada del 25/05/2023, se reportó desbordamiento del río Clementina, mismo que afectó a varias viviendas del lugar.</td></tr><tr><td>Situación actual:</td><td>Personal técnico realizó levantamiento de EVIN el 25/05/2023, en donde se actualizan los datos de afectación, actualmente las familias afectadas se mantienen en sus viviendas y el caudal del río Clementina se encuentra con tendencia a disminuir de nivel.</td></tr><tr><td>Afectaciones:</td><td>- 82 viviendas afectadas.- 82 familias afectadas.- 254 personas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>UGR realizó levantamiento de EVIN</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Los Ríos/ GAD Babahoyo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/792c7d7aa4be59c48acbf45e6740c876b27689408f1178505abff4adf45f129c.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Caluma/ Caluma/ varios sectores, Santa Teresita, Barrio Central-San Vicente (Caluma Viejo), Pita, Charquiyacu, Unión de Pacana, Hoyo Bravo, Agua Santa, Pasagua, Cumbilli Chico - Naranjapata, Cumbilli Chico (Y) y Cumbilli Grande, Guayabal, Guamaspungo, Barrio Nueva Esperanza, Barrio San José, Barrio Hemisferio-Guamaspungo, Unión de Pacana - Plomovado, Charquiyacu - retiro de Charquiyacu, Charquiyacu - Sub centro, Guamaspungo Copales, Estero del Pescado, San Vicente de Pacana.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en los sectores, se produjo el desbordamiento de los ríos Caluma, Escaleras, Naranja Pata, Choripungo y los Esteros S/NEl COE Cantonal el 26/05/2023, resolvió Declarar la situación de EMERGENCIA AL GOBIERNO AUTÓNOMO DESCENTRALIZADO MUNICIPAL DEL CANTÓN CALUMA, por el lapso de 60 días.El servicio eléctrico fue restablecido en el Barrio Central-San Vicente (Caluma Viejo) y en del sector de Pasagua.Se encuentra restablecido el servicio de líquido vital en el sector de Pasagua.</td></tr><tr><td>Situación actual:</td><td>UGR Caluma indica que continúan realizando trabajos de rehabilitación de la vía y muros de escollera tras el Mercado Municipal. En la vía Charquiyacu a Pasagua continúa la limpieza de cunetas y de la vía la cual está habilitada parcialmente. En el sector de Pita finalizó los arreglos en el puente. La vía que va de Pasagua a Naranjapata, Cumbillí Chico (Y), Cumbillí Grande se encuentra cerrada.</td></tr><tr><td>Afectaciones:</td><td>- 9.260 metros lineales de vía.- 2 viviendas destruidas (1 en Pasagua; 1 en Unión de Pacana - Plomovado).- 2 familias, 8 personas damnificadas (mismas que se encuentran en hogar acogiente).- 122 viviendas afectadas por el ingreso de agua y lodo- 128 familias, 434 personas afectadas mismas que se encuentran en las mismas viviendas)- 31 bienes públicos afectados (16 alcantarillas, 5 postes, 2 canchas, 1 cementerio, 1 iglesia; 3 muro de contención; 1 mercado, 1 malecón).- 3 bienes públicos destruidos (2 muro de contención; 1 muro de gaviones).- 79 bienes privados afectados (1 tuberías del agua; 1 cerramiento; 1 iglesia; 73 locales comerciales; 3 centros turísticos).- 5 bienes privados destruidos (4 bienes de mercadería; 1 vehículo)- 5 puentes afectados- 4 puentes destruidos- 59 Ha de cultivos afectados (cacao y naranja)- 40 Ha de cultivos perdidos (cacao y naranja)- 43 animales afectados (porcinos y bovinos)- 12 animales muertos (porcinos y bovinos)- 8 productores afectados</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria del GAD Provincial y personal del GAD Caluma continúan realizando limpieza de alcantarillas, cunetas y la vía de segundo orden desde Charquiyacu a Pasagua.Maquinaria de la Empresa Privada contratada por el GAD Caluma y del GAD Provincial continúan realizando el muro de piedra escollera a la orilla del río Caluma y encauzamiento del río, a la altura del Barrio Central - San Vicente (Caluma Viejo).Personal del GAD Cantonal finalizó los arreglos en las barandas del puente de Pita.Maquinaria de Empresa Privada contratada por el GAD Caluma paralizó los trabajos de encauzamiento de río Caluma en la vía Guamaspungo - Hemisferio por daño en la maquinaria.MIES indica que se van a activar 23 Bonos de Contingencia bajo la tipología de Calamidades provocadas por Desastres Naturales y varios Bonos de Contingencia para personas afectadas por eventos de origen natural y antrópico por el decreto 316.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/UPREA/GAD Caluma/C.B.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 12 de 25

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/1ce0208dca651eb9917b6de62875d5584baef731e9e0c8a077a9bf67e812ec17.jpg)


Inundación 

<table><tr><td>Localización:</td><td>Bolívar/Echeandía/Echeandía/ varios sectores: El Malecón Alto, El Congreso, San Carlos, Santa Lucia, San Gerardo, La Esperanza Baja, Galápagos, Estero de Damas, Las Malvinas, Puruhuay, San Antonio, La Florida, Plaza Roja</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en el sector la noche del 24 y madrugada del 25/05/2023, El 25/05/2023 se activó el COE Cantonal Echeandía para coordinar acciones. El 31/05/2023, volvió a sesionar el COE Cantonal donde recomendó: Declarar en situación de Emergencia Institucional al Municipio del Cantón Echeandía debido a las fuertes precipitaciones presentado en el cantón Echeandía.</td></tr><tr><td>Situación actual:</td><td>UGR Echandía mediante informe técnico indica que existen varios puentes colapsados y afectados en algunas comunidades. La captación de agua del cantón Echeandía sufrió afectación, a la fecha se encuentra funcionando normalmente. En el sector San Carlos vía al Congreso se encuentra socavada parte de la vía, en los sectores de Plaza Roja, Galápagos, vía que conduce a Estero de Damas y a la Pradera a 5km de Camarón, existen deslizamientos de tierra a lo largo de las vías de tercer orden que obstaculiza un carril de la calzada.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas destruidas- 4 familias 18 personas damnificadas (se encuentran en hogares acogientes)- 10 viviendas afectadas- 16 familias 47 personas afectadas (de las cuales 2 familias 7 personas se encuentran arrendando por un mes pagado por la Empresa Privada Hnos. Viscarra y Acción Social Larry Viscarra; 3 familias 4 personas se encuentran en sus mismos predios y las 11 familias, 36 personas restantes se encuentran en hogares acogientes)- 3 puentes destruidos- 11 puentes afectados- 3 bienes privados afectados (Local comercial, La Asociación de artistas y el Centro de Artesanos 26 de Julio)- 4 bienes públicos afectados (un muro de contención de escollera 100 metros sector Malecón, captación de agua taponada, 2 alcantarillas de ármico taponadas en los sectores cruce a la Libertad y el Congreso; y La Florida)- 150 metros lineales</td></tr><tr><td>Acciones de respuesta:</td><td>Empresa de Agua y Alcantarillado Municipal realizó trabajos de limpieza de la captación de agua.Maquinaria del GAD Cantonal realizó limpieza de las alcantarillas en algunos sectores.MIES indica que se van a activar 6 Bonos de Contingencia bajo la tipología de Calamidades provocadas por Desastres Naturales y algunos bonos de contingencias por el decreto 316. UGR indica que finalizó los trabajos de protección de las riberas del río Soloma con maquinaria contratada (125 horas) por el GAD Cantonal</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/ GAD Echeandía, UPREA,</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/398848662b6d34745c2488933aaa7e9f5bb064d3c0608b3edbb2fff1690471b8.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Las Naves/Las Naves/varios sectores: La Playita, el Paraíso, Buenos Aires, La 40; Suquibi Viejo, El Mirador Bajo, ciudadela Elisita vía a Las Mercedes, Suquibi Nuevo, San Pedro y La Isla.</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023 a causa de las lluvias registradas en el sector, se produjo el desbordamiento del río Suquibi.Alcaldesa del GAD Las Naves informa que debido al desbordamiento del río Suquibi, resultó viviendas destruidas, afectadas por el ingreso de agua y lodo y dejó una persona fallecida en el sector La Playita debido al arrastre de la corriente.Además indica que propietarios de las viviendas afectadas realizaron trabajos de limpieza de los inmuebles.En horas de la tarde del 25/05/20023 se reunió el COE Cantonal de Las Naves para la evaluación de las afectaciones y coordinar acciones para atender el evento.</td></tr><tr><td>Situación actual:</td><td>Continúan con los trabajos de limpieza, encauzamiento y protección de muros del río Suquibi en algunos frentes.</td></tr><tr><td>Afectaciones:</td><td>- 1 persona fallecida (Adulto Mayor)- 5 viviendas destruidas- 5 familias, 18 personas damnificadas (de las cuales 4 familias 15 personas La Playita, 1 familia 3 personas del Paraíso, todos se encuentran en hogares acogientes por el mismo sector)- 62 viviendas afectadas (por ingreso de agua, lodo y colapso parcial)- 62 familias, 193 personas afectadas (de las cuales 1 familia 1 persona en el Paraíso, 5 familias 9 personas Buenos Aires, 17 familias 61 personas La 40, 3 familias 10 personas Suquibi Viejo, 1 familia 1 persona El Mirador Bajo, 27 familias 83 personas La Playita, 2 familias 8 personas ciudadela Elisita vía a Las Mercedes, 2 familias 7 personas Suquibi Nuevo, 3 familias 8 personas San Pedro y 1 familia 5 personas La Isla, todos se encuentran en las mismas viviendas)- 2 puentes vehiculares afectados (1 metálico vía Las Naves-San Luis de Pambil y 1 hormigón armado vía a Selva Alegre)- 3 bienes públicos afectados (alcantarillas por taponamiento sector de Buenos Aires)- 2 bienes públicos destruido (1 alcantarilla vía a Selva Alegre, 1 muro de gaviones 300m en Buenos Aires)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 13 de 25

<table><tr><td></td><td>- 200 metros lineales de vía.- 169 ha de cultivos afectados (cacao, naranja, plátano)- 18 ha de cultivos perdidos (cacao, naranja, plátano, mencionar que algunas plantas son de vivero)- 65 productores, 260 personas afectadas- 2 Establecimientos Educativos afectados (en lo funcional)</td></tr><tr><td>Acciones de respuesta:</td><td>Maquinaria del Gad Provincial de Bolívar, del GAD Cantonal Las Naves y de la Empresa Privada contratada por el GAD Cantonal realizan limpieza, encauzamiento y protección de muros a lo largo del río Suquibi.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD Cantonal/C.B</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/9665beb1c81c97f619099b2384ba9cbb403e5019e82a14c95efb4bd3d73d0109.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Guaranda/San Luis de Pambil/varios sectores: La Playita, La Delicia, El Faraón, Moraspungo, Barrio Los Negritos, Bosque de Oro, San Luis de Las Mercedes, Suquibi Viejo, Pisis, Las Minas.</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023 a causa de las lluvias registradas en el sector, se produjo el desbordamiento del río Suquibi, el cual destruyó el puente al ingreso de la parroquia y varias viviendas destruidas.Cuerpo de Bomberos de San Luis apoyaron a la evacuación de dos familias a hogar acogiente.El Servicio eléctrico se encuentra restablecidoEl 25/05/2023 se reunió el COE Cantonal de Guaranda en la parroquia de San Luis de Pambil para analizar las afectaciones y coordinar acciones.Se recomienda tomar la ruta alterna vía de tercer orden de San Luis de Pambil - Las NavesEl 26/05/2023, fue restablecido el líquido vital en el centro de la parroquia de San Luis de Pambil.Se recomienda tomar la ruta alterna vía de tercer orden de San Luis de Pambil - Las Naves</td></tr><tr><td>Situación actual:</td><td>Presidente del GAD Parroquial de San Luis de Pambil informa que continúan realizando trabajos de conformación del área para armar los muros de gaviones que serán el soporte del puente Bailey en el sector la Playita; demás reconformación de la vía que conectará con el puente y dragado del río Suquibi.Se recomienda tomar la ruta alterna de la vía de tercer orden para vehículos livianos (Las Naves, Puente Caído, La Esperanza, Suquibi Nuevo y San Luis de Pambil) y para vehículos pesados (Las Naves, Buenos Aires, La Libertad y San Luis de Pambil).El caudal del río Suquibí se encuentra normal.</td></tr><tr><td>Afectaciones:</td><td>- 4 vivienda destruidas- 4 familias, 21 personas damnificadas- 13 viviendas afectadas- 13 familias, 55 personas afectadas- 1 puente destruido vehicular- 3 puentes afectados vehicular (colapso parcial)- 1 bien privado destruido (vehículo)- 3 bienes públicos afectados(Postes)- 1 bien privado afectado (la captación y tuberías)- 330 Ha de cultivos afectados (cacao, naranja, pasto y café)- 680 Ha de cultivos perdidos (cacao, naranja, pasto y café)- 100 animales afectados (cuyes y gallinas)- 600 animales muertos (cuyes y gallinas)- 30 productores afectados</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial de Bolívar, del GAD Cantonal de Guaranda y del GAD Parroquial de San Luis de Pambil realizan trabajos de conformación del área para armar los muros de gaviones que serán el soporte del puente Bailey en el sector la Playita, mismo que será instalado en los próximos días con el fin de rehabilitar el paso vehicular.Además, realizan reconformación de la vía que conectará con el puente y dragado del río Suquibi.</td></tr><tr><td>Fuentes de información:</td><td>PP. NN, TEPOL, SGR Unidad de Monitoreo Bolívar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/896b4c2e40053630904d52ec731bb19af3b80b727b5faa40e4622ea885f2c8bf.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Guayas/Santa lucía/Santa lucía Cabecera Cantonal/varios sectores.</td></tr><tr><td>Antecedentes:</td><td>El 15/04/2023 y madrugada del 16/04/2023, por lluvias con tormentas eléctricas se registró algunos sectores con calles y avenidas anegadas por acumulación de agua.GAD Cantonal declara en emergencia al cantón Santa Lucía, adicionalmente indica que se realizó recorridos por los sectores afectados en conjunto al alcalde y personal de Cuerpo de Bomberos, Jefatura Política, MIES y SGR. Las familias se mantienen en el albergue y familias acogidas.Con fecha 22/05/2023 UGR del GAD Santa Lucia informa que se realizó el cierre de los alojamientos temporales “Junta Higuerón – El Porvenir” y del “CDI San Pablo”, ya que las familias han retornado a sus viviendas.</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos – No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 14 de 25

<table><tr><td>Situación actual:</td><td>UGR del GAD Santa Lucia informa que el Albergue Temporal “Santa Rosa”aún continua familias albergadas, adicional indicó que el nivel de la cota del río Daule y Pula se encuentran disminuyendo su caudal.</td></tr><tr><td>Afectaciones:</td><td>- 1024 viviendas afectadas- 1024 familias, 3944 personas afectadas (21 familias, 58 personas en el Albergue Temporal “Santa Rosa).- 4500 hectáreas de arroz afectadas- 25 instituciones educativas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal Santa Lucía dio seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/SGR - UPREA/UGR GAD Cantonal Santa Lucia.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/9d5d550d1e5d65e062969e8819377ca138722f081dcb78b3de365f393a3d41a0.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Bolívar/Chillanes/Cabecera Cantonal/San Francisco de Azapi.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 a causa de las lluvias registradas en el sector, se ha producido grietas en un terreno.- Bucay y varios cambios paisajísticos del sector, lo cual evidencia el movimiento de masa activo del sector.La Escuela Ciudad de Latacunga del recinto San Francisco de Azapi se encuentra en zona de riesgo.El 05/05/2023, Personal de la SGR realizó la socialización y concientización del nivel de riesgo alto por el deslizamiento en el sector dirigido a la comunidad, Alcaldesa electa, técnicos de las UGR de los cantones de Bucay - &quot;Guayas&quot;, Cumandá - &quot;Chimborazo&quot;, Chillanes - &quot;Bolívar&quot; y Gobernación de Bolívar.</td></tr><tr><td>Situación actual:</td><td>IIGE realiza actividades de geología y de aerofotogrametría en la zona afectada.MIDUVI indica que las familias deben ser reubicadas por cuanto el suelo de casi toda la comunidad presenta hundimientos fuertes, fisuras, grietas, cuarteamientos, desplazamientos horizontales. Solicitar al GAD Municipal del Cantón Chillanes la donación de un terreno para la reubicación de estas familias</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas- 3 familias, 15 personas afectadas (de las cuales 1 familia, 4 personas se encuentran en otra vivienda de su propiedad y las 2 familias, 11 personas se encuentran arrendando por el mismo sector en una zona segura)- 1 bien público afectado (cancha de la comunidad)- 1 bien privado afectado (capilla)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR y Personal técnico del IIGE en conjunto con GAD Cantonal Chillanes realizaron toma de datos geológicos a detalle, medición de parámetros morfo métricos, colocación de mojones y toma de sus respectivas coordenadas con equipo GNSS en San Francisco de Azapi.SGR realizó la socialización y concientización del nivel de riesgo de la zona afectada.MIDUVI realizó la inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/SGR Unidad de Respuesta y Unidad de Monitoreo Bolívar.</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/0509bb103d0642ab4c2833f6d107a314aa98f0e4742ebca03a9e92ef902c7e19.jpg)


## Aluvión

<table><tr><td>Localización:</td><td>Azuay/Cuenca/Baños/La Inmaculada-Lirio.</td></tr><tr><td>Antecedentes:</td><td>El 26/05/2023, por lluvias se suscitó un aluvión que afectó 1 vivienda parcialmente (colapso parcial de una pared), adicional 4 viviendas se encuentran en la zona de riesgo.</td></tr><tr><td>Situación actual:</td><td>Con fecha 27/05/2023 Directora Zonal de la SGR CZ6 informa de 2 familias integradas por 9 personas (1 familia afectada y 1 familia evacuada por precaución) en Alojamiento Temporal (Iglesia de la Inmaculada), adicional 25 personas evacuadas por precaución a casas de familias acogientes. Con fecha 01/06/2023 DGR Cuenca informa que 19 de las 25 personas evacuadas por precaución retornaron a sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda afectada- 1 familia afectada- 3 personas afectadas, (Iglesia de la Inmaculada)- 6 personas evacuadas, (Iglesia de la Inmaculada)- 3 bienes privados afectados (galpones)</td></tr><tr><td>Acciones de respuesta:</td><td>Con fecha 27/05/2023 SGR CZ6 coordinó con FFAA, GAD Parroquial, GAD Provincial, CELEC, GAD Cantonal, Gobernación y MIES para atención del evento, Directora Zonal del SGR CZ6 realizó asesoría en AT y levantamiento de información de familias en AT, DGR Cuenca realiza monitoreo constante al evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/Cuerpo de Bomberos de Cuenca/DGR Cuenca.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 15 de 25

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/7b8e431c04d99b2acb83fb37ac57fe348139abad75d5b66e727234bfb4795e6a.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Morona Santiago/Limón Indanza/San Antonio (cabecera en San Antonio Centro)/San Salvador, Mayapis, Tserembo, El Cisne, 12 de Febrero</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas durante el 17/04/2023, se produjo un deslizamiento que provocó varias afectaciones y la obstaculización total de la vía de tercer orden.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se encuentra parcialmente habilitada al tránsito vehicular y peatonal, no se registra lluvias en el sector.</td></tr><tr><td>Afectaciones:</td><td>- 2 kilómetros de vía afectada- 1 puente afectado (riesgo de colapso)- 1 puente destruido- 2 bienes públicos (sistema de agua y alcantarillado vial)- 2 animales de granja muertos (ganado)- 5 bienes privados afectados (peceras)- 42 ha de vegetación afectada (40 de pasto y 2 de cultivos)- 18 familias (78 personas) afectadas directamente (pérdida de ganado y peceras)- 107 familias (535 personas) afectadas indirectamente (no pueden sacar sus productos ni ingresar</td></tr><tr><td>Acciones de respuesta:</td><td>GAD-Provincial se mantiene realizando actividades de limpieza y habilitación total de la vía. GAD-Cantonal informa que una vez habilitada la vía se procederá a realizar las reparaciones de los sistemas de agua y alcantarillado. SGR se mantiene en constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ 6 Unidad de Monitoreo Morona Santiago/GAD-Cantonal de Limón Indanza.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/65898d1ed6390305afec02961b4af845b399fee9bef6316c462b8d9c239d83c5.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Santa Isabel/Santa Isabel/La Cría</td></tr><tr><td>Antecedentes:</td><td>El 03/06/2022, Se suscitó un deslizamiento producto de la saturación del suelo originado por la combinación deficiente del riego del sector, el taponamiento de diferentes quebradas y la deficiencia del drenaje del terreno.Con fecha 31/03/2023 la SGR declaró la ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa, el cual tiene un área de 526.22 hectáreas que se extiende sobre la comunidad La Cría, cantón Santa Isabel, provincia del Azuay.El 06/04/2023 la SGR emite el cambio a ALERTA NARANJA de acuerdo al informe elaborado por Técnico de Análisis de Riesgos de la Coordinación Zonal 6 de Gestión de Riesgos.</td></tr><tr><td>Situación actual:</td><td>UGR Santa Isabel informa que al momento en el albergue se encuentran 39 familias integradas por 111 personas, ya que 1 menor de 17 años falleció en un accidente de tránsito</td></tr><tr><td>Afectaciones:</td><td>- 38 familias evacuadas.-130 personas evacuadas (albergue temporal) (Con fecha 30/05/2023 se encuentran en el albergue 39 familias 111 personas)- 3 bienes privado afectado (capilla, casa comunal, cancha central)- 1 bien público afectado- 44 familias afectadas (178 personas)- 44 familias afectadas- 8 viviendas destruidas- 8 familias damnificadas (25 personas que permanecen en casa de familias acogientes)-3 bienes privados afectados (predios)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Santa Isabel se mantiene en monitoreo constante del evento adicional brinda soporte psicológico a la familia de la menor fallecida</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/9e80beb5bea7edd5b9e279a34945f401930062e77f57243054aecce83093102b.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Cañar/Cañar/Cañar/Cuchucun-Cruz Loma-Quilloac.</td></tr><tr><td>Antecedentes:</td><td>GAD Cantonal de Cañar informó que a partir del 13 de Octubre de 2022 por la época lluviosa y mal manejo del agua de riego se reportó un deslizamiento que afecta viviendas del sector. Con fecha 14 de Febrero del 2023 se activó el COE Cantonal donde la máxima autoridad del cantón solicita la activación de las mesas técnicas y grupos de trabajo para la atención de la emergencia. Intervención del MIDUVI y GAD PROVINCIAL.Con fecha 31/03/2023 la SGR declaró la ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa, con un área de 330.56 hectáreas pertenecientes al sector Cuchucún, el cual comprende las comunidades: Quilloac, Cruz Loma y Cuchucún, del cantón Cañar, provincia de Cañar</td></tr><tr><td>Situación actual:</td><td>Con fecha 03/05/2023 personal técnico de la SGR de forma conjunta con GAD Cañar y el uso de equipos geofísicos realizaron una inspección técnica con el objetivo de caracterizar el subsuelo en función de la conductividad de las rocas debido que se trata de un movimiento complejo, complementando así el levantamiento de información realizado en días anteriores con la técnica sísmica de refracción.</td></tr><tr><td>Afectaciones:</td><td>- 22 viviendas afectadas- 4 viviendas destruidas- 6 familias damnificadas</td></tr></table>

## Secretaría de Gestión de Riesgos

<table><tr><td></td><td>- 16 personas damnificadas (permanecen en casa de familia acogiente)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR en coordinación con el GAD Cañar, realizó levantamiento de información</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/Directora SGR CZ6.</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 16 de 25

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/02a460357c4ade4fb3906cdfd6d0a7390a8e9939b8608a489d12fc1b0e9c1516.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Nabón/Nabón/Rosas, Bellavista, Tamboloma, Chunazana.</td></tr><tr><td>Antecedentes:</td><td>El 14/03/2022, se reportó un movimiento en masa provocando la filtración de agua de riego en la planta de Uzhcurrumi. El 23/11/2021 el Secretaría de Gestión de Riesgos declaró la alerta naranja por movimiento en masa de 130,94 hectáreas en el área que comprenden los barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay.</td></tr><tr><td>Situación actual:</td><td>Con fecha 09/05/2023 técnico de la UGR Nabón informa que la segunda etapa de las obras de mitigación tiene un avance del 35%. La vía Ramada-Nabón sector Trancapata continúa cerrada, vía alterna La Ramada-Chunazana-El Salado-Nabón.</td></tr><tr><td>Afectaciones:</td><td>- 50 metros de vía afectada (vía habilitada, sector El Progreso)- 84 familias afectadas (238 personas afectadas)- 60 familias damnificadas (162 personas damnificadas)- 40 metros de vía afectados (vía Cerrada, sector Trancapata)- 60 metros de vía afectados (vía parcialmente habilitada, sector Quebrada del Canal)- 1 Casa comunal afectada con cuarteaduras- 84 viviendas afectadas (las familias evacuadas se alojan en diferentes alojamientos temporales como arriendos o familias de acogida)- 59 viviendas destruidas.- Terminal terrestre con grietas en oficinas, gradas (cierre de operaciones)- Iglesia demolida por los daños estructurales presentados- Centro de salud con fisuras, en evaluación permanente por parte del MSP</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Nabón se mantiene en continuo monitoreo de la zona afectada</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/UGR Nabón</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/cbac743bc8622f6553e98286433962df1e52fb70f235b361d7203532d148d790.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Loja/Puyango/El Limo/varios sectores (3 de Noviembre, La Bocana, La Palmira).</td></tr><tr><td>Antecedentes:</td><td>Por presencia de lluvias en la tarde del viernes 28/04/2023, se produjo el desbordamiento de la quebrada del sector ocasionando daños a viviendas y vehículos que se encontraban estacionados y fueron arrastrados por el sedimento originado por dicho desbordamiento, adicional se reportó el cierre temporal de una vía de tercer orden.GAD Cantonal de Puyango se declaró en situación de emergencia el 29/04/2023 para coordinar acciones oportunas con las entidades de respuesta y poder dar una rápida atención al evento por inundación</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan habitando sus viviendas.El tramo que conduce hacia Añalcal - Caucho continúa cerrada debido al socavamiento presentado y el tramo que conduce hacia La Bocana se encuentra habilitada</td></tr><tr><td>Afectaciones:</td><td>- 20 viviendas destruidas- 29 viviendas afectadas- 18 familias damnificadas conformadas por 53 personas permanecen en casa de familia acogiente- 60 familias 300 personas afectadas.- 19 bienes privados destruidos. (10 carros arrastrados y 9 motocicletas)- 30 metros de vía afectada.- 25 hectáreas de cultivos de maíz afectados</td></tr><tr><td>Acciones de respuesta:</td><td>SGR realizó el levantamiento de información y la entrega de Asistencia Humanitaria. GAD Provincial de Loja (VIALSUR E.P.) y GAD Cantonal de Puyango continúan realizando trabajos de habilitación vial.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/GAD Cantonal Puyango.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/f927390c0919838bf9656bdb4a70965a729ceaad8912319979692e8dbdf14c1a.jpg)


## Inundación

Localización: Loja/Zapotillo/varias Parroquias (Cazaderos, Mangahurco, Bolaspamba y Paletillas).
Antecedentes: El 17/04/2023 por lluvias suscitadas en días anteriores se produjo el desbordamiento de varias quebradas: (Cazaderos, Mangahurco, El Guabo y quebrada Paletillas); causando afectaciones en viviendas, cultivos, vías, bienes privados en varias parroquias del cantón; en la Parroquia Cazaderos existe el riesgo de perder 30 mil plantas de tomate y en la Parroquia Bolaspamba existen 10 viviendas con riesgo de colapsar; así mismo COE Cantonal con fecha 17 de abril del 2023, sugirió al GAD Cantonal de Zapotillo se declare la situación de emergencia al cantón Zapotillo.
Situación actual: La familia damnificada permanecerá de manera indefinida en casa de familia acogiente Vía de segundo orden habilitada al tránsito vehicular
Afectaciones: Parroquia Cazaderos:
- 120 hectáreas de cultivo de maíz perdido 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 17 de 25

<table><tr><td></td><td>- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 1 vivienda destruida- 37 familias damnificadas conformadas por 118 integrantes- 36 familias afectadas conformadas por 94 integrantesParroquia Mangahurco:- 70 hectáreas de cultivo de maíz perdido- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 50 familias afectadas- 1 vía de segundo orden cerrada (Y de Mangahurco a Cazaderos)Parroquia Bolaspamba:-10 familias conformadas por 35 personas afectadas-1 familia damnificada conformada por 4 personas-3 viviendas afectadas (Sector El Guabo)-7 viviendas afectadas (Sector Chaquino)-1 vivienda destruida (Sector Transito Mangahurquillo)-Vía de segundo orden (habilitada)Parroquia Paletillas:- Pérdida de cultivos en fase de ciclo productivo (En fase de levantamiento de información)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Zapotillo conjuntamente con personal técnico de SGR realizó el levantamiento de información.Personal de Gobierno Provincial (VIALSUR), GAD Cantonal y moradores de la parroquia Bolaspamba, realizaron los trabajos de rehabilitación vial.SGR coordinó la atención del evento y realiza constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/UGR Zapotillo/GAD-P (VIALSUR).</td></tr></table>

## Monitoreo de estado de vías afectadas por eventos peligrosos

VÍAS DE PRIMER ORDEN: 

## 08 vías de primer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Morona Santiago</td><td>Morona</td><td>Macas</td><td>Tramo puente sobre el río Upano-puente sobre el río Copueno</td><td>INUNDACIÓN</td><td>270</td><td>15/06/2023</td><td>Sevilla - Seipa - Sucúa.</td></tr><tr><td>2</td><td>Guayas</td><td>Pedro Carbo</td><td>Sabanilla</td><td>Recinto Villao</td><td>SOCAVAMIENTO</td><td>55</td><td>11/05/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>Puerto Quito</td><td>Puerto Quito</td><td>Puente que limita entre Pichincha y Esmeraldas, Los Bancos [E28]</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>18/03/2023</td><td>Quito, Alóag - Unión del Toachi - Santo Domingo.----Puerto Quito-La Sexta - Quinindé----Calacalí-Los Bancos-Las Mercedes-Santo Domingo</td></tr><tr><td>4</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>Vía Rcto. La Estrella Rcto. La Vitalia de 1er orden - Pisagua Alto - La Constancia</td><td>SOCAVAMIENTO</td><td>--</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>Chaco</td><td>Gonzalo Díaz de Pineda</td><td>Puente sobre el río Marker, vía E45 San Luis -El Reventador</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>22/02/2023</td><td>El Reventador-Lago Agrio-El Coca-Loreto -Y de Narupa-Y de Baeza-Quito o viceversa.</td></tr><tr><td>6</td><td>Manabí</td><td>Manta</td><td>San Lorenzo</td><td>Ruta del Spondiylus San Lorenzo - Santa Rosa [E15]</td><td>OLEAJE</td><td>1200</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Alausí</td><td>Alausí, Cabecera Cantonal</td><td>Casual, vía Guamote - Alausí [E-35].</td><td>HUNDIMIENTO</td><td>1120</td><td>09/12/2022</td><td>- Vehículos livianos: Alausí - García Moreno - Guamote- Vehículos pesados: Zhud - El Triunfo - Cumandá - Pallatanga - Rióbamba</td></tr><tr><td>8</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrío [E45]</td><td>SOCAVAMIENTO</td><td>1040</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 18 de 25

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Narupa - Tena - Ambato - Quito</td></tr></table>

## 50 vías de primer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Vía Y de Narupa-Archidona [E45].</td><td>DESLIZAMIENTO</td><td>--</td><td>15/05/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Esmeraldas</td><td>Atacames</td><td>Tonchigüe</td><td>Recinto El Aguacate</td><td>SOCAVAMIENTO</td><td>--</td><td>04/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Pichincha</td><td>San Miguel de los Bancos</td><td>Mindo</td><td>pasando la Y de Mindo</td><td>DESLIZAMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 74, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>30</td><td>01/06/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Partidero, La Libertad, Baden, vía Guarumales-Méndez [E40]</td><td>DESLIZAMIENTO</td><td>190</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 96, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>40</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Sevilla de Oro</td><td>Amaluza</td><td>Sopladora, vía Paute-Guarumales-Méndez [E-40]</td><td>DESLIZAMIENTO</td><td>50</td><td>26/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Bolívar</td><td>Echeandía</td><td>Cabecera cantonal</td><td>La Dolorosa, vía Guanujo-Echeandía [E494]</td><td>DESLIZAMIENTO</td><td>300</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Vivar, km 117 vía Cuenca-Girón -Pasaje [E-59]</td><td>SOCAVAMIENTO</td><td>20</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Napo</td><td>Archidona</td><td>Hatun Sumaku</td><td>Comunidad Wamaní, vía a Loreto-Coca (Narupa) Archidona [E45].</td><td>DESLIZAMIENTO</td><td>--</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 111, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>30</td><td>22/05/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Orellana</td><td>Loreto</td><td>San Vicente de Huaticocha</td><td>Límite provincial Napo-Orellana, Pasohurco, vía Loreto - Y de Narupa [E20-E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>12/05/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>km 24, Km 26, vía Y de Narupa - Y de Baeza [E20-E45A].</td><td>DESLIZAMIENTO</td><td>250</td><td>09/05/023</td><td>Km vía parcialmente habilitada</td></tr><tr><td>14</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 90, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>El Oro</td><td>Balsas</td><td>Balsas</td><td>Km4, vía Balsas - Saracay [E-50]</td><td>DESLIZAMIENTO</td><td>15</td><td>26/04/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Bolívar</td><td>Chillanes</td><td>Chillanes</td><td>Varios sectores: a la altura de la hacienda de San Juan de Azapi, Vista Alegre, San Francisco de Azapi, vía Chillanes-Bucay [E495]</td><td>DESLIZAMIENTO</td><td>300</td><td>22/04/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 13, vía Coca - Dayuma [E45A]</td><td>DESLIZAMIENTO</td><td>--</td><td>20/04/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Loja</td><td>Célica</td><td>Sabanilla</td><td>Cabuyo, vía Redondel de la Aduana a Pindal - Troncal de la Costa [E25]</td><td>DESLIZAMIENTO</td><td>50</td><td>14/04/2023</td><td>Ninguna</td></tr><tr><td>21</td><td>Los Ríos</td><td>Montalvo</td><td>La Esmeralda</td><td>La Guayaba - río La Esmeralda</td><td>SOCAVAMIENTO</td><td>60</td><td>05/04/2023</td><td>Ninguna</td></tr><tr><td>22</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 92, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>--</td><td>05/04/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0339
Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 19 de 25


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>23</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 91, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>--</td><td>04/04/2023</td><td>Ninguna</td></tr><tr><td>24</td><td>Santo Domingo de los Tsáchilas</td><td>Santo Domingo</td><td>Abraham Calazacón</td><td>Coop. Modelo Av. Los Colonos, calle Río Verde, Junto al UPC.</td><td>INUNDACIÓN</td><td>30</td><td>01/04/2023</td><td>Ninguna</td></tr><tr><td>25</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 64, vía Cuenca-Molleturo-Naranjal [E-582</td><td>DESLIZAMIENTO</td><td>--</td><td>28/03/2023</td><td>Ninguna</td></tr><tr><td>26</td><td>Loja</td><td>Las Lajas</td><td>La Victoria</td><td>El Tigre, Vía El Tigre - Puyango [E-25]</td><td>DESLIZAMIENTO</td><td>8</td><td>26/03/2023</td><td>Ninguna</td></tr><tr><td>27</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 92-96-97-98, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>80</td><td>18/03/2023</td><td>Ninguna</td></tr><tr><td>28</td><td>Pichincha</td><td>Quito</td><td>Pifo</td><td>10 minutos Virgen de Papallacta, vía Papallacta - Baeza [E20]</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2023</td><td>Ninguna</td></tr><tr><td>29</td><td>Loja</td><td>Chaguarpamba</td><td>Santa Rufina</td><td>Salida de Santa Rufina hacía, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>30</td><td>El Oro</td><td>Arenillas</td><td>Arenillas</td><td>Vía Arenillas - Las Lajas [E25]</td><td>DESLIZAMIENTO</td><td>10</td><td>10/03/2023</td><td>Ninguna</td></tr><tr><td>31</td><td>Bolívar</td><td>San Miguel</td><td>San Miguel</td><td>El Calzado-Abs.27+800, vía San Miguel-Balzapamba [E 491]</td><td>DESLIZAMIENTO</td><td>100</td><td>23/02/2023</td><td>Ninguna</td></tr><tr><td>32</td><td>Azuay</td><td>Sevilla de Oro</td><td>Palmas</td><td>Km 61, vía Paute Guarumales Méndez [E-40]</td><td>SOCAVAMIENTO</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr><tr><td>33</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>34</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>35</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>36</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>37</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>38</td><td>Esmeraldas</td><td>Quinindé</td><td>Rosa zarate</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>HUNDIMIENTO</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>39</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Siete Ríos, El Estado y Macuchi.</td><td>INUNDACIÓN</td><td>35</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>40</td><td>Cotopaxi</td><td>Pujilí</td><td>Tingo</td><td>Negrillo Km 100, vía Latacunga - La Maná [E-30]</td><td>INUNDACIÓN</td><td>40</td><td>30/01/2022</td><td>Ninguna</td></tr><tr><td>41</td><td>Cotopaxi</td><td>Pujilí</td><td>Pilaló</td><td>Caserío Pilaló, Tinieblas, Km 94, vía Pujilí - La Mana [E30].</td><td>DESLIZAMIENTO</td><td>2000</td><td>29/01/2022</td><td>Ninguna</td></tr><tr><td>42</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tulcán - Ibarra 2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>43</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 20 de 25

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>44</td><td>Orellana</td><td>Francisco de Orellana</td><td>El Dorado</td><td>Km 21 y km 28, vía el Coca - Dayuma [E45A]</td><td>HUNDIMIENTO</td><td>150</td><td>19/06/2021</td><td>Ninguna</td></tr><tr><td>45</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>45</td><td>Esmeraldas</td><td>Esmeraldas</td><td>5 De Agosto</td><td>El Cabezón (desvío Tachina)</td><td>SOCAVAMIENTO</td><td>150</td><td>10/03/2021</td><td>Ninguna</td></tr><tr><td>46</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr><tr><td>47</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>48</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>49</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>50</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago -San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr></table>

## VÍAS DE SEGUNDO ORDEN


08 vías de segundo orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Manabí</td><td>Jama</td><td>Jama</td><td>Sitio El Colorado, vía a El Colorado Arriba vía a Convento</td><td>ALUVIÓN</td><td>--</td><td>29/03/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>Km 37, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>--</td><td>24/03/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Loja</td><td>Loja</td><td>Gualel</td><td>San Francisco, vía Gualel- Chuquiribamba.</td><td>SOCAVAMIENTO</td><td>--</td><td>15/03/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>5</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Quito</td><td>Itchimbía</td><td>Av. De los Conquistadores</td><td>DESLIZAMIENTO</td><td>--</td><td>17/06/2023</td><td>Ruta Viva y la av. Interoceánica Oswaldo Guayasamín.</td></tr><tr><td>7</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Vía Mariano Acosta</td></tr><tr><td>8</td><td>Guayas</td><td>Colimes</td><td>Colimes, Cabecera Cantonal</td><td>Av. Principal entrada de Colimes</td><td>COLAPSO ESTRUCTURAL</td><td>50130,5</td><td>23/04/2020</td><td>Palestina - San Jacinto- Colimes</td></tr></table>

## 22 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (cabecera en 9 de Octubre)</td><td>Km 76, vía Macas-Riobamba [E46]</td><td>DESLIZAMIENTO</td><td>50</td><td>16/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Morona Santiago</td><td>Limón Indanza</td><td>General Leonidas Plaza</td><td>Loma de San Vicente, vía Gualaceo-Limón</td><td>DESLIZAMIENTO</td><td>20</td><td>15/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Manabí</td><td>Santa Ana</td><td>Honorato Vázquez</td><td>Comunidad las Mercedes</td><td>DESLIZAMIENTO</td><td>1000</td><td>06/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Unión Manabita, vía Lomas del Perú, vía El Mirador, vía Maracayairo</td><td>DESLIZAMIENTO</td><td>300</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Morona</td><td>General Proaño</td><td>Kilómetro 105, vía Macas-Riobamba [E465]</td><td>DESLIZAMIENTO</td><td>15</td><td>12/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Manabí</td><td>Paján</td><td>Campuzano</td><td>Estero Ciego</td><td>HUNDIMIENTO</td><td>250</td><td>09/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Alausí</td><td>Multitud</td><td>Varios Sectores, vía Pallatanga-Cumandá [E-487].</td><td>HUNDIMIENTO</td><td>100</td><td>09/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>El Oro</td><td>Zaruma</td><td>Muluncay</td><td>Vía Zaruma - Atahualpa [E585].</td><td>DESLIZAMIENTO</td><td>8</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Imbabura</td><td>Ibarra</td><td>Caranqui</td><td>Guayaquil de Caranqui</td><td>SOCVAMIENTO</td><td>20</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>El Oro</td><td>Piñas</td><td>Piedras</td><td>El Recuerdo, vía Saracay - Piedras.</td><td>SOCAVAMIENTO</td><td>5</td><td>13/04/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Imbabura</td><td>Ibarra</td><td>Angochagua</td><td>El Cunrró, vía Ibarra - Zuleta.</td><td>ALUVIÓN</td><td>70</td><td>07/04/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0339
Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 21 de 25


<table><tr><td>12</td><td>Pichincha</td><td>Quito</td><td>El Condado</td><td>La Roldós, calle Rumihurco vía a Chicahuaico</td><td>SOCAVAMIENTO</td><td>--</td><td>19/03/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Los Ríos</td><td>Quinsaloma</td><td>Quinsaloma</td><td>Rcto. San Gabriel - Rcto. San Vicente - Rcto. Oro Verde - Río Calope</td><td>INUNDACIÓN</td><td>72</td><td>18/03/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>El Oro</td><td>Santa Rosa</td><td>Victoria</td><td>Km 18, vía Buenavista - San Juan de Cerro Azul [E-585]</td><td>ALUVION</td><td>150</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>El Oro</td><td>Atahualpa</td><td>Paccha</td><td>Km 47, vía Paccha - Pasaje [E-585]</td><td>DESLIZAMIENTO</td><td>25</td><td>06/03/2023</td><td>Ninguna</td></tr><tr><td>16</td><td>Chimborazo</td><td>Pallatanga</td><td>Pallatanga</td><td>Caserío Guapo, vía Colta -Pallatanga [E-487]</td><td>ALUVIÓN</td><td>40</td><td>21/02/2023</td><td>Riobamba - Guaranda - Babahoyo - Guayaquil</td></tr><tr><td>17</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>15</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>18</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>--</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>19</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>09/03/2022</td><td>Ninguna</td></tr><tr><td>20</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>Bellavista, vía Girón Santa Teresita</td><td>COLAPSO ESTRUCTURAL</td><td>20</td><td>06/03/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>El Oro</td><td>Zaruma</td><td>Malvas</td><td>Km 75, vía malvas - Zaruma [E-585]</td><td>DESLIZAMIENTO</td><td>20</td><td>03/03/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr></table>


VÍAS DE TERCER ORDEN:



29 vías de tercer orden cerradas


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Esmeraldas</td><td>Carlos Concha</td><td>Recinto Huele</td><td>SOCAVAMIENTO</td><td>---</td><td>16/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>Vía San José de Guayusa-Lumucha.</td><td>SOCAVAMIENTO</td><td>--</td><td>16/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Tena</td><td>Puerto Misahuallí</td><td>Sector Santa Marta, vía Puerto Misahaulí-Palmeras.</td><td>DESLIZAMIENTO</td><td>--</td><td>05/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Esmeraldas</td><td>Esmeraldas</td><td>Camarones</td><td>Recinto Santa Lucía.</td><td>HUNDIMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Santiago</td><td>Santiago de Méndez, cabecera cantonal</td><td>Singuiantza, vía Mendez-Sinquiantza.</td><td>DESLIZAMIENTO</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Chimborazo</td><td>Pallatanga</td><td>Matriz</td><td>Jiménez</td><td>COLAPSO ESTRUCTURAL.</td><td>--</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Esmeraldas</td><td>Quinindé</td><td>Cube</td><td>Tachina, sector Boca Grande.</td><td>DESLIZAMIENTO</td><td>--</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Cotopaxi</td><td>Pangua</td><td>El Corazón</td><td>Mulligua vía El Corazón - Ramón Campaña</td><td>DESLIZAMIENTO</td><td>80</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Cotopaxi</td><td>Sigchos</td><td>Las Pampas</td><td>Recinto Las Juntas.</td><td>INUNDACIÓN</td><td>300</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Cotopaxi</td><td>Pangua</td><td>Moraspungo</td><td>La Providencia Alta y Baja, vía Libertadores de Sillagua - La Providencia Alta; vía La Providencia Alta - Agua Santa; y Vía La Providencia Baja - San Francisco de Sillagua - Jesús del Gran Poder - Guapara</td><td>DESLIZAMIENTO</td><td>103</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Cotopaxi</td><td>Pangua</td><td>El Corazón</td><td>Vía San Francisco - Chaca.</td><td>SOCAVAMIENTO</td><td>150</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza, cabecera cantonal</td><td>San Luis, vía Gualaquiza- San Luis de Yantsas</td><td>ALUVIÓN.</td><td>30</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Estero Piedra</td><td>DESLIZAMIENTO</td><td>--</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Loja</td><td>Puyango</td><td>El Limo</td><td>Añalcal - Caucho</td><td>SOCAVAMIENTO</td><td>30</td><td>28/04/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Imbabura</td><td>Otavalo</td><td>Selva Alegre</td><td>San Luis, vía Selva Alegre - San Luis.</td><td>SOCAVAMIENTO</td><td>20</td><td>26/04/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 22 de 25

<table><tr><td>16</td><td>Los Ríos</td><td>Urdaneta</td><td>Ricaurte</td><td>Rcto. Barranco hacia Rcto. Salampe - río Catarama</td><td>SOCAVAMIENTO</td><td>300</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Cañar</td><td>Deleg</td><td>Deleg</td><td>Sector Camal Municipal</td><td>SOCAVAMIENTO</td><td>--</td><td>21/04/2023</td><td>Ninguna</td></tr><tr><td>18</td><td>Morona Santiago</td><td>Limón Indanza</td><td>San Antonio (cabecera en San Antonio Centro)</td><td>San Salvador, Mayapis, Serembo, El Cisne, 12 de Febrero</td><td>DESLIZAMIENTO</td><td>2000</td><td>17/04/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Cabecera Cantonal</td><td>Recinto El Tránsito</td><td>SOCAVAMIENTO</td><td>60</td><td>06/04/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Bolívar</td><td>Guaranda</td><td>San Luis de Pambil</td><td>Varios sectores; María Aurora, Rosa Elvira - vía a las Comunidades de San Luis de Pambil.</td><td>COLAPSO ESTRUCTURAL</td><td>28</td><td>24/03/2023</td><td>Ninguna</td></tr><tr><td>21</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>La Valdivia - río Clementina</td><td>INUNDACIÓN</td><td>30</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>22</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>La Estrella - Cdla. Felipe Abud - río Cristal</td><td>SOCAVAMIENTO</td><td>800</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>23</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur</td><td>INUNDACIÓN</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>27</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants-Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>28</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>29</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>955.9</td><td>20/01/2021</td><td>Ninguna</td></tr></table>

## 13 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Esmeraldas</td><td>Carlos Concha</td><td>Recinto Huele</td><td>SOCAVAMIENTO</td><td>--</td><td>16/06/2023</td><td>Ninguna</td></tr><tr><td></td><td>Esmeraldas</td><td>Quinindé</td><td>La Unión</td><td>San Vicente de Mache, vía playa del Muerto.</td><td>SOCAVAMIENTO</td><td>--</td><td>13/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Esmeraldas</td><td>Eloy Alfaro</td><td>Borbón</td><td>vía San Pedro - Anchayacu</td><td>DESLIZAMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Esmeraldas</td><td>Muisne</td><td>Galera</td><td>Estero de Plátano.</td><td>DESLIZAMIENTO</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Chilcaplaya</td><td>SOCAVAMIENTO</td><td>--</td><td>24/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Carchi</td><td>Tulcán</td><td>González Suárez</td><td>Ciudadela Padre Carlos de la Vega, calle Manuel Machado y Adolfo Becker.</td><td>DESLIZAMIENTO</td><td>20</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Valle del Sade</td><td>HUNDIMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Esmeraldas</td><td>Quinindé</td><td>La Unión</td><td>El Tambo</td><td>HUNDIMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Imbabura</td><td>Cotacachi</td><td>Peñaherrera</td><td>Villa flora</td><td>HUNDIMIENTO</td><td>30</td><td>05/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>El Oro/Piñas</td><td>Moromoro</td><td>El Palto</td><td>Via El Palto - La Libertad</td><td>SOCAVAMIENTO</td><td>8</td><td>04/05/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Cotopaxi</td><td>Pangua</td><td>Ramón Campaña La Estrella</td><td>Miligua, vía Ramón Campaña - El Corazón</td><td>DESLIZAMIENTO</td><td>50</td><td>12/03/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>12</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>

## 4. Declaratorias emitidas por el SGR (vigentes en orden cronológico)

<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td rowspan="2"><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/c7bcc6afbade27ee497c1c13b55b93ed0fd7faa3b68064752145e9de96a47a6c.jpg"/></td><td rowspan="2">Declaratoria de ALERTA AMARILLA Movimientos en masa en La Vainilla y La LagunaParroquia: Honorato Vásquez, Cantón: Santa Ana, Provincia: Manabí.</td><td>Amarilla</td><td>23/05/2023</td><td>Resolución No. SGR-169-2023</td></tr><tr><td>Amarilla</td><td>15/05/2023</td><td>Resolución No. SGR-156-2023</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 23 de 25

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/3125d6d27fba5e78d998d99edb68428bee2af3f3e4a51edb3ae5a0b8cb56b14a.jpg)


Declaratoria de ALERTA AMARILLA Fenómeno El Niño: Oscilación del Sur (ENOS), en los territorios ubicados a una altitud igual y menor a 1500 msnm, que comprende 17 provincias, 143 cantones, y 489 parroquias 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/f0c7e6ff1477ebf30ce24fcab0feb6b788a3f8cf450c7665b32a5b89806deef9.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/985777b8abd54a5a4421da61da809a6a1df8b413877ea3953484d157a93a8a58.jpg)


Declaratoria de ALERTA AMARILLA Fenómeno El Niño: Oscilación del Sur (ENOS), en los territorios ubicados a una altitud igual y menor a 1500 msnm, que comprende 17 provincias, 143 cantones, y 489 parroquias 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/5c3633338773ce5f8470ee1218b8b8512e3d7c1c2db258831fc8756bb7d2e8ae.jpg)


Declaratoria de Cambio de ALERTA AMARILLA por movimientos en masa al área de 11,50 hectáreas en el sector Astillero, de la parroquia Bahía de Caráquez, cantón Sucre, provincia de Manabí; considerando que las condiciones y parámetros indican que puede presentarse un evento que produzca afectaciones en la población e infraestructura. 

Declaratoria de Cambio de ALERTA AMARILLA a NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/b109e0a7abd2a442b6af1149c144b969974f8428dfff0d77f7ac98fd90c60067.jpg)


Declaratoria del estado de ALERTA NARANJA por movimientos en masa al área de 152,22 hectáreas que comprende los sectores: Namza Chico, Pasán, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chachán, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/89df199284c86c7ae127de1b4fc76105e27f6d15ce6419dc6255d73054d76862.jpg)


Declaratoria del estado de ALERTA NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa el cual tiene un área de 442.62 hectáreas que se extiende sobre la comunidad La Cría - Cantón: Santa Isabel, Provincia: Azuay. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/f29b3fc2b273dbfed3445f5d284642ff4e248f930a8978226ab8e95ea19ca86f.jpg)


Declaratoria del estado de ALERTA NARANJA por movimientos en masa, el área de influencia equivalente a 53132.993 m², ubicada en la ciudadela El Fátima, parroquia Francisco Pacheco, del cantón Portoviejo, Provincia de Manabí, debido a que la materialización del evento peligroso por movimientos en masa es inminente, lo que afectaría a la población. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/c891960952ae1a81a38611739ae5eda5f64cc48d9d71e823c3ed8fc878b57151.jpg)


Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa con un área de 330.56 hectáreas pertenecientes al sector Cuchucún, el cual comprende las comunidades: Quilloac, Cruz Loma y Cuchucún. Cantón: Cañar, Provincia: Cañar. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/71df135bad638435f88579d18f7e8d4c07e8be33fa9da27f865d09161259af10.jpg)


Incremento Actividad Volcánica Cotopaxi 

<table><tr><td></td><td></td><td></td></tr><tr><td>Amarilla</td><td>15/05/2023</td><td>Resolución No. SGR-156-2023</td></tr><tr><td>Amarilla</td><td>10/04/2023</td><td>Resolución No. SGR-110-2023</td></tr><tr><td>Naranja</td><td>10/04/2023</td><td>Resolución No. SGR-111-2023</td></tr><tr><td>Naranja</td><td>09/04/2023</td><td>Resolución No. SGR 106-023</td></tr><tr><td>Naranja</td><td>06/04/2023</td><td>Resolución No. SGR-104-2023</td></tr><tr><td>Naranja</td><td>03/04/2023</td><td>Resolución No. SGR-099-2023</td></tr><tr><td>Amarilla</td><td>31/03/2023</td><td>Resolución No. SGR-091-2023</td></tr><tr><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SGR-0311-2022</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/da13d55851f8dda7140e7004dfab6abc8f88554374e9484af285eb52ece93216.jpg)


## Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 24 de 25

<table><tr><td>Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo.</td><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SGR-182-2022</td></tr><tr><td>Movimiento en masa barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SGR-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes -Cantón: El Chaco, Provincia: Napo.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SGR-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SGR-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquias Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SGR-140-2019</td></tr><tr><td>Incendios Forestales Imbabura, Carchi, Pichincha, Chimborazo, Guayas, El Oro y Loja</td><td>Amarilla</td><td>19/09/2019</td><td>Resolución No. SGR-111-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SGR-066-2019</td></tr><tr><td>Fenómeno El Niño (ENOS) Provincias del Litoral e Insular</td><td>Amarilla</td><td>10/01/2019</td><td>Resolución No. SGR-005-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Incremento Actividad Volcánica del Sierra Negra, Galápagos</td><td>Amarilla</td><td>16/01/2018</td><td>Resolución No. SGR-009-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="2">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td colspan="2">Inundaciones Babahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/52174fe451c954c720a9d41f4105667b76e5ceda31892ed3d8ad02d5bfdb6fde.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/b70778ab7b87a6a52ea76ef878100547325972e42cae776f4522ac32549f5880.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/b9aab7c3bbbd7fb47a274c1fdd7b25e57f3fb4238abfb0ff4ebde715e4156b51.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/494d1e2d01906aec4835f49657707334723ac24744b748bab43e72ae1ca0d971.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/b1bafe102275a73d4250fbc8afb98baa0817d0c401b023f085832f4c53719cc1.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/c5ab631faf6ad1e5bb9836ff5ec96567b97f1e13eee8ee5cbd897c20eb31bd48.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/096cde1842b9f2da8d5be1b972d5689873298dc4752b2c89b2e07303f912bbeb.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/8e6d6b9ad23dd96b63d2e3948e2263697b002313ea3c3265c3d444337032b560.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/ca89e67a17084d1b3af502c5b60518fa92265f85ef8eaa30796dcc1888fddf8e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/f50dc91e6fb709c16474f857042af4261a881087077ea1921cf88cedd824714c.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/1c62de14afde5b6201439189431125a163cb4f8d732469512b0c25d051303a1f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/f34cb805b53d4c8d4aa6456ec59f4a124f4461dd03f860fd8df2bb04cbb48fd4.jpg)


## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0339 Fecha y Hora de actualización: lunes, 19 de junio de 2023 - 20:44:01 / Página 25 de 25

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/98d0da78-e545-4fda-967e-3ba35e951394/a6deebb17cd18a8dd2da759069ecc6cf7c614d357693edb8f193bbad841c26f9.jpg)


Hundimiento, 

Zaruma, El Oro 

07/03/2017 

Resolución No. Sz|GR-029-2015 

Elaborado por: Juan Suquilanda/Fernando Saltos - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón.
Revisado por: -- Analista Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón.
Enviado por: -Fernando Saltos - Operador Nacional de Turno 24/7 - Sala de Situación y Monitoreo Samborondón. 