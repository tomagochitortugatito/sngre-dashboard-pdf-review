# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 1 de 23

Periodo de Monitoreo: 

Desde: 21H00 26/06/2023 

Hasta: 09h00 27/06/2023 

## Monitoreo de amenazas naturales y antrópicas

- Amenaza en desarrollo, posible desencadenamiento de eventos peligrosos. 

- Amenaza en incremento y probable materialización inminente. 

- Amenaza dentro de los parámetros normales. 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/f3cb1eca5596b8123ac2cecf47cccc9907f07657d76bede430d9fe9e5e09addc.jpg)


## PELIGRO VOLCÁNICO

<table><tr><td colspan="2">Ubicación</td><td>Nivel de alerta declarada</td><td>Situación actual</td><td>Valoración actual</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/9b51610c0b155a8ede895c10c3ccb9d4a67abc9dd988e04a12298a69d78f612a.jpg"/></td><td>Volcán Reventador, Napo</td><td>NARANJA</td><td>06:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/97ce2e00e2bb72213bebaeaab43f1527fe14d50dbabd35b6e74bd0d2692305b4.jpg"/></td><td>Volcán Chiles-Cerro Negro, Carchi</td><td>AMARILLA</td><td>06:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c266e67d282aa7f6f5a87895c24d186d49b6ef5178c8a368b8af9d9c88756c55.jpg"/></td><td>Volcán Cotopaxi</td><td>AMARILLA</td><td>06:00 Mediante cámaras se visualiza el volcán nublado, sin novedad.</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/cfce42a534b53b726b1174454f30ab01da5b47288dee920edb548eb0a2d08d7f.jpg"/></td><td>Volcán Sierra Negra, Galápagos</td><td>AMARILLA</td><td>07:00 Sin reporte de actividad superficial</td><td>VERDE</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/17e2cc3368c4bf788d875ed970196f39695e1ff38826c04b6c01d05e3a453274.jpg"/></td><td>Volcán Sangay, Morona Santiago</td><td>AMARILLA</td><td>06:00 Mediante cámaras se visualiza el volcán nublado, sin novedad</td><td>VERDE</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/d71109c51e959c574dee2867f089adba9f12115af17df615b286be6217fdfec9.jpg)


## PELIGRO POR INCREMENTO DE CAUDALES DE RÍOS

<table><tr><td colspan="5">01 Cuerpo de Agua Desbordado</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del Río</td></tr><tr><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Sector Puente sobre el río Upano</td><td>Upano</td></tr><tr><td colspan="5">00 Cuerpos de Agua con tendencia a aumentar de nivel</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Nombre del Río</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/a54add982157ca1d6fbc63e58e4292e3322a7a535a6cf615b196e1cb7b7215f4.jpg)


## PELIGRO POR PRESENCIA DE INCENDIOS FORESTALES

<table><tr><td colspan="5">00 incendios activos</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr><tr><td colspan="5">00 incendios controlados</td></tr><tr><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector</td><td>Afectación (Ha)</td></tr><tr><td>--</td><td>--</td><td>--</td><td>--</td><td>--</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/d651104fd765b8299f72ce1919ba9bd43b09bd13780381a19e587e087a27baab.jpg)


## PELIGRO POR APERTURA Y/O COLAPSO DE PRESAS Y REPRESAS

<table><tr><td>Recurso</td><td>Cota mínima</td><td>Cota Actual</td><td>Cota máxima</td><td>Hora de corte</td><td>Valoración</td></tr><tr><td>Molino, Azuay</td><td>1970.00</td><td>---</td><td>1990.50</td><td>---</td><td></td></tr><tr><td>Mazar, Azuay</td><td>2138.05</td><td>---</td><td>2153.45</td><td>---</td><td></td></tr><tr><td>Daule Peripa, Guayas</td><td>70.00</td><td>---</td><td>85.00</td><td>---</td><td></td></tr><tr><td>Central Baba, Los Ríos</td><td>114.00</td><td>---</td><td>117.00</td><td>---</td><td></td></tr><tr><td>Chongón, Guayas</td><td>44.50</td><td>---</td><td>---</td><td>---</td><td></td></tr><tr><td>El Azúcar, Santa Elena</td><td>40.00</td><td>---</td><td>---</td><td>---</td><td></td></tr><tr><td>San Vicente, Santa Elena</td><td>50.00</td><td>---</td><td>---</td><td>---</td><td></td></tr><tr><td>La Esperanza, Manabí</td><td>53.40</td><td>---</td><td>66.00</td><td>---</td><td></td></tr><tr><td>Poza Honda, Manabí</td><td>104.29</td><td>---</td><td>106.50</td><td>---</td><td></td></tr><tr><td>Multipropósito Chone, Manabí</td><td>48.00</td><td>---</td><td>68.50</td><td>---</td><td></td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5
Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

Instituto Nacional de Meteorología e Hidrología - INAMHI 

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/6e11d77fb1dbb0438a49c881074c301e498fd5ce1e52f14ebb390b9c81e87772.jpg)


# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 2 de 23

<table><tr><td>Agoyán, Tungurahua</td><td>1645.00</td><td>---</td><td>1651.00</td><td>---</td><td></td></tr><tr><td>Pucará-Pisayambo, Tungurahua</td><td>3541.00</td><td>---</td><td>3565.00</td><td>---</td><td></td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/43384ba9392d0167e4fa83c2faeeac0c9a00c73ea6bb41c3a17a02163c136573.jpg)


## SITUACIÓN HIDROMETEREOLÓGICA


Pronóstico por localidades
LITORAL



Pronóstico por localidades
INTERANDINA


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/5f7b7cc41af6b44c954d8e03e2f91f7d9c2410fe8951aefd75ebf3b715a9c095.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/ba6aa9379aa2ff84907f10c957bd68b2b0e1da7eb9f312d1cf27f44eda1e8f54.jpg)



Instituto Nacional de Meteorología e Hidrología - INAMHI



Pronóstico por localidades
AMAZONÍA


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/773a47b06f415f671c80fbf50710e2eed8ca1e146a20716922f6d648abdf2a4b.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/ef680a5920ba32ad29a82b386ac88ced2c8689e57d15694a0fab4e4d1fea9f8f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/50e031ee726a8dfdb987d3b5ba34eab584a358e8866e98b0afa74712d34dda3b.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/accf69308dc9ebdf22931626c4e6d48c1bd43b11697f94fa14ad65051f0e7a15.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/085e7a5f3ab78b89b292aec3ee71ff47a01cb37eb793cac56d93c2c134723bf5.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/65c2d70022bff84b071fcc68298fdf35cebee235354a330aa2ad73e94e6babc8.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/7cac83fb3223bbbc1069a5ea997711b9d5e87ac2dc08e998b267f76de9cfe356.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/48962f2ee3c5913b35fd57a88c58a52972644ab5f8452b8dea6f5304fdd70969.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c2c6ead9a272124ebd82ba6c42eb5d5dcfd253ddcbf1e510b7e851e3d1a1e5b1.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/a9a941c6415448397033bcee89dc41ef3eb202c913a6e6e879296ea8bbfeb30e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/5c942c5a51e8fd3f0d65c5076dd19f27678439252fcd9e25e68a05b91d70ee93.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/64a6030dc4319f7ce1ca7d2702acd75ffbede9dbecd3e52bf11dd2a518461600.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/f0529e2817b36d21520a88a9a8ca28d49782f61e66a63dbfb9de2d2c4902948e.jpg)



Instituto Nacional de Meteorología e Hidrología - INAMHI



Pronóstico por localidades
INSULAR


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/bcbc8c4f8cfc2d33db5138c6c6331948ba17ec4f52432d4fef09d3091ffab262.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/3739509ab372c7ccc3b637405ca5434a6768ce7bd103d3f9fb0dc9c40d4a135d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/aec8fb6f76ab43997218eb26e287a1ffd66dcd5579968f35810e8fe7fa646869.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/80e153f5360d54312e78ef54b74630848d8e02e550a704c702a92991f7f3208e.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/b4b2378f90c25f7fd1fe8384d8a13d57cef2533ed0678240eba5bf238ed87ec4.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/1eb1e3aacbca3f705793d31cae4695c33c4416fc38154b8026305aa1460ed241.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/1bb17d9c3f2e3d64337f6f652be059cee9330417251302cafbcfea7657d99e1d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/33a4c9035132310fe867f32e3e8d5330415fd96c7677c68fab902927782dc6c2.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/cb42b11e84c4074dd934520798eaaa8cef4bfe7b4448a3f6df04e85dc414ae00.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/8547e2e6c3fb28b03cd1ff490a39cb34211e08630be732282c181c892e74ffed.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/a816178d3592564de4d21f40e3c09b4c42019723a2749d15d73a9b8688cc19eb.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/02317ad4afb484bac5cfc5ba27358337ddad0cfec56c71b5516d2486f7131631.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/76f9d3d19cd51b2f18f95eb11b0ea4f1ce1cda220381b6d38ec24cf7dc55315b.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/8517c7bee2f350e29c1385d71280d9fa955c995b31c5b56d56f6da6973437152.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c67503cedd9aebdb32dc7f5ad10c2a8b9cdc1cfdf63279c36b9ac4a0b0eecea0.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/ae9b64669c08440be813c65c78417800f0ac960fbab7bfde562cbac18d6f2099.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/4c7368283114275381980aa202e01c74df8eb8a0a26e57e87a6e79739f7561a1.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/367b7d04e40abed7913131bdeab7b4f2ab1bb361940b460d541ad0d43b7d28f4.jpg)



Instituto Nacional de Meteorología e Hidrología - INAMHI


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/61058843766a9fdde70bfcc7170b5c637da5bd9821a0997177d735152bf4c594.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/3720e5456d2871e3a5a8a1d47bc13295a0c5f3c7f17c4baa6128d3a4f6e088e3.jpg)


## PELIGRO SÍSMICO

<table><tr><td>Fecha - Hora Local</td><td>Magnitud</td><td>Profundidad</td><td>Cercano a</td><td>Sentido por la población</td></tr><tr><td>---</td><td>---</td><td>---</td><td>---</td><td>---</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

<table><tr><td>Localización:</td><td>Esmeraldas</td></tr><tr><td>Antecedentes:</td><td>Por fuertes lluvias suscitadas la noche del 03 y la madrugada del 04/06/2023, se produjo el desbordamiento de varios ríos que provocaron inundaciones en 6 cantones de la provincia.En Esmeraldas, desbordamiento de los ríos Tabiazo y Teaone, provocaron las inundaciones en las parroquias Tabiazo, Simón Plata Torres, 05 de Agosto, Vuelta Larga y Esmeraldas;En Atacames, se desbordaron los ríos Súa, Tonchigüe y La Unión, suscitándose inundaciones en varios sectores. El servicio de agua potable fue suspendido debido a fallas en la planta de captación.En Muisne, los ríos Canuto, Matambal y Sucio se desbordaron; las parroquias Muisne y San Gregorio presentaron inundaciones.En Quinindé, parroquias Cube y Viche se suscitaron inundaciones, por el desbordamiento de los ríos Cube, Viche y Blanco.</td></tr><tr><td>Situación actual:</td><td>Los ríos se encuentran con su caudal normal.1717 personas de 488 familias afectadas por la inundación se encuentran albergadas en alojamientos temporales.Existen 7 alojamientos temporales activos y 1 desactivado.El COE Provincial, MTTP, GTP; COE Cantonal Esmeraldas, Atacames, Muisne y Quinindé con las MTTC se encuentran activos.Se encuentran activos los siguientes alojamientos temporales:Esmeraldas: U. E Alfonso Quiñonez (308 personas), U. E Camilo Borja (317 personas), U. E Vicente Cueva (424 personas), U. E León Febres Cordero (171 personas), U. E Edilfo Benett (177 personas) y U. E Fausto Molina (130 personas), U.E. 10 de Septiembre (190 personas), U.E. Tabiazo (0).La vía de primer orden del sector El Aguacate se encuentra parcialmente habilitada.</td></tr><tr><td>Afectaciones:</td><td>Esmeraldas:- 3769 viviendas afectadas; 298 viviendas destruidas.- 10 establecimientos educativos impactados.- 41 HA de cultivos afectados.-271,5 HA de cultivo destruidos.- 100 animales muertos.- 3256 familias (13577 personas afectadas); 811 familias (2679 personas damnificadas).- 3 bienes públicos afectados.Rioverde- 14 establecimientos educativos impactados.- 281 familias (1125 personas afectadas).- 281 viviendas afectadas.- 2 Bienes públicos (1 coliseo y 1 cancha).</td></tr></table>

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 3 de 23

## Monitoreo de eventos peligrosos (emergencias y desastres)

## ZONA 1

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/acbb02c68b55d836dc2db5968badd5a992f71b2c21b856dfe7325ffaa04895d5.jpg)


## Inundación

- 1 centro de salud impactado. 

## Atacames:

- 804 familias (3242 personas afectadas); 48 familias (174 personas damnificadas) 

- 825 viviendas afectadas; 27 viviendas destruidas. 

- 239 animales afectados. 

- 62 animales muertos. 

- 45 bienes privados afectados. 

- 1 bien público afectado (subestación eléctrica). 

- 1 bien público destruido (tubería). 

- 1 vía parcialmente habilitada (20 metros lineales). 

- 9 establecimientos educativos afectados. 

- 63 ha de cultivos afectados 

## Quinindé:

-192 familias (619 personas afectadas). 

- 5 familias (20 personas afectadas). 

- 192 viviendas afectadas. 

- 5 viviendas destruidas. 

- 1 bien público afectado. 

-5 establecimientos educativos afectados. 

-2 establecimientos educativos destruidos. 

- 38 HA de cultivo afectadas. 

- 229 HA cultivo destruidas. 

## Muisne:

- 334 familias (1281 personas afectadas); 78 familias (326 personas damnificadas). 

- 334 viviendas afectadas; 85 viviendas destruidas. 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 4 de 23

-23 establecimientos educativos afectados. 

- 1 bien público destruido. 

- 74 bienes privados afectados. 

- 7 centros de salud afectados. 

- 28 bienes privados destruidos (camaroneras). 

- 802 HA cultivo afectadas. 

- 53 HA cultivo destruidas. 

- 11744 animales muertos. 

## Eloy Alfaro:

- 4 familias (15 personas afectadas.) 

- 4 viviendas afectadas 

- 1 establecimiento educativo afectado. 

## San Lorenzo:

- 1 establecimiento educativo afectado. 

Nota aclaratoria: Toda la información de cifras mostradas en el presente informe, está sujeta a variación en virtud del levantamiento continuo de información. 

## Acciones de respuesta:

MAATE continúa conjuntamente con los directivos de la Junta Administradora de Agua Potable de la Parroquia Carlos Concha, la limpieza de la captación de agua y cuarto donde se ubican los tableros electrónicos y clorificador. 

La CRE mantiene la limpieza de las clorinadoras para continuar con la elaboración de hipoclorito de sodio al 1% en las 5 máquinas clorinadoras a disposición. 

La Agencia Nacional de Regulación, Control y Vigilancia Sanitaria (ARCSA) mantiene el monitoreo de parámetros físico químico para verificar la calidad de agua y cloración de las cisternas de los 8 alojamientos temporales activos. 

El Ministerio de Salud Pública (MSP), informa que se mantienen operativos 6 hospitales básicos, 1 hospital general y 104 centros de salud, los cuales continúan brindando atención a la población. 

El MSP ha realizado 6260 atenciones en salud en los siguientes cantones afectados Quinindé (70) atenciones, Esmeraldas (4336), Atacames (1375) y Muisne (429). 

El MSP activó 11 EAIS (Equipos de Atención Integral de Salud) que realizan inspecciones, evaluaciones y búsqueda para la atención en salud en los alojamientos temporales y zonas afectadas por la emergencia. 

El MSP continúa con las actividades de control vectorial (fumigación) para la destrucción del vector “AEDES” en los alojamientos temporales y en las zonas afectadas; esta actividad es realizada con el resguardo de FF.AA. mediante requerimientos. 

en cada tramo, se ejecutan labores de construcción de alcantarillas para la reconformación de la vía, colocación de pasos laterales provisionales y trabajos para instalación de un puente Bailey. 

CNEL efectúa trabajos emergentes en los cantones Esmeraldas, Atacames y Muisne restableciendo el servicio de energía eléctrica con un total de 404 beneficiarios. 

La Secretaría de Gestión de Riesgos (SGR) en conjunto con las instituciones de la Mesa Técnica 4 dan seguimiento de los centros de acopio activados. 

La SGR solicita al MIES que se active el Bono de Contingencia para las familias damnificadas por la emergencia, conforme al levantamiento EVIN. 

El MSP abasteció con medicamentos e insumos médicos a los alojamientos temporales activos. 

MIES y CRE apoyan en la digitalización de las fichas EVIN levantadas desde el centro implementado en la Cruz Roja. 

El Ministerio de Desarrollo Urbano y Vivienda (MIDUVI) coordina el apoyo técnico para el levantamiento de información en los sectores afectados. 

El MIDUVI realizó la evaluación de viviendas de acuerdo a la metodología utilizada por la institución en la semaforización. 

FFAA continúa brindando seguridad con personal en los traslados de ayuda humanitaria a los diferentes sectores, así como también, en los centros de acopio y alojamientos temporales. 

La Policía Nacional (PPNN) se encuentra reforzando con capital humano y medios de movilización institucionales provenientes de otras zonas y subzonas, a los distritos afectados. 

## Esmeraldas:

MAATE gestionó 1 hidrocleaner de la ciudad de Quito y 4 tanqueros con EP - PETROECUADOR continúan con la limpieza de pozos sépticos sector Vuelta Larga. 

La Empresa Pública - PETROECUADOR y Cuerpo de Bomberos Esmeraldas mediante tanqueros realizaron la entrega de agua potable en la parroquia Simón Plata Torres. 

La Prefectura Esmeraldas realizó la distribución de agua mediante tanqueros en el sector 50 Casas y Tecnipetrol; además de la recolección de basura en el sector Propicia #4. 

EPMAPSE realizó la distribución de agua mediante tanqueros en los alojamientos temporales y en sectores de la zona sur de Esmeraldas. 

La SGR continúa con la entrega de asistencia humanitaria en los alojamientos temporales y en los sectores afectados por la emergencia. 

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 5 de 23

<table><tr><td></td><td>La SGR lideró la capacitación EVIN digital dirigido al personal de apoyo de Gobernación, GAD Cantonal Esmeraldas y Cuerpo de Bomberos Esmeraldas.Muisne:El MAATE gestionó un hidroclean del municipio de Quito, para realizar actividades de limpieza en el cantón Muisne.El MTOP se encuentra realizando el armado del puente Bailey junto con técnicos de otras direcciones distritales del MTOP, mismo que va ser ubicado en el sector de Bilsa y El Hojal, pertenecientes a la parroquia San Gregorio del cantón Muisne.MPCEIP y la Federación Nacional de Cooperativas Pesqueras del Ecuador (FENACOPEC) realizaron el levantamiento de información de los afectados en el cantón Muisne.La UGR GAD Cantonal Muisne continúa realizando el levantamiento de información y daños, adicional remitió varios EVINES.MPCEIP mediante la Subsecretaria de Recursos Pesqueros realizó entregas de asistencia humanitaria en el cantón Atacames, Parroquia Súa y en el cantón Muisne.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Esmeraldas/MTT Provinciales, GAD ’s Cantonales.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/228990d1c05872340e4d83a0f6d1a4406ed974cf9858cc867f44d547476d38c5.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Carchi/Tulcán/González Suárez/Ciudadela Padre Carlos de la Vega, calle Manuel Machado y Adolfo Becker.</td></tr><tr><td>Antecedentes:</td><td>El 16/05/2023, producto de las fuertes precipitaciones, se presentaron movimientos en masa en un tramo de las riveras del Río Bobo, en este sector se encuentra asentada la ciudadela Padre Carlos de la Vega; y producto de esto existen varias viviendas en riesgo las cuales presentan fisuras y grietas.La SGR realizó 2 Informes Técnicos por parte de la Unidad de Análisis de Riesgo, INFORME N°. SGR-IASR-01-2023-0029 e INFORME N°. SGR-IASR-01-2023-0032 que ha sido enviado a las autoridades del GAD C Tulcán; para que en base de sus competencias ejecuten acciones de prevención y mitigación.</td></tr><tr><td>Situación actual:</td><td>Se realizó la reunión del COE Cantonal el 05/06/2023; en donde se resuelve: 1. Recomendar al Sr. Alcalde del cantón se Declare en Emergencia, en base a los informes presentados por la SGR, EMAPA - T, UGR del GAD C Tulcán, entre otras resoluciones; y se proceda a atender la emergencia en base de las competencias y normativas vigentes. Al momento la vía de tercer orden está parcialmente habilitada</td></tr><tr><td>Afectaciones:</td><td>- 12 familias y 52 personas en riesgo.- 8 viviendas afectadas por fisuras y en riesgo de colapso.- 20 metros lineales de vía colapsada.</td></tr><tr><td>Acciones de respuesta:</td><td>El 05/06/2023 sesionó el COE Cantonal para la coordinación de acciones y la toma de decisiones.UGR del GAD Cantonal Tulcán realizó el informe técnico.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura-Carchi/UAR SGR CZ1/Gobernación de Carchi.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c79be60506840d33396ebb2a8ef1df05eb12e347b8af3a483621492ffcbb945a.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Imbabura/Pimampiro/Pimampiro/San José de Aloburo.</td></tr><tr><td>Antecedentes:</td><td>El 26/11/2021, de acuerdo al informe del SGR se indicó que el evento se suscitó en la vertiente heterogénea, donde se desencadenaron movimientos en masa a causa de filtraciones de agua y por la presencia de fuertes lluvias.Mediante resolución administrativa No. GADMSPP-A-2021 -077-R, el Sr. Alcalde resuelve declarar la situación de emergencia en el cantón Pimampiro.Se informa que el SGR CZ1, geólogos de la Prefectura, Universidad Central, Universidad Yachay y autoridades locales realizaron recorridos e inspecciones técnicas.El 16/11/2021, SGR-CZ1 entregó asistencia humanitaria. El Informe del MAG indica que la afectación de los cultivos en total es de 12,43 ha de cultivos de la zona. GAD Cantonal de Pimampiro en apoyo del GAD Provincial Imbabura trabajan en la construcción de una vía que servirá como variante para brindar acceso a la población de la comunidad, tendrá la conexión directa de las comunidades de Aloburo, San Juan, entre otras comunidades con su cabecera cantonal.</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan en los alojamientos temporales y en familias acogientes. Desde enero de 2023 se inició con la instalación de las acometidas de los servicios básicos. El MIDUVI está a la espera de que el GAD termine de hacer las acometidas para iniciar con la construcción de las viviendas; ya que dispone de los recursos económicos para este proyecto.</td></tr><tr><td>Afectaciones:</td><td>- 41 familias afectadas (113 personas),- 12 familias damnificadas (35 personas),- 38 familias evacuadas (116 personas evacuadas: 10 en la escuela del Tejar, 2 en la Unidad Educativa Pimampiro y 26 en familias acogientes),- 12 viviendas destruidas,- 6 viviendas afectadas,- 6 invernaderos destruidos de tomate riñón y pepinillo,- 5 reservorios colapsados,- 50 hectáreas de cultivos de ciclo corto, de aguacates, mandarinas, duraznos y pastizales; (12,43 ha de cultivos destruidos y 37,57 ha de pastos afectadas);</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 6 de 23

<table><tr><td></td><td>- 530 metros de los canales de riego secundarios están colapsados,- 800 metros del tendido de la red eléctrica, 3 postes colapsados y 1 transformador colapsado,- 150 metros destruidos de la red de distribución de agua de consumo humano,- 150 metros de la red de alcantarillado destruidos,- 150 metros de la red de telecomunicaciones colapsado.</td></tr><tr><td>Acciones de respuesta:</td><td>El GAD Cantonal de Pimampiro determinó un predio para la construcción del Proyecto de Vivienda, y realizó la instalación de servicios básicos.GAD Cantonal y Provincial de Imbabura habilitaron una vía alterna. La comunidad habilitó la vía a Mariano Acosta que pasa por la zona de riesgo de San José de Aloburo inobservando los informes de riesgo remitidos por parte del SGR, exponiéndose a futuros riesgos vinculados a la zona propensa de deslizamiento.Las familias afectadas continúan en los alojamientos temporales y en familias acogientes.EI 02/05/2023, MIDUVI realizó la inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ1 Unidad de Monitoreo Imbabura - Carchi/MIES, MIDUVI, GAD C Pimampiro - UGR.</td></tr></table>

## ZONA 2

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/17d7e2f3d2027bdfd3e43f5fb57aad02c2ad76a05071cdc75adaf9c4fe6741c6.jpg)


## Sismo

<table><tr><td>Localización:</td><td>Zonal 2/ Napo /45.1 km de Tena</td></tr><tr><td>Antecedentes:</td><td>Debido al sismo de MAGNITUD 5.3 con EPICENTRO a 45.1 km de Tena y PROFUNDIDAD 4 Km, se percibió de forma moderada en Archidona, Quijos, El Chaco, Tena y Arosemena Tola.Cantón Archidona/Parroquia Archidona: Una persona resultó herida debido a que el vidrio de una puerta cayó sobre la pierna de una guía en el CPL.Parroquia Cotundo: En el sector de Cocodrilos existen 3 viviendas con fisuras y en el sector de Y de Narupa existe una vivienda con fisuras.Cantón Quijos: Se observan fisuras en paredes de las instalaciones del GAD Municipal de QuijosCantón El Chaco: Moradores escucharon un ruido de desprendimiento de tierra en el sector afectado por la erosión del río Quijos.</td></tr><tr><td>Situación actual:</td><td>Según el reporte de los GAD de Quijo, no se reportan novedades relevantes</td></tr><tr><td>Afectaciones:</td><td>- 1 Persona herida.- 2 Bien público afectado (GAD Municipal Quijos, Unidad Educativa Baeza)- 4 viviendas afectadas (Fisuras)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR GAD Municipal de Archidona conjuntamente con Cuerpo de Bomberos de Archidona realizó la inspección de viviendas en el sector Cocodrilos y la Y de Narupa reportadas con afectaciones.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Unidad de Monitoreo Napo-Orellana/MDG/MTOP/CELEC EP/ECU 911 Tena.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/bfd5f81777c1b068557a8974d49c4a020def0b2a330dcec3a1b12f8d41e797c1.jpg)



Socavamiento


<table><tr><td>Localización:</td><td>Napo/El Chaco/Gonzalo Díaz De Pineda (El Bombón)/San Rafael, Piedra Fina 2, San Luis, San Carlos, vía Y de Baeza-Lago Agrio [E45].</td></tr><tr><td>Antecedentes:</td><td>Debido al proceso erosivo desarrollado desde febrero del 2020, el río Quijos (Alto Coca) mantiene en riesgo a varias viviendas y sectores estratégicos, tales como: la Red Estatal Vial [E45], Hidroeléctrica Coca Codo Sinclair, tuberías de SOTE, Poliducto Shushufindi - Quito y OCP.Se mantiene la declaratoria emitida mediante resolución SGR-058-2021 de cambiar el nivel de alerta Naranja a Roja.</td></tr><tr><td>Situación actual:</td><td>El 12/06/2023, la Comisión Ejecutora del Río Coca, CERC, informó que el frente de erosión se encuentra en la abscisa 7+560 por 91 días. Entre el km 9+000 y 10+000, el río continúa erosionando el margen y desplazando su cauce principal hacia la izquierda; además, se mantiene el avance de la erosión regresiva local en el río Loco y erosión lateral en los taludes; en el río Malo, la erosión local y su frente de erosión se mantiene sin cambios. En la zona del campamento La Loma, se aprecia degradación en el cauce central y en el margen derecho; el margen izquierdo se mantiene sin cambios y el riesgo es bajo para el campamento. Se mantienen las condiciones de inestabilidad en la zona de Ventana 2 que amenazan los terrenos del antiguo campamento de SINOHYDRO, , el sector del poblado de San Luis y las zonas ubicadas en la margen izquierda del cauce.El río Coca presentó los siguientes registros de caudales: máximo 89.4 m3/seg; mínimo 25.6 m3/seg; medio 60.0 m3/seg.San Rafael continúa sin servicio eléctrico debido a la pérdida de la vía en Piedra Fina, que imposibilita colocar los postes para la distribución del servicio.</td></tr><tr><td>Afectaciones:</td><td>Desde el 2020 a la fecha las afectaciones son las siguientes:- Personas Afectadas indirectas: 100-Personas Damnificadas: 51-Personas Afectadas: 76-Personas Evacuadas: 63-Viviendas destruidas: 2-Metros de vía afectadas: 1040</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 7 de 23

<table><tr><td></td><td>- Puentes destruidos: 4 (Puente sobre el río Montana, Marker, Ventana 2 y Puente Piedra Fina 2)- Bienes Afectados: 4 (tuberías del SOTE, Poliducto Shushufindi- Quito y OCP; Sistema de Agua Potable de San Luis)- Ha de Cultivo perdida:100.03- Animales de granja afectados y muertos: 3448</td></tr><tr><td>Acciones de respuesta:</td><td>CELEC EP En el campamento la Loma, se aprecia degradación en el cauce central y en la margen derecha; la margen izquierda se mantiene sin cambios y el riesgo es bajo para el campamento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ2 Umeva Napo-Orellana/CELEC EP/GAD Municipal El Chaco/MTOP/Teniente Político Gonzalo Díaz de Pineda</td></tr></table>

## ZONA 3

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/62bcfe96c8a857676e28d2732396394f62e07328ffb57f9d1f5272dc047a6faa.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Huigra/Las Violetas, Huigra Viejo, Barrio Azuay, Barrio Turístico, vía Huigra - El Triunfo [E-47].</td></tr><tr><td>Antecedentes:</td><td>El 28/05/2023, a causa de las lluvias registradas por la madrugada, se produjo el crecimiento del caudal del río Chanchán, el socavamiento de unas gradas y el colapso de un poste de la red eléctrica.</td></tr><tr><td>Situación actual:</td><td>Al momento las 3 familias aún se encuentran habitando con familiares acogientes , además Uprea Alausí manifiesta que el albergue temporal en la Ex Unidad Educativa Numa Pompillo Llona se encuentra activo e implementado, al existen 6 familias en el lugar.</td></tr><tr><td>Afectaciones:</td><td>- 16 familias afectadas (70 personas aproximadamente),- 16 familias (32 personas) son afectadas en cultivos y animales.- 16 viviendas afectadas aproximadamente- 4 bienes públicos destruidos (poste de la red eléctrica, puente peatonal, gradas, puente carrozable)- 3 bienes públicos afectados (muros de hormigón - piedras, cancha de vóley, plaza de feria)- 1 vía de primer orden afectado parcialmente (Tramo vial de la vía [E-47]- 1 vía de tercer orden parcialmente afectada (Barrio Turístico)- 1 bien privado afectado (Complejo la Playita)- 6 familias evacuadas (57 personas).- 6 familias en alojamiento temporal (57 personas)- 3 ha de cultivos afectados- 2 ha de cultivos destruidos- 12 animales afectados- 1000 animales muertos</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Alausí realizó la entrega de asistencia humanitaria a las familias que se encuentran con familiares de acogida.MTOP realiza trabajos en la vía de primer orden para su habilitación total.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGR GADC Alausí/GADP Huigra/Cuerpo de Bomberos de Alausí/PPNN/MSP/SGR Uprea Chimborazo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/5fee6f982a29da82a1cf9bf5b7a48577ad647cd67d3125b2bc5f647e3116d476.jpg)


## Hundimiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Multitud/ Comunidad Las Rocas, vía Pallatanga-Cumandá [E-487].</td></tr><tr><td>Antecedentes:</td><td>El 09/05/2023, por causas desconocidas se produjo un hundimiento en la vía de segundo orden, que posiblemente afecte a viviendas del sector. Además en varios sectores se evidencian grietas en el suelo.Se recomienda al Gobierno Autónomo Descentralizado Municipal del Cantón Alausí para que conjuntamente con la Junta Parroquial de Multitud y los representantes de la Comunidad Las Rocas realicen la construcción de medidas estructurales para reducir la amenaza en el sector, principalmente para disponer de un adecuado sistema de drenaje y el encausamiento de las aguas provenientes de las precipitaciones en la zona hacia la quebrada que desemboca al Río Chimbo.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía secundaria se encuentra parcialmente habilitada.Mediante informe EVIN la UGR manifiesta que el grado de precipitación en la zona sería el principal factor desencadenante para que ocurra este tipo de eventos, la geología presente, es de origen sedimentario, dicha zona se asocia con agentes externos como el agua ya que esta parroquia no cuenta con sistema de alcantarillados lo cual satura los materiales superficiales del sitio. La falta de trabajos de mitigación para evitar tanto desprendimientos como procesos de erosión, así como también la acción hidráulica que arranca y transporta las partículas de suelo por el escurrimiento en laderas y taludes, al momento 12 familias de 33 personas fueron evacuadas y se encuentran habitando con familiares acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 700 m. de vía afectada (Km 73 Vía Parcial habilitada)- 14 viviendas afectadas- 21 Familias afectadas (76 personas, de las cuales 33 fueron evacuadas)- 1 Unidad educativa afectada (Escuela Bilingüe 15 de Octubre)- 4 Bienes públicos afectados (Casa Comunal, Iglesia, Estación de Radio y Casa Pastoral)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 8 de 23

<table><tr><td>Acciones de respuesta:</td><td>UGR GAD Cantonal Alausí realizo el levantamiento del informe EVIN. UGR GAD Cantonal de Alausí, con el GADPR de Multitud y moradores de la comunidad de Las Rocas se ha procedido a la implementación de 5 extensómetros artesanales en las principales grietas. SGR realizó entrega de asistencia humanitaria y monitorea el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGR Cantonal/GAD Parroquial.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/ce0e9e7c0199c3cbba92c8a54438b54f2c0f1f1eabdfdf12552b556cd37075c7.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Chimborazo/Chunchi/Capzol/Pacucansha, Yaute, Pasaloma, Piñancay.</td></tr><tr><td>Antecedentes:</td><td>El 01/04/2023 Debido a al mal manejo de recursos hídricos se produjo acumulación de agua provocando grietas en los diferentes sectores mencionados afectado vías de primer orden y vías de tercer orden que al momento se encuentran parcialmente habilitadas.Según análisis morfométrico Los sectores de Santa Rosa, Pacucansha, Yaute, Pasaloma y Piñancay, al estar localizados en un antiguo deslizamiento donde se evidenció que el material presenta desplazamiento lento. Al momento las vías de primer y tercer orden se encuentran parcialmente habilitadas.</td></tr><tr><td>Situación actual:</td><td>Mediante resolución El 21/06/2023 respecto al evento el COE Provincial resolvió:6. El Gad de Chunchi hará llegar a la presidencia del COE provincial, el pedido de necesidad de actuación del equipo de mantenimiento, con el detalle exacto del riesgo y locaciones específicas para coordinar con el MTOP y la Prefectura para la atención en la zona.7. Se recomienda al GAD de Chunchi la instalación de sistemas de alerta temprana acompañada de simulacros con la población que se puede encontrar en riesgo, en coordinación con el Ecu 911 y SGR.8. Elevar al COE Nacional la situación del riesgo vial que se presentan en las vías Balbanera, Pallatanga, Cumandá (E-487), Guamote - Chunchi (E35) y Huigra - El triunfo (E47) y que no han sido atendidos por el MTOP en comunicaciones de resoluciones anteriores de este COE Provincial.</td></tr><tr><td>Afectaciones:</td><td>- Vías de primer y tercer orden (por cuantificar).- Cultivos afectados (por cuantificar)- 120 personas evacuadas (28 familias).</td></tr><tr><td>Acciones de respuesta:</td><td>COE Provincial mantuvo sesión extraordinaria el 21/06/2023 donde participaron las diferentes Mesas Técnicas de Trabajo para tomar las respectivas resoluciones. Al momento se encuentra activo el alojamiento temporal Dr. Severo Espinoza.UGIAR SGR se encuentra realizando estudios geofísica en el polígono de riesgo.SGR monitorea el evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGIAR Chimborazo.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/3f8504351e0a89095206dd53aa2d46d563e21179ba1146ae8402be51ad178329.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Alausí, Cabecera Cantonal/Casual, vía Guamote - Alausí [E-35].</td></tr><tr><td>Antecedentes:</td><td>El 09/12/2022, se produjo un hundimiento en la vía de primer orden, que al momento está cerrada.El día 26/03/2023, debido al hundimiento, se produjo un deslizamiento en la E35 se bajó la montaña afectando completamente la vía de primer orden y viviendas aledañas.Mediante RESOLUCIÓN Nro. SGR-111-2023, se determina CAMBIAR EL NIVEL DE ALERTA AMARILLA A NARANJA por movimientos en masa en el área de 214 hectáreas, que comprende el sector: Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua, del cantón Alausí y RATIFICAR el estado de ALERTA AMARILLA en el área de 38,07 hectáreas, considerando la actualización del análisis y observaciones técnicas realizadas en campo.</td></tr><tr><td>Situación actual:</td><td>Mediante resolución El 21/06/2023 respecto al evento el COE Provincial resolvió:1. Llamar la atención por escrito al Director de MTOP, por su falta de concurrencia a esta reunión del COE, personalmente o con un delegado, tomando en cuenta que dicha Institución lidera la mesa técnica 3.2. Aprobar el informe de labores de búsqueda en el sector de Casual en el cantón Alausí, con sus recomendaciones para que sean ejecutadas por las Instituciones competentes. Además de levantar el PMI en el cantón Alausí y en su reemplazo mantener reuniones periódicas e informes semanales.3. Exhortar a los GADs cantonales y provincial de Chimborazo, a adaptar las directrices en sus circunscripciones territoriales para época lluviosa y Fenómeno de El niño, expedida por parte de la SGR.4. Disponer el cumplimiento a las mesas técnicas de trabajo las directrices para la época lluviosa y fenómeno El Niño expedidas por la SGR.9. Insistir a la Policía Nacional en la restricción de tránsito de vehículos mayores a 3.5 toneladas en el sector Casual las 24 horas y recomendar al GAD Alausí buscar alternativas de vías para evitar el transporte de vehículos en la zona del deslizamiento.</td></tr><tr><td>Afectaciones:</td><td>- 65 personas fallecidas- 581 personas afectadas- 44 personas heridas.- 10 personas desaparecidas.- 1034 personas damnificadas (evacuadas hacia los alojamientos temporales).</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 9 de 23

<table><tr><td></td><td>- 163 viviendas afectadas- 57 viviendas destruidas- 2 bienes privados destruidos (Asadero Don Fausto y Damada - cafetería se encuentra destruido)- 1 bien privado afectado (Hostería Pircapamba)- 1 Unidad Educativa afectada (U.E. Federico Gonzales Suarez)- 2 bienes públicos destruidos (1 Estadio y 1 coliseo).- Vías destruidas:- Primer Orden: 1,12 Km- Segundo orden: 1,20 Km- Total: 2.32 Km- 3 bienes públicos afectados (25% de red público afectado y 60 % de servicio de agua potable afectado, 20 % de servicio de alcantarillado afectado).- 6 ha de cultivos y pasto destruidos.- 20 ha de cultivos afectados.- 230 Animales afectados.- 427 metros de línea férrea destruida.</td></tr><tr><td>Acciones de respuesta:</td><td>COE Provincial mantuvo sesión extraordinaria el 21/06/2023 donde participaron las diferentes Mesas Técnicas de Trabajo para tomar las respectivas resoluciones.SGR monitorea el evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/MTOP.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/0f7ab55b420791ff5f2447ba34e1b1f94b23446790be99cd22427609f46e3a01.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Chimborazo/Alausí/Huigra/Cerro Pasan y Namza Chico.</td></tr><tr><td>Antecedentes:</td><td>De acuerdo a informe técnico de la SGR del 11 de junio del 2018 indican que debido a la litología y a la sobre saturación de material se produjo grietas en los sectores señalados por lo que la SGR declara el estado de ALERTA NARANJA el 09 de abril del 2023 debido al incremento de amenaza de movimiento de masa en Pasan y Namza Chico, además, de acuerdo a informe del INAMHI en el que se indicó que en el mes de abril se incrementarán las lluvias. La evacuación de la población se da bajo el principio de autoprotección, considerando la continuidad de las grietas y el carácter activo de movimientos en masa de 152,22 ha, que comprende los sectores de Namza Chico, Pasan, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chanchán.Mediante Resolución MINEDUC Alausí - Chunchi dispone al rector y planta docente de la Unidad Educativa Eloy Alfaro, que se suspendan las actividades pedagógicas presenciales debido a la DECLARATORIA del estado de ALERTA NARANJA.</td></tr><tr><td>Situación actual:</td><td>Al momento las 12 familias que se encontraban albergadas en el Hotel Huigra retornaron a sus viviendas y las otras 10 familias se encuentran con familiares acogientes.</td></tr><tr><td>Afectaciones:</td><td>- 117 personas evacuadas (27 familias):- Hotel Huigra: 48 personas (16 familias) (retornaron a sus viviendas)- Hotel Rosero Resort: 4 personas (1 familia) (retornaron a sus viviendas)- Familias acogientes: 65 personas (10 familias)</td></tr><tr><td>Acciones de respuesta:</td><td>Mediante apoyo interinstitucional entre SGR, IGM e IIGE realizaron mediciones en la parroquia Huigra con la finalidad de monitorear un potencial deslizamiento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ3 Unidad de Monitoreo Tungurahua/UGIAR.</td></tr></table>

## ZONA 4

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/444f583f2a3c95d4e852b510bd101373df05ca6d3309e0f9c57a5db9e0e3cf65.jpg)


<table><tr><td>Localización:</td><td>Manabí/Santa Ana/Honorato Vásquez/sectores Vainilla y La Laguna.</td></tr><tr><td>Antecedentes:</td><td>El 18/04/2023, por las lluvias suscitadas en los últimos días, se produjo el deslizamiento de una ladera afectando a varias viviendas en los sectores mencionados.Las familias afectadas permanecen en casas de familias acogientes.SGR emitió la RESOLUCIÓN Nro. SGR-169-2023 que DECLARA el estado de ALERTA AMARILLA por movimientos en masa al área de influencia de 147.52 hectáreas, que comprenden las comunidades: La Vainilla y La Laguna. UGR GAD Cantonal informa que las familias retornaron a sus respectivas viviendas. SGR CZ4 gestionó la entrega de AH a las familias afectadas por parte de Plan Internacional.</td></tr><tr><td>Situación actual:</td><td>Técnico SGR-CZ4 informa que continuarán con el estudio del suelo, ya que aún se encuentran pendientes sitios con puntos de agrietamientos sin evaluación.</td></tr><tr><td>Afectaciones:</td><td>- 21 viviendas afectadas- 25 familias afectadas (84 personas afectadas)- 2 familias evacuadas (alojamiento temporal)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR GAD Cantonal realizó la Evaluación de Daños y Análisis de Necesidades.SGR emitió la RESOLUCIÓN Nro. SGR-169-2023 que DECLARA el estado de ALERTA AMARILLASGR CZ4 gestionó la entrega de AH a las familias afectadas por parte de Plan Internacional.SGR continúa con evaluación y monitoreo del evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Manabí/UGR GAD Santa Ana/Tenencia Política.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 10 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/60e15c6ebeb7d8ba08457cbff85afb4279a57eda68fc1a77f09b219592093a33.jpg)


<table><tr><td>Localización:</td><td>Santo Domingo de Los Tsáchilas/La Concordia/La Concordia/Sector del Camal.</td></tr><tr><td>Antecedentes:</td><td>El 18/03/2023, producto de las lluvias de la madrugada se produjo el aumento del caudal del río Blanco, provocando la ruptura de la tubería principal de la planta de tratamiento de agua potable, afectando la distribución de agua en el Cantón.</td></tr><tr><td>Situación actual:</td><td>Se realizan los trabajos de reparación de la tubería principal de agua potable.La empresa de agua potable habilitó dos pozos de agua donde la ciudadanía pueda acudir a solicitar agua.Se continúa con el suministro agua a la población con tanqueros.</td></tr><tr><td>Afectaciones:</td><td>- La afectación de la distribución de agua de la planta es del 100%- 2 bienes Públicos afectados (Planta de Agua Potable y Camal Municipal).- 51 animales de granja fallecidos (cerdos, Reses).- Aproximadamente 170.000 personas afectadas indirectamente por el suministro de agua</td></tr><tr><td>Acciones de respuesta:</td><td>GAD La Concordia continúa con la entrega de agua, con tanqueros.Empresa privada realiza trabajos de reparación de la tubería principal de agua potable.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ4 Unidad de Monitoreo Santo Domingo/UGR GAD La Concordia.</td></tr></table>

## ZONA 5

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/d7ecbee5732d0e3d5e208e837e7cab8e25244181f63698b32de2862a360f106c.jpg)


<table><tr><td>Localización:</td><td>Bolívar/Caluma/ Caluma/ varios sectores, Santa Teresita, Barrio Central-San Vicente (Caluma Viejo), Pita, Charquiyacu, Unión de Pacana, Hoyo Bravo, Agua Santa, Pasagua, Cumbilli Chico - Naranjapata, Cumbilli Chico (Y) y Cumbilli Grande, Guayabal, Guamaspungo, Barrio Nueva Esperanza, Barrio San José, Barrio Hemisferio-Guamaspungo, Unión de Pacana - Plomovado, Charquiyacu - retiro de Charquiyacu, Charquiyacu - Sub centro, Guamaspungo Copales, Estero del Pescado, San Vicente de Pacana.</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en los sectores, se produjo el desbordamiento de los ríos Caluma, Escaleras, Naranja Pata, Choripungo y los Esteros S/NEl COE Cantonal el 26/05/2023, resolvió Declarar la situación de EMERGENCIA AL GOBIERNO AUTÓNOMO DESCENTRALIZADO MUNICIPAL DEL CANTÓN CALUMA, por el lapso de 60 días.El servicio eléctrico fue restablecido en el Barrio Central-San Vicente (Caluma Viejo) y en el sector de Pasagua.Se encuentra restablecido el servicio de agua potable en el sector de Pasagua.La vía de segundo orden que conduce desde Charquiyacu a Pasagua se encuentra parcialmente habilitada al tránsito vehicular, las vías de tercer orden para los sectores de Naranjapata, Cumbillí Chico (Y), Cumbillí Grande, se encuentran cerradas al tránsito vehicular y existen 37 familias aisladas del sector de Pasagua - Cumbillí Chico - Naranjapata y 17 familias en el sector Cumbillí Chico (Y) - Cumbillí Grande debido al cierre de las vías.</td></tr><tr><td>Situación actual:</td><td>UGR del GAD Caluma indica que maquinaria de la institución y moradores del sector realizan trabajos de limpieza de la vía de tercer orden desde Cumbilli Chico a Naranjapata y permanece cerrada.Además menciona que GAD Provincial realiza el encauzamiento del río Caluma para la recuperación de la vía en el barrio Hemisferio y continúan aguas arriba con trabajos de encauzamiento y limpieza del río Caluma a la altura del Barrio Santa Marianita y San Vicente.</td></tr><tr><td>Afectaciones:</td><td>- 9.260 metros lineales de vía.- 2 viviendas destruidas (1 en Pasagua; 1 en Unión de Pacana - Plomovado).- 2 familias, 8 personas damnificadas (mismas que se encuentran en hogar acogiente).- 122 viviendas afectadas por el ingreso de agua y lodo- 128 familias, 434 personas afectadas mismas que se encuentran en las mismas viviendas)- 31 bienes públicos afectados (16 alcantarillas, 5 postes, 2 canchas, 1 cementerio, 1 iglesia; 3 muro de contención; 1 mercado, 1 malecón).- 3 bienes públicos destruidos (2 muro de contención; 1 muro de gaviones).- 79 bienes privados afectados (1 tuberías del agua; 1 cerramiento; 1 iglesia; 73 locales comerciales; 3 centros turísticos).- 5 bienes privados destruidos (4 bienes de mercadería; 1 vehículo)- 5 puentes afectados- 4 puentes destruidos- 59 Ha de cultivos afectados (cacao y naranja)- 40 Ha de cultivos perdidos (cacao y naranja)- 43 animales afectados (porcinos y bovinos)- 12 animales muertos (porcinos y bovinos)- 8 productores afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Caluma y moradores del sector realizan trabajos de limpieza de la vía desde Cumbilli Chico a Naranjapata.GAD Provincial realiza trabajos de encauzamiento del río Caluma para la recuperación de la vía en el barrio Hemisferio.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 11 de 23

<table><tr><td></td><td>GAD Provincial y de la Empresa Privada contratada por el GAD Caluma continúan aguas arriba con los trabajos de encauzamiento y limpieza del río Caluma a la altura del Barrio Santa Marianita y San Vicente.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/UPREA/GAD Caluma/C.B.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/89d479ecb069c47678adfcd9bf6fa4bbb4000ba3be1f898bb115b17b682d96b4.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Echeandía/Echeandía/ varios sectores: El Malecón Alto, El Congreso, San Carlos, Santa Lucia, San Gerardo, La Esperanza Baja, Galápagos, Estero de Damas, Las Malvinas, Puruhuay, San Antonio, La Florida, Plaza Roja</td></tr><tr><td>Antecedentes:</td><td>A causa de las lluvias registradas en el sector la noche del 24 y madrugada del 25/05/2023 debido al aumento del caudal del río Soloma y río Piedras se produjo un socavamiento en las riberas de los ríos, el 25/05/2023 se activó el COE Cantonal Echeandía para coordinar acciones, el 31/05/2023, volvió a sesionar el COE Cantonal donde recomendó: Declarar en situación de Emergencia Institucional al Municipio del Cantón Echeandía debido a las fuertes precipitaciones presentado en el cantón Echeandía.</td></tr><tr><td>Situación actual:</td><td>UGR y Director de O.P. del GAD Echeandía indican que realiza trabajos de encauzamiento del río y protección de los muros en el sector de Galápagos y Santa Lucia.Además menciona que realizaron trabajos de rellenó de la vía que ingresa al puente vehicular en el sector Congreso Alto y la limpieza de la vía y cunetas en el sector la Pradera a 5 km de Camarón, misma que continúa parcialmente habilitada.Las familias continúan en hogares acogientes y arrendando.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas destruidas- 4 familias 18 personas damnificadas (se encuentran en hogares acogientes)- 10 viviendas afectadas- 16 familias 47 personas afectadas (de las cuales 2 familias 7 personas se encuentran arrendando por un mes pagado por la Empresa Privada Hnos. Viscarra y Acción Social Larry Viscarra; 3 familias 4 personas se encuentran en sus mismos predios y las 11 familias, 36 personas restantes se encuentran en hogares acogientes)- 3 puentes destruidos- 11 puentes afectados- 3 bienes privados afectados (Local comercial, La Asociación de artistas y el Centro de Artesanos 26 de Julio)- 4 bienes públicos afectados (un muro de contención de escollera 100 metros sector Malecón, captación de agua taponada, 2 alcantarillas de ármico taponadas en los sectores cruce a la Libertad y el Congreso; y La Florida)- 150 metros lineales</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial realiza trabajos de encauzamiento del río y protección de los muros en los sectores de Galápagos y Santa Lucía.Moradores y GAD Cantonal realizaron el relleno de la vía que ingresa al puente vehicular en el sector Congreso Alto y la limpieza de la vía y cunetas en el sector la Pradera a 5 km de Camarón.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/ GAD Echeandía, UPREA,</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/55ac4e90cef34a0f8a8d6d7447f0e0a09edf1316726391d0cdf20129076806f8.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Las Naves/Las Naves/varios sectores: La Playita, el Paraíso, Buenos Aires, La 40; Suquibi Viejo, El Mirador Bajo, ciudadela Elisita vía a Las Mercedes, Suquibi Nuevo, San Pedro y La Isla.</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023 a causa de las lluvias registradas en el sector, se produjo el desbordamiento del río Suquibi.Alcaldesa del GAD Las Naves informa que debido al desbordamiento del río Suquibi, resultó viviendas destruidas, afectadas por el ingreso de agua y lodo y dejó una persona fallecida en el sector La Playita debido al arrastre de la corriente.Además indica que propietarios de las viviendas afectadas realizaron trabajos de limpieza de los inmuebles.En horas de la tarde del 25/05/20023 se reunió el COE Cantonal de Las Naves para la evaluación de las afectaciones y coordinar acciones para atender el evento.</td></tr><tr><td>Situación actual:</td><td>Continúan con los trabajos de limpieza, encauzamiento y protección de muros del río Suquibi en el sector de la Playita y a la altura de Puente Caído.</td></tr><tr><td>Afectaciones:</td><td>- 1 persona fallecida (Adulto Mayor)- 5 viviendas destruidas- 5 familias, 18 personas damnificadas (de las cuales 4 familias 15 personas La Playita, 1 familia 3 personas del Paraíso, todos se encuentran en hogares acogientes por el mismo sector)- 62 viviendas afectadas (por ingreso de agua, lodo y colapso parcial)- 62 familias, 193 personas afectadas (de las cuales 1 familia 1 persona en el Paraíso, 5 familias 9 personas Buenos Aires, 17 familias 61 personas La 40, 3 familias 10 personas Suquibi Viejo, 1 familia 1 persona El Mirador Bajo, 27 familias 83 personas La Playita, 2 familias 8 personas ciudadela Elisita vía a Las Mercedes, 2 familias 7 personas Suquibi Nuevo, 3 familias 8 personas San Pedro y 1 familia 5 personas La Isla, todos se encuentran en las mismas viviendas)</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 12 de 23

<table><tr><td></td><td>- 2 puentes vehiculares afectados (1 metálico vía Las Naves-San Luis de Pambil y 1 hormigón armado vía a Selva Alegre)- 3 bienes públicos afectados (alcantarillas por taponamiento sector de Buenos Aires)- 2 bienes públicos destruido (1 alcantarilla vía a Selva Alegre, 1 muro de gaviones 300m en Buenos Aires)- 200 metros lineales de vía.- 169 ha de cultivos afectados (cacao, naranja, plátano)- 18 ha de cultivos perdidos (cacao, naranja, plátano, mencionar que algunas plantas son de vivero)- 65 productores, 260 personas afectadas- 2 Establecimientos Educativos afectados (en lo funcional)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial de Bolívar en conjunto con la del GAD Cantonal Las Naves realizan limpieza, encauzamiento y protección de muros a lo largo del río Suquibi.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/GAD Cantonal/C.B</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/90ba195f352f2b53ea0a66f710715048db652d1c922f0b3c227a527fd232256d.jpg)


## Inundación

<table><tr><td>Localización:</td><td>Bolívar/Guaranda/San Luis de Pambil/varios sectores: La Playita, La Delicia, El Faraón, Moraspungo, Barrio Los Negritos, Bosque de Oro, San Luis de Las Mercedes, Suquibi Viejo, Pisis, Las Minas.</td></tr><tr><td>Antecedentes:</td><td>El 25/05/2023 a causa de las lluvias registradas en el sector, se produjo el desbordamiento del río Suquibi, el cual destruyó el puente al ingreso de la parroquia y varias viviendas destruidas.Cuerpo de Bomberos de San Luis apoyaron a la evacuación de dos familias a hogar acogiente.El Servicio eléctrico se encuentra restablecidoEl 25/05/2023 se reunió el COE Cantonal de Guaranda en la parroquia de San Luis de Pambil para analizar las afectaciones y coordinar acciones.Se recomienda tomar la ruta alterna vía de tercer orden de San Luis de Pambil - Las NavesEl 26/05/2023, fue restablecido el líquido vital en el centro de la parroquia de San Luis de Pambil.</td></tr><tr><td>Situación actual:</td><td>Presidente del GAD Parroquial y Tenienta Política de San Luis de Pambil informan que culminaron los trabajos de la conformación de las bases para el soporte del puente bailey y la reconformación de la vía que conectará con el puente.Además mencionan que MTOP-Bolívar, GAD Parroquial y comunidad, realizan el armado de la estructura del puente bailey en el sector la Playita.Se recomienda tomar la ruta alterna de la vía de tercer orden para vehículos livianos (Las Naves, Puente Caído, La Esperanza, Suquibi Nuevo y San Luis de Pambil) y para vehículos pesados (Las Naves, Buenos Aires, La Libertad y San Luis de Pambil).El caudal del río Suquibí se encuentra normal.</td></tr><tr><td>Afectaciones:</td><td>- 4 vivienda destruidas- 4 familias, 21 personas damnificadas- 13 viviendas afectadas- 13 familias, 55 personas afectadas- 1 puente destruido vehicular- 3 puentes afectados vehicular (colapso parcial)- 1 bien privado destruido (vehículo)- 3 bienes públicos afectados(Postes)- 1 bien privado afectado (la captación y tuberías)- 330 Ha de cultivos afectados (cacao, naranja, pasto y café)- 680 Ha de cultivos perdidos (cacao, naranja, pasto y café)- 100 animales afectados (cuyes y gallinas)- 600 animales muertos (cuyes y gallinas)- 30 productores afectados.</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Provincial de Bolívar, del GAD Cantonal de Guaranda y del GAD Parroquial de San Luis de Pambil realizan trabajos de conformación del área para armar los muros de gaviones que serán el soporte del puente Bailey en el sector la Playita, mismo que será instalado en los próximos días con el fin de rehabilitar el paso vehicular. Además, realizan reconformación de la vía que conectará con el puente y dragado del río Suquibi.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/PPNN/TEPOL.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/927bbed80080c57389998df3f03554b104b6bcd6dc28d4516946db0ca9c24203.jpg)


## Inundación

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 13 de 23

<table><tr><td>Situación actual:</td><td>UGR del GAD Santa Lucia informa que el Albergue Temporal “Santa Rosa”aún continúan familias albergadas, adicional indicó que el nivel de la cota del río Daule y Pula se encuentran disminuyendo su caudal.</td></tr><tr><td>Afectaciones:</td><td>- 1024 viviendas afectadas- 1024 familias, 3944 personas afectadas (21 familias, 58 personas en el Albergue Temporal “Santa Rosa).- 4500 hectáreas de arroz afectadas- 25 instituciones educativas afectadas</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal Santa Lucía dio seguimiento al evento.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Guayas/SGR - UPREA/UGR GAD Cantonal Santa Lucia.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/585ff876d35bb1a2cb11298ba12a54f2bedead684daadc9b5767112c546ed65b.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Bolívar/Chillanes/Cabecera Cantonal/San Francisco de Azapi.</td></tr><tr><td>Antecedentes:</td><td>El 09/03/2023 a causa de las lluvias registradas en el sector, se ha producido grietas en un terreno.- Bucay y varios cambios paisajísticos del sector, lo cual evidencia el movimiento de masa activo del sector.La Escuela Ciudad de Latacunga del recinto San Francisco de Azapi se encuentra en zona de riesgo.El 05/05/2023, Personal de la SGR realizó la socialización y concientización del nivel de riesgo alto por el deslizamiento en el sector dirigido a la comunidad, Alcaldesa electa, técnicos de las UGR de los cantones de Bucay - &quot;Guayas&quot;, Cumandá - &quot;Chimborazo&quot;, Chillanes -&quot;Bolívar&quot; y Gobernación de Bolívar.</td></tr><tr><td>Situación actual:</td><td>IIGE realiza actividades de geología y de aerofotogrametría en la zona afectada.MIDUVI indica que las familias deben ser reubicadas por cuanto el suelo de casi toda la comunidad presenta hundimientos fuertes, fisuras, grietas, cuarteamientos, desplazamientos horizontales. Solicitar al GAD Municipal del Cantón Chillanes la donación de un terreno para la reubicación de estas familias.</td></tr><tr><td>Afectaciones:</td><td>- 3 viviendas afectadas- 3 familias, 15 personas afectadas (de las cuales 1 familia, 4 personas se encuentran en otra vivienda de su propiedad y las 2 familias, 11 personas se encuentran arrendando por el mismo sector en una zona segura)- 1 bien público afectado (cancha de la comunidad)- 1 bien privado afectado (capilla)</td></tr><tr><td>Acciones de respuesta:</td><td>SGR y Personal técnico del IIGE en conjunto con GAD Cantonal Chillanes realizaron toma de datos geológicos a detalle, medición de parámetros morfo métricos, colocación de mojones y toma de sus respectivas coordenadas con equipo GNSS en San Francisco de Azapi.SGR realizó la socialización y concientización del nivel de riesgo de la zona afectada.MIDUVI realizó la inspección en la zona.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ5 Unidad de Monitoreo Bolívar/SGR Unidad de Respuesta y Unidad de Monitoreo Bolívar.</td></tr></table>

## ZONA 6

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c7967ff87045e9a1337d5f5565f1ef9dd8d990cc547887bb76131033affb4a30.jpg)


<table><tr><td>Localización:</td><td>Azuay/Cuenca/Baños/La Inmaculada-Lirio.</td></tr><tr><td>Antecedentes:</td><td>El 26/05/2023, por lluvias se suscitó un aluvión que afectó 1 vivienda parcialmente (colapso parcial de una pared), adicional 4 viviendas se encuentran en la zona de riesgo.</td></tr><tr><td>Situación actual:</td><td>Con fecha 27/05/2023 la Directora Zonal de la SGR CZ6 informó que 2 familias (9 personas) 1 familia afectada y 1 familia evacuada por precaución en Alojamiento Temporal (Iglesia de la Inmaculada), adicional 25 personas evacuadas por precaución a casas de familias acogientes. Con fecha 01/06/2023 DGR Cuenca informa que 19 de las 25 personas evacuadas por precaución retornaron a sus viviendas.</td></tr><tr><td>Afectaciones:</td><td>- 1 vivienda afectada- 1 familia afectada- 3 personas afectadas, (Iglesia de la Inmaculada)- 6 personas evacuadas, (Iglesia de la Inmaculada)- 3 bienes privados afectados (galpones)</td></tr><tr><td>Acciones de respuesta:</td><td>Con fecha 27/05/2023 SGR CZ6 coordinó con FFAA, GAD Parroquial, GAD Provincial, CELEC, GAD Cantonal, Gobernación y MIES para atención del evento, Directora Zonal del SGR CZ6 realizó asesoría en AT y levantamiento de información de familias en AT, DGR Cuenca realiza monitoreo constante al evento</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar/Cuerpo de Bomberos de Cuenca/DGR Cuenca.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 14 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/af3e21b0f1cee525f4974e7a4cafe6aeb1127612a138354fe977cc72521cd947.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Morona Santiago/Limón Indanza/San Antonio (cabecera en San Antonio Centro)/San Salvador, Mayapis, Tserembo, El Cisne, 12 de Febrero</td></tr><tr><td>Antecedentes:</td><td>Por lluvias suscitadas durante el 17/04/2023, se produjo un deslizamiento que provocó varias afectaciones y la obstaculización total de la vía de tercer orden.</td></tr><tr><td>Situación actual:</td><td>Al momento la vía se encuentra parcialmente habilitada al tránsito vehicular y peatonal, no se registra lluvias en el sector.</td></tr><tr><td>Afectaciones:</td><td>- 2 kilómetros de vía afectada- 1 puente afectado (riesgo de colapso)- 1 puente destruido- 2 bienes públicos (sistema de agua y alcantarillado vial)- 2 animales de granja muertos (ganado)- 5 bienes privados afectados (peceras)- 42 ha de vegetación afectada (40 de pasto y 2 de cultivos)- 18 familias (78 personas) afectadas directamente (pérdida de ganado y peceras)- 107 familias (535 personas) afectadas indirectamente (no tienen acceso)</td></tr><tr><td>Acciones de respuesta:</td><td>GAD-Provincial se mantiene realizando actividades de limpieza y habilitación total de la vía. GAD-Cantonal informa que una vez habilitada la vía se procederá a realizar las reparaciones de los sistemas de agua y alcantarillado. SGR se mantiene en constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ 6 Unidad de Monitoreo Morona Santiago/GAD-Cantonal de Limón Indanza.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/387258087165de9c3c0335e3c4d8dd5f4ac5ac946bdcb1dcb55cd412d7087570.jpg)


## Deslizamiento

<table><tr><td>Localización:</td><td>Azuay/Santa Isabel/Santa Isabel/La Cría</td></tr><tr><td>Antecedentes:</td><td>El 03/06/2022, Se suscitó un deslizamiento producto de la saturación del suelo originado por la combinación deficiente del riego del sector, el taponamiento de diferentes quebradas y la deficiencia del drenaje del terreno.Con fecha 31/03/2023 la SGR declaró la ALERTA AMARILLA al polígono identificado como susceptible a movimientos en masa, el cual tiene un área de 526.22 hectáreas que se extiende sobre la comunidad La Cría, cantón Santa Isabel, provincia del Azuay.El 06/04/2023 la SGR emite el cambio a ALERTA NARANJA de acuerdo al informe elaborado por Técnico de Análisis de Riesgos de la Coordinación Zonal 6 de Gestión de Riesgos.</td></tr><tr><td>Situación actual:</td><td>Con fecha 20/06/2023 Técnico del MIES informa la entrega de Bonos de Contingencia a 22 familias afectadas de la comunidad La Cría.</td></tr><tr><td>Afectaciones:</td><td>- 38 familias evacuadas.-130 personas evacuadas (albergue temporal) (Con fecha 30/05/2023 se encuentran en el albergue 39 familias 111 personas)- 3 bienes privado afectado (capilla, casa comunal, cancha central)- 1 bien público afectado- 44 familias afectadas (178 personas)- 44 familias afectadas- 8 viviendas destruidas- 8 familias damnificadas (25 personas que permanecen en casa de familias acogientes)- 3 bienes privados afectados (predios)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Santa Isabel se mantiene en monitoreo constante del evento adicional brinda soporte psicológico a la familia de la menor fallecida</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ6 Unidad de Monitoreo Azuay-Cañar.</td></tr></table>

## ZONA 7

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/56134e47e97926d12bc2c248c3d64262662a585dc66667eec020f7475fb715cb.jpg)


<table><tr><td>Localización:</td><td>Loja/Puyango/El Limo/varios sectores (3 de Noviembre, La Bocana, La Palmira).</td></tr><tr><td>Antecedentes:</td><td>Por presencia de lluvias en la tarde del viernes 28/04/2023, se produjo el desbordamiento de la quebrada del sector ocasionando daños a viviendas y vehículos que se encontraban estacionados y fueron arrastrados por el sedimento originado por dicho desbordamiento, adicional se reportó el cierre temporal de una vía de tercer orden.GAD Cantonal de Puyango se declaró en situación de emergencia el 29/04/2023 para coordinar acciones oportunas con las entidades de respuesta y poder dar una rápida atención al evento por inundación</td></tr><tr><td>Situación actual:</td><td>Las familias afectadas continúan habitando sus viviendas.El tramo que conduce hacia Añalcal - Caucho continúa cerrada debido al socavamiento presentado y el tramo que conduce hacia La Bocana se encuentra habilitada</td></tr><tr><td>Afectaciones:</td><td>- 20 viviendas destruidas- 29 viviendas afectadas- 18 familias damnificadas conformadas por 53 personas permanecen en casa de familia acogiente- 60 familias 300 personas afectadas.- 19 bienes privados destruidos. (10 carros arrastrados y 9 motocicletas)- 30 metros de vía afectada.- 25 hectáreas de cultivos de maíz afectados</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 15 de 23

<table><tr><td>Acciones de respuesta:</td><td>SGR realizó el levantamiento de información y la entrega de Asistencia Humanitaria. GAD Provincial de Loja (VIALSUR E.P.) y GAD Cantonal de Puyango continúan realizando trabajos de habilitación vial.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/GAD Cantonal Puyango.</td></tr></table>

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/ea1868e9823013dfab42319e2a589ff85fb9ad910e8d4c46918c800f4805a349.jpg)


<table><tr><td>Localización:</td><td>Loja/Zapotillo/varias Parroquias (Cazaderos, Mangahurco, Bolaspamba y Paletillas).</td></tr><tr><td>Antecedentes:</td><td>El 17/04/2023 por lluvias suscitadas en días anteriores se produjo el desbordamiento de las quebradas: (Cazaderos, Mangahurco, El Guabo y Paletillas); causando afectaciones en viviendas, cultivos, vías y bienes privados en varias parroquias del cantón.En la Parroquia Cazaderos existe el riesgo de perder 30 mil plantas de tomate y en la Parroquia Bolaspamba existen 10 viviendas con riesgo de colapsar; así mismo COE Cantonal con fecha 17 de abril del 2023, sugirió al GAD Cantonal de Zapotillo se declare la situación de emergencia al cantón Zapotillo.</td></tr><tr><td>Situación actual:</td><td>La familia damnificada permanecerá de manera indefinida en casa de familia acogiente Vía de segundo orden habilitada al tránsito vehicular</td></tr><tr><td>Afectaciones:</td><td>Parroquia Cazaderos:- 120 hectáreas de cultivo de maíz perdido- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 1 vivienda destruida- 37 familias damnificadas conformadas por 118 integrantes- 36 familias afectadas conformadas por 94 integrantesParroquia Mangahurco:- 70 hectáreas de cultivo de maíz perdido- 2 bienes privados destruidos (equipos de bombeo e instalaciones de riego, en fase de levantamiento de información)- 50 familias afectadas- 1 vía de segundo orden cerrada (Y de Mangahurco a Cazaderos)Parroquia Bolaspamba:-10 familias conformadas por 35 personas afectadas-1 familia damnificada conformada por 4 personas-3 viviendas afectadas (Sector El Guabo)-7 viviendas afectadas (Sector Chaquino)-1 vivienda destruida (Sector Transito Mangahurquillo)-Vía de segundo orden (habilitada)Parroquia Paletillas:- Pérdida de cultivos en fase de ciclo productivo (En fase de levantamiento de información)</td></tr><tr><td>Acciones de respuesta:</td><td>UGR Zapotillo conjuntamente con personal técnico de SGR realizó el levantamiento de información.Personal de Gobierno Provincial (VIALSUR), GAD Cantonal y moradores de la parroquia Bolaspamba, realizaron los trabajos de rehabilitación vial.SGR coordinó la atención del evento y realiza constante monitoreo.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ7 Unidad de Monitoreo Loja - Zamora Chinchipe/UGR Zapotillo/GAD-P (VIALSUR).</td></tr></table>

## ZONA 9

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/f36107f68f188f52bf3c64758d3c6f0cf68f8fc67dfe829da0df2a5de23d22ba.jpg)


<table><tr><td>Localización:</td><td>Pichincha/Quito/Zambiza/Simón Bolívar y Calle Quito, quebrada Porotohuayco.</td></tr><tr><td>Antecedentes:</td><td>El 20/06/2023, se suscitó un deslizamiento de tierra del talud de una quebrada.</td></tr><tr><td>Situación actual:</td><td>El talud continúa deslizándose lo que pone en riesgo varias viviendas del sector, se dieron recomendaciones a los propietarios de las viviendas aledañas al deslizamiento para que evacuen inmediatamente ante cualquier novedad que ponga en riesgo sus inmuebles o agrietamiento de los mismos</td></tr><tr><td>Afectaciones:</td><td>- 40 metros de ancho del talud deslizado</td></tr><tr><td>Acciones de respuesta:</td><td>GAD Cantonal del DMQ conjuntamente con técnicos de la EPMAPS Y EPMMOP realizaron levantamiento de información y registro fotográfico mediante Drone, tomando como acciones el “Diseño y construcción del Colector de Alivio Granados, en la Parroquia Jipijapa”, el cual tiene como objetivo realizar el desvío de un porcentaje del caudal pluvial del colector Eloy Alfaro Norte, la construcción de un interceptor sanitario en túnel, que conduzca las aguas residuales de la cuenca hacia el sistema del colector Central de Iñaquito. En el año 2022, se licitó la construcción, pero por recomendación del SERCOP se declaró desierto este proceso. En agosto del presente año se reiniciará el proceso de contratación, se estima que la obra podría estar iniciando en enero de 2024, con un plazo de construcción de 12 meses.</td></tr><tr><td>Fuentes de información:</td><td>SGR CZ9 Unidad de Monitoreo Pichincha/COEM/EPMAPS/EPMMOP.</td></tr></table>

## Secretaría de Gestión de Riesgos

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 16 de 23

Monitoreo de estado de vías afectadas por eventos peligrosos 

VÍAS DE PRIMER ORDEN: 

## 13 vías de primer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Morona Santiago</td><td>Morona</td><td>Macas</td><td>Tramo puente sobre el río Upano-puente sobre el río Copueno</td><td>INUNDACIÓN</td><td>270</td><td>15/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Manabí</td><td>Flavio Alfaro</td><td>Flavio Alfaro</td><td>Puerto Alto, Las Cumbres, vía El Carmen [E38]</td><td>DESLIZAMIENTO</td><td>---</td><td>07/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Manabí</td><td>Chone</td><td>San Antonio</td><td>Horconcito, vía Chone San Vicente [E383A].</td><td>DESLIZAMIENTO</td><td>---</td><td>16/04/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Chimborazo</td><td>Alausí</td><td>Alausí</td><td>Casual y Nuevo Alausí, vía Alausí - Guamote [E-35]</td><td>DESLIZAMIENTO</td><td>---</td><td>26/03/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Loja</td><td>Loja</td><td>Sucre</td><td>Tierras Coloradas, vía antigua Loja - Catamayo</td><td>SOCAVAMIENTO</td><td>---</td><td>23/03/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Puerto Quito</td><td>Puerto Quito</td><td>Puente que limita entre Pichincha y Esmeraldas, Los Bancos [E28]</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>18/03/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>VÍA RCTO. LA ESTRELLA RCTO. LA VITALIA DE 1ER ORDEN - PISAGUA ALTO - LA CONSTANCIA</td><td>SOCAVAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Napo</td><td>Tena</td><td>Chontapunta</td><td>Comunidad 12 de Octubre, vía Chonta Punta-Los Zorros [E436].</td><td>SOCAVAMIENTO</td><td>---</td><td>02/03/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Pichincha</td><td>Mejía</td><td>Aloag</td><td>Km 54 vía Alóag- Unión del Toachi [E20]</td><td>DESLIZAMIENTO</td><td>---</td><td>24/02/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, San Luis, vía Y de Baeza-Lago Agrio [E45]</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>23/02/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>Puente sobre el río Marker, tramo de la vía San Luis - Reventador[E45]</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>22/02/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Chimborazo</td><td>Alausí</td><td>Alausí</td><td>Casual, vía Guamote - Alausí [E-35].</td><td>HUNDIMIENTO</td><td>---</td><td>09/12/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Napo</td><td>El Chaco</td><td>Gonzalo Díaz De Pineda (El Bombón)</td><td>San Rafael, Piedra Fina, San Luis, San Carlos, Vía Y de Baeza-Lago Agrio [E45]</td><td>SOCAVAMIENTO</td><td>---</td><td>02/02/2020</td><td>Lago Agrio - Coca - Y de Narupa - Tena - Ambato - Quito</td></tr></table>

## 56 vías de primer orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Atacames</td><td>Tonchigüe</td><td>vía [E15] Recinto El Aguacate</td><td>SOCAVAMIENTO</td><td>2900</td><td>04/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Azuay</td><td>santa Isabel</td><td>santa Isabel (Chaguarurco)</td><td>km 95 +340, vía Cuenca-Girón -Pasaje [E-59]</td><td>Deslizamiento</td><td>30</td><td>05/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Napo</td><td>Archidona</td><td>Cotundo</td><td>Puente de Jondachi, vía Y de Narupa - Tena[E45]</td><td>COLAPSO ESTRUTU RAL</td><td>2</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Azuay</td><td>Pucara</td><td>Pucará</td><td>km 74, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>30</td><td>01/06/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Morona Santiago</td><td>Santiago</td><td>Copal</td><td>Partidero, La Libertad, Baden, vía Guarumales-Méndez [E40]</td><td>DESLIZAMIENTO</td><td>190</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 96, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>40</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Azuay</td><td>Sevilla de Oro</td><td>Amaluza</td><td>Sopladora, vía Paute-Guarumales- Méndez [E-40]</td><td>DESLIZAMIENTO</td><td>50</td><td>26/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Bolívar</td><td>Echeandía</td><td>Cabecera cantonal</td><td>La Dolorosa, vía Guanujo-Echeandía [E494]</td><td>DESLIZAMIENTO</td><td>300</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Vivar, km 117 vía Cuenca-Girón -Pasaje [E-59]</td><td>SOCAVAMIENTO</td><td>20</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Vivar, km 117 +800 vía Cuenca-Girón - Pasaje [E-59]</td><td>SOCAVAMIENTO</td><td>15</td><td>23/05/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0355
Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 17 de 23


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>11</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 111, vía Cuenca-Girón -Pasaje [E-59]</td><td>DESLIZAMIENTO</td><td>30</td><td>22/05/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Pichincha</td><td>Mejía</td><td>Manuel cornejo Astorga (Tandapi)</td><td>Km 65, vía Alóag Unión del Toachi [E20]</td><td>DESLIZAMIENTO</td><td>8</td><td>20/05/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 90, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>40</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Cotopaxi</td><td>Pujilí</td><td>Zumbahua</td><td>Zumbahua, vía Zumbahua-Pilaló - La Maná [E-30].</td><td>DESLIZAMIENTO</td><td>10</td><td>24/04/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Bolívar</td><td>Chillanes</td><td>Chillanes</td><td>Varios sectores: a la altura de la hacienda de San Juan de Azapi, Vista Alegre, San Francisco de Azapi, vía Chillanes-Bucay [E495]</td><td>DESLIZAMIENTO</td><td>300</td><td>22/04/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Loja</td><td>Puyango</td><td>Alamor</td><td>Puente de Chirimoyo, vía a la costa [E50]</td><td>DESLIZAMIENTO</td><td>30</td><td>20/04/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Loja</td><td>Sozoranga</td><td>Sozoranga</td><td>La Cruz - Vía Sozoranga - Macará [E-69]</td><td>DESLIZAMIENTO</td><td>80</td><td>16/04/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Manabí</td><td>Flavio Alfaro</td><td>san francisco de novillo (Cab. en novillo)</td><td>Vía Flavio Alfaro-El Carmen sector Novillo a la Altura del Túnel Cañas [E38].</td><td>Hundimiento</td><td>25</td><td>16/04/2023</td><td>Ninguna</td></tr><tr><td>21</td><td>Loja</td><td>Célica</td><td>Sabanilla</td><td>Cabuyo, vía Redondel de la Aduana a Pindal - Troncal de la Costa [E25]</td><td>DESLIZAMIENTO</td><td>50</td><td>14/04/2023</td><td>Ninguna</td></tr><tr><td>22</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 91, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>60</td><td>04/04/2023</td><td>Ninguna</td></tr><tr><td>23</td><td>esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Malimpia, E20 pasando el basurero a mano derecha</td><td>Socavamiento</td><td>30</td><td>03/04/2023</td><td>Ninguna</td></tr><tr><td>24</td><td>el oro</td><td>Machala</td><td>el cambio</td><td>EL CAMBIO, VÍA MACHALA - EL GUABO [E-25]</td><td>Socavamiento</td><td>--</td><td>01/04/2023</td><td>Ninguna</td></tr><tr><td>25</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 62, 88, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>Deslizamiento</td><td>60</td><td>01/04/2023</td><td>Ninguna</td></tr><tr><td>26</td><td>Santo Domingo de los Tsáchilas</td><td>Santo Domingo</td><td>Abraham Calazacón</td><td>Coop. Modelo Av. Los Colonos, calle Río Verde, Junto al UPC.</td><td>INUNDACIÓN</td><td>30</td><td>01/04/2023</td><td>Ninguna</td></tr><tr><td>27</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 64, vía Cuenca-Molleturo-Naranjal [E-582</td><td>DESLIZAMIENTO</td><td>60</td><td>28/03/2023</td><td>Ninguna</td></tr><tr><td>28</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>km 92-96-97-98, vía Cuenca-Molleturo-Naranjal [E-582]</td><td>DESLIZAMIENTO</td><td>80</td><td>18/03/2023</td><td>Ninguna</td></tr><tr><td>29</td><td>Azuay</td><td>SANTA ISABEL</td><td>SANTA ISABEL (CHAGUARURCO)</td><td>km 56+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>Socavamiento</td><td>60</td><td>09/03/2023</td><td>Ninguna</td></tr><tr><td>30</td><td>los ríos</td><td>Montalvo</td><td>Montalvo</td><td>SANTA MARIANITA - VÍA A BALZAPAMBA</td><td>Deslizamiento</td><td>45</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>31</td><td>Morona Santiago</td><td>Limón Indanza</td><td>Yunganza (Cab. en el rosario)</td><td>Km 35, El Rosario, vía Bella Unión - Limón [E45].</td><td>Deslizamiento</td><td>30</td><td>04/03/2023</td><td>Ninguna</td></tr><tr><td>32</td><td>Bolívar</td><td>San Miguel</td><td>San Miguel</td><td>El Calzado-Abs.27+800, vía San Miguel-Balzapamba [E 491]</td><td>DESLIZAMIENTO</td><td>100</td><td>23/02/2023</td><td>Ninguna</td></tr><tr><td>33</td><td>Manabí</td><td>Manta</td><td>san Lorenzo</td><td>Ruta del Spondylus San Lorenzo - Santa Rosa [E15]</td><td>Oleaje</td><td>1200</td><td>24/01/2023</td><td>Ninguna</td></tr><tr><td>34</td><td>Cotopaxi</td><td>Pujilí</td><td>Guangaje</td><td>Desvío a Apagua Km 76, vía La Maná - Latacunga [E-30]</td><td>Deslizamiento</td><td>20</td><td>20/01/2023</td><td>Ninguna</td></tr><tr><td>35</td><td>Azuay</td><td>Sevilla de oro</td><td>palmas</td><td>km 76, Vía Paute Guarumales Méndez [E-40]</td><td>Deslizamiento</td><td>25</td><td>05/09/2022</td><td>Ninguna</td></tr><tr><td>36</td><td>Azuay</td><td>Sevilla de oro</td><td>palmas</td><td>km 61, Vía Paute Guarumales Méndez [E-40]</td><td>Socavamiento</td><td>35</td><td>30/08/2022</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0355
Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 18 de 23


<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>37</td><td>Manabí</td><td>puerto López</td><td>Salango</td><td>La Rinconada 5 Cerros, vía Puerto López - Santa Elena [E15].</td><td>Hundimiento</td><td>4</td><td>28/08/2022</td><td>Ninguna</td></tr><tr><td>38</td><td>Manabí</td><td>Sucre</td><td>Leonidas Plaza</td><td>Km 19, San Agustín-Tosagua [E-383]</td><td>SUBSIDENCIA</td><td>150</td><td>14/08/2022</td><td>Ninguna</td></tr><tr><td>39</td><td>Morona Santiago</td><td>Sucúa</td><td>Asunción</td><td>Sector paso Carreño [E45]</td><td>SOCAVAMIENTO</td><td>5</td><td>18/05/2022</td><td>Ninguna</td></tr><tr><td>40</td><td>Loja</td><td>paltas</td><td>Catacocha</td><td>La Supa</td><td>Deslizamiento</td><td>20</td><td>22/04/2022</td><td>Ninguna</td></tr><tr><td>41</td><td>Loja</td><td>célica</td><td>célica</td><td>Mullunumá, vía Célica El Empalme [E68]</td><td>Deslizamiento</td><td>20</td><td>31/03/2022</td><td>Ninguna</td></tr><tr><td>42</td><td>Loja</td><td>Loja</td><td>Yangana (Arsenio castillo)</td><td>Suro, vía Yangana-Vilcabamba[E35]</td><td>Deslizamiento</td><td>40</td><td>30/03/2022</td><td>Ninguna</td></tr><tr><td>43</td><td>Loja</td><td>calvas</td><td>Utuana</td><td>Utuana, vía Cariamanga-Macará[E69]</td><td>Deslizamiento</td><td>30</td><td>12/03/2022</td><td>Ninguna</td></tr><tr><td>44</td><td>Azuay</td><td>Girón</td><td>Girón</td><td>km 39+500, vía Cuenca-Girón-Pasaje [E-59]</td><td>HUNDIMIENTO</td><td>80</td><td>04/03/2022</td><td>Ninguna</td></tr><tr><td>45</td><td>Loja</td><td>Loja</td><td>Santiago</td><td>Santiago, vía Loja a Saraguro [E35]</td><td>Deslizamiento</td><td>20</td><td>26/02/2022</td><td>Ninguna</td></tr><tr><td>46</td><td>Pichincha</td><td>Mejia</td><td>Manuel Cornejo A.</td><td>km 38 + 600, vía Alóag - Unión del Toachi [E20]</td><td>HUNDIMIENTO</td><td>15</td><td>25/02/2022</td><td>Ninguna</td></tr><tr><td>47</td><td>Esmeraldas</td><td>Quinindé</td><td>rosa zarate (Quinindé)</td><td>Km 68 Los Vergeles, vía Esmeraldas - Quinindé [E20]</td><td>Hundimiento</td><td>40</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>48</td><td>Imbabura</td><td>Ibarra</td><td>Carolina</td><td>San Jerónimo; vía Salinas - Lita [E 10]</td><td>DESLIZAMIENTO</td><td>225</td><td>22/12/2021</td><td>1.- Ruta desde la E10 Guallupe - San Juan de Lachas (Carchi) - por la E 182 Gualchan - Chical - Maldonado - Tulcán - Ibarra 2.- Para vehículos livianos, E10 desde San Jerónimo - Buenos Aires - Cahuasqui - Tumbabiro.</td></tr><tr><td>49</td><td>Cañar</td><td>Cañar</td><td>Ingapirca</td><td>Vía El tambo - Ingapirca - Honorato Vásquez km 8+100, km 15.</td><td>DESLIZAMIENTO</td><td>100</td><td>24/11/2021</td><td>Ninguna</td></tr><tr><td>50</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Vía Macas-Puyo [E45], tramo puente sobre el río Copueno-puente sobre el río Upano</td><td>SOCAVAMIENTO</td><td>180</td><td>16/05/2021</td><td>Ninguna</td></tr><tr><td>51</td><td>Morona Santiago</td><td>Santiago</td><td>Patuca</td><td>Loma Seca vía Patuca - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>15</td><td>15/01/2020</td><td>Ninguna</td></tr><tr><td>52</td><td>Morona Santiago</td><td>Tiwintza</td><td>San José de Morona</td><td>Shaime, vía Santiago-San José de Morona [E40]</td><td>COLAPSO ESTRUCTURAL</td><td>170</td><td>13/05/2020</td><td>Ninguna</td></tr><tr><td>53</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Km 75, Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>DESLIZAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>54</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Palomino km 68, vía Santiago-San José de Morona [E40]</td><td>SOCAVAMIENTO</td><td>70</td><td>16/05/2020</td><td>Ninguna</td></tr><tr><td>55</td><td>Morona Santiago</td><td>Morona</td><td>Macas, cabecera cantonal y capital provincial</td><td>Puente sobre el río Upano, vía Macas-Puyo-[E45]</td><td>SOCAVAMIENTO</td><td>57</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>56</td><td>Morona Santiago</td><td>Tiwintza</td><td>Santiago, cabecera cantonal</td><td>Yapapas, vía Entronque a Santiago de Méndez - Santiago [E40]</td><td>SOCAVAMIENTO</td><td>50</td><td>21/08/2020</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

# Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 19 de 23

VÍAS DE SEGUNDO ORDEN 

## 18 vías de segundo orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Morona Santiago</td><td>Limón Indanza</td><td>GENERAL LEONIDAS PLAZA GUTIERREZ (LIMON)</td><td>Chacras, vía Gulaceo-Limón</td><td>DESLIZAMIENTO</td><td>60</td><td>18/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Manabí</td><td>Santa Ana</td><td>HONORATO VASQUEZ (CAB. EN VASQUEZ)</td><td>Las Mercedes</td><td>ALUVIÓN</td><td>1000</td><td>6/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Manabí</td><td>Jama</td><td>JAMA</td><td>Via a El Colorado Arriba via a Convento.</td><td>ALUVIÓN</td><td>15</td><td>29/05/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Chimborazo</td><td>Pallatanga</td><td>PALLATANGA</td><td>Jiménez, vía Jiménez - Pallatanga</td><td>SOCAVAMIENTO</td><td>--</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Esmeraldas</td><td>Quinindé</td><td>CUBE</td><td>Recinto Cube</td><td>DESLIZAMIENTO</td><td>--</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Pichincha</td><td>Mejía</td><td>UYUMBICHO</td><td>Camino hacia el Pasochoa,Barrio Laureles, Chaquibamba, Pilopata,</td><td>INUNDACIÓN</td><td>30</td><td>22/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Loja</td><td>Zapotillo</td><td>MANGAHURCO</td><td>Mangahurco - varios sectores</td><td>INUNDACIÓN</td><td>--</td><td>18/04/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Chimborazo</td><td>Pallatanga</td><td>PALLATANGA</td><td>Caserío San Francisco de Trigoloma, vía Pallatanga - Guayaquil [E-487]</td><td>SOCAVAMIENTO</td><td>--</td><td>13/04/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Cotopaxi</td><td>Pangua</td><td>MORASPUNGO</td><td>Recintos Los Laureles, Palo Blanco, Los Esteros, Nueva Santa Rosa Bajo. y La Inmaculada, Agua SantaRecintos Los Laureles, Palo Blanco, Los Esteros y Nueva Santa Rosa Bajo, La Inmaculada, Agua Santa, Punta Brava, La Piedrecita, La Envidia y Narcisa de Jesús.</td><td>INUNDACIÓN</td><td>--</td><td>17/03/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Loja</td><td>Loja</td><td>GUALEL</td><td>SAN FRANCISCO - VIA GUALEL - CHUQUIRIBAMBA</td><td>SOCAVAMIENTO</td><td>--</td><td>16/03/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Tungurahua</td><td>Ambato</td><td>LA PENINSULA</td><td>Puente de la Ciudadela Cumandá.</td><td>HUNDIMIENTO</td><td>--</td><td>15/03/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Santa Elena</td><td>Salinas</td><td>ANCONCITO</td><td>Vía al Puerto Pesquero</td><td>SOCAVAMIENTO</td><td>--</td><td>14/03/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Loja</td><td>SANTIAGO</td><td>Puente de San José</td><td>COLAPSO ESTRUCTURAL</td><td>--</td><td>20/01/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Pichincha</td><td>Quito</td><td>EL CONDADO</td><td>Via Nono Y Club de Abogados</td><td>DESLIZAMIENTO</td><td>--</td><td>19/10/2022</td><td>Ninguna</td></tr><tr><td>15</td><td>Pichincha</td><td>Mejía</td><td>TAMBILLO</td><td>Barrio la Joya</td><td>COLAPSO ESTRUCTURAL</td><td>30</td><td>17/04/2022</td><td>Ninguna</td></tr><tr><td>16</td><td>Pichincha</td><td>Quito</td><td>CONOCOTO</td><td>calles Hermano Miguel y Panzaleo, cruce de vías.</td><td>SOCAVAMIENTO</td><td>30</td><td>28/02/2022</td><td>--</td></tr><tr><td>17</td><td>Imbabura</td><td>Pimampiro</td><td>Pimampiro, Cabecera Cantonal</td><td>San José de Aloburo</td><td>DESLIZAMIENTO</td><td>500</td><td>09/11/2021</td><td>Via Narchimbuela - Pimampiro</td></tr><tr><td>18</td><td>Azuay</td><td>Nabon</td><td>Nabon</td><td>Rosas, Bellavista, Tamboloma, Chunazana.</td><td>DESLIZAMIENTO</td><td>--</td><td>14/03/2021</td><td>Corraleja-Yasudel-Susudel</td></tr></table>

## 30 vías de segundo orden parcialmente habilitadas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Pichincha</td><td>Quito</td><td>Itchimbía</td><td>Av. Simón Bolívar y Av. De los Conquistadores</td><td>HUNDIMIENTO</td><td>20</td><td>21/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Pichincha</td><td>Quito</td><td>ITCHIMBIA</td><td>Av. De los Conquistadores, ref pasando la casa del Quinde</td><td>DESLIZAMIENTO</td><td>60</td><td>17/06/2023</td><td>Ruta Viva y la Av. Interoceánica Oswaldo Guayasamín.</td></tr><tr><td>3</td><td>Morona Santiago</td><td>Morona</td><td>Alshi (Cab. En 9 De Octubre)</td><td>Km 76, vía Macas-Riobamba [E46]</td><td>DESLIZAMIENTO</td><td>50</td><td>16/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Morona Santiago</td><td>Limón Indanza</td><td>General Leonidas Plaza Gutiérrez (Limón)</td><td>Loma de San Vicente, vía Gualaceo-Limón</td><td>DESLIZAMIENTO</td><td>20</td><td>15/06/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Napo</td><td>Tena</td><td>Tena</td><td>Barrio Sagrado Corazón de Jesús, Unidad Educativa Ciudad de Tena.</td><td>SOCAVAMIENTO</td><td>---</td><td>5/06/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Morona Santiago</td><td>Limón Indanza</td><td>General Leonidas Plaza Gutiérrez (Limón)</td><td>Plan de Milagro-Tinajillas km32</td><td>DESLIZAMIENTO</td><td>---</td><td>15/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Chimborazo</td><td>Alausí</td><td>Multitud</td><td>Las Rocas, vía Pallatanga-Cumandá [E-487]</td><td>HUNDIMIENTO</td><td>100</td><td>9/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Manabí</td><td>Paján</td><td>Campozano (La Palma De Paján)</td><td>Estero Ciego</td><td>HUNDIMIENTO</td><td>250</td><td>9/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>El Oro</td><td>Zaruma</td><td>Muluncay Grande</td><td>Vía Zaruma - Atahualpa [E585].</td><td>DESLIZAMIENTO</td><td>8</td><td>27/04/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>Imbabura</td><td>Ibarra</td><td>Caranqui</td><td>Guayaquil de Caranqui, calle General Pintag</td><td>SOCAVAMIENTO</td><td>20</td><td>23/04/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 


Reporte de monitoreo de amenazas y eventos peligrosos - No 0355
Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 20 de 23


<table><tr><td>11</td><td>Chimborazo</td><td>Colta</td><td>Juan De Velasco (Pangor)</td><td>Tepeyac Bajo, vía Colta -Pallatanga [E-487]</td><td>ALUVIÓN</td><td>---</td><td>16/04/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Imbabura</td><td>Ibarra</td><td>Angochagua</td><td>El Cunro, vía Ibarra - Zuleta</td><td>COLAPSO ESTRUCTURAL</td><td>70</td><td>7/04/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Pichincha</td><td>Quito</td><td>El Condado</td><td>Santa Rosa, vía Quito hacia Nono</td><td>DESLIZAMIENTO</td><td>---</td><td>7/04/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Pichincha</td><td>Quito</td><td>Itchimbía</td><td>Velasco Ibarra y Vicente Solano NI6A</td><td>DESLIZAMIENTO</td><td>---</td><td>29/03/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Pichincha</td><td>Quito</td><td>San Juan</td><td>El Placer &amp; Ramón Pacheco</td><td>DESLIZAMIENTO</td><td>---</td><td>25/03/2023</td><td>Ninguna</td></tr><tr><td>16</td><td>Pichincha</td><td>Quito</td><td>El Condado</td><td>La Roldós, calle Rumihurco vía a Chicahuaco</td><td>SOCAVAMIENTO</td><td>---</td><td>19/03/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Bolívar</td><td>San Miguel</td><td>Bilován</td><td>vía urbana a Camino Real</td><td>DESLIZAMIENTO</td><td>---</td><td>11/03/2023</td><td>Ninguna</td></tr><tr><td>18</td><td>Chimborazo</td><td>Cumandá</td><td>Cumandá</td><td>La Soberana, vía Pallatanga - Cumandá [E-487].</td><td>SOCAVAMIENTO</td><td>100</td><td>9/03/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Pichincha</td><td>Quito</td><td>La Ferroviaria</td><td>La Clemencia, calles Joaquín Gutiérrez S14-Hermandad Ferroviaria E5</td><td>DESLIZAMIENTO</td><td>---</td><td>23/01/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Chigüinda</td><td>Sector Churuco, vía Gualaquiza-Chigüinda-Sigsig [E594].</td><td>SOCAVAMIENTO</td><td>---</td><td>6/06/2022</td><td>Ninguna</td></tr><tr><td>21</td><td>Pichincha</td><td>Quito</td><td>San Antonio</td><td>Monjas y Chaguar</td><td>COLAPSO ESTRUCTURAL</td><td>15</td><td>7/05/2022</td><td>Ninguna</td></tr><tr><td>22</td><td>Cañar</td><td>Biblián</td><td>Nazón (Cab. En Pampa De Domínguez)</td><td>San Roque</td><td>INUNDACIÓN</td><td>---</td><td>20/04/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>El Murco - Pasando la escuela Carlos Freire Larrea.</td><td>INUNDACIÓN</td><td>---</td><td>11/04/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>El Oro</td><td>Zaruma</td><td>Huertas</td><td>Huertas, Vía Huertas - Muluncay Grande [E-585]</td><td>DESLIZAMIENTO</td><td>---</td><td>4/04/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Azuay</td><td>Pucara</td><td>Pucara</td><td>km 23-Deuta, Vía Minas-Tablón-Pucará</td><td>HUNDIMIENTO</td><td>100</td><td>9/03/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Chimborazo</td><td>Guano</td><td>La Matriz</td><td>Barrios La Merced, La Dolorosa del cementerio, Magdalena, Santa Anita, Central, San Pedro, La Inmaculada, San Roque, María de Los Ángeles, Espíritu santo, La Dolorosa Centro, Balneario Los Elenes</td><td>ALUVIÓN</td><td>---</td><td>11/12/2021</td><td>Ninguna</td></tr><tr><td>27</td><td>Zamora Chinchipe</td><td>Zamora</td><td>Cumbaratza</td><td>Tunantza Alto, vía Timbara Bajo - Timbara Alto</td><td>COLAPSO ESTRUCTURAL</td><td>---</td><td>15/10/2021</td><td>Ninguna</td></tr><tr><td>28</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>15 km, vía a la Comunidad Sardinas.</td><td>SOCAVAMIENTO</td><td>80</td><td>20/07/2021</td><td>Ninguna</td></tr><tr><td>29</td><td>Chimborazo</td><td>Guano</td><td>Guanando</td><td>Km 35, vía Cahuají - Pillate - Cotaló [E-304].</td><td>DESLIZAMIENTO</td><td></td><td>28/04/2021</td><td>Riobamba - Mocha - Baños</td></tr><tr><td>30</td><td>Morona Santiago</td><td>Gualaquiza</td><td>El Rosario</td><td>El Aguacate, vía Sig-Sig-Chiguinda-Gualaquiza [E594]</td><td>DESLIZAMIENTO</td><td>---</td><td>23/09/2020</td><td>Ninguna</td></tr></table>

## VÍAS DE TERCER ORDEN:

## 28 vías de tercer orden cerradas

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Orellana</td><td>Francisco de Orellana</td><td>San José de Guayusa</td><td>Vía San José de Guayusa-Lumucha.</td><td>SOCAVAMIENTO</td><td>--</td><td>16/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Napo</td><td>Tena</td><td>Puerto Misahuallí</td><td>Sector Santa Marta, vía Puerto Misahaullí-Palmeras.</td><td>DESLIZAMIENTO</td><td>--</td><td>05/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Esmeraldas</td><td>Esmeraldas</td><td>Camarones</td><td>Recinto Santa Lucía.</td><td>HUNDIMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Morona Santiago</td><td>Santiago</td><td>Santiago de Méndez, cabecera cantonal</td><td>Singuiantza, vía Mendez-Sinquiantza.</td><td>DESLIZAMIENTO</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Chimborazo</td><td>Pallatanga</td><td>Matriz</td><td>Jiménez</td><td>COLAPSO ESTRUCTURAL.</td><td>--</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Esmeraldas</td><td>Quinindé</td><td>Cube</td><td>Tachina, sector Boca Grande.</td><td>DESLIZAMIENTO</td><td>--</td><td>27/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Cotopaxi</td><td>Pangua</td><td>El Corazón</td><td>Mulligua vía El Corazón - Ramón Campaña</td><td>DESLIZAMIENTO</td><td>80</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Cotopaxi</td><td>Sigchos</td><td>Las Pampas</td><td>Recinto Las Juntas.</td><td>INUNDACIÓN</td><td>300</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Cotopaxi</td><td>Pangua</td><td>Moraspungo</td><td>La Providencia Alta y Baja, vía Libertadores de Sillagua - La Providencia Alta; vía La Providencia Alta - Agua Santa; y Vía La Providencia Baja - San Francisco de Sillagua - Jesús del Gran Poder - Guapara</td><td>DESLIZAMIENTO</td><td>103</td><td>25/05/2023</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 21 de 23

<table><tr><td>10</td><td>Cotopaxi</td><td>Pangua</td><td>El Corazón</td><td>Vía San Francisco - Chaca.</td><td>SOCAVAMIENTO</td><td>150</td><td>25/05/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Morona Santiago</td><td>Gualaquiza</td><td>Gualaquiza, cabecera cantonal</td><td>San Luis, vía Gualaquiza- San Luis de Yantsas</td><td>ALUVIÓN.</td><td>30</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Cuenca</td><td>Molleturo</td><td>Estero Piedra</td><td>DESLIZAMIENTO</td><td>--</td><td>23/05/2023</td><td>Ninguna</td></tr><tr><td>13</td><td>Loja</td><td>Puyango</td><td>El Limo</td><td>Añalcal - Caucho</td><td>SOCAVAMIENTO</td><td>30</td><td>28/04/2023</td><td>Ninguna</td></tr><tr><td>14</td><td>Imbabura</td><td>Otavalo</td><td>Selva Alegre</td><td>San Luis, vía Selva Alegre - San Luis.</td><td>SOCAVAMIENTO</td><td>20</td><td>26/04/2023</td><td>Ninguna</td></tr><tr><td>15</td><td>Los Ríos</td><td>Urdaneta</td><td>Ricaurte</td><td>Rcto. Barranco hacia Rcto. Salampe - río Catarama</td><td>SOCAVAMIENTO</td><td>300</td><td>23/04/2023</td><td>Ninguna</td></tr><tr><td>16</td><td>Cañar</td><td>Deleg</td><td>Deleg</td><td>Sector Camal Municipal</td><td>SOCAVAMIENTO</td><td>--</td><td>21/04/2023</td><td>Ninguna</td></tr><tr><td>17</td><td>Morona Santiago</td><td>Limón Indanza</td><td>San Antonio (cabecera en San Antonio Centro)</td><td>San Salvador, Mayapis, Serembo, El Cisne, 12 de Febrero</td><td>DESLIZAMIENTO</td><td>2000</td><td>17/04/2023</td><td>Ninguna</td></tr><tr><td>18</td><td>Guayas</td><td>Alfredo Baquerizo Moreno (Juján)</td><td>Cabecera Cantonal</td><td>Recinto El Tránsito</td><td>SOCAVAMIENTO</td><td>60</td><td>06/04/2023</td><td>Ninguna</td></tr><tr><td>19</td><td>Bolívar</td><td>Guaranda</td><td>San Luis de Pambil</td><td>Varios sectores; María Aurora, Rosa Elvira - vía a las Comunidades de San Luis de Pambil.</td><td>COLAPSO ESTRUCTURAL</td><td>28</td><td>24/03/2023</td><td>Ninguna</td></tr><tr><td>20</td><td>Los Ríos</td><td>Babahoyo</td><td>La Unión</td><td>La Valdivia - río Clementina</td><td>INUNDACIÓN</td><td>30</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>21</td><td>Los Ríos</td><td>Montalvo</td><td>Montalvo</td><td>La Estrella - Cdla. Felipe Abud - río Cristal</td><td>SOCAVAMIENTO</td><td>800</td><td>08/03/2023</td><td>Ninguna</td></tr><tr><td>22</td><td>Tungurahua</td><td>Quero</td><td>Quero</td><td>San Antonio de Hipolonguito, vía Quero - San Antonio</td><td>SOCAVAMIENTO</td><td>30</td><td>26/06/2022</td><td>Ninguna</td></tr><tr><td>23</td><td>Pichincha</td><td>Quito</td><td>Conocoto</td><td>Monserrat, calles Juan Bautista Aguirre y Juan Hernando Dávila</td><td>SOCAVAMIENTO</td><td>--</td><td>12/06/2022</td><td>Ninguna</td></tr><tr><td>24</td><td>Pichincha</td><td>Mejía</td><td>Tambillo</td><td>Ushco, vía Tambillo - Panamericana Sur</td><td>INUNDACIÓN</td><td>20</td><td>10/04/2022</td><td>Ninguna</td></tr><tr><td>25</td><td>Pichincha</td><td>Mejía</td><td>Manuel Cornejo Astorga (Tandapi)</td><td>Vía de ingreso a las Comunidades Peñas Blancas, El Paraíso, El Mirador y San Francisco.</td><td>DESLIZAMIENTO</td><td>140</td><td>08/02/2022</td><td>Ninguna</td></tr><tr><td>26</td><td>Morona Santiago</td><td>Morona</td><td>Sinaí</td><td>Playas de San Luis, vía Santa María Tunants- Playas de San Luis-Quinta Cooperativa</td><td>INUNDACIÓN</td><td>3884</td><td>02/05/2021</td><td>Ninguna</td></tr><tr><td>27</td><td>Azuay</td><td>Cuenca</td><td>Nulti</td><td>Pasto Romero, vía al centro Parroquial</td><td>DESLIZAMIENTO</td><td>--</td><td>16/04/2021</td><td>Ninguna</td></tr><tr><td>28</td><td>Chimborazo</td><td>Chunchi</td><td>Chunchi, cabecera cantonal</td><td>Armenia</td><td>DESLIZAMIENTO</td><td>955.9</td><td>20/01/2021</td><td>Ninguna</td></tr></table>

## 14 vías de tercer orden parcialmente habilitadas.

<table><tr><td>No.</td><td>Provincia</td><td>Cantón</td><td>Parroquia</td><td>Sector/Vía</td><td>Evento Peligroso</td><td>Afectación (metros lineales)</td><td>Fecha del evento</td><td>Vías alternas</td></tr><tr><td>1</td><td>Esmeraldas</td><td>Esmeraldas</td><td>Carlos Concha</td><td>Recinto Huele</td><td>SOCAVAMIENTO</td><td>100</td><td>16/06/2023</td><td>Ninguna</td></tr><tr><td>2</td><td>Esmeraldas</td><td>Quinindé</td><td>La Unión</td><td>San Vicente de Mache, vía playa del Muerto.</td><td>SOCAVAMIENTO</td><td>--</td><td>13/06/2023</td><td>Ninguna</td></tr><tr><td>3</td><td>Esmeraldas</td><td>Eloy Alfaro</td><td>Borbón</td><td>vía San Pedro - Anchayacu</td><td>DESLIZAMIENTO</td><td>--</td><td>02/06/2023</td><td>Ninguna</td></tr><tr><td>4</td><td>Esmeraldas</td><td>Muisne</td><td>Galera</td><td>Estero de Plátano.</td><td>DESLIZAMIENTO</td><td>--</td><td>28/05/2023</td><td>Ninguna</td></tr><tr><td>5</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>Chilcaplaya</td><td>SOCAVAMIENTO</td><td>--</td><td>24/05/2023</td><td>Ninguna</td></tr><tr><td>6</td><td>Carchi</td><td>Tulcán</td><td>González Suárez</td><td>Ciudadela Padre Carlos de la Vega, calle Manuel Machado y Adolfo Becker.</td><td>DESLIZAMIENTO</td><td>20</td><td>16/05/2023</td><td>Ninguna</td></tr><tr><td>7</td><td>Esmeraldas</td><td>Quinindé</td><td>Malimpia</td><td>Valle del Sade</td><td>HUNDIMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>8</td><td>Esmeraldas</td><td>Quinindé</td><td>La Unión</td><td>El Tambo</td><td>HUNDIMIENTO</td><td>--</td><td>14/05/2023</td><td>Ninguna</td></tr><tr><td>9</td><td>Imbabura</td><td>Cotacachi</td><td>Peñaherrera</td><td>Villa flora</td><td>HUNDIMIENTO</td><td>30</td><td>05/05/2023</td><td>Ninguna</td></tr><tr><td>10</td><td>El Oro/Piñas</td><td>Moromoro</td><td>El Palto</td><td>Vía El Palto - La Libertad</td><td>SOCAVAMIENTO</td><td>8</td><td>04/05/2023</td><td>Ninguna</td></tr><tr><td>11</td><td>Cotopaxi</td><td>Pangua</td><td>Ramón Campaña La Estrella</td><td>Miligua, vía Ramón Campaña - El Corazón</td><td>DESLIZAMIENTO</td><td>50</td><td>12/03/2023</td><td>Ninguna</td></tr><tr><td>12</td><td>Azuay</td><td>Pucará</td><td>Pucará</td><td>km 16+500, Vía Minas-Tablón-Pucará</td><td>DESLIZAMIENTO</td><td>50</td><td>19/04/2022</td><td>Ninguna</td></tr><tr><td>13</td><td>Morona Santiago</td><td>Morona</td><td>Sevilla Don Bosco</td><td>Santa Rosa</td><td>INUNDACIÓN</td><td>30</td><td>21/06/2020</td><td>Ninguna</td></tr><tr><td>14</td><td>Morona Santiago</td><td>San Juan Bosco</td><td>Santiago de Pananza</td><td>Varios Sectores</td><td>DESLIZAMIENTO</td><td>860</td><td>02/04/2020</td><td>Ninguna</td></tr></table>

## Secretaría de Gestión de Riesgos

Dirección: CIS ECU 9-1-1, Av. Samborondón, Km 0,5 Código postal: 092302 / Samborondón-Ecuador
Teléfono: +593-4-259 3500
www.gestionderiesgos.gob.ec 

Reporte de monitoreo de amenazas y eventos peligrosos - No 0355
Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 22 de 23 

<table><tr><td colspan="2">Evento peligroso</td><td>Nivel de alerta</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/25cb8707e2bb4dbdeb4331aae8afc654fb044f01a1a85b78d25f2356b003ad1e.jpg"/></td><td>Declaratoria de ALERTA AMARILLA Movimientos en masa en La Vainilla y La Laguna Parroquia: Honorato Vásquez, Cantón: Santa Ana, Provincia: Manabí.</td><td>Amarilla</td><td>23/05/2023</td><td>Resolución No. SGR-169-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c7bcc6afbade27ee497c1c13b55b93ed0fd7faa3b68064752145e9de96a47a6c.jpg"/></td><td>Declaratoria de ALERTA AMARILLA Fenómeno El Niño: Oscilación del Sur (ENOS), en los territorios ubicados a una altitud igual y menor a 1500 msnm, que comprende 17 provincias, 143 cantones, y 489 parroquias</td><td>Amarilla</td><td>15/05/2023</td><td>Resolución No. SGR-156-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c7cdf2aad34fe542c5fc0236d16f2d6d550ccf8fe545107fafe89526ae099765.jpg"/></td><td>Declaratoria de Cambio de ALERTA AMARILLA por movimientos en masa al área de 11,50 hectáreas en el sector Astillero, de la parroquia Bahía de Caráquez, cantón Sucre, provincia de Manabí; considerando que las condiciones y parámetros indican que puede presentarse un evento que produzca afectaciones en la población e infraestructura.</td><td>Amarilla</td><td>10/04/2023</td><td>Resolución No. SGR-110-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/5188e932961968ae548198f445df47e264a0d46ffffcd88ad74e8322ab1c7386.jpg"/></td><td>Declaratoria de Cambio de ALERTA AMARILLA a NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa en las comunidades Aypug, Casual y los barrios: La Esperanza, Control Norte, Nueva Alausí, Pircapamba y Bua.</td><td>Naranja</td><td>10/04/2023</td><td>Resolución No. SGR-111-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/68938cf30b0c70a51cc7b8170f88e6a2f2112ea180a300efbbced04a55e1c7a9.jpg"/></td><td>Declaratoria del estado de ALERTA NARANJA por movimientos en masa al área de 152,22 hectáreas que comprende los sectores: Namza Chico, Pasán, Quebrada La Ninfa, UE Eloy Alfaro y Puente Chachán, de la parroquia Huigra, cantón Alausí, provincia de Chimborazo</td><td>Naranja</td><td>09/04/2023</td><td>Resolución No. SGR 106-023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/d481a4725e244e396b3f4e78614827b85853963aeea0a7951c74206c62dfe25d.jpg"/></td><td>Declaratoria del estado de ALERTA NARANJA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa el cual tiene un área de 442.62 hectáreas que se extiende sobre la comunidad La Cría - Cantón: Santa Isabel, Provincia: Azuay.</td><td>Naranja</td><td>06/04/2023</td><td>Resolución No. SGR-104-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/15907fc6c4e9bdac416115c5e5df9b69acffabe6d5e8890b2d2498c49953fde0.jpg"/></td><td>Declaratoria del estado de ALERTA NARANJA por movimientos en masa, el área de influencia equivalente a 53132.993 <eq>m^{2}</eq>, ubicada en la ciudadela El Fátima, parroquia Francisco Pacheco, del cantón Portoviejo, Provincia de Manabí, debido a que la materialización del evento peligroso por movimientos en masa es inminente, lo que afectaría a la población.</td><td>Naranja</td><td>03/04/2023</td><td>Resolución No. SGR-099-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/59c4a48e4361a227bc5f3e77f83efba61f937e6d41fd02b61b04d503b445944b.jpg"/></td><td>Declaratoria del estado de ALERTA AMARILLA por incremento de amenaza de movimientos en masa al polígono identificado como susceptible a movimientos en masa con un área de 330.56 hectáreas pertenecientes al sector Cuchucún, el cual comprende las comunidades: Quilloac, Cruz Loma y Cuchucún. Cantón: Cañar, Provincia: Cañar.</td><td>Amarilla</td><td>31/03/2023</td><td>Resolución No. SGR-091-2023</td></tr><tr><td><img src="https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/7df0061531ca93d6cf96c55271f0cd3b5ab06ed68ebbc4c54f29c2835237670a.jpg"/></td><td>Incremento Actividad Volcánica Cotopaxi</td><td>Amarilla</td><td>22/10/2022</td><td>Resolución No. SGR-0311-2022</td></tr></table>

## Secretaría de Gestión de Riesgos

## Reporte de monitoreo de amenazas y eventos peligrosos - No 0355 Fecha y Hora de actualización: martes, 27 de junio de 2023 - 10:12:56 / Página 23 de 23

![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/63da9f8930ec5ed1557df4f5e2a057a0a9628db5076bc84b9c17209f786bf4ed.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/87cd951ed1103750047cb7c5091ffee7c7e92b172b461fcd4eac887526db824d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/d36449c46575767dbe8dcd6d4ae27c21c5d0308b94604a683dba60e8b6ec8c2f.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/47c8847ade9184f6d08ed662e26203b78f990348c31495cecdc4fefe53d9ba3d.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/92c7ba316e5f378afdc1247c14fd8cf33c257c0020b5bc30625fee42181519a1.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/9b255aa94bcfbaabddd28cbafc63406cd65f4425826a80ca0b8c23746af134d3.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/e15bcb0059f3ba8d6aa78316869086a73e4311e26eaf9d9e6936a23ae9ebfb06.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/98ec0dcbca29e51ec47022f8c473bf338003a6592b90ea7a54de5d398b41e9e4.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/82573390ea4c4695b387fb5a58a1fbee982a15060958499da548d4aa290215de.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/b6df0a1caa44b9cbfcab935e541d297da7f07bbbadb94d2877d061206d52ecd7.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/df9f14fa1b2d6aa3ee0c09589b0f7378fbb5b1b6e91dbd7ba3d558054fa5e2e7.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/c44aee9806876339a44aa3d1a9b6fb27427852dc0fd2e0306f313f72f11195fe.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/0e20d59cfeba92722b573c7e51274b898f0266f40dab9e8c5b5cafe2c08aab2a.jpg)


![image](https://cdn-mineru.openxlab.org.cn/result/2026-08-15/cb520fc6-e3c7-4fa1-8b91-d03397f3bdd4/ca8c8409544cfb9f58e16768e8eff53106b7b8a522fbb166d729ee1ecd28f8a2.jpg)


<table><tr><td>Declaratoria del estado de ALERTA AMARILLA por deslizamiento en La Armenia, Chunchi, provincia de Chimborazo.</td><td>Amarilla</td><td>15/07/2022</td><td>Resolución No. SGR-182-2022</td></tr><tr><td>Movimiento en masa barrios Rosas, Bellavista, Tamboloma y Rosario de la parroquia Nabón, cantón Nabón, provincia de Azuay</td><td>Naranja</td><td>23/11/2021</td><td>Resolución No. SGR-171-2021</td></tr><tr><td>Socavamiento por la erosión del río Coca y sus afluentes –Cantón: El Chaco, Provincia: Napo.</td><td>Roja</td><td>21/05/2021</td><td>Resolución No. SGR-058-2021</td></tr><tr><td>Actividad Volcánica Sangay: Caída de ceniza Provincia de Chimborazo</td><td>Amarilla</td><td>16/06/2020</td><td>Resolución No. SGR-045-2020</td></tr><tr><td>Aumento de sedimentos volcánicos Río Upano- Parroquías Sinaí y Sevilla de Don Bosco, cantón Morona, Morona Santiago</td><td>Amarilla</td><td>05/12/2019</td><td>Resolución No. SGR-140-2019</td></tr><tr><td>Incremento de lluvias e inundaciones Guayas, El Oro, Sto. Domingo, Esmeraldas, Manabí y Los Ríos y Bolívar, cantón Chillanes, San José del Tambo.</td><td>Amarilla</td><td>16/07/2019</td><td>Resolución No. SGR-066-2019</td></tr><tr><td>Deslizamiento San José de Alluriquín, Santo Domingo de Los Tsáchilas</td><td>Amarilla</td><td>17/10/2018</td><td>Resolución No. SGR-006-2018</td></tr><tr><td>Deslizamiento Sector las Juanitas, Quinindé, Esmeraldas</td><td>Naranja</td><td>12/05/2016</td><td>Resolución No. SGR-060-2016</td></tr><tr><td>Sismo 7.8 Pedernales, Manabí</td><td>Roja</td><td>17/Abril/2016</td><td>Resolución No. SGR-048-2016</td></tr><tr><td>Incremento Actividad Volcánica del Chiles - Cerro Negro, Carchi</td><td>Amarilla</td><td>01/10/2014</td><td>Resolución No. SGR-049-2014</td></tr><tr><td>Deslizamiento San José de Atahualpa, El Oro</td><td>Naranja</td><td>08/05/2014</td><td>Resolución No. SGR-012-2014</td></tr><tr><td>Incremento Actividad Volcánica del Reventador, Napo</td><td>Naranja</td><td>27/03/2014</td><td>Resolución No. SGR-008-2014</td></tr><tr><td colspan="2">Declaratorias de Zonas de Riesgos</td><td>Fecha de vigencia</td><td>Documento</td></tr><tr><td colspan="2">Inundaciones Babahoyo, Los Ríos</td><td>11/12/2019</td><td>Resolución No. SGR-149-2019</td></tr><tr><td colspan="2">Hundimiento, Zaruma, El Oro</td><td>07/03/2017</td><td>Resolución No. SzIGR-029-2015</td></tr></table>